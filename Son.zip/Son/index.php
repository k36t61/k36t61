<?php
if (!defined('IMAGETYPE_WEBP')) define('IMAGETYPE_WEBP', 18);
if (!defined('CURLOPT_RESOLVE')) define('CURLOPT_RESOLVE', 10203);
if (!function_exists('random_bytes')) {
    function random_bytes($length) {
        $length = (int)$length; if ($length < 1) $length = 1;
        $any = false;
        if (function_exists('openssl_random_pseudo_bytes')) {
            $strong = false; $b = openssl_random_pseudo_bytes($length, $strong);
            if ($b !== false && strlen($b) === $length) { if ($strong) return $b; $any = $b; }
        }
        if (@is_readable('/dev/urandom')) {
            $fp = @fopen('/dev/urandom', 'rb');
            if ($fp) { $b = fread($fp, $length); fclose($fp); if ($b !== false && strlen($b) === $length) return $b; }
        }
        if ($any !== false) return $any;
        $b = ''; for ($i = 0; $i < $length; $i++) $b .= chr(mt_rand(0, 255));
        return $b;
    }
}
if (!function_exists('mb_strlen')) {
    function mb_strlen($s, $enc = null) { $n = preg_match_all('/./su', (string)$s, $m); return $n === false ? strlen((string)$s) : $n; }
}
if (!function_exists('mb_substr')) {
    function mb_substr($s, $start, $len = null, $enc = null) {
        $a = preg_split('//u', (string)$s, -1, PREG_SPLIT_NO_EMPTY);
        if ($a === false) return (string)substr((string)$s, $start, $len === null ? strlen((string)$s) : $len);
        return implode('', $len === null ? array_slice($a, $start) : array_slice($a, $start, $len));
    }
}
function x_cmp($a, $b) { return $a < $b ? -1 : ($a > $b ? 1 : 0); }
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');
header_remove('X-Powered-By');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: frame-ancestors 'self'; base-uri 'self'; object-src 'none'; form-action 'self'");
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');

define('X_SESSION_IDLE', 86400);
ini_set('session.gc_maxlifetime', (string)X_SESSION_IDLE);
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_set_cookie_params(array('lifetime'=>0,'path'=>'/','secure'=>(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off'),'httponly'=>true,'samesite'=>'Lax'));
session_start();
if (isset($_SESSION['x_last_act']) && (time() - (int)$_SESSION['x_last_act']) > X_SESSION_IDLE) {
    $_SESSION = array(); session_destroy(); session_start(); session_regenerate_id(true);
}
$GLOBALS['x_prev_act'] = isset($_SESSION['x_last_act']) ? (int)$_SESSION['x_last_act'] : 0;
$_SESSION['x_last_act'] = time();
if (empty($_SESSION['x_csrf']) || !is_string($_SESSION['x_csrf'])) $_SESSION['x_csrf'] = bin2hex(random_bytes(32));
$GLOBALS['x_csrf_tok'] = $_SESSION['x_csrf'];
function x_csrf_ok() {
    $t = '';
    if (isset($_SERVER['HTTP_X_CSRF_TOKEN']) && is_string($_SERVER['HTTP_X_CSRF_TOKEN'])) $t = $_SERVER['HTTP_X_CSRF_TOKEN'];
    elseif (isset($_POST['_csrf']) && is_string($_POST['_csrf'])) $t = $_POST['_csrf'];
    elseif (isset($_GET['_t']) && is_string($_GET['_t'])) $t = $_GET['_t'];
    return $t !== '' && hash_equals($GLOBALS['x_csrf_tok'], $t);
}
function x_csrf_rewrite($b) {
    if (empty($GLOBALS['x_csrf_on']) || $b === '' || strlen($b) > 12582912) return $b;
    foreach (headers_list() as $h) if (stripos($h, 'content-type:') === 0 && stripos($h, 'text/html') === false) return $b;
    $t = $GLOBALS['x_csrf_tok'];
    $b = preg_replace('~(?<=[?&;])action=(tab_delete|cat_delete|delete|pin|github_delete|github_pin|note_pin|note_delete|img_remove|note_remove_image|remove_screenshot|github_remove_image|nfile_remove|vid_remove|vid_main|img_main)(?![A-Za-z0-9_])~', 'action=$1&_t='.$t, $b);
    $js = '<script>(function(){var T="'.$t.'";function add(f){try{if(f.method&&f.method.toLowerCase()==="post"&&!f.querySelector("input[name=_csrf]")){var i=document.createElement("input");i.type="hidden";i.name="_csrf";i.value=T;f.appendChild(i)}}catch(e){}}document.addEventListener("submit",function(e){add(e.target)},true);var fs=HTMLFormElement.prototype.submit;HTMLFormElement.prototype.submit=function(){add(this);return fs.call(this)};var of=window.fetch;if(of){window.fetch=function(u,o){o=o||{};var m=String(o.method||(u&&u.method)||"GET").toUpperCase();if(m!=="GET"&&m!=="HEAD"){var h=new Headers(o.headers||(u&&u.headers)||{});h.set("X-CSRF-Token",T);o.headers=h}return of.call(this,u,o)}}var oo=XMLHttpRequest.prototype.open,os=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m){this.__m=String(m).toUpperCase();return oo.apply(this,arguments)};XMLHttpRequest.prototype.send=function(){if(this.__m&&this.__m!=="GET"&&this.__m!=="HEAD"){try{this.setRequestHeader("X-CSRF-Token",T)}catch(e){}}return os.apply(this,arguments)}})();</script>';
    if (preg_match('~<head[^>]*>~i', $b)) return preg_replace('~<head[^>]*>~i', '$0'.$js, $b, 1);
    return $js.$b;
}
ob_start('x_csrf_rewrite');

define('DATA_FILE', __DIR__ . '/xfile_data.php');
define('DATA_FILE_OLD', __DIR__ . '/xfile_data.json');
define('LOGIN_FILE', __DIR__ . '/xfile_login.php');
define('X_GUARD', "<?php exit; ?>\n");
define('FILES_DIR', __DIR__ . '/dosyalar');
define('THUMBS_DIR', FILES_DIR . '/thumb');
define('SCREENSHOTS_DIR', FILES_DIR . '/ekran');
define('VIDEOS_DIR', FILES_DIR . '/video');
define('BFILES_DIR', FILES_DIR . '/bilgi');
define('HTACCESS_FILE', FILES_DIR . '/.htaccess');
define('APP_NAME', 'Exlonea');
define('PASS_HASH_ADMIN', '$2y$10$cJBa3X9StdaZ5MCSAjG/eOs74oVaNgjyh.XsSn5rDn4V327bP5Yfm');
define('PASS_HASH_VISITOR', '$2y$10$VgcVM8CwfMnwmm/eCwOj9uI1EeukuG2lmhXb.ljIrul.f/h.TOq.W');
define('EDITOR_DIR', FILES_DIR . '/editor');
define('APPR_DIR', FILES_DIR . '/onay');
define('TRASH_DIR', FILES_DIR . '/cop');
define('SITE_DIR', FILES_DIR . '/site');
define('ACCOUNTS_FILE', __DIR__ . '/xfile_accounts.php');

function x_init() {
    if (!is_dir(FILES_DIR)) mkdir(FILES_DIR, 0755, true);
    if (!is_dir(SCREENSHOTS_DIR)) mkdir(SCREENSHOTS_DIR, 0755, true);
    if (!is_dir(THUMBS_DIR)) mkdir(THUMBS_DIR, 0755, true);
    if (!is_dir(VIDEOS_DIR)) mkdir(VIDEOS_DIR, 0755, true);
    if (!is_dir(BFILES_DIR)) mkdir(BFILES_DIR, 0755, true);
    if (!is_dir(EDITOR_DIR)) mkdir(EDITOR_DIR, 0755, true);
    if (!file_exists(HTACCESS_FILE) || strpos((string)@file_get_contents(HTACCESS_FILE), 'Require all denied') === false || strpos((string)@file_get_contents(HTACCESS_FILE), 'engine off') === false) {
        $h = "Options -Indexes\n<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n";
        $h .= "AddType text/plain .php .php2 .php3 .php4 .php5 .php6 .php7 .php8 .phtml .pht .phar .shtml .cgi .pl .py .asp .aspx .jsp\n";
        $h .= "<FilesMatch \"\.(?i:php|php[0-9]?|phtml|pht|phar|shtml)\$\">\n    SetHandler default-handler\n</FilesMatch>\n";
        $h .= "<IfModule mod_php.c>\n    php_flag engine off\n</IfModule>\n<IfModule mod_php7.c>\n    php_flag engine off\n</IfModule>\n<IfModule mod_php5.c>\n    php_flag engine off\n</IfModule>\n";
        $h .= "<IfModule mod_headers.c>\n    Header set X-Content-Type-Options nosniff\n</IfModule>\n";
        file_put_contents(HTACCESS_FILE, $h);
    }
    foreach (array(FILES_DIR, SCREENSHOTS_DIR, THUMBS_DIR, VIDEOS_DIR, BFILES_DIR, EDITOR_DIR) as $xd) if (!file_exists($xd.'/index.html')) @file_put_contents($xd.'/index.html', '');
    if (!file_exists(DATA_FILE) && file_exists(DATA_FILE_OLD)) {
        $o = @file_get_contents(DATA_FILE_OLD);
        if ($o !== false && is_array(json_decode($o, true)) && @file_put_contents(DATA_FILE, X_GUARD.$o, LOCK_EX) !== false) { if (!@unlink(DATA_FILE_OLD)) @file_put_contents(DATA_FILE_OLD, '{}'); }
    }
    if (!file_exists(DATA_FILE)) {
        $default = [
            'categories' => [],
            'dosya' => [],
'notes' => [],
            'github' => [],

        ];
        file_put_contents(DATA_FILE, X_GUARD.json_encode($default, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
}

function x_sort_cmp($a,$b) {
    $ap=!empty($a['pinned']); $bp=!empty($b['pinned']);
    if ($ap !== $bp) return $ap ? -1 : 1;
    $ao=isset($a['sort_order']); $bo=isset($b['sort_order']);
    if ($ao && $bo) { if ($a['sort_order'] != $b['sort_order']) return x_cmp($a['sort_order'], $b['sort_order']); }
    elseif ($ao !== $bo) return $ao ? 1 : -1;
    if ($ap && $bp) {
        $aT=strtotime((isset($a['pinned_at']) ? $a['pinned_at'] : (isset($a['pin_date']) ? $a['pin_date'] : (isset($a['updated_at']) ? $a['updated_at'] : (isset($a['date_added']) ? $a['date_added'] : '0')))));
        $bT=strtotime((isset($b['pinned_at']) ? $b['pinned_at'] : (isset($b['pin_date']) ? $b['pin_date'] : (isset($b['updated_at']) ? $b['updated_at'] : (isset($b['date_added']) ? $b['date_added'] : '0')))));
        if ($aT !== $bT) return x_cmp($bT, $aT);
    }
    return x_cmp(strtotime((isset($b['date_added']) ? $b['date_added'] : '0')), strtotime((isset($a['date_added']) ? $a['date_added'] : '0')));
}
function x_raw_data() { $r = @file_get_contents(DATA_FILE); if ($r === false) return false; if (strncmp($r, X_GUARD, strlen(X_GUARD)) === 0) $r = substr($r, strlen(X_GUARD)); return $r; }
function x_data() { return json_decode((string)x_raw_data(), true); }
function x_utf8_fix($v) {
    if (is_array($v)) { foreach ($v as $k=>$x) $v[$k] = x_utf8_fix($x); return $v; }
    if (is_string($v) && !preg_match('//u', $v)) {
        if (function_exists('mb_convert_encoding')) return mb_convert_encoding($v, 'UTF-8', 'UTF-8');
        if (function_exists('iconv')) { $r = @iconv('UTF-8', 'UTF-8//IGNORE', $v); if ($r !== false) return $r; }
    }
    return $v;
}
function x_save_fail() {
    $rt = isset($GLOBALS['route']) ? $GLOBALS['route'] : '';
    if (x_admin() && $rt !== 'analytics_event' && !headers_sent()) { header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=save_failed'); exit; }
}
function x_save($d) {
    if (!empty($GLOBALS['x_media_hook'])) { $mh = $GLOBALS['x_media_hook']; $GLOBALS['x_media_hook'] = null; x_hist_media($d, $mh); }
    $fl = JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE;
    $j = json_encode($d, $fl);
    if ($j === false) $j = json_encode(x_utf8_fix($d), $fl);
    if ($j === false) { x_save_fail(); return false; }
    if (!x_write_verified(DATA_FILE, X_GUARD.$j)) { x_save_fail(); return false; }
    return true;
}
function x_write_verified($path, $data) {
    $len = strlen($data);
    $old = file_exists($path) ? @file_get_contents($path) : false;
    $same = function($p, $d) { clearstatcache(true, $p); $r = @file_get_contents($p); return $r !== false && $r === $d; };
    if (file_exists($path) && ($h = @fopen($path, 'r+b'))) {
        $ok = false;
        if (@flock($h, LOCK_EX)) {
            if (@ftruncate($h, 0)) { @rewind($h); $n = @fwrite($h, $data); @fflush($h); $ok = ($n === $len); }
            @flock($h, LOCK_UN);
        } else {
            if (@ftruncate($h, 0)) { @rewind($h); $n = @fwrite($h, $data); @fflush($h); $ok = ($n === $len); }
        }
        @fclose($h);
        if ($ok && $same($path, $data)) return true;
    }
    $tmp = $path.'.tmp'.bin2hex(random_bytes(4));
    if ($h = @fopen($tmp, 'wb')) {
        $n = @fwrite($h, $data); @fflush($h); @fclose($h);
        if ($n === $len && @rename($tmp, $path) && $same($path, $data)) return true;
        @unlink($tmp);
    }
    @file_put_contents($path, $data);
    if ($same($path, $data)) return true;
    if ($old !== false && ($h = @fopen($path, 'wb'))) { @fwrite($h, $old); @fclose($h); }
    return false;
}
function x_saved_has($type,$id) {
    $raw = x_raw_data(); if ($raw === false) return false;
    $d = json_decode($raw, true); if (!is_array($d) || !isset($d[$type]) || !is_array($d[$type])) return false;
    foreach ($d[$type] as $it) if (is_array($it) && isset($it['id']) && (string)$it['id'] === (string)$id) return true;
    return false;
}
function x_admin_role() { return isset($_SESSION['role']) && $_SESSION['role']==='admin'; }
function x_admin() { if (!isset($_SESSION['role'])) return false; if ($_SESSION['role']==='admin') return true; return ($_SESSION['role']==='visitor' || $_SESSION['role']==='editor') && x_vis_priv(); }
function x_vis_priv() { static $v = null; if ($v === null) { $v = false; $me = x_acc_self(); if ($me) $v = count(x_acc_perms($me)) > 0; } return $v; }
function x_perm($k) {
    if (!isset($_SESSION['role'])) return false;
    if (x_super()) return true;
    static $c = null;
    if ($c === null) { $c = array(); $me = x_acc_self(); if ($me) foreach (x_acc_perms($me) as $p) $c[$p] = true; }
    return !empty($c[$k]);
}
function x_logged() { return isset($_SESSION['role']); }
function x_tab_defaults() { return array('dosya'=>array('label'=>'Dosya Arşivi','enabled'=>true),'github'=>array('label'=>'GitHub','enabled'=>true),'notes'=>array('label'=>'Bilgiler','enabled'=>true)); }
function x_tabs_build($data) {
    $t = x_tab_defaults();
    $st = (isset($data['settings']['tabs']) && is_array($data['settings']['tabs'])) ? $data['settings']['tabs'] : array();
    foreach ($t as $k=>$d) {
        if (isset($st[$k]['label']) && is_string($st[$k]['label']) && trim($st[$k]['label'])!=='') $t[$k]['label'] = mb_substr(trim($st[$k]['label']),0,30);
        if (isset($st[$k]['enabled'])) $t[$k]['enabled'] = (bool)$st[$k]['enabled'];
    }
    $any = false; foreach ($t as $x) if ($x['enabled']) $any = true;
    if (!$any) $t['notes']['enabled'] = true;
    return $t;
}
function x_tab_roles() { return array('visitor'=>'Ziyaretçi hesabı','editor'=>'Editör','admin'=>'Yönetici','guest'=>'Giriş yapmamış'); }
function x_me_role() { if (x_super()) return 'super'; if (!x_logged()) return 'guest'; $r = (string)$_SESSION['role']; return in_array($r, array('admin','editor','visitor'), true) ? $r : 'guest'; }
function x_tab_vis($src) {
    $sh = array(); if (is_array($src) && isset($src['show']) && is_array($src['show'])) foreach ($src['show'] as $r) if (is_string($r) && isset(x_tab_roles()[$r])) $sh[] = $r;
    return array('hide'=>(is_array($src) && !empty($src['hide'])), 'show'=>array_values(array_unique($sh)));
}
function x_tab_hidden_me($e) { if (empty($e['hide']) || x_super()) return false; $sh = (isset($e['show']) && is_array($e['show'])) ? $e['show'] : array(); return !in_array(x_me_role(), $sh, true); }
function x_tab_on($k) { return !empty($GLOBALS['x_tabs'][$k]['enabled']); }
function x_tab_label($k) { return isset($GLOBALS['x_tabs'][$k]['label']) ? $GLOBALS['x_tabs'][$k]['label'] : $k; }
function x_tab_first() { foreach ($GLOBALS['x_tabs'] as $k=>$t) if ($t['enabled']) return $k; return 'notes'; }

function x_types() { return array('dosya','github','notes'); }
function x_type_label($t) { if ($t==='home') return 'Ana Sayfa'; $d = x_tab_defaults(); return isset($d[$t]) ? $d[$t]['label'] : $t; }
function x_home_title() { $k = x_ws_cur('home'); return isset($GLOBALS['x_all_tabs'][$k]['label']) ? $GLOBALS['x_all_tabs'][$k]['label'] : 'Ana Sayfa'; }
function x_all_tabs_build($data) {
    $out = array();
    $st = (isset($data['settings']['tabs']) && is_array($data['settings']['tabs'])) ? $data['settings']['tabs'] : array();
    foreach (x_tab_defaults() as $k=>$d) {
        if (!empty($data['settings']['deleted_tabs'][$k])) continue;
        $lbl = $d['label']; $en = true;
        if (isset($st[$k]['label']) && is_string($st[$k]['label']) && trim($st[$k]['label'])!=='') $lbl = mb_substr(trim($st[$k]['label']),0,30);
        if (isset($st[$k]['enabled'])) $en = (bool)$st[$k]['enabled'];
        $ic = (isset($st[$k]['icon']) && is_string($st[$k]['icon'])) ? $st[$k]['icon'] : ''; if ($ic!=='none' && !x_icon_ok($ic)) $ic = '';
        $out[$k] = array('key'=>$k,'type'=>$k,'label'=>$lbl,'enabled'=>$en,'base'=>true,'icon'=>$ic);
    }
    $ct = (isset($data['settings']['custom_tabs']) && is_array($data['settings']['custom_tabs'])) ? $data['settings']['custom_tabs'] : array();
    foreach ($ct as $k=>$c) {
        if (!is_string($k) || !preg_match('/^ws_[a-f0-9]{8}$/',$k) || !is_array($c) || !isset($c['type']) || !in_array($c['type'],array_merge(x_types(),array('home')),true)) continue;
        $lbl = (isset($c['label']) && is_string($c['label']) && trim($c['label'])!=='') ? mb_substr(trim($c['label']),0,30) : x_type_label($c['type']);
        $out[$k] = array('key'=>$k,'type'=>$c['type'],'label'=>$lbl,'enabled'=>(!isset($c['enabled']) || (bool)$c['enabled']),'base'=>false,'content'=>((isset($c['content']) && is_string($c['content'])) ? $c['content'] : ''),'icon'=>((isset($c['icon']) && is_string($c['icon']) && ($c['icon']==='none' || x_icon_ok($c['icon']))) ? $c['icon'] : ''));
    }
    foreach ($out as $k=>$e) { $src = $e['base'] ? (isset($st[$k]) ? $st[$k] : array()) : (isset($ct[$k]) ? $ct[$k] : array()); $out[$k] += x_tab_vis($src); }
    $ord = (isset($data['settings']['tab_order']) && is_array($data['settings']['tab_order'])) ? $data['settings']['tab_order'] : array();
    if ($ord) { $sorted = array(); foreach ($ord as $ok) if (is_string($ok) && isset($out[$ok]) && !isset($sorted[$ok])) $sorted[$ok] = $out[$ok]; foreach ($out as $k=>$e) if (!isset($sorted[$k])) $sorted[$k] = $e; $out = $sorted; }
    $any = false; foreach ($out as $x) if ($x['enabled']) $any = true;
    if (!$any) {
        if (!$out) $out['notes'] = array('key'=>'notes','type'=>'notes','label'=>x_type_label('notes'),'enabled'=>true,'base'=>true,'icon'=>'');
        elseif (isset($out['notes'])) $out['notes']['enabled'] = true;
        else { reset($out); $fk = key($out); $out[$fk]['enabled'] = true; }
    }
    return $out;
}
function x_ws_field($t) { $k = x_ws_cur($t); return '<input type="hidden" name="ws" value="'.x_h($k!=='' ? $k : 'base').'">'; }
function x_ws_cur($t) { return (isset($GLOBALS['x_ws'][$t]) && is_string($GLOBALS['x_ws'][$t])) ? $GLOBALS['x_ws'][$t] : ''; }
function x_ws_init() {
    $all = $GLOBALS['x_all_tabs']; $cur = array('dosya'=>'','github'=>'','notes'=>'','home'=>'');
    foreach ($cur as $t=>$_u) {
        if (isset($_SESSION['x_ws'][$t]) && is_string($_SESSION['x_ws'][$t])) {
            $w = $_SESSION['x_ws'][$t];
            if (isset($all[$w]) && empty($all[$w]['base']) && $all[$w]['type']===$t) $cur[$t] = $w;
        }
    }
    $wp = isset($_GET['ws']) ? $_GET['ws'] : (isset($_POST['ws']) ? $_POST['ws'] : null);
    if (is_string($wp)) {
        $w = $wp;
        if ($w==='base') { $tp = isset($_GET['tab']) ? $_GET['tab'] : (isset($_POST['tab']) ? $_POST['tab'] : null); if (is_string($tp) && isset($cur[$tp])) $cur[$tp] = ''; }
        elseif (isset($all[$w]) && empty($all[$w]['base'])) $cur[$all[$w]['type']] = $w;
    }
    $_SESSION['x_ws'] = $cur;
    return $cur;
}
function x_tabs_active($all,$cur) {
    $o = array();
    foreach (x_types() as $t) { $k = (isset($cur[$t]) && $cur[$t]!=='' && isset($all[$cur[$t]])) ? $cur[$t] : $t; $o[$t] = isset($all[$k]) ? array('label'=>$all[$k]['label'],'enabled'=>$all[$k]['enabled']) : array('label'=>x_type_label($t),'enabled'=>false); }
    return $o;
}
function x_item_ws($it) { return (is_array($it) && isset($it['ws']) && is_string($it['ws'])) ? $it['ws'] : ''; }
function x_item_tabkey($c,$it) { $w = x_item_ws($it); if ($w!=='' && isset($GLOBALS['x_all_tabs'][$w]) && $GLOBALS['x_all_tabs'][$w]['type']===$c) return $w; return $c; }
function x_item_on($c,$it) { $k = x_item_tabkey($c,$it); return !empty($GLOBALS['x_all_tabs'][$k]['enabled']); }
function x_type_any_on($t) { foreach ($GLOBALS['x_all_tabs'] as $e) if ($e['type']===$t && $e['enabled']) return true; return false; }
function x_first_entry() { foreach ($GLOBALS['x_all_tabs'] as $e) if ($e['enabled']) return $e; $fa = $GLOBALS['x_all_tabs']; return reset($fa); }
function x_entry_href($e) { return '?tab='.$e['type'].'&ws='.($e['base'] ? 'base' : $e['key']); }
function x_stamp_ws(&$arr,$t) { $w = x_ws_cur($t); if ($w!=='' && $arr) { end($arr); $k = key($arr); if ($k!==null) $arr[$k]['ws'] = $w; } }
function x_view_items($items,$c,$tab,$xcur) { if ($tab==='all') return $items; $o = array(); foreach ($items as $it) if (x_item_tabkey($c,$it)===$xcur[$c]) $o[] = $it; return $o; }
function x_list_has_tab($list,$c,$k) { foreach ($list as $it) if (x_item_tabkey($c,$it)===$k) return true; return false; }
function x_icon_names() { return array('home','folder','file','book','bookmark','clipboard','code','link','globe','star','heart','bell','user','mail','music','video','image','camera','gift','key','map-pin','zap','grid','tag','info','shield','calendar','cog','pin','briefcase','eye','lock'); }
function x_icon_ok($n) { return is_string($n) && in_array($n, x_icon_names(), true); }
function x_entry_icon($e,$where) {
    $i = (isset($e['icon']) && is_string($e['icon'])) ? $e['icon'] : '';
    if ($i==='none') return '';
    if ($i!=='' && x_icon_ok($i)) return $i;
    $t = $e['type'];
    if ($t==='home') return 'home';
    if ($t==='dosya') return 'folder';
    if ($t==='github') return $where==='top' ? 'link' : 'code';
    return 'book';
}
function x_tab_purge(&$data,$dk) {
    if (!isset($GLOBALS['x_all_tabs'][$dk])) return false;
    $dt = $GLOBALS['x_all_tabs'][$dk]['type']; $removed = array();
    if ($dt==='home') {
        $removed[] = array('content'=>$GLOBALS['x_all_tabs'][$dk]['content']);
    } else {
        foreach ($data[$dt] as $it) if (x_item_tabkey($dt,$it)===$dk) {
            $removed[] = $it;
            if ($dt==='dosya') { $bf = FILES_DIR.'/'.basename((string)(isset($it['stored_name']) ? $it['stored_name'] : '')); if (is_file($bf)) x_rm($bf); x_pack_unlink($it); x_delete_all_images($it,'screenshot'); }
            else { x_delete_all_images($it,'image'); }
            x_delete_all_videos($it); x_delete_note_files($it);
        }
        $data[$dt] = array_values(array_filter($data[$dt], function($it) use ($dt,$dk) { return x_item_tabkey($dt,$it)!==$dk; }));
    }
    if (!empty($GLOBALS['x_all_tabs'][$dk]['base'])) {
        if (!isset($data['settings']['deleted_tabs']) || !is_array($data['settings']['deleted_tabs'])) $data['settings']['deleted_tabs'] = array();
        $data['settings']['deleted_tabs'][$dk] = true;
        unset($data['settings']['tabs'][$dk]);
    } else { unset($data['settings']['custom_tabs'][$dk]); }
    x_purge_extras($data,$removed);
    if (isset($_SESSION['x_ws'][$dt]) && $_SESSION['x_ws'][$dt]===$dk) $_SESSION['x_ws'][$dt] = '';
    return true;
}
function x_fmt_size($b) { $b=(float)$b; if ($b>=1073741824) return round($b/1073741824,2).' GB'; if ($b>=1048576) return round($b/1048576,1).' MB'; return max(1,round($b/1024)).' KB'; }
function x_item_files($item) {
    $l = array();
    if (!empty($item['files']) && is_array($item['files'])) foreach ($item['files'] as $f) if (is_array($f) && isset($f['name'],$f['stored_name'])) $l[] = $f;
    return $l;
}
function x_danger_exts() { return array('php','php2','php3','php4','php5','php6','php7','php8','phtml','pht','phar','shtml','cgi','pl','py','asp','aspx','jsp','htaccess','html','htm','xhtml','svg','js','mjs','sh','phps','phpt','inc','pgif','shtm','stm','xml','xsl','xslt','mht','mhtml','swf','htc','jspx','cfm','cfc','asa','asax','ashx','asmx','cer','cdx','war','jar','conf','ini','user'); }
function x_store_ext($ext) {
    $e = strtolower((string)$ext);
    if (!preg_match('/^[a-z0-9]{1,10}$/', $e) || in_array($e, x_danger_exts(), true)) return 'bin';
    return $e;
}
function x_dl_ext($name, $fallback = 'txt') {
    $e = (string)substr(preg_replace('/[^A-Za-z0-9]/', '', pathinfo((string)$name, PATHINFO_EXTENSION)), 0, 10);
    return $e !== '' ? $e : $fallback;
}
function x_ext_opts() { return array('bin','txt','php','png','jpg'); }
function x_dl_pick($name) { $v = (isset($_POST['dl_ext']) && is_string($_POST['dl_ext'])) ? $_POST['dl_ext'] : ''; return in_array($v, x_ext_opts(), true) ? $v : x_dl_ext($name); }
function x_php_ext_ok() { return x_super() || x_perm('php_ext'); }
function x_st_post() { $v = (isset($_POST['st_ext']) && is_string($_POST['st_ext'])) ? $_POST['st_ext'] : ''; $ok = array('bin','txt','png','jpg'); if (x_php_ext_ok()) $ok[] = 'php'; return in_array($v, $ok, true) ? $v : ''; }
function x_st_pick($ext) { $v = x_st_post(); return $v!=='' ? $v : x_store_ext($ext); }
function x_nf_opts() {
    $st = '<option value="">Otomatik (tehlikeli uzantılar .bin olur)</option>'; $dl = '<option value="">Orijinal uzantı</option>';
    foreach (x_ext_opts() as $e) { $st .= '<option value="'.$e.'"'.($e==='php' && !x_php_ext_ok() ? ' disabled' : '').'>.'.$e.' olarak kaydedilsin'.($e==='php' ? (x_php_ext_ok() ? ' (dikkat)' : ' (yalnızca Süper Admin)') : '').'</option>'; $dl .= '<option value="'.$e.'">.'.$e.' olarak indirilsin</option>'; }
    return '<div class="nf-opts" style="display:flex;gap:10px;flex-wrap:wrap;margin-top:8px"><div style="flex:1;min-width:180px"><label style="font-size:11px">Yeni dosyalar: sunucuya kayıt biçimi</label><select name="nf_st">'.$st.'</select></div><div style="flex:1;min-width:180px"><label style="font-size:11px">Yeni dosyalar: indirme biçimi</label><select name="nf_dl">'.$dl.'</select></div></div>';
}
function x_gh_col($list) { static $c = array(); $k = md5(json_encode(array_column((array)$list, 'id'))); if (isset($c[$k])) return $c[$k]; $r = x_admin(); if (!$r) foreach ((array)$list as $g) if (x_gh_flag($g,'gh_link',true)) { $r = true; break; } return $c[$k] = $r; }
function x_gh_flag($g, $k, $def) { return (is_array($g) && array_key_exists($k, $g)) ? !empty($g[$k]) : $def; }
function x_gh_post(&$g) {
    $g['gh_link'] = isset($_POST['gh_link']); $g['gh_copy'] = isset($_POST['gh_copy']); $g['gh_dl'] = isset($_POST['gh_dl']);
    $v = (isset($_POST['gh_dl_ext']) && is_string($_POST['gh_dl_ext'])) ? $_POST['gh_dl_ext'] : '';
    $g['gh_dl_ext'] = in_array($v, x_ext_opts(), true) ? $v : '';
}
function x_gh_toggles($g) {
    $row = function($n, $on, $t) { return '<div class="toggle-row"><label class="sw"><input type="checkbox" name="'.$n.'" value="1"'.($on ? ' checked' : '').'><span class="sl"></span></label><span class="swl">'.$t.'</span></div>'; };
    $cur = (is_array($g) && !empty($g['gh_dl_ext'])) ? $g['gh_dl_ext'] : '';
    $h = '<div class="fg">'.$row('gh_link', x_gh_flag($g,'gh_link',true), 'Link görünsün (aktif / pasif)').$row('gh_copy', x_gh_flag($g,'gh_copy',true), 'Kopyalama aktif').$row('gh_dl', x_gh_flag($g,'gh_dl',false), 'İndirme aktif');
    $h .= '<label style="font-size:11px;margin-top:6px">GitHub indirme biçimi</label><select name="gh_dl_ext"><option value="">Orijinal uzantı</option>';
    foreach (x_ext_opts() as $e) $h .= '<option value="'.$e.'"'.($cur===$e ? ' selected' : '').'>.'.$e.' olarak indirilsin</option>';
    return $h.'</select><div class="muted" style="font-size:11px;margin-top:4px">Yönetici hesapları her zaman hepsini görür; kapalı olanlar ziyaretçilerden gizlenir.</div></div>';
}
function x_st_select($cur, $edit) {
    $c = strtolower((string)pathinfo((string)$cur, PATHINFO_EXTENSION)); $h = '<div class="fg"><label>Sunucuya kayıt biçimi</label><select name="st_ext"><option value="">'.($edit ? 'Mevcut kalsın' : 'Otomatik (tehlikeli uzantılar .bin olur)').'</option>';
    foreach (x_ext_opts() as $o) $h .= '<option value="'.$o.'"'.(($edit && $c===$o) || ($o==='php' && !x_php_ext_ok()) ? ' disabled' : '').'>.'.$o.' olarak kaydedilsin'.($o==='php' ? (x_php_ext_ok() ? ' (dikkat)' : ' (yalnızca Süper Admin)') : '').'</option>';
    return $h.'</select></div>';
}
function x_dl_select($cur) {
    $c = strtolower((string)substr(preg_replace('/[^A-Za-z0-9]/', '', pathinfo((string)$cur, PATHINFO_EXTENSION)), 0, 10)); $h = '<div class="fg"><label>İndirme biçimi</label><select name="dl_ext"><option value="">Orijinal uzantı</option>';
    foreach (x_ext_opts() as $o) $h .= '<option value="'.$o.'"'.($c===$o ? ' selected' : '').'>.'.$o.' olarak indirilsin</option>';
    return $h.'</select></div>';
}
function x_dl_name($name, $fallback = 'txt') { return ('sh_'.bin2hex(random_bytes(12))).'.'.x_dl_ext($name, $fallback); }
function x_clean_fname($s) {
    $s = preg_replace('/[\x00-\x1F\x7F\\\\\/]+/u', '', (string)$s);
    if (!is_string($s)) return '';
    return mb_substr(trim($s), 0, 120);
}
function x_migrate_bin(&$data) {
    $changed = false;
    if (empty($data['dosya']) || !is_array($data['dosya'])) return false;
    foreach ($data['dosya'] as &$sx) {
        if (!empty($sx['download_name']) || empty($sx['stored_name'])) continue;
        $old = basename($sx['stored_name']); $ext = pathinfo($old, PATHINFO_EXTENSION);
        if (strtolower($ext) === 'bin' || x_store_ext($ext) !== 'bin') continue;
        $new = preg_replace('/\.[^.]*$/', '', $old).'.bin';
        $from = FILES_DIR.'/'.$old; $to = FILES_DIR.'/'.$new;
        if (is_file($from) && !file_exists($to) && @rename($from, $to)) { $sx['download_name'] = $old; $sx['stored_name'] = $new; $changed = true; }
    }
    unset($sx);
    return $changed;
}
function x_save_note_files($key='nfile', $names=array(), $descs=array(), $pins=array()) {
    $out = array();
    if (!isset($_FILES[$key]) || !is_array($_FILES[$key]['name'])) return $out;
    $f = $_FILES[$key];
    foreach ($f['name'] as $i=>$nm) {
        if ($f['error'][$i]!==UPLOAD_ERR_OK || !x_is_up($f['tmp_name'][$i])) continue;
        $orig = x_clean_fname(basename((string)$nm));
        if ($orig === '') $orig = 'dosya';
        $disp = (is_array($names) && isset($names[$i]) && is_string($names[$i])) ? x_clean_fname($names[$i]) : '';
        if ($disp === '') $disp = $orig;
        $dsc = (is_array($descs) && isset($descs[$i]) && is_string($descs[$i])) ? x_file_desc($descs[$i]) : '';
        $pin = is_array($pins) && in_array((string)$i, array_map('strval',$pins), true);
        $nfs = (isset($_POST['nf_st']) && is_string($_POST['nf_st']) && in_array($_POST['nf_st'], x_ext_opts(), true) && ($_POST['nf_st']!=='php' || x_php_ext_ok())) ? $_POST['nf_st'] : '';
        $nfd = (isset($_POST['nf_dl']) && is_string($_POST['nf_dl']) && in_array($_POST['nf_dl'], x_ext_opts(), true)) ? $_POST['nf_dl'] : '';
        $stored = 'nf_'.bin2hex(random_bytes(10)).'.'.($nfs!=='' ? $nfs : x_store_ext(pathinfo($orig,PATHINFO_EXTENSION)));
        if (x_mv_up($f['tmp_name'][$i],BFILES_DIR.'/'.$stored)) {
            $out[] = array('name'=>$disp,'stored_name'=>$stored,'size'=>filesize(BFILES_DIR.'/'.$stored),'dl_name'=>($nfd!=='' ? ('sh_'.bin2hex(random_bytes(12))).'.'.$nfd : x_dl_name($disp, x_dl_ext($orig))),'desc'=>$dsc,'pinned'=>$pin);
        }
    }
    return $out;
}
function x_delete_note_files($item) {
    foreach (x_item_files($item) as $f) { $p = BFILES_DIR.'/'.basename($f['stored_name']); if (is_file($p)) x_rm($p); }
}
function x_remove_note_files(&$item,$ns) {
    $keep = array();
    foreach (x_item_files($item) as $i=>$f) {
        if (in_array($i,$ns,true)) { $p = BFILES_DIR.'/'.basename($f['stored_name']); if (is_file($p)) x_rm($p); }
        else $keep[] = $f;
    }
    $item['files'] = $keep;
}
function x_cf_ranges() { return array('173.245.48.0/20','103.21.244.0/22','103.22.200.0/22','103.31.4.0/22','141.101.64.0/18','108.162.192.0/18','190.93.240.0/20','188.114.96.0/20','197.234.240.0/22','198.41.128.0/17','162.158.0.0/15','104.16.0.0/13','104.24.0.0/14','172.64.0.0/13','131.0.72.0/22','2400:cb00::/32','2606:4700::/32','2803:f800::/32','2405:b500::/32','2405:8100::/32','2a06:98c0::/29','2c0f:f248::/32'); }
function x_ip_in_cidr($ip, $cidr) {
    $p = explode('/', $cidr); if (count($p) !== 2) return false;
    $a = @inet_pton($ip); $b = @inet_pton($p[0]);
    if ($a === false || $b === false || strlen($a) !== strlen($b)) return false;
    $bits = (int)$p[1]; $full = (int)floor($bits / 8); $rem = $bits % 8;
    if ($full > 0 && substr($a, 0, $full) !== substr($b, 0, $full)) return false;
    if ($rem > 0) { $m = (0xFF << (8 - $rem)) & 0xFF; if ((ord($a[$full]) & $m) !== (ord($b[$full]) & $m)) return false; }
    return true;
}
function x_is_cf_ip($ip) { foreach (x_cf_ranges() as $c) if (x_ip_in_cidr($ip, $c)) return true; return false; }
function x_cf_enabled() {
    static $v = null; if ($v !== null) return $v;
    $d = x_data(); $v = (is_array($d) && !empty($d['settings']['cf']['enabled']));
    return $v;
}
function x_ip() {
    static $ip = null; if ($ip !== null) return $ip;
    $ip = (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown');
    if ($ip !== 'unknown' && isset($_SERVER['HTTP_CF_CONNECTING_IP']) && is_string($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $h = trim($_SERVER['HTTP_CF_CONNECTING_IP']);
        if (filter_var($h, FILTER_VALIDATE_IP) && x_is_cf_ip($ip) && x_cf_enabled()) $ip = $h;
    }
    return $ip;
}
function x_track(&$data, $type, $id, $action, $label='') {
    if (!isset($data['analytics']) || !is_array($data['analytics'])) $data['analytics'] = [];
    $data['analytics'][] = ['type'=>$type,'id'=>(string)$id,'action'=>$action,'label'=>$label,'ip'=>x_ip(),'role'=>(isset($_SESSION['role']) ? $_SESSION['role'] : 'guest'),'name'=>(isset($_SESSION['uname']) && is_string($_SESSION['uname']) ? $_SESSION['uname'] : ''),'uid'=>(isset($_SESSION['uid']) && is_string($_SESSION['uid']) ? $_SESSION['uid'] : ''),'time'=>date('Y-m-d H:i:s')];
    if (count($data['analytics']) > 10000) $data['analytics'] = array_slice($data['analytics'], -10000);
}
function x_h($s) { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function x_php_post() { return (isset($_POST['php_version_enabled']) && trim((isset($_POST['php_version']) ? $_POST['php_version'] : ''))!=='') ? trim($_POST['php_version']) : null; }
function x_php_badge($v) {
    $v = trim((string)((isset($v) ? $v : '')));
    if ($v === '') return '<span style="color:var(--text3)">—</span>';
    return '<span class="badge badge-a" style="white-space:nowrap">'.x_h($v).'</span>';
}
function x_pack_list($it) { return (is_array($it) && isset($it['pack']) && is_array($it['pack'])) ? array_values(array_filter($it['pack'], 'is_array')) : array(); }
function x_php_badges($it) { return x_php_badge(isset($it['php_version']) ? $it['php_version'] : ''); }
function x_gh_norm($u) {
    $u = trim((string)$u);
    if ($u!=='' && !preg_match('#^[a-z][a-z0-9+.\-]*://#i', $u) && preg_match('#^[a-z0-9][a-z0-9.\-]*\.[a-z]{2,}(?::\d+)?(?:/|$)#i', $u)) $u = 'https://'.$u;
    if (preg_match('#^https?://(?:www\.)?github\.com/([^/?\#]+)/([^/?\#]+)/(?:raw|blob)/([^?\#]+)#i', $u, $m)) return 'https://raw.githubusercontent.com/'.$m[1].'/'.$m[2].'/'.$m[3];
    return $u;
}
function x_gh_resolve($h) {
    $h = strtolower(trim((string)$h, '[]')); if ($h==='') return false; $f = FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE;
    if (filter_var($h, FILTER_VALIDATE_IP)) return filter_var($h, FILTER_VALIDATE_IP, $f) ? $h : false;
    $ips = @gethostbynamel($h); if (!$ips) return false;
    foreach ($ips as $ip) if (!filter_var($ip, FILTER_VALIDATE_IP, $f)) return false;
    return $ips[0];
}
function x_gh_get($url, $to) {
    $url = x_gh_norm($url);
    if (function_exists('curl_init')) {
        for ($hop = 0; $hop < 6; $hop++) {
            $h = parse_url($url, PHP_URL_HOST); $sc = strtolower((string)parse_url($url, PHP_URL_SCHEME)); $pt = (int)parse_url($url, PHP_URL_PORT);
            if (!$h || ($sc!=='https' && $sc!=='http')) return false;
            if (!$pt) $pt = ($sc==='https') ? 443 : 80;
            if (!in_array($pt, array(80, 443, 8080, 8443), true)) return false;
            $ip = x_gh_resolve($h); if ($ip===false) return false;
            $c = curl_init($url); if (!$c) return false;
            curl_setopt($c, CURLOPT_RETURNTRANSFER, true); curl_setopt($c, CURLOPT_TIMEOUT, (int)$to); curl_setopt($c, CURLOPT_CONNECTTIMEOUT, (int)$to);
            curl_setopt($c, CURLOPT_FOLLOWLOCATION, false); curl_setopt($c, CURLOPT_USERAGENT, 'Exlonea');
            curl_setopt($c, CURLOPT_RESOLVE, array(strtolower($h).':'.$pt.':'.$ip));
            if (defined('CURLOPT_PROTOCOLS')) curl_setopt($c, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
            $r = curl_exec($c); $code = (int)curl_getinfo($c, CURLINFO_RESPONSE_CODE); $loc = (string)curl_getinfo($c, CURLINFO_REDIRECT_URL);
            if (PHP_VERSION_ID < 80000) { curl_close($c); }
            if ($code >= 300 && $code < 400 && $loc !== '') { $url = $loc; continue; }
            return ($r !== false && $r !== '' && $code === 200) ? $r : false;
        }
        return false;
    }
    if (ini_get('allow_url_fopen')) {
        $h = parse_url($url, PHP_URL_HOST); $sc = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        if (!$h || ($sc!=='https' && $sc!=='http') || x_gh_resolve($h)===false) return false;
        $ctx = stream_context_create(array('http' => array('timeout' => (int)$to, 'header' => "User-Agent: Exlonea\r\n", 'follow_location' => 0, 'ignore_errors' => false)));
        $r = @file_get_contents($url, false, $ctx);
        return ($r !== false && $r !== '') ? $r : false;
    }
    return false;
}
function x_gh_fetch($url) { $url = x_gh_norm($url); if (!x_pack_gh_ok($url)) return false; $b = x_gh_get($url, 40); return ($b===false || strlen($b) > 52428800) ? false : $b; }
function x_gh_archive(&$data, $g) {
    foreach ($data['dosya'] as $d) if (isset($d['from_github']) && $d['from_github']===$g['id']) return array('dup', $d['id'], 0);
    $sid = 'sh_'.bin2hex(random_bytes(12));
    $ents = array(array('php'=>(string)(isset($g['php_version']) ? $g['php_version'] : ''), 'enc'=>!empty($g['encrypted']), 'url'=>(string)(isset($g['url']) ? $g['url'] : '')));
    foreach (x_pack_list($g) as $p) $ents[] = array('php'=>(string)(isset($p['php']) ? $p['php'] : ''), 'enc'=>!empty($p['enc']), 'url'=>(string)(isset($p['url']) ? $p['url'] : ''));
    $files = array(); $fail = 0;
    foreach ($ents as $e) {
        $b = x_gh_fetch($e['url']); if ($b===false) { $fail++; continue; }
        $orig = basename((string)parse_url($e['url'], PHP_URL_PATH)); if ($orig==='' || $orig==='.') $orig = 'dosya.php';
        $ext = pathinfo($orig, PATHINFO_EXTENSION); $base = $files ? $sid.'_p'.bin2hex(random_bytes(4)) : $sid;
        $stored = $base.'.'.x_st_pick($ext ? $ext : 'txt'); $dl = $base.'.'.x_dl_pick($orig);
        if (@file_put_contents(FILES_DIR.'/'.$stored, $b)===false) { $fail++; continue; }
        $files[] = array('php'=>x_pack_php_in($e['php']), 'enc'=>$e['enc'], 'stored_name'=>$stored, 'original_name'=>$orig, 'download_name'=>$dl);
    }
    if (!$files) return array('fail', null, $fail);
    $f0 = array_shift($files);
    $imgs = array(); $i = 0;
    foreach (x_item_images($g, 'image') as $f) {
        $src = SCREENSHOTS_DIR.'/'.basename($f); if (!is_file($src)) continue;
        $nn = $sid.'_c'.(++$i).bin2hex(random_bytes(2)).'.'.strtolower(pathinfo($f, PATHINFO_EXTENSION));
        if (@copy($src, SCREENSHOTS_DIR.'/'.$nn)) { $t = THUMBS_DIR.'/'.basename($f); if (is_file($t)) @copy($t, THUMBS_DIR.'/'.$nn); else x_thumb(SCREENSHOTS_DIR.'/'.$nn, THUMBS_DIR.'/'.$nn, 80); $imgs[] = $nn; }
    }
    $ss = $imgs ? array_shift($imgs) : null;
    $vids = array(); $vn = 0; $vl = x_item_videos($g);
    foreach ($vl as $v) {
        if ($v['t']==='f') { $src = VIDEOS_DIR.'/'.basename((string)$v['v']); if (!is_file($src)) continue; $nn = $sid.'_v'.(++$vn).'.'.strtolower(pathinfo($src, PATHINFO_EXTENSION)); if (@copy($src, VIDEOS_DIR.'/'.$nn)) { $v['v'] = $nn; $vids[] = $v; } }
        else $vids[] = $v;
    }
    $nfs = array();
    foreach (x_item_files($g) as $f) {
        $src = BFILES_DIR.'/'.basename((string)$f['stored_name']); if (!is_file($src)) continue;
        $nn = 'nf_'.bin2hex(random_bytes(10)).'.'.strtolower(pathinfo($src, PATHINFO_EXTENSION));
        if (@copy($src, BFILES_DIR.'/'.$nn)) { $f['stored_name'] = $nn; $nfs[] = $f; }
    }
    $it = array('id'=>$sid,'by'=>x_owner_uid(),'zip_on'=>x_zip_post(),'name'=>(isset($g['name']) ? $g['name'] : 'İsimsiz Dosya'),'description'=>(isset($g['description']) ? $g['description'] : ''),'has_password'=>!empty($f0['enc']),'show_code'=>!empty($g['show_code']),'category_id'=>(isset($g['category_id']) ? $g['category_id'] : null),'php_version'=>($f0['php']!=='' ? $f0['php'] : null),'pack'=>$files,'original_name'=>$f0['original_name'],'stored_name'=>$f0['stored_name'],'download_name'=>$f0['download_name'],'screenshot'=>$ss,'gallery'=>$imgs,'videos'=>$vids,'files'=>$nfs,'from_github'=>$g['id'],'date_added'=>date('Y-m-d H:i:s'),'pinned'=>false);
    if (isset($g['main_video']) && $g['main_video']!==null && count($vids)===count($vl)) $it['main_video'] = $g['main_video'];
    $data['dosya'][] = $it; x_stamp_ws($data['dosya'], 'dosya');
    return array('ok', $sid, $fail);
}
function x_pack_gh_ok($u) { $h = parse_url($u, PHP_URL_HOST); return (bool)(filter_var($u, FILTER_VALIDATE_URL) && $h && preg_match('#^https?://#i', $u)); }
function x_pack_php_in($v) { return trim(mb_substr(is_string($v) ? $v : '', 0, 20)); }
function x_pack_new_dosya($sid) {
    $o = array(); $ph = (isset($_POST['pack_php']) && is_array($_POST['pack_php'])) ? $_POST['pack_php'] : array();
    if (!isset($_FILES['pack_file']) || !is_array($_FILES['pack_file']['name'])) return $o;
    $f = $_FILES['pack_file'];
    foreach ($f['name'] as $i=>$nm) {
        if (!isset($f['error'][$i]) || $f['error'][$i]!==UPLOAD_ERR_OK) continue;
        $orig = basename($nm); $ext = pathinfo($orig, PATHINFO_EXTENSION); $b = $sid.'_p'.bin2hex(random_bytes(4));
        $stored = $b.'.'.x_st_pick($ext?:'txt'); $dl = $b.'.'.x_dl_pick($orig);
        if (!x_move_upload($f['tmp_name'][$i], FILES_DIR.'/'.$stored)) continue;
        $o[] = array('php'=>x_pack_php_in(isset($ph[$i]) ? $ph[$i] : ''), 'enc'=>(isset($_POST['pack_enc'][$i]) && $_POST['pack_enc'][$i]==='1'), 'stored_name'=>$stored, 'original_name'=>$orig, 'download_name'=>$dl);
    }
    return $o;
}
function x_pack_apply_dosya(&$it, $sid) {
    $keep = array();
    foreach (x_pack_list($it) as $i=>$p) {
        if (!empty($_POST['pack_old_del'][$i])) { if (!empty($p['stored_name'])) @unlink(FILES_DIR.'/'.basename($p['stored_name'])); continue; }
        if (isset($_POST['pack_old_php'][$i])) $p['php'] = x_pack_php_in($_POST['pack_old_php'][$i]);
        if (isset($_POST['pack_old_enc'][$i])) $p['enc'] = ($_POST['pack_old_enc'][$i]==='1');
        if (empty($p['enc'])) $p['php'] = '';
        $keep[] = $p;
    }
    $it['pack'] = array_merge($keep, x_pack_new_dosya($sid));
    $it['zip_on'] = x_zip_post();
}
function x_pack_unlink($it) { foreach (x_pack_list($it) as $p) if (!empty($p['stored_name'])) { $f = FILES_DIR.'/'.basename($p['stored_name']); if (is_file($f)) x_rm($f); } }
function x_main_shim() { if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['main_enc'])) {
    $_en = ($_POST['main_enc']==='1'); unset($_POST['has_password'], $_POST['encrypted'], $_POST['php_version_enabled']);
    if ($_en) { $_POST['has_password'] = '1'; $_POST['encrypted'] = '1'; $_mp = x_pack_php_in(isset($_POST['main_php']) ? $_POST['main_php'] : ''); if ($_mp !== '') { $_POST['php_version_enabled'] = '1'; $_POST['php_version'] = $_mp; } }
    $_POST['php_version'] = isset($_POST['php_version_enabled']) ? $_POST['php_version'] : '';
}
}
x_main_shim();
function x_zip_post() { return !isset($_POST['main_enc']) || isset($_POST['zip_on']); }
function x_pack_new_gh() {
    $o = array(); $ph = (isset($_POST['pack_php']) && is_array($_POST['pack_php'])) ? $_POST['pack_php'] : array(); $u = (isset($_POST['pack_url']) && is_array($_POST['pack_url'])) ? $_POST['pack_url'] : array();
    foreach ($u as $i=>$url) { $url = is_string($url) ? x_gh_norm($url) : ''; if ($url==='' || !x_pack_gh_ok($url)) continue; $en = (isset($_POST['pack_enc'][$i]) && $_POST['pack_enc'][$i]==='1'); $o[] = array('php'=>$en ? x_pack_php_in(isset($ph[$i]) ? $ph[$i] : '') : '', 'enc'=>$en, 'url'=>$url); }
    return $o;
}
function x_pack_apply_gh(&$it) {
    $keep = array();
    foreach (x_pack_list($it) as $i=>$p) {
        if (!empty($_POST['pack_old_del'][$i])) continue;
        if (isset($_POST['pack_old_php'][$i])) $p['php'] = x_pack_php_in($_POST['pack_old_php'][$i]);
        if (isset($_POST['pack_old_enc'][$i])) $p['enc'] = ($_POST['pack_old_enc'][$i]==='1');
        if (empty($p['enc'])) $p['php'] = '';
        if (isset($_POST['pack_old_url'][$i]) && is_string($_POST['pack_old_url'][$i]) && x_pack_gh_ok(x_gh_norm($_POST['pack_old_url'][$i]))) $p['url'] = x_gh_norm($_POST['pack_old_url'][$i]);
        $keep[] = $p;
    }
    $it['pack'] = array_merge($keep, x_pack_new_gh()); $it['zip_on'] = x_zip_post();
}
function x_pack_assets() {
    static $done = false; if ($done) return ''; $done = true;
    return <<<'PKX'
<style>
.pack-box{border:1px solid var(--border);border-radius:var(--r-sm,6px);padding:12px;background:var(--surface2,transparent)}
.pack-box>label{display:block;margin-bottom:8px}
.pack-scroll{max-height:300px;overflow-y:auto;margin-bottom:8px;padding-right:2px}.pack-scroll:not(:has(.pack-row)){display:none}.pack-rows,.pack-new{display:flex;flex-direction:column;gap:6px}.pack-new{margin-top:6px}.pack-new:empty{margin:0}.pack-row select{width:150px!important;flex:0 0 150px;margin:0}
.pack-row{display:flex;gap:6px;align-items:center;flex-wrap:wrap;padding:6px 8px;border:1px solid var(--border);border-radius:var(--r-sm,6px);background:var(--inp,transparent)}
.pack-row .pack-php{width:110px!important;flex:0 0 110px;margin:0}.pack-row .pack-in{flex:1 1 220px;min-width:0;margin:0}
.pack-fn{flex:1 1 180px;min-width:0;font-size:12px;color:var(--text);word-break:break-all}
.pack-del{font-size:12px;color:var(--text2);display:flex;gap:4px;align-items:center;cursor:pointer;margin:0}
.pack-x{flex:0 0 auto}
.pack-addbtn{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;padding:14px;border:1.5px dashed var(--border);border-radius:var(--r-sm,6px);background:transparent;color:var(--text3);cursor:pointer;font:500 13px var(--font,inherit);transition:.15s}
.pack-addbtn:hover{border-color:var(--green);color:var(--green)}
.pack-box .file-zone{margin:0}
</style>
<script>
function packEnc(q){var r=q.parentNode,i=r&&r.querySelector('.pack-php');if(!i)return;if(q.value==='1'){i.disabled=false;i.placeholder='örn: 7.4'}else{i.value='';i.disabled=true;i.placeholder='—'}}
document.addEventListener('change',function(e){if(e.target&&e.target.matches&&e.target.matches('.pack-row select'))packEnc(e.target)});
document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('.pack-row select').forEach(packEnc)});
function packSel(nm,val){var q=document.createElement('select');q.name=nm;q.innerHTML='<option value="0">Açık kaynak</option><option value="1">Şifreli</option>';q.value=val==='1'?'1':'0';return q}
function packSync(box){var v=box._v||(box._v=[]),en=box._e||(box._e=[]);box.querySelectorAll('.pack-new .pack-php').forEach(function(e,i){v[i]=e.value});box.querySelectorAll('.pack-new select').forEach(function(e,i){en[i]=e.value})}
function packRender(box){var L=box.querySelector('.pack-new'),dt=box._dt,v=box._v||[];L.innerHTML='';if(!dt)return;for(var i=0;i<dt.files.length;i++)(function(i){var r=document.createElement('div');r.className='pack-row';var n=document.createElement('span');n.className='pack-fn';n.textContent=dt.files[i].name;var e=document.createElement('input');e.type='text';e.className='pack-php';e.name='pack_php[]';e.placeholder='örn: 7.4';e.value=v[i]||'';var q=packSel('pack_enc[]',(box._e||[])[i]);var x=document.createElement('button');x.type='button';x.className='btn btn-or btn-xs pack-x';x.innerHTML='&times;';x.title='Kaldır';x.onclick=function(){packDel(box,i)};r.appendChild(n);r.appendChild(q);r.appendChild(e);r.appendChild(x);L.appendChild(r);packEnc(q)})(i)}
function packFiles(inp){var box=inp.closest('.pack-box');packSync(box);var dt=box._dt||(box._dt=new DataTransfer());for(var i=0;i<inp.files.length;i++){dt.items.add(inp.files[i]);box._v.push('');(box._e||(box._e=[])).push('0')}inp.files=dt.files;packRender(box);var t=box.querySelector('.fzt');if(t)t.textContent=dt.files.length+' dosya seçildi — daha fazla eklemek için tıklayın'}
function packDel(box,k){packSync(box);var nd=new DataTransfer();for(var i=0;i<box._dt.files.length;i++)if(i!==k)nd.items.add(box._dt.files[i]);box._dt=nd;box._v.splice(k,1);box._e.splice(k,1);box.querySelector('input[type=file]').files=nd.files;packRender(box)}
function packAdd(b){var box=b.closest('.pack-box'),r=document.createElement('div');r.className='pack-row';r.appendChild(packSel('pack_enc[]','0'));r.insertAdjacentHTML('beforeend','<input type="text" class="pack-php" name="pack_php[]" placeholder="örn: 7.4"><input type="text" inputmode="url" class="pack-in" name="pack_url[]" placeholder="https://raw.githubusercontent.com/... veya siteadi.com/dosya.php">');var x=document.createElement('button');x.type='button';x.className='btn btn-or btn-xs pack-x';x.innerHTML='&times;';x.onclick=function(){r.remove()};r.appendChild(x);box.querySelector('.pack-new').appendChild(r);packEnc(r.querySelector('select'))}
</script>
PKX;
}
function x_pack_field($kind, $pack=array(), $ls='', $main=null) {
    $h = x_pack_assets().'<div class="fg fw pack-box" data-kind="'.$kind.'"><label>Paket (aynı dosyanın farklı sürümleri — açık kaynak / şifreli, PHP sürümü)</label><div class="pack-scroll"><div class="pack-rows">';
    if (is_array($main)) {
        $me = !empty($main['enc']);
        $h .= '<div class="pack-row"><span class="pack-fn">'.($kind==='dosya' ? 'Ana dosya'.(!empty($main['name']) ? ': '.x_h($main['name']) : '') : 'Ana link (yukarıdaki Dosya Linki)').'</span><select name="main_enc"><option value="0">Açık kaynak</option><option value="1"'.($me ? ' selected' : '').'>Şifreli</option></select><input type="text" class="pack-php" name="main_php" value="'.($me ? x_h(isset($main['php']) ? $main['php'] : '') : '').'" placeholder="örn: 7.4"></div>';
    }
    foreach (is_array($pack) ? array_values($pack) : array() as $i=>$p) {
        if (!is_array($p)) continue;
        $h .= '<div class="pack-row">';
        if ($kind==='dosya') $h .= '<span class="pack-fn">'.x_h(isset($p['original_name']) ? $p['original_name'] : '').'</span>';
        $h .= '<select name="pack_old_enc['.$i.']"><option value="0">Açık kaynak</option><option value="1"'.(!empty($p['enc']) ? ' selected' : '').'>Şifreli</option></select><input type="text" class="pack-php" name="pack_old_php['.$i.']" value="'.x_h(isset($p['php']) ? $p['php'] : '').'" placeholder="örn: 7.4">';
        if ($kind!=='dosya') $h .= '<input type="text" inputmode="url" class="pack-in" name="pack_old_url['.$i.']" value="'.x_h(isset($p['url']) ? $p['url'] : '').'">';
        $h .= '<label class="pack-del"><input type="checkbox" name="pack_old_del['.$i.']" value="1"> Sil</label></div>';
    }
    $h .= '</div><div class="pack-new"></div></div>';
    if (is_array($main)) $h .= '<div class="toggle-row" style="margin:0 0 8px"><label class="sw"><input type="checkbox" name="zip_on" value="1"'.((!isset($main['zip']) || $main['zip']) ? ' checked' : '').'><span class="sl"></span></label><span class="swl">"Tümünü ZIP olarak indir" butonu (aktif / pasif)</span></div>';
    if ($kind==='dosya') $h .= '<div class="file-zone">'.svg('upload',14).' <span class="fzt">Paket dosyalarını seçmek için tıklayın (birden fazla seçilebilir)</span><span class="fzn" style="display:none"></span><input type="file" name="pack_file[]" multiple onchange="packFiles(this)"></div>';
    else $h .= '<button type="button" class="pack-addbtn" onclick="packAdd(this)">'.svg('plus',14).' Paket linki ekle</button>';
    return $h.'</div>';
}
function x_pack_modal_data($kind, $it) {
    $rows = array(); $id = isset($it['id']) ? $it['id'] : '';
    if ($kind==='dosya') {
        $rows[] = array('php'=>trim((string)(isset($it['php_version']) ? $it['php_version'] : '')), 'enc'=>!empty($it['has_password']), 'name'=>(isset($it['original_name']) ? $it['original_name'] : ''), 'dl'=>'?action=download&id='.rawurlencode($id));
        foreach (x_pack_list($it) as $i=>$p) $rows[] = array('php'=>trim((string)(isset($p['php']) ? $p['php'] : '')), 'enc'=>!empty($p['enc']), 'name'=>(isset($p['original_name']) ? $p['original_name'] : ''), 'dl'=>'?action=download&id='.rawurlencode($id).'&n='.($i+1));
    } else {
        $adm = x_admin(); $lk = $adm || x_gh_flag($it,'gh_link',true); $cp = $adm || x_gh_flag($it,'gh_copy',true); $dl = $adm || x_gh_flag($it,'gh_dl',false);
        $all = array(array('php'=>(isset($it['php_version']) ? $it['php_version'] : ''), 'enc'=>!empty($it['encrypted']), 'url'=>(isset($it['url']) ? $it['url'] : '')));
        foreach (x_pack_list($it) as $p) $all[] = $p;
        foreach ($all as $i=>$p) { $u = (string)(isset($p['url']) ? $p['url'] : ''); $bn = basename((string)parse_url($u, PHP_URL_PATH));
            $rows[] = array('php'=>trim((string)(isset($p['php']) ? $p['php'] : '')), 'enc'=>!empty($p['enc']), 'name'=>$bn, 'url'=>$lk ? $u : '', 'copy'=>$cp ? $u : '', 'dl'=>$dl ? '?action=github_download&id='.rawurlencode($id).($i>0 ? '&n='.$i : '') : ''); }
    }
    $zc = x_sec_cfg(); $zip = (!$zc['zip'] || (isset($it['zip_on']) && !$it['zip_on'])) ? '' : ((($kind==='dosya' || x_admin() || x_gh_flag($it,'gh_dl',false))) ? '?action=pack_zip&id='.rawurlencode($id) : '');
    return htmlspecialchars(json_encode(array('title'=>(isset($it['name']) ? $it['name'] : ''), 'zip'=>$zip, 'rows'=>$rows), JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function x_php_field($name, $value, $labelStyle='') {
    $enabled = trim((string)$value) !== '';
    $sv = x_h((isset($value) ? $value : ''));
    $label = $labelStyle!=='' ? '<span style="'.$labelStyle.'">PHP Versiyonu</span>' : '<span class="swl">PHP Versiyonu</span>';
    return '<div class="toggle-row php-ver-row"><label class="sw"><input type="checkbox" name="'.$name.'_enabled" value="1" onchange="togglePhpVer(this)" '.($enabled?'checked':'').'><span class="sl"></span></label>'.$label.'<input type="text" name="'.$name.'" class="php-ver-input" placeholder="örn: 7.3" value="'.$sv.'" '.($enabled?'':'disabled style="display:none"').'></div>';
}

function x_rich_fonts() {
    return array(
        'arial'=>"Arial,Helvetica,sans-serif",
        'verdana'=>"Verdana,Geneva,sans-serif",
        'tahoma'=>"Tahoma,Geneva,sans-serif",
        'times new roman'=>"'Times New Roman',Times,serif",
        'georgia'=>"Georgia,serif",
        'courier new'=>"'Courier New',Courier,monospace",
        'roboto'=>"Roboto,Arial,sans-serif",
        'open sans'=>"'Open Sans',Arial,sans-serif",
        'montserrat'=>"Montserrat,Arial,sans-serif",
        'cinzel decorative'=>"'Cinzel Decorative',Georgia,serif",
        'inherit'=>'inherit'
    );
}
function x_rich_font($val) {
    $parts = explode(',', (string)$val);
    $first = strtolower(trim(str_replace(array('"', "'", '&quot;'), '', $parts[0])));
    $map = x_rich_fonts();
    return isset($map[$first]) ? $map[$first] : '';
}
function x_rich_style($style,$allowWidth=false) {
    $safe = array();
    foreach (explode(';', (string)$style) as $rule) {
        if (strpos($rule, ':') === false) continue;
        $pv = array_map('trim', explode(':', $rule, 2));
        $prop = strtolower($pv[0]); $val = $pv[1];
        if ($val === '' || preg_match('/url|expression|javascript|@import|\\\\/i', $val)) continue;
        if (in_array($prop, array('color','background-color','font-size','font-weight','font-style','text-decoration'), true) && preg_match('/^[#a-z0-9 ,.()%\-]+$/i', $val)) { if (($prop==='color' || $prop==='background-color') && ($n = x_rgb_norm($val)) !== '' && isset(x_rich_theme_set()[$n])) continue; $safe[] = $prop.':'.$val; }
        elseif ($prop === 'font-family') { $ff = x_rich_font($val); if ($ff !== '') $safe[] = 'font-family:'.$ff; }
        elseif ($prop === 'text-align' && preg_match('/^(left|right|center|justify)$/i', $val)) $safe[] = 'text-align:'.strtolower($val);
        elseif ($allowWidth && $prop === 'width' && preg_match('/^\d{1,3}(\.\d{1,2})?(%|px)$/', $val)) $safe[] = 'width:'.$val;
    }
    return implode(';', $safe);
}
function x_rich_media_src($src, $kind) {
    $src = trim((string)$src);
    if ($kind === 'img' && preg_match('/^\?action=eimg&f=e_[a-f0-9]{20}\.(jpg|png|gif|webp)$/', $src)) return $src;
    if ($kind === 'video' && preg_match('/^\?action=evid&f=e_[a-f0-9]{20}\.(mp4|m4v|webm|ogv|ogg|mov)$/', $src)) return $src;
    if (preg_match('~^https?://[^\s"\'<>]{1,1800}$~i', $src)) return $src;
    return '';
}
function x_rich_attrs($str) {
    $a = array();
    if (preg_match_all('/([a-zA-Z_:][-a-zA-Z0-9_:.]*)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'>]+)))?/', (string)$str, $m, PREG_SET_ORDER)) {
        foreach ($m as $x) {
            $n = strtolower($x[1]); $v = '';
            foreach (array(2,3,4) as $k) if (isset($x[$k]) && $x[$k] !== '') { $v = $x[$k]; break; }
            if (!isset($a[$n])) $a[$n] = html_entity_decode($v, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
    }
    return $a;
}
function x_rich_pop(&$stack, $tag, &$out) {
    $i = count($stack) - 1;
    while ($i >= 0 && $stack[$i][0] !== $tag) $i--;
    if ($i < 0) return;
    while (count($stack) > $i) { $e = array_pop($stack); if ($e[1]) $out .= '</'.$e[0].'>'; }
}
function x_rich($s, $preview = false) {
    $s = (string)$s;
    if (trim($s) === '') return '';
    static $cache = array();
    $ck = ($preview ? 'p' : 'f').md5($s);
    if (isset($cache[$ck])) return $cache[$ck];
    $dropC = array('script','style','noscript','template','svg','math','object','applet','canvas','head','title','textarea','select','frameset');
    $textTags = array('p','div','h2','h3','h4','li','blockquote','span','font','ul','ol','b','strong','i','em','u','s','strike','del','sub','sup','code','pre');
    $parts = preg_split('~(<!--.*?-->|<(?:[^>"\']|"[^"]*"|\'[^\']*\')*>)~s', $s, -1, PREG_SPLIT_DELIM_CAPTURE);
    $out = ''; $stack = array(); $drop = ''; $depth = 0;
    foreach ($parts as $tok) {
        if ($tok === '') continue;
        if (substr($tok, 0, 4) === '<!--') continue;
        if ($tok[0] === '<' && strlen($tok) > 1 && preg_match('~^<\s*(/?)\s*([a-zA-Z][a-zA-Z0-9]*)\b(.*?)/?>$~s', $tok, $m)) {
            $close = ($m[1] === '/'); $tag = strtolower($m[2]); $attrStr = $m[3];
            if ($drop !== '') {
                if ($tag === $drop) { if ($close) { if (--$depth <= 0) $drop = ''; } else $depth++; }
                continue;
            }
            if (in_array($tag, $dropC, true)) { if (!$close) { $drop = $tag; $depth = 1; } continue; }
            if ($tag === 'iframe') {
                if ($close) continue;
                $at = x_rich_attrs($attrStr); $src = isset($at['src']) ? trim($at['src']) : '';
                $drop = 'iframe'; $depth = 1;
                if (!preg_match('~^https://(www\.youtube-nocookie\.com/embed/[A-Za-z0-9_-]{11}|www\.youtube\.com/embed/[A-Za-z0-9_-]{11}|player\.vimeo\.com/video/\d+)(\?[A-Za-z0-9_=&%.\-]*)?$~', $src)) continue;
                if ($preview) { $out .= "\xF0\x9F\x8E\xAC "; continue; }
                $top = $stack ? $stack[count($stack)-1] : null;
                $iframe = '<iframe src="'.x_h($src).'" allowfullscreen="allowfullscreen" loading="lazy" allow="accelerometer; encrypted-media; picture-in-picture; fullscreen" referrerpolicy="strict-origin-when-cross-origin"></iframe>';
                if ($top && isset($top[2]) && $top[2] === 'embed') $out .= $iframe; else $out .= '<div class="ed-embed" style="width:100%">'.$iframe.'</div>';
                continue;
            }
            if ($tag === 'img' || $tag === 'video') {
                if ($close) continue;
                $at = x_rich_attrs($attrStr);
                $src = x_rich_media_src(isset($at['src']) ? $at['src'] : '', $tag === 'img' ? 'img' : 'video');
                if ($tag === 'video') { $drop = 'video'; $depth = 1; }
                if ($src === '') continue;
                if ($preview) { $out .= ($tag === 'img' ? "\xF0\x9F\x96\xBC " : "\xF0\x9F\x8E\xAC "); continue; }
                $cls = array();
                foreach (preg_split('/\s+/', isset($at['class']) ? $at['class'] : '') as $k) if (in_array($k, array('ed-left','ed-right','ed-center'), true)) $cls[] = $k;
                array_unshift($cls, $tag === 'img' ? 'ed-img' : 'ed-vid');
                $style = x_rich_style(isset($at['style']) ? $at['style'] : '', true);
                $o = '<'.$tag.' src="'.x_h($src).'" class="'.implode(' ', $cls).'"';
                if ($style !== '') $o .= ' style="'.x_h($style).'"';
                if ($tag === 'img') $o .= ' alt="'.x_h(mb_substr(isset($at['alt']) ? $at['alt'] : '', 0, 200)).'" loading="lazy">';
                else $o .= ' controls="controls" preload="metadata" playsinline="playsinline"></video>';
                $out .= $o;
                continue;
            }
            if ($tag === 'br' || $tag === 'hr') { if (!$close) $out .= $preview ? ' ' : '<'.$tag.'>'; continue; }
            if ($tag === 'a') {
                if ($close) { x_rich_pop($stack, 'a', $out); continue; }
                $at = x_rich_attrs($attrStr); $href = isset($at['href']) ? trim($at['href']) : '';
                $good = !$preview && preg_match('~^(https?://|mailto:|tel:|#|\?|/(?!/))~i', $href) && !preg_match('/[\x00-\x1F]/', $href);
                if ($good) {
                    $out .= '<a href="'.x_h($href).'"'.(preg_match('~^https?://~i', $href) ? ' target="_blank" rel="noopener noreferrer"' : '').'>';
                    $stack[] = array('a', true);
                } else $stack[] = array('a', false);
                continue;
            }
            if ($preview && in_array($tag, $textTags, true)) {
                if (in_array($tag, array('p','div','h2','h3','h4','li','blockquote','ul','ol','pre'), true)) $out .= ' ';
                continue;
            }
            if (in_array($tag, $textTags, true)) {
                if ($close) { x_rich_pop($stack, $tag, $out); continue; }
                $at = x_rich_attrs($attrStr);
                $embed = ($tag === 'div' && !$preview && preg_match('/(^|\s)ed-embed(\s|$)/', isset($at['class']) ? $at['class'] : ''));
                $style = x_rich_style(isset($at['style']) ? $at['style'] : '', $embed);
                if ($tag === 'font') {
                    if (isset($at['color']) && preg_match('/^(#[a-f0-9]{3,8}|[a-z]+)$/i', $at['color']) && !isset(x_rich_theme_set()[x_rgb_norm($at['color'])])) $style = 'color:'.$at['color'].($style !== '' ? ';'.$style : '');
                }
                $o = '<'.$tag;
                if ($embed) { $o .= ' class="ed-embed"'; if ($style === '') $style = 'width:100%'; }
                if ($style !== '') $o .= ' style="'.x_h($style).'"';
                if ($tag === 'font' && isset($at['size']) && preg_match('/^[1-7]$/', $at['size'])) $o .= ' size="'.$at['size'].'"';
                $out .= $o.'>';
                $stack[] = $embed ? array($tag, true, 'embed') : array($tag, true);
                continue;
            }
            continue;
        }
        if ($drop !== '') continue;
        $out .= str_replace('<', '&lt;', $tok);
    }
    while ($stack) { $e = array_pop($stack); if ($e[1]) $out .= '</'.$e[0].'>'; }
    $out = trim($out);
    if ($preview) $out = trim(preg_replace('/\s+/u', ' ', $out));
    if (!preg_match('/<(img|video|iframe)\b/i', $out) && trim(str_replace("\xc2\xa0", ' ', strip_tags($out))) === '') $out = '';
    return $cache[$ck] = $out;
}
function x_ci($item, $field) {
    if (is_array($item) && isset($item[$field]) && is_string($item[$field])) $item[$field] = x_rich($item[$field]);
    if (is_array($item) && isset($item['files']) && is_array($item['files'])) {
        $fl = array();
        foreach (x_item_files($item) as $ff) $fl[] = array('name'=>$ff['name'],'size'=>isset($ff['size'])?$ff['size']:0,'desc'=>isset($ff['desc'])?(string)$ff['desc']:'','pinned'=>!empty($ff['pinned']));
        $item['files'] = $fl;
    }
    return $item;
}
function x_editor_css() {
    return <<<'REDITCSS'
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@400;700&family=Montserrat:wght@400;700&family=Open+Sans:wght@400;700&family=Roboto:wght@400;700&display=swap">
<style>.rich-font-select{max-width:150px}
img.ed-img,video.ed-vid{max-width:100%;height:auto;border-radius:6px;vertical-align:middle}
video.ed-vid{background:#000}
.ed-left{float:left;margin:4px 14px 8px 0}.ed-right{float:right;margin:4px 0 8px 14px}
img.ed-center,video.ed-center{display:block;margin:10px auto;float:none}
.ed-embed{position:relative;aspect-ratio:16/9;max-width:100%;margin:10px 0;background:#000;border-radius:6px;overflow:hidden}
.ed-embed iframe{position:absolute;inset:0;width:100%;height:100%;border:0}
.archive-detail-description,.github-detail-description,.desc-m .val,.rich-content{display:flow-root}
.archive-detail-description a,.github-detail-description a,.desc-m .val a{color:var(--green,#ff5c65);text-decoration:none}
.rich-content a{color:var(--green,#ff5c65);text-decoration:underline;text-underline-offset:2px}
.archive-detail-description blockquote,.github-detail-description blockquote,.desc-m .val blockquote,.rich-content blockquote{margin:8px 0;padding:4px 12px;border-left:3px solid var(--green,#b71c1c);color:var(--text2,#d1d5e0);background:color-mix(in srgb,var(--green,#b71c1c) 7%,transparent)}
.archive-detail-description ul,.archive-detail-description ol,.github-detail-description ul,.github-detail-description ol,.desc-m .val ul,.desc-m .val ol,.rich-content ul,.rich-content ol{padding-left:24px;margin:6px 0}
.archive-detail-description ol,.github-detail-description ol,.desc-m .val ol,.rich-content ol{list-style-type:decimal}
.archive-detail-description ul,.github-detail-description ul,.desc-m .val ul,.rich-content ul{list-style-type:disc}
.archive-detail-description hr,.github-detail-description hr,.desc-m .val hr,.rich-content hr{border:0;border-top:1px solid var(--border,#1e2130);margin:12px 0}
.rich-toolbar button.on{border-color:var(--green,#b71c1c);color:var(--green,#b71c1c);background:color-mix(in srgb,var(--green,#b71c1c) 16%,transparent)}
</style>
REDITCSS;
}
function x_editor_assets() {
    static $d = false;
    if ($d) return '';
    $d = true;
    return x_editor_css().<<<'REDITJS'
<style>
.rich-editor{position:relative}
.rich-content{max-height:70vh!important;resize:vertical}
.rich-toolbar .re-sep{width:1px;height:20px;background:var(--border,#1e2130);margin:0 3px;flex:none}
.rich-toolbar button svg{display:block;margin:auto}
.rich-toolbar button.re-b{padding:0 6px}
.rich-content .ed-embed iframe{pointer-events:none}
.rich-content .ed-sel{outline:2px solid var(--green,#b71c1c);outline-offset:2px}
.rich-content img,.rich-content video{cursor:pointer}
.re-mbar{display:flex;align-items:center;flex-wrap:wrap;gap:4px;padding:6px;border-bottom:1px solid var(--border,#1e2130);background:color-mix(in srgb,var(--green,#b71c1c) 8%,transparent);font-size:11px;color:var(--text2,#d1d5e0)}
.re-mbar[hidden]{display:none}
.re-mbar button{height:26px;padding:0 8px;background:var(--inp,#0c0e14);border:1px solid var(--border,#1e2130);border-radius:4px;color:var(--text2,#d1d5e0);font:11px var(--font,sans-serif);cursor:pointer}
.re-mbar button:hover,.re-mbar button.on{border-color:var(--green,#b71c1c);color:var(--green,#ff5c65)}
.re-mbar .re-rng{width:110px;height:4px;padding:0;accent-color:var(--green,#b71c1c)}
@media(pointer:coarse){.re-handle{width:26px;height:26px}.re-mbar button{height:32px}.re-mbar .re-rng{width:140px;height:20px}}
.re-mbar .re-pct{min-width:34px;text-align:right}
.re-handle{position:absolute;width:14px;height:14px;background:var(--green,#b71c1c);border:2px solid #fff;border-radius:50%;cursor:nwse-resize;z-index:5;display:none;touch-action:none}
.re-ov{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.65);display:flex;align-items:center;justify-content:center;padding:16px}
.re-box{width:min(460px,100%);max-height:90vh;overflow:auto;background:var(--surface,#111318);border:1px solid var(--border,#1e2130);border-radius:10px;color:var(--text2,#d1d5e0);box-shadow:0 20px 60px rgba(0,0,0,.5)}
.re-h{padding:14px 16px;font-size:14px;font-weight:700;border-bottom:1px solid var(--border,#1e2130)}
.re-b{padding:14px 16px;display:flex;flex-direction:column;gap:8px}
.re-b label{font-size:11px;color:var(--text,#8b8fa3)}
.re-b .re-ck{display:flex;align-items:center;gap:7px;font-size:12px;color:var(--text2,#d1d5e0);cursor:pointer}
.re-b .re-in{width:100%;padding:10px;background:var(--inp,#0c0e14);border:1px solid var(--border,#1e2130);border-radius:6px;color:var(--text2,#d1d5e0);font:13px var(--font,sans-serif);outline:none;box-sizing:border-box}
.re-b .re-in:focus{border-color:var(--green,#b71c1c)}
.re-b .re-ck input{width:auto;accent-color:var(--green,#b71c1c)}
.re-tabs{display:flex;gap:6px}
.re-tabs button{flex:1;padding:8px;background:var(--inp,#0c0e14);border:1px solid var(--border,#1e2130);border-radius:6px;color:var(--text2,#d1d5e0);font:12px var(--font,sans-serif);cursor:pointer}
.re-tabs button.on{border-color:var(--green,#b71c1c);color:var(--green,#ff5c65)}
.re-drop{display:flex;align-items:center;justify-content:center;min-height:70px;padding:12px;border:1px dashed var(--border,#1e2130);border-radius:8px;text-align:center;font-size:12px;color:var(--text,#8b8fa3);cursor:pointer;position:relative}
.re-drop.has,.re-drop:hover{border-color:var(--green,#b71c1c);color:var(--green,#ff5c65)}
.re-drop input{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%}
.re-f{display:flex;align-items:center;gap:8px;padding:12px 16px;border-top:1px solid var(--border,#1e2130)}
.re-msg{flex:1;font-size:11px;color:var(--green,#ff5c65)}
.re-f button{padding:8px 14px;border-radius:6px;border:1px solid var(--border,#1e2130);background:transparent;color:var(--text2,#d1d5e0);font:13px var(--font,sans-serif);cursor:pointer}
.re-f .re-ok{background:var(--green,#b71c1c);border-color:var(--green,#b71c1c);color:#fff}
.re-f button:disabled{opacity:.5;cursor:default}
.re-emo{position:fixed;z-index:99998;width:292px;background:var(--surface,#111318);border:1px solid var(--border,#1e2130);border-radius:10px;box-shadow:0 14px 40px rgba(0,0,0,.5);padding:8px}
.re-emo-t{display:flex;gap:4px;margin-bottom:6px}
.re-emo-t button{flex:1;height:28px;background:var(--inp,#0c0e14);border:1px solid var(--border,#1e2130);border-radius:5px;cursor:pointer;font-size:15px;line-height:1}
.re-emo-t button.on{border-color:var(--green,#b71c1c)}
.re-emo-g{display:grid;grid-template-columns:repeat(8,1fr);gap:2px;max-height:190px;overflow:auto}
.re-emo-g button{height:32px;background:transparent;border:0;border-radius:5px;cursor:pointer;font-size:19px;line-height:1}
.re-emo-g button:hover{background:color-mix(in srgb,var(--green,#b71c1c) 20%,transparent)}
.re-toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:100000;padding:10px 16px;background:var(--d1,#111318);border:1px solid var(--green,#b71c1c);border-radius:8px;color:#fff;font:13px var(--font,sans-serif);box-shadow:0 10px 30px rgba(0,0,0,.5)}
</style>
<script>
(function(){
if(window.__re2)return;window.__re2=1;
var EMO_GROUPS=[
 ['😀','😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😋 😛 😜 🤪 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 😶 😐 😑 😬 🙄 😯 😮 😲 😴 🤤 😪 🥴 🤢 🤮 🤧 😷'],
 ['👍','👍 👎 👌 ✌️ 🤞 🤟 🤘 👈 👉 👆 👇 ☝️ ✋ 🤚 👋 🤙 💪 🙏 👏 🙌 🤝 ✍️ 👀 🧠'],
 ['❤️','❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 ✨ ⭐ 🌟 💫 🔥 💥 💯 ✅ ❌ ⚠️ ❓ ❗ 💡 🎉 🎊 🏆 🎯 ➡️ ⬅️ ⬆️ ⬇️ ✔️ ➕ ➖'],
 ['💻','📌 📎 📁 📂 📄 📝 📖 📚 💻 🖥️ 📱 ⌨️ 🖱️ 🔒 🔓 🔑 ⚙️ 🔧 🛠️ 🔍 📷 🎬 🎵 🎧 📢 🔔 ⏰ 📅 🚀 📦 🧩 🔗 💾 🗑️ 📊 📈'],
 ['🌞','🌞 🌙 ☁️ 🌈 ⚡ ❄️ 🌸 🌹 🌳 🍀 🐶 🐱 🦊 🐼 🐧 🍎 🍕 🍔 ☕ 🍰 ⚽ 🎮 🚗 ✈️ 🏠']
];
var EMOTICONS=[[':-)','😊'],[':)','😊'],[':-D','😃'],[':D','😃'],[';-)','😉'],[';)','😉'],[':-(','😞'],[':(','😞'],[":'(",'😢'],[':-P','😛'],[':P','😛'],[':p','😛'],[':-O','😮'],[':O','😮'],[':o','😮'],[':*','😘'],['</3','💔'],['<3','❤️'],[':/','😕'],[':|','😐'],['xD','😆'],['XD','😆'],['(y)','👍'],['(n)','👎']];
EMOTICONS.sort(function(a,b){return b[0].length-a[0].length});
var IC={
 link:'<path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/>',
 unlink:'<path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/><line x1="3" y1="3" x2="21" y2="21"/>',
 image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>',
 video:'<rect x="2" y="4" width="14" height="16" rx="2"/><polygon points="22 8 16 12 22 16 22 8"/>',
 smile:'<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>',
 undo:'<polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 102.13-9.36L1 10"/>',
 redo:'<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/>',
 al:'<line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="14" y2="12"/><line x1="3" y1="18" x2="18" y2="18"/>',
 ac:'<line x1="3" y1="6" x2="21" y2="6"/><line x1="7" y1="12" x2="17" y2="12"/><line x1="5" y1="18" x2="19" y2="18"/>',
 ar:'<line x1="3" y1="6" x2="21" y2="6"/><line x1="10" y1="12" x2="21" y2="12"/><line x1="6" y1="18" x2="21" y2="18"/>',
 hr:'<line x1="3" y1="12" x2="21" y2="12"/>'
};
function svg(n){return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+IC[n]+'</svg>'}
function esc(t){return String(t==null?'':t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function normUrl(u){u=(u||'').trim();if(!u)return '';if(/^(https?:|mailto:|tel:)/i.test(u))return u;if(/^[a-z][a-z0-9+.\-]*:/i.test(u))return '';if(/^\/\//.test(u))return 'https:'+u;if(/^[#?\/]/.test(u))return u;return 'https://'+u}
function embedSrc(u){var m;u=(u||'').trim();if(m=u.match(/^https?:\/\/(?:www\.|m\.)?(?:youtube\.com\/(?:watch\?(?:[^#]*&)?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/i))return 'https://www.youtube-nocookie.com/embed/'+m[1];if(m=u.match(/^https?:\/\/(?:www\.)?vimeo\.com\/(?:video\/)?(\d+)/i))return 'https://player.vimeo.com/video/'+m[1];return ''}
function isVideoUrl(u){return /^https?:\/\/[^\s"'<>]+\.(mp4|m4v|webm|ogv|ogg|mov)(\?[^\s"'<>]*)?$/i.test(u||'')}
function isImageUrl(u){return /^https?:\/\/[^\s"'<>]+$/i.test(u||'')}
function toast(t){var d=document.createElement('div');d.className='re-toast';d.textContent=t;document.body.appendChild(d);setTimeout(function(){d.remove()},3200)}
var saved=null;
function saveSel(ed){var s=getSelection();if(s.rangeCount&&ed.contains(s.anchorNode))saved={r:s.getRangeAt(0).cloneRange(),ed:ed}}
function restore(ed){ed.focus();var s=getSelection();if(saved&&saved.ed===ed){s.removeAllRanges();s.addRange(saved.r)}else{var r=document.createRange();r.selectNodeContents(ed);r.collapse(false);s.removeAllRanges();s.addRange(r)}}
function sync(ed){if(typeof window.syncRich==='function')window.syncRich(ed);else ed.dispatchEvent(new Event('input',{bubbles:true}))}
function ins(ed,html){restore(ed);document.execCommand('insertHTML',false,html);prep(ed);sync(ed)}
function prep(ed){var l=ed.querySelectorAll('.ed-embed');for(var i=0;i<l.length;i++)l[i].setAttribute('contenteditable','false')}
window.richPrep=prep;
function imgHtml(u,alt){return '<img class="ed-img" src="'+esc(u)+'" alt="'+esc(alt||'')+'" style="width:50%">'}
function vidHtml(u){return '<video class="ed-vid" controls preload="metadata" src="'+esc(u)+'" style="width:60%"></video>'}
function embedHtml(src){return '<div class="ed-embed" contenteditable="false" style="width:100%"><iframe src="'+esc(src)+'" allowfullscreen loading="lazy"></iframe></div><p><br></p>'}
function shrinkImg(file){return new Promise(function(res){if(!/^image\/(jpeg|png|webp)$/.test(file.type)||file.size<1500000){res(file);return}var u=URL.createObjectURL(file),im=new Image();im.onerror=function(){URL.revokeObjectURL(u);res(file)};im.onload=function(){URL.revokeObjectURL(u);var w=im.naturalWidth,h=im.naturalHeight,k=Math.min(1,2200/Math.max(w,h)),cw=Math.max(1,Math.round(w*k)),ch=Math.max(1,Math.round(h*k));function draw(bg){var c=document.createElement('canvas');c.width=cw;c.height=ch;var g=c.getContext('2d');if(bg){g.fillStyle='#fff';g.fillRect(0,0,cw,ch)}g.drawImage(im,0,0,cw,ch);return c}function done(b,t){if(!b||b.size>=file.size){res(file);return}res(new File([b],file.name.replace(/\.[^.]+$/,'')+(t==='image/png'?'.png':'.jpg'),{type:t}))}try{if(file.type==='image/png'){draw(false).toBlob(function(b){if(b&&b.size<=1500000)done(b,'image/png');else draw(true).toBlob(function(b2){done(b2,'image/jpeg')},'image/jpeg',.85)},'image/png')}else{draw(true).toBlob(function(b){done(b,'image/jpeg')},'image/jpeg',.85)}}catch(e){res(file)}};im.src=u})}
function upload(file,msgEl){if(msgEl)msgEl.textContent='Resim hazırlanıyor...';return shrinkImg(file).then(function(file){return new Promise(function(res,rej){var fd=new FormData();fd.append('file',file);var x=new XMLHttpRequest();x.open('POST','?action=editor_upload');x.upload.onprogress=function(e){if(e.lengthComputable&&msgEl)msgEl.textContent='Yükleniyor %'+Math.round(e.loaded/e.total*100)};x.onload=function(){try{var j=JSON.parse(x.responseText);j.ok?res(j):rej(new Error(j.error||'Yüklenemedi'))}catch(err){rej(new Error('Sunucu yanıtı okunamadı (boyut sınırı aşılmış olabilir)'))}};x.onerror=function(){rej(new Error('Bağlantı hatası'))};x.send(fd)})})}
function dlg(title,body,okText,onOk){
 var o=document.createElement('div');o.className='re-ov';
 o.innerHTML='<div class="re-box" role="dialog" aria-modal="true"><div class="re-h">'+title+'</div><div class="re-b">'+body+'</div><div class="re-f"><span class="re-msg"></span><button type="button" class="re-x">İptal</button><button type="button" class="re-ok">'+okText+'</button></div></div>';
 document.body.appendChild(o);
 var msg=o.querySelector('.re-msg'),ok=o.querySelector('.re-ok');
 var api={el:o,msg:function(t){msg.textContent=t||''},busy:function(b){ok.disabled=b;o.querySelector('.re-x').disabled=b},close:function(){o.remove();document.removeEventListener('keydown',kd,true)}};
 function kd(e){if(e.key==='Escape'){e.stopPropagation();api.close()}}
 document.addEventListener('keydown',kd,true);
 o.addEventListener('mousedown',function(e){if(e.target===o)api.close()});
 o.querySelector('.re-x').onclick=api.close;
 ok.onclick=function(){onOk(api)};
 o.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target.tagName==='INPUT'&&e.target.type!=='file'&&e.target.type!=='checkbox'){e.preventDefault();ok.click()}});
 var f=o.querySelector('input.re-in');if(f)setTimeout(function(){f.focus()},30);
 return api;
}
function val(o,k){var e=o.querySelector('[data-k="'+k+'"]');return e?(e.type==='checkbox'?e.checked:e.value):''}
function tabs(o){
 var bt=o.querySelectorAll('.re-tabs button'),pn=o.querySelectorAll('.re-pane');
 bt.forEach(function(b,i){b.onclick=function(){bt.forEach(function(x,j){x.classList.toggle('on',i===j)});pn.forEach(function(p,j){p.style.display=i===j?'':'none'});o.dataset.tab=i}});
 o.dataset.tab=0;
}
function dropHook(o){
 var inp=o.querySelector('input[type=file]'),dz=o.querySelector('.re-drop');if(!inp)return;
 inp.onchange=function(){if(inp.files.length){dz.classList.add('has');dz.firstChild.textContent=inp.files.length>1?inp.files.length+' dosya seçildi':inp.files[0].name}else{dz.classList.remove('has');dz.firstChild.textContent=dz.dataset.t}};
}
function linkDlg(ed){
 var s=getSelection(),anchor=null,selText='';
 if(s.rangeCount&&ed.contains(s.anchorNode)){var n=s.anchorNode;n=n.nodeType===3?n.parentNode:n;anchor=n.closest?n.closest('a'):null;selText=s.toString()}
 saveSel(ed);
 var showTxt=!(selText||anchor);
 var api=dlg('Bağlantı ekle','<label>Adres (URL)</label><input class="re-in" data-k="url" placeholder="https://ornek.com" value="'+esc(anchor?anchor.getAttribute('href'):'')+'">'+(showTxt?'<label>Görünen yazı (opsiyonel)</label><input class="re-in" data-k="txt" placeholder="Bağlantı yazısı">':'')+'<label class="re-ck"><input type="checkbox" data-k="blank" checked> Yeni sekmede aç</label>',anchor?'Güncelle':'Ekle',function(a){
  var o=a.el,url=normUrl(val(o,'url'));
  if(!url){a.msg('Geçerli bir adres girin (http, https, mailto veya tel).');return}
  var blank=val(o,'blank')&&/^https?:/i.test(url);
  if(anchor&&ed.contains(anchor)){anchor.setAttribute('href',url);if(blank){anchor.setAttribute('target','_blank');anchor.setAttribute('rel','noopener noreferrer')}else{anchor.removeAttribute('target');anchor.removeAttribute('rel')}}
  else{
   restore(ed);
   if(selText){document.execCommand('createLink',false,url)}
   else{document.execCommand('insertHTML',false,'<a href="'+esc(url)+'">'+esc(val(o,'txt')||url)+'</a>&nbsp;')}
   var as=ed.querySelectorAll('a[href]');for(var i=0;i<as.length;i++){if(as[i].getAttribute('href')===url){if(blank){as[i].setAttribute('target','_blank');as[i].setAttribute('rel','noopener noreferrer')}else{as[i].removeAttribute('target')}}}
  }
  sync(ed);a.close();
 });
}
function imageDlg(ed){
 saveSel(ed);
 var api=dlg('Resim ekle','<div class="re-tabs"><button type="button" class="on">Bilgisayardan yükle</button><button type="button">Adresten ekle</button></div><div class="re-pane"><div class="re-drop" data-t="Resim seçmek için tıklayın (birden fazla seçilebilir)"><span>Resim seçmek için tıklayın (birden fazla seçilebilir)</span><input type="file" accept="image/*" multiple></div></div><div class="re-pane" style="display:none"><label>Resim adresi</label><input class="re-in" data-k="url" placeholder="https://ornek.com/resim.jpg"><label>Açıklama (alt yazı, opsiyonel)</label><input class="re-in" data-k="alt"></div>','Ekle',function(a){
  var o=a.el;
  if(o.dataset.tab==='1'){var u=(val(o,'url')||'').trim();if(!isImageUrl(u)){a.msg('http/https ile başlayan bir resim adresi girin.');return}ins(ed,imgHtml(u,val(o,'alt')));a.close();return}
  var fl=o.querySelector('input[type=file]').files;if(!fl.length){a.msg('Önce bir resim seçin.');return}
  a.busy(true);var html='',list=Array.prototype.slice.call(fl),k=0;
  (function next(){if(k>=list.length){ins(ed,html);a.close();return}var f=list[k++];a.msg('('+k+'/'+list.length+') yükleniyor...');upload(f,o.querySelector('.re-msg')).then(function(j){if(j.type!=='image')throw new Error('Bu dosya bir resim değil');html+=imgHtml(j.url,'');next()}).catch(function(e){a.busy(false);if(html)ins(ed,html);a.msg(e.message)})})();
 });
 tabs(api.el);dropHook(api.el);
}
function videoDlg(ed){
 saveSel(ed);
 var api=dlg('Video ekle','<div class="re-tabs"><button type="button" class="on">Bilgisayardan yükle</button><button type="button">Adres (YouTube / Vimeo / mp4)</button></div><div class="re-pane"><div class="re-drop" data-t="Video seçmek için tıklayın (mp4, webm, ogg, mov)"><span>Video seçmek için tıklayın (mp4, webm, ogg, mov)</span><input type="file" accept="video/*"></div></div><div class="re-pane" style="display:none"><label>Video adresi</label><input class="re-in" data-k="url" placeholder="https://www.youtube.com/watch?v=... veya .mp4 adresi"></div>','Ekle',function(a){
  var o=a.el;
  if(o.dataset.tab==='1'){var u=(val(o,'url')||'').trim(),es=embedSrc(u);if(es){ins(ed,embedHtml(es));a.close();return}if(isVideoUrl(u)){ins(ed,vidHtml(u));a.close();return}a.msg('YouTube, Vimeo veya .mp4/.webm/.ogg/.mov adresi girin.');return}
  var fl=o.querySelector('input[type=file]').files;if(!fl.length){a.msg('Önce bir video seçin.');return}
  a.busy(true);upload(fl[0],o.querySelector('.re-msg')).then(function(j){if(j.type!=='video')throw new Error('Bu dosya bir video değil');ins(ed,vidHtml(j.url)+'<p><br></p>');a.close()}).catch(function(e){a.busy(false);a.msg(e.message)});
 });
 tabs(api.el);dropHook(api.el);
}
var emoBox=null;
function closeEmo(){if(emoBox){emoBox.remove();emoBox=null}}
function emojiPicker(ed,btn){
 saveSel(ed);
 if(emoBox){closeEmo();return}
 var b=document.createElement('div');b.className='re-emo';
 var t='<div class="re-emo-t">',i;for(i=0;i<EMO_GROUPS.length;i++)t+='<button type="button" data-g="'+i+'"'+(i===0?' class="on"':'')+'>'+EMO_GROUPS[i][0]+'</button>';
 b.innerHTML=t+'</div><div class="re-emo-g"></div>';
 document.body.appendChild(b);emoBox=b;
 var g=b.querySelector('.re-emo-g');
 function fill(n){var l=EMO_GROUPS[n][1].split(' '),h='';for(var k=0;k<l.length;k++)if(l[k])h+='<button type="button">'+l[k]+'</button>';g.innerHTML=h}
 fill(0);
 b.addEventListener('mousedown',function(e){e.preventDefault()});
 b.addEventListener('click',function(e){var x=e.target.closest('button');if(!x)return;if(x.dataset.g!==undefined){b.querySelectorAll('.re-emo-t button').forEach(function(y){y.classList.remove('on')});x.classList.add('on');fill(+x.dataset.g);return}restore(ed);document.execCommand('insertText',false,x.textContent);saveSel(ed);sync(ed)});
 var r=btn.getBoundingClientRect(),left=Math.min(r.left,window.innerWidth-300),top=r.bottom+6;if(top+270>window.innerHeight)top=Math.max(8,r.top-276);
 b.style.left=Math.max(8,left)+'px';b.style.top=top+'px';
 setTimeout(function(){document.addEventListener('mousedown',outside,true)},0);
 function outside(e){if(!b.contains(e.target)&&!btn.contains(e.target)){closeEmo();document.removeEventListener('mousedown',outside,true)}}
}
function autoEmoji(ed){
 var s=getSelection();if(!s.rangeCount||!s.isCollapsed)return false;var n=s.anchorNode;if(!n||n.nodeType!==3||!ed.contains(n))return false;
 var off=s.anchorOffset,t=n.nodeValue.slice(0,off);
 for(var i=0;i<EMOTICONS.length;i++){var k=EMOTICONS[i][0];
  if(t.length>=k.length&&t.slice(-k.length)===k){var before=t.charAt(t.length-k.length-1);
   if(before===''||/[\s\u00a0]/.test(before)){var r=document.createRange();r.setStart(n,off-k.length);r.setEnd(n,off);s.removeAllRanges();s.addRange(r);document.execCommand('insertText',false,EMOTICONS[i][1]);return true}}}
 return false;
}
function setWidth(el,p,wrap){p=Math.max(10,Math.min(100,Math.round(p)));el.style.width=p+'%';el.style.height='';if(wrap){var rg=wrap.querySelector('.re-rng'),pc=wrap.querySelector('.re-pct');if(rg)rg.value=p;if(pc)pc.textContent='%'+p}}
function curPct(ed,el){var w=parseFloat(el.style.width);if(/%/.test(el.style.width)&&!isNaN(w))return w;var cw=ed.clientWidth-20||1;return Math.min(100,Math.round(el.getBoundingClientRect().width/cw*100))}
function init(wrap){
 if(wrap.dataset.re2)return;wrap.dataset.re2='1';
 var ed=wrap.querySelector('.rich-content'),tb=wrap.querySelector('.rich-toolbar');if(!ed||!tb)return;
 function btn(icon,title,fn,cls){var b=document.createElement('button');b.type='button';b.title=title;b.innerHTML=icon;if(cls)b.className=cls;b.addEventListener('mousedown',function(e){e.preventDefault()});b.addEventListener('click',function(e){e.preventDefault();fn(b)});tb.appendChild(b);return b}
 function sep(){var s=document.createElement('span');s.className='re-sep';tb.appendChild(s)}
 function cmd(c,v){ed.focus();if(c==='insertUnorderedList'||c==='insertOrderedList')normLines(ed);document.execCommand(c,false,v||null);sync(ed)}
 sep();
 btn(svg('undo'),'Geri al (Ctrl+Z)',function(){cmd('undo')});
 btn(svg('redo'),'Yinele (Ctrl+Y)',function(){cmd('redo')});
 sep();
 btn('<s>S</s>','Üstü çizili',function(){cmd('strikeThrough')},'re-b');
 btn('1.','Numaralı liste',function(){cmd('insertOrderedList')},'re-b');
 btn('&ldquo;','Alıntı (açık/kapalı)',function(){ed.focus();var q=getSelection(),inq=q&&q.rangeCount&&ed.contains(q.anchorNode)&&bqOf(q.getRangeAt(0).startContainer,ed);if(inq){if(unquote(ed,false))sync(ed)}else cmd('formatBlock','<blockquote>')},'re-b');
 btn('&#8629;','Alıntıdan çık (alta geç / alıntıyı kaldır)',function(){ed.focus();if(unquote(ed,true))sync(ed)},'re-b');
 ed.addEventListener('keydown',function(e){if(e.key!=='Enter'||e.shiftKey||e.ctrlKey||e.metaKey||e.altKey||e.isComposing)return;var q=getSelection();if(!q||!q.rangeCount||!q.isCollapsed||!ed.contains(q.anchorNode))return;var bq=bqOf(q.anchorNode,ed);if(!bq)return;var ln=q.anchorNode.nodeType===3?q.anchorNode.parentNode:q.anchorNode;while(ln&&ln!==bq&&!/^(DIV|P|LI)$/.test(ln.tagName))ln=ln.parentNode;if(ln&&ln!==bq&&ln.tagName==='LI')return;var line=(ln&&ln!==bq)?ln:bq;if(blankL(line)){e.preventDefault();if(unquote(ed,false))sync(ed)}});
 (function(){if(!ed.id)ed.id='re_'+Math.random().toString(36).slice(2,9);var fs=document.createElement('select');fs.className='rich-size-select rich-font-select';fs.title='Yazı tipi';fs.setAttribute('aria-label','Yazı tipi');fs.innerHTML='<option value="">Yazı tipi</option><option value="inherit">Varsayılan</option>'+FONTS.map(function(f){return '<option value="'+f[0]+'" style="font-family:'+f[1].replace(/"/g,'')+'">'+f[0]+'</option>'}).join('');fs.addEventListener('change',function(){var v=fs.value;if(v)window.richCmd('fontName',ed.id,v)});var sz=tb.querySelector('.rich-size-select');if(sz&&sz.parentNode)sz.parentNode.insertBefore(fs,sz.nextSibling);else tb.insertBefore(fs,tb.firstChild)})();
 btn(svg('hr'),'Ayırıcı çizgi',function(){cmd('insertHorizontalRule')});
 btn(svg('al'),'Sola hizala',function(){cmd('justifyLeft')});
 btn(svg('ac'),'Ortala',function(){cmd('justifyCenter')});
 btn(svg('ar'),'Sağa hizala',function(){cmd('justifyRight')});
 btn('Tx','Biçimi temizle',function(){cmd('removeFormat')},'re-b');
 sep();
 btn(svg('link'),'Bağlantı ekle / düzenle (Ctrl+K)',function(){linkDlg(ed)});
 btn(svg('unlink'),'Bağlantıyı kaldır',function(){cmd('unlink')});
 btn(svg('image'),'Resim ekle',function(){imageDlg(ed)});
 btn(svg('video'),'Video ekle',function(){videoDlg(ed)});
 btn(svg('smile'),'İfade (emoji) ekle',function(b){emojiPicker(ed,b)});
 var mb=document.createElement('div');mb.className='re-mbar';mb.hidden=true;
 mb.innerHTML='<span>Boyut</span><button type="button" data-w="25">%25</button><button type="button" data-w="50">%50</button><button type="button" data-w="75">%75</button><button type="button" data-w="100">%100</button><input type="range" class="re-rng" min="10" max="100" step="1" value="50"><span class="re-pct"></span><span class="re-sep"></span><button type="button" data-al="left">Sol</button><button type="button" data-al="center">Orta</button><button type="button" data-al="right">Sağ</button><button type="button" data-al="none">Satır içi</button><span class="re-sep"></span><button type="button" class="re-del">Sil</button><button type="button" class="re-close">Kapat</button>';
 tb.parentNode.insertBefore(mb,ed);
 var hd=document.createElement('div');hd.className='re-handle';hd.title='Boyutu değiştirmek için sürükleyin';wrap.appendChild(hd);
 var sel=null;
 function place(){if(!sel||!ed.contains(sel)){hd.style.display='none';return}var w=wrap.getBoundingClientRect(),r=sel.getBoundingClientRect(),c=ed.getBoundingClientRect();if(r.bottom<c.top+4||r.bottom>c.bottom+2||r.right>c.right+2){hd.style.display='none';return}hd.style.display='block';var hh=(hd.offsetWidth||18)/2;hd.style.left=(r.right-w.left-hh)+'px';hd.style.top=(r.bottom-w.top-hh)+'px'}
 function unpick(){if(sel)sel.classList.remove('ed-sel');sel=null;mb.hidden=true;hd.style.display='none'}
 function pick(el){if(sel&&sel!==el)sel.classList.remove('ed-sel');sel=el;el.classList.add('ed-sel');mb.hidden=false;var p=curPct(ed,el);mb.querySelector('.re-rng').value=p;mb.querySelector('.re-pct').textContent='%'+p;var cl=el.classList,a=cl.contains('ed-left')?'left':cl.contains('ed-right')?'right':cl.contains('ed-center')?'center':'none';mb.querySelectorAll('[data-al]').forEach(function(b){b.classList.toggle('on',b.dataset.al===a)});place()}
 ed.addEventListener('click',function(e){var m=e.target.closest&&e.target.closest('img,video,.ed-embed');if(m&&ed.contains(m)){pick(m);try{var r=document.createRange();r.selectNode(m);var s=getSelection();s.removeAllRanges();s.addRange(r)}catch(x){}}else unpick()});
 ed.addEventListener('scroll',place);window.addEventListener('resize',place);
 mb.addEventListener('mousedown',function(e){if(e.target.tagName!=='INPUT')e.preventDefault()});
 mb.addEventListener('click',function(e){var b=e.target.closest('button');if(!b||!sel)return;
  if(b.dataset.w){setWidth(sel,+b.dataset.w,mb);sync(ed);place()}
  else if(b.dataset.al){sel.classList.remove('ed-left','ed-right','ed-center');if(b.dataset.al!=='none')sel.classList.add('ed-'+b.dataset.al);mb.querySelectorAll('[data-al]').forEach(function(x){x.classList.toggle('on',x===b)});sync(ed);place()}
  else if(b.classList.contains('re-del')){var m=sel;unpick();m.remove();sync(ed)}
  else if(b.classList.contains('re-close')){unpick()}});
 mb.querySelector('.re-rng').addEventListener('input',function(e){if(sel){setWidth(sel,+e.target.value,mb);sync(ed);place()}});
 var drag=null;
 hd.addEventListener('pointerdown',function(e){if(!sel)return;e.preventDefault();hd.setPointerCapture(e.pointerId);drag={x:e.clientX,w:sel.getBoundingClientRect().width,cw:(ed.clientWidth-20)||1}});
 hd.addEventListener('pointermove',function(e){if(!drag||!sel)return;setWidth(sel,(drag.w+(e.clientX-drag.x))/drag.cw*100,mb);place()});
 function endDrag(e){if(!drag)return;drag=null;try{hd.releasePointerCapture(e.pointerId)}catch(x){}sync(ed);place()}
 hd.addEventListener('pointerup',endDrag);hd.addEventListener('pointercancel',endDrag);
 ed.addEventListener('keydown',function(e){if((e.ctrlKey||e.metaKey)&&(e.key==='k'||e.key==='K')){e.preventDefault();linkDlg(ed)}else if(sel&&(e.key==='Delete'||e.key==='Backspace')){setTimeout(function(){if(sel&&!ed.contains(sel))unpick()},0)}});
 ed.addEventListener('input',function(e){if(e.inputType==='insertText'&&e.data&&e.data.length===1){if(autoEmoji(ed))sync(ed)}});
 function filesOf(dt){var o=[];if(dt&&dt.files)for(var i=0;i<dt.files.length;i++)if(/^image\//.test(dt.files[i].type))o.push(dt.files[i]);return o}
 function pushImgs(list){saveSel(ed);var html='',k=0;toast('Resim yükleniyor...');(function next(){if(k>=list.length){if(html)ins(ed,html);return}upload(list[k++]).then(function(j){html+=imgHtml(j.url,'');next()}).catch(function(e){toast(e.message);if(html)ins(ed,html)})})()}
 ed.addEventListener('paste',function(e){var f=filesOf(e.clipboardData);if(f.length){e.preventDefault();pushImgs(f)}});
 ed.addEventListener('drop',function(e){var f=filesOf(e.dataTransfer);if(f.length){e.preventDefault();pushImgs(f)}});
 prep(ed);
 new MutationObserver(function(){prep(ed)}).observe(ed,{childList:true});
}
var BLKRE=/^(DIV|P|H[1-6]|BLOCKQUOTE|PRE|UL|OL|LI|HR|TABLE)$/;
function isBlk(n){return n.nodeType===1&&BLKRE.test(n.tagName)}
function hasLines(b){if(b.nodeType!==1)return false;if(b.querySelector('br'))return true;var w=document.createTreeWalker(b,NodeFilter.SHOW_TEXT,null),t;while(t=w.nextNode())if(t.nodeValue.indexOf('\n')>-1)return true;return false}
function emptyBlk(b){return b.textContent.replace(/[\s\u200b]+/g,'')===''&&!b.querySelector('img,video,iframe,hr,[data-rm]')}
function splitBlock(b){var pts=[],w=document.createTreeWalker(b,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT,null),n;while(n=w.nextNode()){if(n.nodeType===1){if(n.tagName==='BR')pts.push({br:n})}else{var t=n.nodeValue,i=-1;while((i=t.indexOf('\n',i+1))>-1)pts.push({tx:n,off:i})}}
if(!pts.length)return[b];var tails=[];
for(var k=pts.length-1;k>=0;k--){var p=pts[k],r=document.createRange();if(p.br)r.setStartAfter(p.br);else{var tail=p.tx.splitText(p.off+1);p.tx.nodeValue=p.tx.nodeValue.slice(0,p.off);r.setStartBefore(tail)}
r.setEnd(b,b.childNodes.length);var nb=b.cloneNode(false);nb.removeAttribute('id');nb.appendChild(r.extractContents());tails.unshift(nb);if(p.br&&p.br.parentNode)p.br.parentNode.removeChild(p.br)}
var ref=b;tails.forEach(function(x){b.parentNode.insertBefore(x,ref.nextSibling);ref=x});
var all=[b].concat(tails),keep=[];all.forEach(function(x){if(all.length>1&&emptyBlk(x)){if(x.parentNode)x.parentNode.removeChild(x)}else keep.push(x)});return keep.length?keep:[b]}
function normLines(ed){var s=getSelection();if(!s||!s.rangeCount||!ed||!ed.contains(s.anchorNode))return;var r=s.getRangeAt(0);if(!ed.contains(r.startContainer)||!ed.contains(r.endContainer))return;
var ms=document.createElement('span'),me=document.createElement('span');ms.setAttribute('data-rm','1');me.setAttribute('data-rm','2');
var re=r.cloneRange();re.collapse(false);re.insertNode(me);var rs=r.cloneRange();rs.collapse(true);rs.insertNode(ms);
function top(n){while(n&&n.parentNode!==ed)n=n.parentNode;return n}
function done(){var rr=document.createRange();rr.setStartBefore(ms);rr.setEndAfter(me);s.removeAllRanges();s.addRange(rr);if(ms.parentNode)ms.parentNode.removeChild(ms);if(me.parentNode)me.parentNode.removeChild(me);s.removeAllRanges();s.addRange(rr)}
var a=top(ms),z=top(me);if(!a||!z){done();return}
var kids=[].slice.call(ed.childNodes),i0=kids.indexOf(a),i1=kids.indexOf(z),run=[];
function flush(){if(!run.length)return;var d=document.createElement('div');ed.insertBefore(d,run[0]);run.forEach(function(x){d.appendChild(x)});run=[]}
for(var i=i0;i<=i1&&i<kids.length;i++){var c=kids[i];if(isBlk(c))flush();else run.push(c)}flush();
var k2=[].slice.call(ed.childNodes),j0=k2.indexOf(top(ms)),j1=k2.indexOf(top(me));
for(var j=j0;j<=j1&&j<k2.length;j++){var c2=k2[j];if(!c2||c2.nodeType!==1||/^(UL|OL|HR|TABLE|BLOCKQUOTE)$/.test(c2.tagName))continue;if(hasLines(c2))splitBlock(c2)}
done()}
window.richNormLines=normLines;
var FONTS=[['Arial','Arial,Helvetica,sans-serif'],['Verdana','Verdana,Geneva,sans-serif'],['Tahoma','Tahoma,Geneva,sans-serif'],['Times New Roman',"'Times New Roman',Times,serif"],['Georgia','Georgia,serif'],['Courier New',"'Courier New',Courier,monospace"],['Roboto','Roboto,Arial,sans-serif'],['Open Sans',"'Open Sans',Arial,sans-serif"],['Montserrat','Montserrat,Arial,sans-serif'],['Cinzel Decorative',"'Cinzel Decorative',Georgia,serif"]];
function bqOf(n,ed){while(n&&n!==ed){if(n.nodeType===1&&n.tagName==='BLOCKQUOTE')return n;n=n.parentNode}return null}
function blankL(x){return x.textContent.replace(/[\s\u200b]+/g,'')===''&&!x.querySelector('img,video,iframe,hr')}
function unquote(ed,below){var s=getSelection();if(!s||!s.rangeCount)return false;var r=s.getRangeAt(0);if(!ed.contains(r.startContainer))return false;var bq=bqOf(r.startContainer,ed);if(!bq)return false;var collapsed=r.collapsed;
var ms=document.createElement('span'),me=document.createElement('span');ms.setAttribute('data-rm','1');me.setAttribute('data-rm','2');
var re=r.cloneRange();re.collapse(false);re.insertNode(me);var rs=r.cloneRange();rs.collapse(true);rs.insertNode(ms);
function rm(x){if(x.parentNode)x.parentNode.removeChild(x)}
var kids=[].slice.call(bq.childNodes),run=[];
function flush(){if(!run.length)return;var d=document.createElement('div');bq.insertBefore(d,run[0]);run.forEach(function(x){d.appendChild(x)});run=[]}
kids.forEach(function(c){if(isBlk(c))flush();else run.push(c)});flush();
[].slice.call(bq.childNodes).forEach(function(c){if(c.nodeType===1&&!/^(UL|OL|HR|TABLE|BLOCKQUOTE)$/.test(c.tagName)&&hasLines(c))splitBlock(c)});
function topIn(n){while(n&&n.parentNode!==bq)n=n.parentNode;return n}
var ch=[].slice.call(bq.childNodes),ca=ch.indexOf(topIn(ms)),cz=ch.indexOf(topIn(me));if(ca<0)ca=0;if(cz<0)cz=ch.length-1;if(cz<ca)cz=ca;
var parent=bq.parentNode;
if(below&&collapsed&&cz===ch.length-1&&ch[cz]&&!blankL(ch[cz])){var nd=document.createElement('div');nd.appendChild(document.createElement('br'));parent.insertBefore(nd,bq.nextSibling);rm(ms);rm(me);var r1=document.createRange();r1.setStart(nd,0);r1.collapse(true);s.removeAllRanges();s.addRange(r1);return true}
var before=ch.slice(0,ca),sel=ch.slice(ca,cz+1),after=ch.slice(cz+1),ref=bq.nextSibling;
sel.forEach(function(x){parent.insertBefore(x,ref)});
if(after.length){var b2=bq.cloneNode(false);after.forEach(function(x){b2.appendChild(x)});parent.insertBefore(b2,ref)}
if(!before.length)rm(bq);
sel.forEach(function(x){if(x.nodeType===1&&blankL(x)&&!x.querySelector('br'))x.appendChild(document.createElement('br'))});
var rr=document.createRange();rr.setStartBefore(ms);rr.setEndAfter(me);rm(ms);rm(me);s.removeAllRanges();s.addRange(rr);return true}
var lastR={};
function richState(e){var w=e.closest('.rich-editor'),tb=w&&w.querySelector('.rich-toolbar');if(!tb)return;var st={bold:1,italic:1,underline:1,insertUnorderedList:1};tb.querySelectorAll('button[onclick]').forEach(function(b){var m=/richCmd\(\s*'(\w+)'\s*,\s*'[^']*'(?:\s*,\s*'([^']*)')?/.exec(b.getAttribute('onclick')||'');if(!m)return;var c=m[1],on=false;try{if(c==='formatBlock'){var fb=String(document.queryCommandValue('formatBlock')).toLowerCase().replace(/[<>]/g,'');on=(fb===(m[2]||'').toLowerCase())||(m[2]==='h3'&&fb==='heading 3')}else if(st[c])on=document.queryCommandState(c)}catch(x){}b.classList.toggle('on',!!on)});var ci=tb.querySelector('input[type=color]');if(ci){var mm=/rgba?\((\d+)\D+(\d+)\D+(\d+)/.exec(String(document.queryCommandValue('foreColor')||''));if(mm)ci.value='#'+[1,2,3].map(function(i){return('0'+(+mm[i]).toString(16)).slice(-2)}).join('')}}
document.addEventListener('selectionchange',function(){var s=getSelection();if(!s||!s.rangeCount)return;var ae=document.activeElement;if(ae&&ae.classList&&ae.classList.contains('rich-size-select'))return;var n=s.anchorNode;n=n&&(n.nodeType===1?n:n.parentNode);var e=n&&n.closest?n.closest('.rich-content'):null;if(e&&e.id){lastR[e.id]=s.getRangeAt(0).cloneRange();richState(e);var w=e.closest('.rich-editor'),z=w&&w.querySelector('.rich-size-select:not(.rich-font-select)');if(z){var v=String(document.queryCommandValue('fontSize')||'');z.selectedIndex=0;for(var q=0;q<z.options.length;q++)if(z.options[q].value&&z.options[q].value===v){z.selectedIndex=q;break}}var fz=w&&w.querySelector('.rich-font-select');if(fz){var fv=String(document.queryCommandValue('fontName')||'').replace(/["']/g,'').split(',')[0].trim().toLowerCase();fz.selectedIndex=0;for(var r=0;r<fz.options.length;r++)if(fz.options[r].value&&fz.options[r].value.toLowerCase()===fv){fz.selectedIndex=r;break}}}});
var held={};
function holdSel(ev){var t=ev.target;if(!t||!t.classList||!t.classList.contains('rich-size-select'))return;var w=t.closest('.rich-editor'),e=w&&w.querySelector('.rich-content');if(!e||!e.id)return;var s=getSelection();if(s&&s.rangeCount&&e.contains(s.anchorNode))held[e.id]=s.getRangeAt(0).cloneRange()}
['touchstart','pointerdown','mousedown'].forEach(function(n){document.addEventListener(n,holdSel,true)});
window.richCmd=function(c,id,v){var e=document.getElementById(id);if(!e)return;e.focus();var r=(c==='fontSize'&&held[id])||lastR[id];if(c==='fontSize')delete held[id];if(r){try{var s=getSelection();s.removeAllRanges();s.addRange(r)}catch(x){}}if(c==='insertUnorderedList'||c==='insertOrderedList')normLines(e);if(c==='fontName')document.execCommand('styleWithCSS',false,true);document.execCommand(c,false,v||null);if(c==='fontName')document.execCommand('styleWithCSS',false,false);sync(e);var s2=getSelection();if(s2&&s2.rangeCount&&e.contains(s2.anchorNode))lastR[id]=s2.getRangeAt(0).cloneRange();richState(e)};

function boot(){document.querySelectorAll('.rich-editor').forEach(init)}
window.richEditorApi={normUrl:normUrl,embedSrc:embedSrc,isVideoUrl:isVideoUrl,autoEmoji:autoEmoji,init:init,setWidth:setWidth};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
</script>
REDITJS;
}

function x_rich_editor($id, $name, $value='', $placeholder='Açıklamayı buraya yazın...') {
    $sid=x_h($id); $sname=x_h($name); $svalue=x_h($value); $shtml=x_rich($value); $splaceholder=x_h($placeholder);
    return '<div class="rich-editor"><div class="rich-toolbar" role="toolbar" aria-label="İçerik biçimlendirme"><button type="button" onclick="richCmd(\'bold\',\''.$sid.'\')" title="Kalın"><strong>B</strong></button><button type="button" onclick="richCmd(\'italic\',\''.$sid.'\')" title="İtalik"><em>I</em></button><button type="button" onclick="richCmd(\'underline\',\''.$sid.'\')" title="Altı çizili"><u>U</u></button><button type="button" onclick="richCmd(\'insertUnorderedList\',\''.$sid.'\')" title="Liste">•</button><button type="button" onclick="richCmd(\'formatBlock\',\''.$sid.'\',\'h3\')" title="Başlık">H</button><select class="rich-size-select" onchange="richCmd(\'fontSize\',\''.$sid.'\',this.value)" title="Yazı boyutu"><option value="" selected disabled hidden>Boyut</option><option value="2">Küçük</option><option value="3">Normal</option><option value="5">Büyük</option><option value="7">Çok büyük</option></select><input type="color" onchange="richCmd(\'foreColor\',\''.$sid.'\',this.value)" title="Yazı rengi"><input type="color" onchange="richCmd(\'hiliteColor\',\''.$sid.'\',this.value)" title="Yazı arka plan rengi (vurgu)"><button type="button" onclick="richCmd(\'hiliteColor\',\''.$sid.'\',\'transparent\')" title="Arka planı kaldır" style="color:#e11d2e">&#10005;</button></div><div id="'.$sid.'" class="rich-content" contenteditable="true" data-target="'.$sname.'" data-placeholder="'.$splaceholder.'">'.$shtml.'</div><textarea name="'.$sname.'" id="'.$sid.'Value" class="rich-value" aria-hidden="true">'.$svalue.'</textarea></div>';
}

function x_thumb($src, $dest, $size=80) {
    if (!file_exists($src)) return false;
    $info = @getimagesize($src);
    if (!$info) return false;
    list($w,$h) = $info;
    $ratio = $w/$h;
    if ($ratio>1) { $nw=$size; $nh=intval($size/$ratio); } else { $nh=$size; $nw=intval($size*$ratio); }
    $img = null;
    switch($info[2]) {
        case IMAGETYPE_JPEG: $img=imagecreatefromjpeg($src); break;
        case IMAGETYPE_PNG: $img=imagecreatefrompng($src); break;
        case IMAGETYPE_GIF: $img=imagecreatefromgif($src); break;
        case IMAGETYPE_WEBP: $img=imagecreatefromwebp($src); break;
        default: return false;
    }
    if (!$img) return false;
    $t = imagecreatetruecolor($nw, $nh);
    if ($info[2]==IMAGETYPE_PNG||$info[2]==IMAGETYPE_WEBP) {
        imagealphablending($t, false); imagesavealpha($t, true);
        imagealphablending($img, true);
    }
    imagecopyresampled($t,$img,0,0,0,0,$nw,$nh,$w,$h);
    $ok = false;
    switch($info[2]) {
        case IMAGETYPE_JPEG: $ok=imagejpeg($t,$dest,75); break;
        case IMAGETYPE_PNG: $ok=imagepng($t,$dest,6); break;
        case IMAGETYPE_GIF: $ok=imagegif($t,$dest); break;
        case IMAGETYPE_WEBP: $ok=imagewebp($t,$dest,75); break;
    }
    if (PHP_VERSION_ID < 80000) { imagedestroy($img); imagedestroy($t); }
    return $ok;
}
function x_cat_tree($cats, $parent=null) {
    $r = [];
    foreach ($cats as $c) { if ($c['parent']===$parent) $r[]=$c; }
    usort($r, function($a, $b) {
        $aOrder = isset($a['order']) ? $a['order'] : 99;
        $bOrder = isset($b['order']) ? $b['order'] : 99;
        if ($aOrder == $bOrder) return 0;
        return ($aOrder < $bOrder) ? -1 : 1;
    });
    return $r;
}
function x_cat_name($cats, $id) {
    foreach ($cats as $c) if ((string)((isset($c['id']) ? $c['id'] : '')) === (string)$id) return $c['name'];
    return '—';
}
function x_cat_matches($item, $categoryId) {
    return (string)((isset($item['category_id']) ? $item['category_id'] : '')) === (string)$categoryId;
}
function x_img_bad($path) {
    if (!is_string($path) || !is_file($path)) return true;
    $sz = (int)@filesize($path); if ($sz > 26214400) return true;
    $b = @file_get_contents($path); if ($b === false) return true;
    return (bool)preg_match('/<\?php|<script|__HALT_COMPILER|<%@|#!\/(?:usr|bin)/i', $b);
}
function x_img_exts() { return array('jpg','jpeg','png','gif','webp','bmp'); }
function x_url_is_public_ip($ip) {
    if (stripos($ip,'::ffff:')===0) $ip = substr($ip,7);
    return (bool)filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
}
function x_url_resolve($host) {
    $host = trim($host,'[]');
    if (filter_var($host, FILTER_VALIDATE_IP)) return array($host);
    $ips = array();
    $v4 = @gethostbynamel($host);
    if ($v4) $ips = $v4;
    if (function_exists('dns_get_record')) {
        $aaaa = @dns_get_record($host, DNS_AAAA);
        if ($aaaa) foreach ($aaaa as $r) if (!empty($r['ipv6'])) $ips[] = $r['ipv6'];
    }
    return $ips;
}
function x_download_image($url, $destTmp, $maxBytes = 10485760) {
    for ($hop=0; $hop<=3; $hop++) {
        $p = parse_url($url);
        if (!$p || empty($p['host']) || empty($p['scheme'])) return false;
        $scheme = strtolower($p['scheme']);
        if ($scheme!=='http' && $scheme!=='https') return false;
        if (isset($p['user']) || isset($p['pass'])) return false;
        $port = isset($p['port']) ? (int)$p['port'] : ($scheme==='https' ? 443 : 80);
        if ($port!==80 && $port!==443) return false;
        $ips = x_url_resolve($p['host']);
        if (!$ips) return false;
        foreach ($ips as $ip) if (!x_url_is_public_ip($ip)) return false;
        $code = 0; $location = ''; $written = 0;
        $out = @fopen($destTmp,'wb');
        if (!$out) return false;
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            $opts = array(
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_TIMEOUT => 20,
                CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; ImageFetcher/1.0)',
                CURLOPT_HTTPHEADER => array('Accept: image/*,*/*;q=0.8'),
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_WRITEFUNCTION => function($c,$d) use ($out,&$written,$maxBytes) {
                    $written += strlen($d);
                    if ($written > $maxBytes) return 0;
                    return fwrite($out,$d);
                },
                CURLOPT_HEADERFUNCTION => function($c,$h) use (&$location) {
                    if (stripos($h,'location:')===0) $location = trim(substr($h,9));
                    return strlen($h);
                }
            );
            if (!filter_var(trim($p['host'],'[]'), FILTER_VALIDATE_IP)) $opts[CURLOPT_RESOLVE] = array($p['host'].':'.$port.':'.$ips[0]);
            curl_setopt_array($ch,$opts);
            curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if (PHP_VERSION_ID < 80000) { curl_close($ch); }
        } else {
            $ctx = stream_context_create(array('http'=>array('method'=>'GET','timeout'=>20,'follow_location'=>0,'ignore_errors'=>true,'header'=>"Accept: image/*\r\nUser-Agent: Mozilla/5.0 (compatible; ImageFetcher/1.0)\r\n"),'ssl'=>array('verify_peer'=>true)));
            $in = @fopen($url,'rb',false,$ctx);
            if (!$in) { fclose($out); return false; }
            if (!empty($http_response_header)) foreach ($http_response_header as $h) {
                if (preg_match('#^HTTP/\S+\s+(\d+)#',$h,$m)) $code = (int)$m[1];
                elseif (stripos($h,'location:')===0) $location = trim(substr($h,9));
            }
            while (!feof($in)) {
                $d = fread($in,8192);
                if ($d===false) break;
                $written += strlen($d);
                if ($written > $maxBytes) break;
                fwrite($out,$d);
            }
            fclose($in);
        }
        fclose($out);
        if ($written > $maxBytes) return false;
        if ($code>=300 && $code<400 && $location!=='') {
            if (strpos($location,'//')===0) $location = $scheme.':'.$location;
            elseif ($location[0]==='/') $location = $scheme.'://'.$p['host'].(isset($p['port'])?':'.$p['port']:'').$location;
            elseif (!preg_match('#^https?://#i',$location)) return false;
            $url = $location;
            continue;
        }
        return ($code===200 && $written>0);
    }
    return false;
}
function x_image_ext_from_file($path) {
    $info = @getimagesize($path);
    if (!$info) return false;
    switch ($info[2]) {
        case IMAGETYPE_JPEG: return 'jpg';
        case IMAGETYPE_PNG: return 'png';
        case IMAGETYPE_GIF: return 'gif';
        case IMAGETYPE_WEBP: return 'webp';
        case IMAGETYPE_BMP: return 'bmp';
    }
    return false;
}
function x_move_upload($tmp, $dest) {
    $d = dirname($dest);
    if (!is_dir($d)) @mkdir($d, 0755, true);
    if (!is_writable($d)) @chmod($d, 0755);
    if (x_mv_up($tmp, $dest)) { @chmod($dest, 0644); return true; }
    if (x_is_up($tmp) && @copy($tmp, $dest)) { @chmod($dest, 0644); return true; }
    return false;
}
function x_save_images($fileKey, $urlKey, $dir, $base, $max=20) {
    $saved = array(); $k = 0;
    if (isset($_FILES[$fileKey]) && is_array($_FILES[$fileKey]['name'])) {
        foreach ($_FILES[$fileKey]['name'] as $i=>$nm) {
            if (count($saved) >= $max) break;
            $er = isset($_FILES[$fileKey]['error'][$i]) ? $_FILES[$fileKey]['error'][$i] : UPLOAD_ERR_NO_FILE;
            if ($er === UPLOAD_ERR_NO_FILE) continue;
            if ($er !== UPLOAD_ERR_OK) { $GLOBALS['x_img_file_failed'] = 'size'; continue; }
            $ext = strtolower(pathinfo(basename($nm),PATHINFO_EXTENSION));
            if (!in_array($ext,x_img_exts(),true) || !@getimagesize($_FILES[$fileKey]['tmp_name'][$i]) || x_img_bad($_FILES[$fileKey]['tmp_name'][$i])) { $GLOBALS['x_img_file_failed'] = 'type'; continue; }
            $name = $base.'_'.(++$k).'.'.$ext;
            $tmpf = $_FILES[$fileKey]['tmp_name'][$i];
            if (x_move_upload($tmpf,$dir.'/'.$name)) $saved[] = $name;
            else { $GLOBALS['x_img_file_failed'] = !is_uploaded_file($tmpf) ? 'tmp' : (!is_writable($dir) ? 'dir' : 'move'); $le = error_get_last(); error_log('x_save_images: '.$dir.'/'.$name.' '.($le ? $le['message'] : '')); }
        }
    }
    $raw = isset($_POST[$urlKey]) && is_string($_POST[$urlKey]) ? $_POST[$urlKey] : '';
    foreach (preg_split('/[\r\n]+/',$raw) as $url) {
        $url = trim($url);
        if ($url==='') continue;
        if (count($saved) >= $max) break;
        $tmp = tempnam(sys_get_temp_dir(),'imgurl_');
        if ($tmp===false) continue;
        $ext = (x_download_image($url,$tmp) && !x_img_bad($tmp)) ? x_image_ext_from_file($tmp) : false;
        if (!$ext) { @unlink($tmp); $GLOBALS['x_img_url_failed']=true; continue; }
        $name = $base.'_'.(++$k).'.'.$ext;
        if (!@rename($tmp,$dir.'/'.$name)) {
            if (!@copy($tmp,$dir.'/'.$name)) { @unlink($tmp); $GLOBALS['x_img_url_failed']=true; continue; }
            @unlink($tmp);
        }
        @chmod($dir.'/'.$name,0644);
        $saved[] = $name;
    }
    return $saved;
}
function x_item_images($item,$mk) {
    $l = array();
    if (!empty($item[$mk])) $l[] = $item[$mk];
    if (!empty($item['gallery']) && is_array($item['gallery'])) foreach ($item['gallery'] as $f) if ($f) $l[] = $f;
    return $l;
}
function x_gal_meta($item,$mk) {
    $l = x_item_images($item,$mk);
    return array('_n'=>count($l), '_gv'=>$l ? abs(crc32(implode('|',$l))) : 0);
}
function x_delete_image_files($name) {
    foreach (array(SCREENSHOTS_DIR,THUMBS_DIR) as $d) { $p = $d.'/'.basename($name); if (is_file($p)) x_rm($p); }
}
function x_delete_all_images($item,$mk) {
    foreach (x_item_images($item,$mk) as $f) x_delete_image_files($f);
}
function x_remove_image_at(&$item,$mk,$n) {
    $l = x_item_images($item,$mk);
    if (!isset($l[$n])) return;
    x_delete_image_files($l[$n]);
    array_splice($l,$n,1);
    $item[$mk] = $l ? array_shift($l) : null;
    $item['gallery'] = $l;
}
function x_add_images(&$item,$mk,$new,$thumbs=false) {
    foreach ($new as $f) {
        if ($thumbs) x_thumb(SCREENSHOTS_DIR.'/'.$f, THUMBS_DIR.'/'.$f, 80);
        if (empty($item[$mk])) $item[$mk] = $f;
        else { if (empty($item['gallery']) || !is_array($item['gallery'])) $item['gallery'] = array(); $item['gallery'][] = $f; }
    }
}
function x_remove_images(&$item,$mk,$ns) {
    $l = x_item_images($item,$mk); $keep = array();
    foreach ($l as $i=>$f) { if (in_array($i,$ns,true)) x_delete_image_files($f); else $keep[] = $f; }
    $item[$mk] = $keep ? array_shift($keep) : null;
    $item['gallery'] = $keep;
}
function x_set_main_image(&$item,$mk,$n) {
    $l = x_item_images($item,$mk);
    if ($n<=0 || !isset($l[$n])) return;
    $m = $l[$n]; array_splice($l,$n,1); array_unshift($l,$m);
    $item[$mk] = array_shift($l);
    $item['gallery'] = $l;
}
function x_gal_js() {
    static $d = false;
    if ($d) return '';
    $d = true;
    return '<style>.gal-wrap input[type=checkbox]{-webkit-appearance:none;appearance:none;width:14px!important;height:14px!important;min-width:14px;padding:0!important;margin:0;background:var(--d1,#171a23);border:1px solid var(--border,#2a2e40);border-radius:3px;cursor:pointer;display:inline-grid;place-content:center;flex:none;box-shadow:none}.gal-wrap input[type=checkbox]::before{content:"";width:8px;height:8px;transform:scale(0);transition:transform .1s ease;background:#fff;clip-path:polygon(14% 44%,0 59%,39% 100%,100% 18%,84% 4%,38% 71%)}.gal-wrap input[type=checkbox]:checked{background:var(--green,#b71c1c);border-color:var(--green,#b71c1c)}.gal-wrap input[type=checkbox]:checked::before{transform:scale(1)}.gal-wrap input[type=checkbox]:focus-visible{outline:2px solid var(--green,#b71c1c);outline-offset:2px}.gal-e{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:6px}.gal-i{position:relative;width:76px}.gal-i img{width:76px;height:76px;object-fit:cover;border-radius:6px;border:1px solid var(--border);display:block}.gal-i.main img{border-color:var(--green,#b71c1c);box-shadow:0 0 0 1px var(--green,#b71c1c)}.gal-i .gk{position:absolute;top:4px;left:4px;margin:0;z-index:2}.gal-i .gm{display:block;width:100%;margin-top:4px;padding:3px 0;font-size:10px;font-family:inherit;background:transparent;color:var(--text2);border:1px solid var(--border);border-radius:4px;cursor:pointer}.gal-i .gm:hover{border-color:var(--green,#b71c1c);color:var(--green,#ff5c65)}.gal-i .gl{display:block;margin-top:4px;text-align:center;font-size:10px;font-weight:700;color:var(--green,#ff5c65)}.gal-bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px;font-size:12px;color:var(--text2)}.gal-bar button{padding:5px 10px;font-size:12px;font-family:inherit;border-radius:6px;border:1px solid var(--green,#b71c1c);background:transparent;color:var(--green,#ff5c65);cursor:pointer}.gal-bar button:disabled{opacity:.4;cursor:default}</style><script>function galAct(b,u,m){if(m&&!confirm(m))return;var f=b.closest("form");if(!f)return;f.setAttribute("action",u);f.setAttribute("method","post");f.submit()}function galSel(b){var w=b.closest(".gal-wrap"),k=w.querySelectorAll(".gk"),c=0,i;for(i=0;i<k.length;i++)if(k[i].checked)c++;var d=w.querySelector(".gal-del");d.disabled=!c;d.textContent=c?"Seçilenleri sil ("+c+")":"Seçilenleri sil";var a=w.querySelector(".gal-all");if(a&&b===a){for(i=0;i<k.length;i++)k[i].checked=a.checked;galSel(k[0])}}</script>';
}
function x_edit_gallery($type,$item,$mk) {
    $l = x_item_images($item,$mk);
    if (!$l) return '';
    $v = abs(crc32(implode('|',$l)));
    $id = rawurlencode($item['id']);
    $h = x_gal_js().'<div class="gal-wrap"><div class="gal-bar"><label style="display:flex;align-items:center;gap:5px;cursor:pointer"><input type="checkbox" class="gal-all" onchange="galSel(this)"> Tümünü seç</label><button type="button" class="gal-del" disabled onclick="galAct(this,\'?action=img_bulk_remove&type='.$type.'&id='.$id.'\',\'Seçili resimler silinsin mi?\')">Seçilenleri sil</button><span class="bulk-count" style="display:none"></span></div><div class="gal-e">';
    foreach ($l as $i=>$f) {
        $src = '?action=gimg&type='.$type.'&id='.$id.'&n='.$i.'&t=1&v='.$v;
        $h .= '<div class="gal-i'.($i===0?' main':'').'"><input type="checkbox" class="gk" name="ns[]" value="'.$i.'" onchange="galSel(this)"><img src="'.x_h($src).'" alt="">';
        if ($i===0) $h .= '<span class="gl">Ana resim</span>';
        else $h .= '<button type="button" class="gm" onclick="galAct(this,\'?action=img_main&type='.$type.'&id='.$id.'&n='.$i.'\')">Ana yap</button>';
        $h .= '</div>';
    }
    return $h.'</div></div>';
}
function x_url_input($name) {
    static $script = false;
    $h = '<textarea name="'.$name.'" class="img-url" rows="2" placeholder="veya resim URL\'leri (her satıra bir adres)" autocomplete="off" spellcheck="false" style="margin-top:6px;width:100%;box-sizing:border-box;min-height:44px;font-family:inherit;font-size:12px;background:var(--inp,#0c0e14);color:var(--text2);border:1px solid var(--border);border-radius:6px;padding:11px;outline:none;transition:border-color .15s,box-shadow .15s" onfocus="this.style.borderColor=\'var(--green)\';this.style.boxShadow=\'0 0 0 2px color-mix(in srgb,var(--green) 35%,transparent)\'" onblur="this.style.borderColor=\'\';this.style.boxShadow=\'none\'"></textarea>';
    if (!$script) {
        $script = true;
        $h .= '<script>if(typeof fu==="undefined"){window.fu=function(i,id){var a=document.getElementById(id),n=a.querySelector(".fzn"),t=a.querySelector(".fzt");if(i.files.length){a.classList.add("has");if(n){n.textContent=i.files.length>1?i.files.length+" resim seçildi":i.files[0].name;n.style.display=""}if(t)t.style.display="none"}else{a.classList.remove("has");if(n)n.style.display="none";if(t)t.style.display=""}}}</script>';
    }
    return $h;
}
function x_video_exts() { return array('mp4','webm','ogv','ogg','mov','m4v'); }
function x_video_mime($ext) { $m=array('mp4'=>'video/mp4','m4v'=>'video/mp4','webm'=>'video/webm','ogv'=>'video/ogg','ogg'=>'video/ogg','mov'=>'video/quicktime'); return isset($m[$ext])?$m[$ext]:'application/octet-stream'; }
function x_video_embed($url) {
    if (preg_match('~^https?://(?:www\.|m\.)?(?:youtube\.com/(?:watch\?(?:[^#]*&)?v=|embed/|shorts/)|youtu\.be/)([A-Za-z0-9_-]{11})~i',$url,$m)) return 'https://www.youtube-nocookie.com/embed/'.$m[1];
    if (preg_match('~^https?://(?:www\.)?vimeo\.com/(?:video/)?(\d+)~i',$url,$m)) return 'https://player.vimeo.com/video/'.$m[1];
    return null;
}
function x_save_videos($base,$max=10) {
    $saved = array(); $k = 0;
    if (isset($_FILES['video']) && is_array($_FILES['video']['name'])) {
        foreach ($_FILES['video']['name'] as $i=>$nm) {
            $err = isset($_FILES['video']['error'][$i]) ? $_FILES['video']['error'][$i] : UPLOAD_ERR_NO_FILE;
            if ($err === UPLOAD_ERR_NO_FILE) continue;
            if ($err !== UPLOAD_ERR_OK) { $GLOBALS['x_vid_failed']=true; continue; }
            if (count($saved) >= $max) break;
            $ext = strtolower(pathinfo(basename($nm),PATHINFO_EXTENSION));
            if (!in_array($ext,x_video_exts(),true)) { $GLOBALS['x_vid_failed']=true; continue; }
            $name = $base.'_v'.(++$k).'.'.$ext;
            if (x_mv_up($_FILES['video']['tmp_name'][$i],VIDEOS_DIR.'/'.$name)) { @chmod(VIDEOS_DIR.'/'.$name,0644); $saved[] = array('t'=>'f','v'=>$name,'n'=>basename($nm)); }
            else $GLOBALS['x_vid_failed']=true;
        }
    }
    $raw = isset($_POST['video_url']) && is_string($_POST['video_url']) ? $_POST['video_url'] : '';
    foreach (preg_split('/[\r\n]+/',$raw) as $url) {
        $url = trim($url);
        if ($url==='') continue;
        if (count($saved) >= $max) break;
        if (!preg_match('~^https?://[^\s<>"\']+$~i',$url)) { $GLOBALS['x_vid_failed']=true; continue; }
        $em = x_video_embed($url);
        $saved[] = $em ? array('t'=>'e','v'=>$em) : array('t'=>'u','v'=>$url);
    }
    return $saved;
}
function x_item_videos($item) {
    $l = array();
    if (!empty($item['videos']) && is_array($item['videos'])) foreach ($item['videos'] as $v) if (is_array($v) && isset($v['t'],$v['v'])) $l[] = $v;
    return $l;
}
function x_delete_all_videos($item) {
    foreach (x_item_videos($item) as $v) if ($v['t']==='f') { $p=VIDEOS_DIR.'/'.basename($v['v']); if (is_file($p)) x_rm($p); }
}
function x_collect_editor_refs($v, &$out) {
    if (is_array($v)) { foreach ($v as $x) x_collect_editor_refs($x, $out); }
    elseif (is_string($v) && strpos($v, 'action=e') !== false && preg_match_all('~action=(?:eimg|evid)(?:&amp;|&)f=([A-Za-z0-9._-]+)~', $v, $m)) { foreach ($m[1] as $f) $out[$f] = true; }
}
function x_purge_extras(&$data, $removed) {
    $gone = array(); $ids = array();
    foreach ($removed as $it) { x_collect_editor_refs($it, $gone); if (is_array($it) && isset($it['id'])) $ids[(string)$it['id']] = true; }
    if ($gone) {
        $keep = array();
        foreach (array('dosya','github','notes') as $c) if (isset($data[$c]) && is_array($data[$c])) x_collect_editor_refs($data[$c], $keep);
        if (isset($data['settings']['custom_tabs']) && is_array($data['settings']['custom_tabs'])) x_collect_editor_refs($data['settings']['custom_tabs'], $keep);
        foreach ($gone as $f => $_) if (!isset($keep[$f])) { $p = EDITOR_DIR.'/'.basename((string)$f); if (is_file($p)) x_rm($p); }
    }
    if ($ids && !empty($data['analytics']) && is_array($data['analytics'])) {
        $data['analytics'] = array_values(array_filter($data['analytics'], function($e) use ($ids) { return !(is_array($e) && isset($e['id']) && isset($ids[(string)$e['id']])); }));
    }
}
function x_remove_videos(&$item,$ns) {
    $keep = array(); $mv = isset($item['main_video']) && $item['main_video']!==null ? (int)$item['main_video'] : null; $newMv = null;
    foreach (x_item_videos($item) as $i=>$v) {
        if (in_array($i,$ns,true)) { if ($v['t']==='f') { $p=VIDEOS_DIR.'/'.basename($v['v']); if (is_file($p)) x_rm($p); } }
        else { if ($mv===$i) $newMv = count($keep); $keep[] = $v; }
    }
    $item['videos'] = $keep;
    $item['main_video'] = $newMv;
}
function x_note_main_video($note) {
    $v = x_item_videos($note);
    if (!$v) return null;
    if (isset($note['main_video']) && $note['main_video']!==null && isset($v[(int)$note['main_video']])) return (int)$note['main_video'];
    return !x_img_ok(isset($note['image']) ? $note['image'] : '') ? 0 : null;
}
function x_note_thumb($note) {
    $id = x_h($note['id']); $vids = x_item_videos($note); $mv = x_note_main_video($note);
    $nj = htmlspecialchars(json_encode($note+array('_v'=>x_img_v(isset($note['image'])?$note['image']:''))+x_gal_meta($note,'image'),JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    if ($mv!==null) {
        $vd = $vids[$mv]; $inner = '';
        if ($vd['t']==='e') {
            if (preg_match('~/embed/([A-Za-z0-9_-]{11})~',$vd['v'],$m)) $inner = '<img src="https://i.ytimg.com/vi/'.$m[1].'/mqdefault.jpg" alt="" loading="lazy">';
        } else {
            $src = $vd['t']==='f' ? '?action=vid&id='.$id.'&n='.$mv.'&f='.rawurlencode(basename($vd['v'])) : x_h($vd['v']);
            $inner = '<video src="'.$src.'#t=0.1" preload="metadata" muted playsinline tabindex="-1"></video>';
        }
        return '<span class="thumb-vid" role="button" title="Videoyu aç" onclick="viewNote('.$nj.')">'.$inner.'<span class="play-badge">&#9654;</span></span>';
    }
    if (x_img_ok(isset($note['image']) ? $note['image'] : '')) {
        $u = '?action=note_image&id='.$id.'&v='.x_img_v($note['image']);
        $h = '<span class="thumb-wrap"><img class="thumb-img" src="'.$u.'" alt="'.x_h($note['title']).'" loading="lazy" onclick="showModal(\''.$u.'\')">'.($vids?'<span class="play-badge sm">&#9654;</span>':'').'</span>';
        if (x_perm('media_delete')) $h .= '<a class="img-remove" href="?action=note_remove_image&id='.$note['id'].'&tab=notes" onclick="return confirm(\'Bu resmi silmek istiyor musunuz?\')">Resmi sil</a>';
        return $h;
    }
    return '<span class="thumb-placeholder">'.svg('image',14).'</span>';
}

function x_media_thumb($it,$type) {
    $vids=x_item_videos($it); if (!$vids) return '';
    $ik=$type==='dosya'?'screenshot':'image';
    $id=x_h($it['id']); $img=isset($it[$ik])?$it[$ik]:'';
    $mv=null;
    if (isset($it['main_video']) && $it['main_video']!==null && isset($vids[(int)$it['main_video']])) $mv=(int)$it['main_video'];
    elseif (!x_img_ok($img)) $mv=0;
    $fn=$type==='dosya'?'viewdosya':'viewGithub';
    $nj=htmlspecialchars(json_encode(x_ci($it,'description')+array('_v'=>x_img_v($img))+x_gal_meta($it,$ik)+array('_t'=>$type),JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    if ($mv!==null) {
        $vd=$vids[$mv]; $inner='';
        if ($vd['t']==='e') { if (preg_match('~/embed/([A-Za-z0-9_-]{11})~',$vd['v'],$m)) $inner='<img src="https://i.ytimg.com/vi/'.$m[1].'/mqdefault.jpg" alt="" loading="lazy">'; }
        else { $src=$vd['t']==='f' ? '?action=vid&id='.$id.'&n='.$mv.'&type='.$type.'&f='.rawurlencode(basename($vd['v'])) : x_h($vd['v']); $inner='<video src="'.$src.'#t=0.1" preload="metadata" muted playsinline tabindex="-1"></video>'; }
        return '<span class="thumb-vid" role="button" title="Videoyu aç" onclick="'.$fn.'('.$nj.')">'.$inner.'<span class="play-badge">&#9654;</span></span>';
    }
    if ($type==='dosya') { $u='?action=thumb&id='.$id.'&v='.x_img_v($img); $big='?action=screenshot&id='.$id.'&v='.x_img_v($img); $rm='?action=remove_screenshot&id='.$id.'&tab=dosya'; }
    else { $u='?action=github_image&id='.$id.'&v='.x_img_v($img); $big=$u; $rm='?action=github_remove_image&id='.$id.'&tab=github'; }
    $h='<span class="thumb-wrap"><img class="thumb-img" src="'.$u.'" alt="" loading="lazy" onclick="showModal(\''.$big.'\')"><span class="play-badge sm">&#9654;</span></span>';
    if (x_perm('media_delete')) $h.='<a class="img-remove" href="'.$rm.'" onclick="return confirm(\'Bu resmi silmek istiyor musunuz?\')">Resmi sil</a>';
    return $h;
}
function x_vid_redirect_flag() { return !empty($GLOBALS['x_vid_failed']) ? '&viderr=1' : ''; }
function x_file_desc($d) { $d=trim(preg_replace('/\s+/u',' ',strip_tags((string)$d))); return function_exists('mb_substr') ? mb_substr($d,0,300) : substr($d,0,300); }
function x_nf_descs() { return (isset($_POST['nfdesc']) && is_array($_POST['nfdesc'])) ? $_POST['nfdesc'] : array(); }
function x_nf_pins() { return (isset($_POST['nfpin']) && is_array($_POST['nfpin'])) ? $_POST['nfpin'] : array(); }
function x_sort_pinned($l) { $p=array(); $u=array(); foreach ($l as $f) { if (!empty($f['pinned'])) $p[]=$f; else $u[]=$f; } return array_merge($p,$u); }
function x_new_files() { return x_sort_pinned(x_save_note_files('nfile',x_nf_names(),x_nf_descs(),x_nf_pins())); }
function x_apply_files(&$it) {
    $nfl=x_item_files($it);
    $nfn=(isset($_POST['nfn'])&&is_array($_POST['nfn']))?$_POST['nfn']:array();
    $nfd=(isset($_POST['nfd'])&&is_array($_POST['nfd']))?$_POST['nfd']:array();
    $nfp=(isset($_POST['nfp'])&&is_array($_POST['nfp']))?$_POST['nfp']:array();
    $nfo=(isset($_POST['nfo'])&&is_array($_POST['nfo']))?$_POST['nfo']:null;
    foreach ($nfl as $ri=>$rf) {
        if (isset($nfn[$ri]) && is_string($nfn[$ri])) {
            $nn=x_clean_fname($nfn[$ri]);
            if ($nn!=='' && $nn!==$rf['name']) {
                $nfl[$ri]['name']=$nn;
                $ne=x_dl_ext($nn,'');
                if ($ne!=='') { $nb=isset($rf['dl_name'])?preg_replace('/\.[^.]*$/','',basename((string)$rf['dl_name'])):('sh_'.bin2hex(random_bytes(12))); $nfl[$ri]['dl_name']=$nb.'.'.$ne; }
            }
        }
        if (isset($nfd[$ri]) && is_string($nfd[$ri])) $nfl[$ri]['desc']=x_file_desc($nfd[$ri]);
        if ($nfo!==null) $nfl[$ri]['pinned']=isset($nfp[$ri]);
    }
    if ($nfo!==null) {
        $ord=array(); $seen=array();
        foreach ($nfo as $o) { $o=(int)$o; if (isset($nfl[$o]) && !isset($seen[$o])) { $ord[]=$nfl[$o]; $seen[$o]=true; } }
        foreach ($nfl as $k=>$f) if (!isset($seen[$k])) $ord[]=$f;
        $nfl=$ord;
    }
    foreach (x_save_note_files('nfile',x_nf_names(),x_nf_descs(),x_nf_pins()) as $ff) $nfl[]=$ff;
    $it['files']=x_sort_pinned($nfl);
}
function x_vtype() { $t = (isset($_GET['type']) && is_string($_GET['type'])) ? $_GET['type'] : 'note'; return in_array($t,array('note','dosya','github'),true) ? $t : 'note'; }
function x_vcoll($t) { return $t==='dosya' ? 'dosya' : ($t==='github' ? 'github' : 'notes'); }
function x_vback($t,$id) { if ($t==='dosya') return '?action=edit&id='.rawurlencode($id); if ($t==='github') return '?action=github_edit&id='.rawurlencode($id).'&tab=github'; return '?tab=notes'; }
function x_nf_names() { return (isset($_POST['nfname']) && is_array($_POST['nfname'])) ? $_POST['nfname'] : array(); }
function x_apply_media_edit(&$it) {
    $nv=x_item_videos($it); foreach (x_save_videos($it['id'].'_'.uniqid()) as $vv) $nv[]=$vv; $it['videos']=$nv;
    x_apply_files($it);
}
function x_media_videos_html($type,$item) {
    $v=x_item_videos($item); if (!$v) return '';
    $mv=(isset($item['main_video']) && $item['main_video']!==null && isset($v[(int)$item['main_video']])) ? (int)$item['main_video'] : 0;
    $id=rawurlencode($item['id']); $q='&amp;type='.$type;
    $h=x_gal_js().'<div class="gal-wrap" style="margin-bottom:8px"><div class="gal-bar"><label style="display:flex;align-items:center;gap:5px;cursor:pointer"><input type="checkbox" class="gal-all" onchange="galSel(this)"> Tüm videoları seç</label><button type="button" class="gal-del" disabled onclick="galAct(this,\'?action=vid_remove&amp;id='.$id.$q.'\',\'Seçili videolar silinsin mi?\')">Seçilenleri sil</button><span class="bulk-count" style="display:none"></span></div>';
    foreach ($v as $i=>$vd) {
        $nm=$vd['t']==='f'?(isset($vd['n'])?$vd['n']:$vd['v']):$vd['v'];
        $h.='<div class="vid-row"><input type="checkbox" class="gk" name="vns[]" value="'.$i.'" onchange="galSel(this)"><span style="flex:1">&#9654; Video '.($i+1).' — '.x_h($nm).'</span>'.($i===$mv?'<span class="vid-main">Ana video</span>':'<button type="button" class="vid-mk" onclick="galAct(this,\'?action=vid_main&amp;id='.$id.$q.'&amp;n='.$i.'\')">Ana yap</button>').'</div>';
    }
    return $h.'</div>';
}
function x_media_files_html($type,$item) {
    $f=x_item_files($item); if (!$f) return '';
    $id=rawurlencode($item['id']); $q='&amp;type='.$type;
    $h=x_gal_js().'<div class="gal-wrap" style="margin-bottom:8px"><div class="gal-bar"><label style="display:flex;align-items:center;gap:5px;cursor:pointer"><input type="checkbox" class="gal-all" onchange="galSel(this)"> Tüm dosyaları seç</label><button type="button" class="gal-del" disabled onclick="galAct(this,\'?action=nfile_remove&amp;id='.$id.$q.'\',\'Seçili dosyalar silinsin mi?\')">Seçilenleri sil</button><span class="bulk-count" style="display:none"></span></div><div class="nf-scroll">';
    foreach ($f as $i=>$ff) $h.='<div class="vid-row nf-er"><input type="checkbox" class="gk" name="fns[]" value="'.$i.'" onchange="galSel(this)"><input type="text" class="nf-rn" name="nfn['.$i.']" value="'.x_h($ff['name']).'" maxlength="120" title="Dosya adı (değiştirebilirsiniz)"><span class="nf-sz">'.x_h(x_fmt_size(isset($ff['size'])?$ff['size']:0)).'</span><label class="nf-pin" title="Üste sabitle"><input type="checkbox" name="nfp['.$i.']" value="1"'.(!empty($ff['pinned'])?' checked':'').'> &#128204;</label><button type="button" class="vid-mk" title="Yukarı taşı" onclick="nfMove(this,-1)">&#9650;</button><button type="button" class="vid-mk" title="Aşağı taşı" onclick="nfMove(this,1)">&#9660;</button><a class="vid-mk" href="?action=nfile&amp;id='.$id.'&amp;n='.$i.$q.'">İndir</a><input type="hidden" name="nfo[]" value="'.$i.'"><input type="text" class="nf-rn nf-dsc" name="nfd['.$i.']" value="'.x_h(isset($ff['desc'])?$ff['desc']:'').'" maxlength="300" placeholder="Dosya hakkında açıklama (isteğe bağlı)"></div>';
    return $h.'</div></div>';
}
function x_nf_edit_assets() {
    static $d = false;
    if ($d) return '';
    $d = true;
    return <<<'NFE'
<style>.nf-scroll{max-height:240px;overflow-y:auto;-webkit-overflow-scrolling:touch}.nf-sz{color:var(--text3,var(--text));font-size:11px;white-space:nowrap}.nf-names{display:flex;flex-direction:column;gap:6px;margin-top:8px;max-height:240px;overflow-y:auto}.nf-nrow{display:flex;align-items:center;gap:8px;font-size:11px;color:var(--text3,var(--text))}.nf-rn{flex:1;min-width:0;padding:6px 9px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:5px;color:var(--text2);font-size:12px;outline:none}.nf-rn:focus{border-color:var(--green)}.nf-er{flex-wrap:wrap}.nf-pin{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--text2);cursor:pointer;white-space:nowrap}.nf-nrow{flex-wrap:wrap}.nf-dsc{flex:1 1 100%!important;width:100%}.nf-desc{display:block;margin-top:3px;font-size:11px;color:var(--text3,var(--text));word-break:break-word}</style>
<script>
window.nfMove=function(b,d){var r=b.closest('.nf-er'),q=r.parentNode;if(d<0){var s=r.previousElementSibling;if(s)q.insertBefore(r,s)}else{var x=r.nextElementSibling;if(x)q.insertBefore(x,r)}};
window.nfu=function(i,id){var a=document.getElementById(id),n=a.querySelector('.fzn'),t=a.querySelector('.fzt'),nm=a.parentNode.querySelector('.nf-names');if(nm)nm.innerHTML='';if(i.files.length){a.classList.add('has');n.textContent=i.files.length>1?i.files.length+' dosya seçildi':i.files[0].name;n.style.display='';t.style.display='none';if(nm)for(var k=0;k<i.files.length;k++){var r=document.createElement('div');r.className='nf-nrow';var l=document.createElement('span');l.textContent='Ad:';var inp=document.createElement('input');inp.type='text';inp.className='nf-rn';inp.name='nfname[]';inp.maxLength=120;inp.value=i.files[k].name;inp.title='Listede görünecek ad (değiştirebilirsiniz)';var pl=document.createElement('label');pl.className='nf-pin';pl.title='Üste sabitle';var pc=document.createElement('input');pc.type='checkbox';pc.name='nfpin[]';pc.value=k;pl.appendChild(pc);pl.appendChild(document.createTextNode(' \uD83D\uDCCC'));r.appendChild(l);r.appendChild(inp);r.appendChild(pl);var dd=document.createElement('input');dd.type='text';dd.className='nf-rn nf-dsc';dd.name='nfdesc[]';dd.maxLength=300;dd.placeholder='Dosya hakkında açıklama (isteğe bağlı)';r.appendChild(dd);nm.appendChild(r)}}else{a.classList.remove('has');n.style.display='none';t.style.display=''}};
if(!window.fu)window.fu=function(i,id){var a=document.getElementById(id),n=a.querySelector('.fzn'),t=a.querySelector('.fzt');if(i.files.length){a.classList.add('has');n.textContent=i.files.length>1?i.files.length+' dosya seçildi':i.files[0].name;n.style.display='';t.style.display='none'}else{a.classList.remove('has');n.style.display='none';t.style.display=''}};
</script>
NFE;
}

function x_video_send($path,$ext) {
    session_write_close();
    while (ob_get_level()) ob_end_clean();
    $size = filesize($path); $start = 0; $end = $size-1;
    $mt = (int)filemtime($path); $etag = '"'.md5($path.'|'.$mt.'|'.$size).'"';
    header_remove('Pragma');
    header('Cache-Control: private, max-age=31536000, immutable');
    header('Expires: '.gmdate('D, d M Y H:i:s', time()+31536000).' GMT');
    header('Last-Modified: '.gmdate('D, d M Y H:i:s', $mt).' GMT');
    header('ETag: '.$etag);
    $inm = isset($_SERVER['HTTP_IF_NONE_MATCH']) ? trim($_SERVER['HTTP_IF_NONE_MATCH']) : '';
    $ims = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE']) : false;
    if ($inm===$etag || ($inm==='' && $ims!==false && $ims>=$mt)) { http_response_code(304); exit; }
    header('Content-Type: '.x_video_mime($ext));
    header('Accept-Ranges: bytes');
    if (isset($_SERVER['HTTP_IF_RANGE']) && trim($_SERVER['HTTP_IF_RANGE'])!==$etag && strtotime($_SERVER['HTTP_IF_RANGE'])!==$mt) { unset($_SERVER['HTTP_RANGE']); }
    if (isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/',$_SERVER['HTTP_RANGE'],$m)) {
        if ($m[1]==='' && $m[2]!=='') { $start = max(0,$size-(int)$m[2]); }
        else { if ($m[1]!=='') $start=(int)$m[1]; if ($m[2]!=='') $end=min($end,(int)$m[2]); }
        if ($start>$end || $start>=$size) { http_response_code(416); header('Content-Range: bytes */'.$size); exit; }
        http_response_code(206);
        header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);
    }
    header('Content-Length: '.($end-$start+1));
    $fp = fopen($path,'rb'); fseek($fp,$start); $left = $end-$start+1;
    while ($left>0 && !feof($fp)) { $chunk = fread($fp,min(8192*8,$left)); if ($chunk===false) break; echo $chunk; $left -= strlen($chunk); flush(); if (connection_aborted()) break; }
    fclose($fp); exit;
}
function x_video_form($id) {
    $ta = 'width:100%;box-sizing:border-box;min-height:44px;font-family:inherit;font-size:12px;background:var(--inp,#0c0e14);color:var(--text2);border:1px solid var(--border);border-radius:6px;padding:11px;outline:none';
    return x_vid_assets().'<div class="vid-box"><button type="button" class="vid-add" onclick="vidTog(this)">'.svg('plus',12).' Video ekle</button><div class="vid-panel" style="display:none"><div class="vid-tabs"><button type="button" class="on" onclick="vidTab(this,0)">Dosya olarak yükle</button><button type="button" onclick="vidTab(this,1)">URL olarak ekle</button></div><div class="vid-pane"><div class="file-zone" id="'.$id.'"><span class="fzt">Video seçmek için tıklayın (mp4, webm, ogg, mov)</span><span class="fzn" style="display:none"></span><input type="file" name="video[]" multiple accept="video/*" onchange="fu(this,\''.$id.'\')"></div></div><div class="vid-pane" style="display:none"><textarea name="video_url" rows="2" placeholder="Video adresleri (her satıra bir adres) — mp4/webm linki, YouTube veya Vimeo" autocomplete="off" spellcheck="false" style="'.$ta.';transition:border-color .15s,box-shadow .15s" onfocus="this.style.borderColor=\'var(--green)\';this.style.boxShadow=\'0 0 0 2px color-mix(in srgb,var(--green) 35%,transparent)\'" onblur="this.style.borderColor=\'\';this.style.boxShadow=\'none\'"></textarea></div></div></div>';
}
function x_upload_assets() {
    static $d = false;
    if ($d) return '';
    $d = true;
    return <<<'EOT'
<style>
#upOv{position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:1000;display:none;align-items:center;justify-content:center;padding:16px}
#upOv.on{display:flex}
.up-box{width:380px;max-width:100%;background:var(--d1,#111318);border:1px solid var(--border,#1e2130);border-radius:10px;padding:20px;box-shadow:0 10px 40px rgba(0,0,0,.5);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
.up-t{color:#d1d5e0;font-size:13px;font-weight:700;margin-bottom:12px}
.up-bar{height:10px;background:var(--d2,#1a1d28);border-radius:6px;overflow:hidden}
.up-fill{height:100%;width:0;background:var(--green,#b71c1c);border-radius:6px;transition:width .15s linear}
.up-row{display:flex;justify-content:space-between;gap:10px;margin-top:10px;font-size:12px;color:#8b8fa3}
.up-pct{color:var(--hi,#fff);font-weight:800;font-size:15px}
.up-err{color:var(--green,#ff5c65);margin-top:12px;font-size:12px;display:none}
.up-x{margin-top:14px;padding:7px 14px;border-radius:6px;border:1px solid var(--border,#1e2130);background:transparent;color:#d1d5e0;font-size:12px;cursor:pointer;font-family:inherit}
.up-x:hover{border-color:var(--green,#b71c1c);color:var(--green,#ff5c65)}
</style>
<div id="upOv"><div class="up-box"><div class="up-t" id="upT">Yükleniyor...</div><div class="up-bar"><div class="up-fill" id="upF"></div></div><div class="up-row"><span class="up-pct" id="upP">%0</span><span id="upI"></span></div><div class="up-err" id="upE"></div><button type="button" class="up-x" id="upX">İptal</button></div></div>
<script>
(function(){
var ov=document.getElementById('upOv'),F=document.getElementById('upF'),P=document.getElementById('upP'),I=document.getElementById('upI'),T=document.getElementById('upT'),E=document.getElementById('upE'),X=document.getElementById('upX'),xhr=null,busy=false;
function fmtS(n){n=Math.max(0,Math.round(n));if(n<60)return n+' sn';var m=Math.floor(n/60);return m+' dk '+(n%60)+' sn'}
function fmtB(b){return b>=1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB'}
function hasFiles(f){var i=f.querySelectorAll('input[type=file]');for(var k=0;k<i.length;k++)if(i[k].files&&i[k].files.length)return true;return false}
function setP(p){p=Math.max(0,Math.min(100,p));F.style.width=p+'%';P.textContent='%'+Math.floor(p)}
function fail(msg){busy=false;E.textContent=msg;E.style.display='block';X.textContent='Kapat';T.textContent='Yükleme başarısız';I.textContent=''}
X.onclick=function(){if(xhr&&busy){xhr.abort()}busy=false;ov.classList.remove('on')};
window.addEventListener('beforeunload',function(e){if(busy){e.preventDefault();e.returnValue=''}});
document.addEventListener('submit',function(e){
    var f=e.target;
    if(e.defaultPrevented||!f||f.tagName!=='FORM'||(f.enctype||'').indexOf('multipart')<0)return;
    if(!hasFiles(f)){var emp=[].filter.call(f.querySelectorAll('input[type=file]'),function(i){return !i.disabled&&(!i.files||!i.files.length)});emp.forEach(function(i){i.disabled=true});if(emp.length)setTimeout(function(){emp.forEach(function(i){i.disabled=false})},0);return}
    e.preventDefault();
    var fd=new FormData(f),t0=Date.now();
    xhr=new XMLHttpRequest();busy=true;
    xhr.open('POST',f.getAttribute('action')||location.href);
    T.textContent='Yükleniyor...';E.style.display='none';X.textContent='İptal';setP(0);I.textContent='Başlıyor...';ov.classList.add('on');
    xhr.upload.onprogress=function(ev){
        if(!ev.lengthComputable)return;
        var p=ev.loaded/ev.total*100,el=(Date.now()-t0)/1000,sp=el>0?ev.loaded/el:0;
        setP(p);
        I.textContent=fmtB(ev.loaded)+' / '+fmtB(ev.total)+(sp>0&&ev.loaded<ev.total&&el>0.7?' · '+fmtS((ev.total-ev.loaded)/sp)+' kaldı':'');
    };
    xhr.upload.onload=function(){setP(100);T.textContent='Kaydediliyor...';I.textContent='Sunucu işliyor'};
    xhr.onload=function(){
        if(xhr.status>=200&&xhr.status<400){busy=false;setP(100);T.textContent='Tamamlandı';I.textContent='';var u=xhr.responseURL||location.href;location.href=u}
        else if(xhr.status===403&&/Güvenlik doğrulaması/.test(xhr.responseText||''))fail('Oturum doğrulaması başarısız (403). Sayfayı yenileyip tekrar deneyin.');
        else if(xhr.status===403)fail('Sunucu isteği reddetti (403). Boyut sorunu değil: sunucunun güvenlik duvarı (ModSecurity / Cloudflare WAF) PHP kodu içeren dosyayı engelliyor olabilir. Hosting panelinden kuralı kapatın ya da dosyayı .txt uzantısıyla yükleyin ve "İndirme biçimi"nden .php seçin.');
        else if(xhr.status===413)fail('Dosya sunucunun yükleme sınırını aşıyor (413).');
        else fail('Sunucu hata verdi ('+xhr.status+'). Dosya boyutu sınırını kontrol edin.');
    };
    xhr.onerror=function(){fail('Bağlantı hatası. Lütfen tekrar deneyin.')};
    xhr.onabort=function(){busy=false};
    xhr.send(fd);
},false);
})();
</script>
EOT;
}
function x_vid_assets() {
    static $d = false;
    if ($d) return '';
    $d = true;
    return <<<'EOT'
<style>
.vid-add{padding:8px 12px;font-size:12px;font-family:inherit;border-radius:6px;border:1px solid var(--green,#b71c1c);background:transparent;color:var(--green,#ff5c65);cursor:pointer;display:inline-flex;align-items:center;gap:6px}
.vid-add:hover{background:color-mix(in srgb,var(--green,#b71c1c) 12%,transparent)}
.vid-panel{margin-top:8px}.vid-tabs{display:flex;gap:6px;margin-bottom:8px}
.vid-tabs button{padding:6px 10px;font-size:12px;font-family:inherit;border-radius:6px;border:1px solid var(--border);background:transparent;color:var(--text2);cursor:pointer}
.vid-tabs button.on{border-color:var(--green,#b71c1c);color:var(--green,#ff5c65)}
.vid-row{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--text2);margin:4px 0;word-break:break-all}
.vp{position:relative;background:#000;border-radius:8px;overflow:hidden;margin:10px 0;outline:none;user-select:none;-webkit-user-select:none;touch-action:manipulation}
.vp video{width:100%;max-height:70vh;display:block;background:#000}
.vp:fullscreen,.vp:-webkit-full-screen{border-radius:0;margin:0;width:100%;height:100%}
.vp:fullscreen video,.vp:-webkit-full-screen video{max-height:none;height:100%}
.vp-tap{position:absolute;left:0;right:0;top:0;bottom:46px;cursor:pointer}
.vp-fb{position:absolute;top:50%;transform:translateY(-50%);padding:10px 16px;border-radius:30px;background:rgba(0,0,0,.6);color:#fff;font-size:15px;font-weight:700;opacity:0;pointer-events:none;transition:opacity .15s}
.vp-fb.show{opacity:1}.vp-fb.l{left:12%}.vp-fb.r{right:12%}
.vp-big{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:54px;height:54px;border-radius:50%;background:rgba(0,0,0,.55);color:#fff;display:flex;align-items:center;justify-content:center;font-size:22px;pointer-events:none;opacity:0;transition:opacity .15s}
.vp.paused .vp-big{opacity:1}
.vp-bar{position:absolute;left:0;right:0;bottom:0;height:46px;display:flex;align-items:center;gap:8px;padding:0 10px;background:linear-gradient(transparent,rgba(0,0,0,.85));color:#fff;font-size:12px;transition:opacity .2s}
.vp.idle:not(.paused) .vp-bar{opacity:0}.vp.idle:not(.paused){cursor:none}
.vp-bar button{background:none;border:0;color:#fff;cursor:pointer;font-size:12px;font-family:inherit;padding:6px 7px;border-radius:5px;white-space:nowrap}
.vp-bar button:hover{background:rgba(255,255,255,.15)}
.vp-seek{flex:1;min-width:40px;height:4px;-webkit-appearance:none;appearance:none;background:rgba(255,255,255,.3);border-radius:3px;outline:none;cursor:pointer;padding:0;border:0}
.vp-seek::-webkit-slider-thumb{-webkit-appearance:none;width:12px;height:12px;border-radius:50%;background:var(--green,#b71c1c);border:0}
.vp-seek::-moz-range-thumb{width:12px;height:12px;border-radius:50%;background:var(--green,#b71c1c);border:0}
.vp-time{white-space:nowrap;font-variant-numeric:tabular-nums}
.vp-volw{display:inline-flex;align-items:center;gap:2px}
.vp-vol{width:70px;height:4px;-webkit-appearance:none;appearance:none;background:linear-gradient(to right,var(--green,#b71c1c) var(--p,100%),rgba(255,255,255,.3) var(--p,100%));border-radius:3px;outline:none;cursor:pointer;padding:0;border:0}
.vp-vol::-webkit-slider-thumb{-webkit-appearance:none;width:11px;height:11px;border-radius:50%;background:#fff;border:0}
.vp-vol::-moz-range-thumb{width:11px;height:11px;border-radius:50%;background:#fff;border:0}
.vp video{transform-origin:center center;will-change:transform}
.vp-tap{touch-action:pan-x pan-y}.vp-tap.zoomed{touch-action:none;cursor:grab}
.vp-gal .vp-stage{min-height:40px}
.vp-strip{display:flex;gap:6px;overflow-x:auto;padding:4px 2px 10px;margin-bottom:6px;scrollbar-width:thin;scrollbar-color:var(--border) transparent;-webkit-overflow-scrolling:touch}
.vp-th{position:relative;width:72px;height:56px;flex:0 0 auto;border-radius:6px;border:2px solid var(--border);background:#000;overflow:hidden;cursor:pointer;opacity:.65;transition:.15s;padding:0}
.vp-th:hover{opacity:1}.vp-th.on{border-color:var(--green);opacity:1}
.vp-th video,.vp-th img{width:100%;height:100%;object-fit:cover;display:block;pointer-events:none}
.vp-th .vp-ph{width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:var(--text3);font-size:18px}
.vp-th .play-badge{width:16px;height:16px;line-height:16px;font-size:7px}
.vp-th .vp-no{position:absolute;left:3px;top:2px;font-size:9px;font-weight:700;color:#fff;background:rgba(0,0,0,.6);border-radius:3px;padding:0 4px;line-height:14px}
.vid-row .vid-main{color:var(--green,#ff5c65);font-weight:700;font-size:11px}
.vid-row .vid-mk{padding:3px 8px;font-size:11px;font-family:inherit;background:transparent;color:var(--text2);border:1px solid var(--border);border-radius:4px;cursor:pointer}
.vid-row .vid-mk:hover{border-color:var(--green,#b71c1c);color:var(--green,#ff5c65)}
.thumb-wrap,.thumb-vid{position:relative;display:inline-block;width:36px;height:36px;vertical-align:top}
.thumb-vid{border-radius:4px;overflow:hidden;border:1px solid var(--border);background:#000;cursor:pointer}
.thumb-vid video,.thumb-vid img{width:100%;height:100%;object-fit:cover;display:block;pointer-events:none}
.play-badge{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:18px;height:18px;border-radius:50%;background:rgba(0,0,0,.65);color:#fff;font-size:8px;line-height:18px;text-align:center;pointer-events:none;padding-left:1px;box-sizing:border-box}
.play-badge.sm{left:auto;top:auto;right:-3px;bottom:-3px;transform:none;width:15px;height:15px;line-height:15px;font-size:7px;background:var(--green,#b71c1c);border:1px solid #fff}
.vp-embed{width:100%;aspect-ratio:16/9;border:0;border-radius:8px;margin:10px 0;display:block;background:#000}
@media(max-width:560px){.vp-vol{width:44px}.vp-bar{gap:2px;padding:0 4px}.vp-time{font-size:10px}.vp-bar button{padding:6px 4px}}
</style>
<script>
function vidStopAll(){var v=document.querySelectorAll('.vp video');for(var i=0;i<v.length;i++)v[i].pause()}
function vidTog(b){var p=b.parentNode.querySelector('.vid-panel');p.style.display=p.style.display==='none'?'':'none'}
function vidTab(b,i){var bx=b.closest('.vid-box'),t=bx.querySelectorAll('.vid-tabs button'),p=bx.querySelectorAll('.vid-pane');for(var j=0;j<t.length;j++){t[j].classList.toggle('on',j===i);p[j].style.display=j===i?'':'none'}}
function vTy(n){return n&&n._t&&n._t!=='note'?'&type='+n._t:''}
function vidFmt(t){if(!isFinite(t))t=0;t=Math.floor(t);var h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=t%60;return (h?h+':'+(m<10?'0':''):'')+m+':'+(s<10?'0':'')+s}
function vpCell(note,vd,i){
    if(vd.t==='e')return '<iframe class="vp-embed" src="'+String(vd.v).replace(/"/g,'&quot;')+'" allow="accelerometer;autoplay;encrypted-media;picture-in-picture;fullscreen" allowfullscreen loading="lazy"></iframe>';
    var src=vd.t==='f'?'?action=vid&id='+encodeURIComponent(note.id)+'&n='+i+'&f='+encodeURIComponent(vd.v)+vTy(note):String(vd.v).replace(/"/g,'&quot;');
    return '<div class="vp paused" tabindex="0"><video preload="metadata" playsinline src="'+src+'"></video><div class="vp-tap"></div><div class="vp-fb l"></div><div class="vp-fb r"></div><div class="vp-big">&#9654;</div><div class="vp-bar"><button type="button" data-a="play" title="Oynat / Duraklat">&#9654;</button><button type="button" data-a="back" title="Geri sar">&#9194; 10</button><button type="button" data-a="fwd" title="İleri sar">10 &#9193;</button><input class="vp-seek" type="range" min="0" max="1000" value="0" step="1"><span class="vp-time">0:00 / 0:00</span><button type="button" data-a="zoom" title="Yakınlaştır (iki parmakla da yapabilirsiniz)">&#128269; 1×</button><span class="vp-volw"><button type="button" data-a="mute" title="Sesi aç / kapat">&#128266;</button><input class="vp-vol" type="range" min="0" max="100" value="100" step="1" title="Ses seviyesi" aria-label="Ses seviyesi"></span><button type="button" data-a="fs" title="Tam ekran">&#9974;</button></div></div>';
}
function vpThumb(note,vd,i){
    var inner='';
    if(vd.t==='e'){
        var m=String(vd.v).match(/\/embed\/([A-Za-z0-9_-]{11})/);
        inner=m?'<img src="https://i.ytimg.com/vi/'+m[1]+'/mqdefault.jpg" alt="" loading="lazy">':'<span class="vp-ph">&#127916;</span>';
    }else{
        var src=vd.t==='f'?'?action=vid&id='+encodeURIComponent(note.id)+'&n='+i+'&f='+encodeURIComponent(vd.v)+vTy(note):String(vd.v).replace(/"/g,'&quot;');
        inner='<video src="'+src+'#t=0.1" preload="metadata" muted playsinline tabindex="-1"></video>';
    }
    return inner+'<span class="play-badge">&#9654;</span><span class="vp-no">'+(i+1)+'</span>';
}
function vpHtml(note){
    var v=note.videos||[];if(!v.length)return '';
    var order=[],mv=(note.main_video!=null&&v[note.main_video])?+note.main_video:-1,i,k,th='';
    if(mv>=0)order.push(mv);
    for(i=0;i<v.length;i++)if(i!==mv)order.push(i);
    if(order.length<2)return vpCell(note,v[order[0]],order[0]);
    window._vpNote=note;
    for(k=0;k<order.length;k++)th+='<button type="button" class="vp-th'+(k?'':' on')+'" title="Video '+(order[k]+1)+'" onclick="vpPick(this,'+order[k]+')">'+vpThumb(note,v[order[k]],order[k])+'</button>';
    return '<div class="vp-gal"><div class="vp-stage">'+vpCell(note,v[order[0]],order[0])+'</div><div class="vp-strip">'+th+'</div></div>';
}
function vpPick(btn,i){
    var note=window._vpNote;if(!note)return;
    var g=btn.closest('.vp-gal'),st=g.querySelector('.vp-stage'),b=g.querySelectorAll('.vp-th');
    vidStopAll();
    for(var j=0;j<b.length;j++)b[j].classList.toggle('on',b[j]===btn);
    st.innerHTML=vpCell(note,note.videos[i],i);
    vpInit(st);
    var v=st.querySelector('video');
    if(v){var pr=v.play();if(pr&&pr.catch)pr.catch(function(){})}
}
function vpInit(root){
    var ps=root.querySelectorAll('.vp');
    for(var k=0;k<ps.length;k++)(function(p){
        if(p._vp)return;p._vp=1;
        var v=p.querySelector('video'),tap=p.querySelector('.vp-tap'),seek=p.querySelector('.vp-seek'),tm=p.querySelector('.vp-time'),
            fbL=p.querySelector('.vp-fb.l'),fbR=p.querySelector('.vp-fb.r'),pb=p.querySelector('[data-a=play]'),mb=p.querySelector('[data-a=mute]'),vol=p.querySelector('.vp-vol'),volw=p.querySelector('.vp-volw'),zb=p.querySelector('[data-a=zoom]'),
            st={'-1':{n:0,tot:0,t:0,h:0},'1':{n:0,tot:0,t:0,h:0}},idleT=0,drag=false,z={s:1,x:0,y:0};
        function toggle(){if(v.paused)v.play();else v.pause()}
        function jump(sec){var d=v.duration||0;var t=v.currentTime+sec;v.currentTime=Math.max(0,d?Math.min(d,t):t)}
        function fb(side,tot){var e=side<0?fbL:fbR;e.textContent=(side<0?'⏪ -':'⏩ +')+tot+' sn';e.classList.add('show');clearTimeout(e._h);e._h=setTimeout(function(){e.classList.remove('show')},650)}
        function noTap(){p._nt=Date.now()}
        function zoneTap(side,fromBtn){
            var s=st[side],now=Date.now();
            if(now-s.t>700){s.n=0;s.tot=0}
            s.t=now;s.n++;
            clearTimeout(s.h);
            if(fromBtn){s.tot+=10;jump(side*10);fb(side,s.tot);return}
            if(s.n===1){s.h=setTimeout(function(){s.n=0;toggle()},320);return}
            s.tot+=10;jump(side*10);fb(side,s.tot);
        }
        tap.addEventListener('click',function(e){
            if(Date.now()-(p._nt||0)<400)return;
            var r=tap.getBoundingClientRect(),x=(e.clientX-r.left)/r.width;
            if(x<.35)zoneTap(-1,false);else if(x>.65)zoneTap(1,false);else toggle();
            p.focus&&p.focus({preventScroll:true});
        });
        function apply(){
            var w=p.clientWidth,h=v.clientHeight,mx=(z.s-1)*w/2,my=(z.s-1)*h/2;
            z.x=Math.max(-mx,Math.min(mx,z.x));z.y=Math.max(-my,Math.min(my,z.y));
            v.style.transform=z.s===1?'':'translate('+z.x+'px,'+z.y+'px) scale('+z.s+')';
            tap.classList.toggle('zoomed',z.s>1);
            zb.innerHTML='&#128269; '+(Math.round(z.s*10)/10)+'×';
        }
        function setScale(s){z.s=Math.max(1,Math.min(5,s));if(z.s===1){z.x=0;z.y=0}apply()}
        zb.onclick=function(){setScale(z.s<1.5?2:(z.s<2.5?3:1))};
        function dist(e){var a=e.touches[0],b=e.touches[1];return Math.sqrt(Math.pow(a.clientX-b.clientX,2)+Math.pow(a.clientY-b.clientY,2))}
        var tp={m:0,d:1,s:1,x:0,y:0,ox:0,oy:0,mv:0};
        function one(e){tp.m=1;tp.x=e.touches[0].clientX;tp.y=e.touches[0].clientY;tp.ox=z.x;tp.oy=z.y;tp.mv=0}
        tap.addEventListener('touchstart',function(e){
            if(e.touches.length===2){tp.m=2;tp.d=dist(e)||1;tp.s=z.s;noTap();e.preventDefault()}
            else if(e.touches.length===1&&z.s>1)one(e);
        },{passive:false});
        tap.addEventListener('touchmove',function(e){
            if(tp.m===2&&e.touches.length===2){setScale(tp.s*dist(e)/tp.d);noTap();e.preventDefault()}
            else if(tp.m===1&&e.touches.length===1){
                var dx=e.touches[0].clientX-tp.x,dy=e.touches[0].clientY-tp.y;
                if(Math.abs(dx)+Math.abs(dy)>6){tp.mv=1;noTap()}
                z.x=tp.ox+dx;z.y=tp.oy+dy;apply();e.preventDefault();
            }
        },{passive:false});
        tap.addEventListener('touchend',function(e){
            if(tp.m===2){noTap();if(e.touches.length===1&&z.s>1)one(e);else tp.m=0}
            else if(!e.touches.length){if(tp.mv)noTap();tp.m=0}
        });
        tap.addEventListener('mousedown',function(e){
            if(z.s<=1||e.button!==0)return;
            var sx=e.clientX,sy=e.clientY,ox=z.x,oy=z.y,moved=false;
            function mm(ev){var dx=ev.clientX-sx,dy=ev.clientY-sy;if(Math.abs(dx)+Math.abs(dy)>4){moved=true;noTap()}z.x=ox+dx;z.y=oy+dy;apply()}
            function mu(){document.removeEventListener('mousemove',mm);document.removeEventListener('mouseup',mu);if(moved)noTap()}
            document.addEventListener('mousemove',mm);document.addEventListener('mouseup',mu);e.preventDefault();
        });
        p.addEventListener('wheel',function(e){if(!(e.ctrlKey||e.metaKey))return;e.preventDefault();setScale(z.s*(e.deltaY<0?1.15:0.87))},{passive:false});
        p.querySelector('[data-a=back]').onclick=function(){zoneTap(-1,true)};
        p.querySelector('[data-a=fwd]').onclick=function(){zoneTap(1,true)};
        pb.onclick=toggle;
        var volOk=true;
        try{var tv=v.volume;v.volume=.5;volOk=Math.abs(v.volume-.5)<.01;v.volume=tv}catch(ex){volOk=false}
        if(!volOk&&vol)vol.style.display='none';
        function vSync(){
            var l=v.muted?0:v.volume,pc=Math.round(l*100);
            if(vol){vol.value=pc;vol.style.setProperty('--p',pc+'%')}
            mb.innerHTML=l===0?'&#128263;':(l<.4?'&#128264;':(l<.7?'&#128265;':'&#128266;'));
        }
        function saveVol(){try{localStorage.setItem('vpVol',String(v.muted?0:v.volume))}catch(ex){}}
        function setVol(x){x=Math.max(0,Math.min(1,x));v.volume=x;v.muted=(x===0);saveVol();vSync()}
        function stepVol(d){setVol((v.muted?0:v.volume)+d)}
        v.addEventListener('volumechange',vSync);
        if(vol){
            vol.addEventListener('input',function(){setVol(vol.value/100)});
            vol.addEventListener('click',function(e){e.stopPropagation()});
        }
        if(volw)volw.addEventListener('wheel',function(e){e.preventDefault();stepVol(e.deltaY<0?.05:-.05)},{passive:false});
        mb.onclick=function(){
            if(v.muted||v.volume===0){v.muted=false;if(v.volume===0)v.volume=.5}else{v.muted=true}
            saveVol();vSync();
        };
        try{var sv=parseFloat(localStorage.getItem('vpVol'));if(volOk&&!isNaN(sv)){v.volume=Math.max(0,Math.min(1,sv));v.muted=(sv===0)}}catch(ex){}
        vSync();
        function fsEl(){return document.fullscreenElement||document.webkitFullscreenElement}
        function fs(){
            if(fsEl()===p){(document.exitFullscreen||document.webkitExitFullscreen).call(document);return}
            var f=p.requestFullscreen||p.webkitRequestFullscreen;
            if(f){f.call(p)}else if(v.webkitEnterFullscreen){v.webkitEnterFullscreen()}
        }
        p.querySelector('[data-a=fs]').onclick=fs;
        v.addEventListener('play',function(){p.classList.remove('paused');pb.innerHTML='&#10074;&#10074;';var o=document.querySelectorAll('.vp video');for(var q=0;q<o.length;q++)if(o[q]!==v)o[q].pause()});
        v.addEventListener('pause',function(){p.classList.add('paused');pb.innerHTML='&#9654;'});
        v.addEventListener('timeupdate',function(){if(!drag&&v.duration)seek.value=Math.round(v.currentTime/v.duration*1000);tm.textContent=vidFmt(v.currentTime)+' / '+vidFmt(v.duration)});
        v.addEventListener('loadedmetadata',function(){tm.textContent=vidFmt(0)+' / '+vidFmt(v.duration)});
        seek.addEventListener('input',function(){drag=true;if(v.duration)v.currentTime=seek.value/1000*v.duration});
        seek.addEventListener('change',function(){drag=false});
        function wake(){p.classList.remove('idle');clearTimeout(idleT);idleT=setTimeout(function(){p.classList.add('idle')},2500)}
        p.addEventListener('mousemove',wake);p.addEventListener('touchstart',wake,{passive:true});p.addEventListener('click',wake);
        p.addEventListener('keydown',function(e){
            if(e.target===seek||e.target===vol)return;
            var kk=e.key;
            if(kk===' '||kk==='k'){e.preventDefault();toggle()}
            else if(kk==='ArrowLeft'){e.preventDefault();zoneTap(-1,true)}
            else if(kk==='ArrowRight'){e.preventDefault();zoneTap(1,true)}
            else if(kk==='f'||kk==='F'){e.preventDefault();fs()}
            else if(kk==='m'||kk==='M'){mb.onclick()}
            else if(kk==='ArrowUp'){e.preventDefault();stepVol(.1)}
            else if(kk==='ArrowDown'){e.preventDefault();stepVol(-.1)}
            else if(kk==='+'||kk==='='){setScale(z.s+.5)}
            else if(kk==='-'){setScale(z.s-.5)}
        });
    })(ps[k]);
}
function vidEditHtml(note){
    var v=note.videos||[];if(!v.length)return '';
    var mv=(note.main_video!=null&&v[note.main_video])?+note.main_video:(note._n?-1:0);
    var id=encodeURIComponent(note.id);
    var h='<div class="gal-wrap" style="margin-bottom:8px"><div class="gal-bar"><label style="display:flex;align-items:center;gap:5px;cursor:pointer"><input type="checkbox" class="gal-all" onchange="galSel(this)"> Tüm videoları seç</label><button type="button" class="gal-del" disabled onclick="galAct(this,\'?action=vid_remove&id='+id+vTy(note)+'\',\'Seçili videolar silinsin mi?\')">Seçilenleri sil</button><span class="bulk-count" style="display:none"></span></div>';
    for(var i=0;i<v.length;i++){
        var nm=v[i].t==='f'?(v[i].n||v[i].v):v[i].v;
        h+='<div class="vid-row"><input type="checkbox" class="gk" name="vns[]" value="'+i+'" onchange="galSel(this)"><span style="flex:1">&#9654; Video '+(i+1)+' — '+String(nm).replace(/</g,'&lt;')+'</span>'+(i===mv?'<span class="vid-main">Ana video</span>':'<button type="button" class="vid-mk" onclick="galAct(this,\'?action=vid_main&id='+id+vTy(note)+'&n='+i+'\')">Ana yap</button>')+'</div>';
    }
    return h+'</div>';
}
</script>
EOT;
}
function x_img_redirect_flag() { return (!empty($GLOBALS['x_img_url_failed']) ? '&imgerr=1' : '').(!empty($GLOBALS['x_img_file_failed']) ? '&imgfile='.$GLOBALS['x_img_file_failed'] : ''); }
function x_img_v($file) {
    $file=(string)$file; if ($file==='') return 0;
    $p=SCREENSHOTS_DIR.'/'.$file;
    return is_file($p) ? (int)filemtime($p) : 0;
}
function x_img_ok($f) { $f=(string)$f; return $f!=='' && is_file(SCREENSHOTS_DIR.'/'.basename($f)); }
function x_img_send($ip) {
    if (!is_file($ip)) return false;
    session_write_close();
    $mt=(int)filemtime($ip); $etag='"'.md5($ip.'|'.$mt.'|'.filesize($ip)).'"';
    while (ob_get_level()) ob_end_clean();
    header_remove('Pragma');
    header('Cache-Control: private, max-age=31536000, immutable');
    header('Expires: '.gmdate('D, d M Y H:i:s', time()+31536000).' GMT');
    header('Last-Modified: '.gmdate('D, d M Y H:i:s', $mt).' GMT');
    header('ETag: '.$etag);
    $inm=isset($_SERVER['HTTP_IF_NONE_MATCH'])?trim($_SERVER['HTTP_IF_NONE_MATCH']):'';
    $ims=isset($_SERVER['HTTP_IF_MODIFIED_SINCE'])?strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE']):false;
    if ($inm===$etag || ($inm==='' && $ims!==false && $ims>=$mt)) { http_response_code(304); exit; }
    header('Content-Type: '.(mime_content_type($ip)?:'image/jpeg'));
    header('Content-Length: '.filesize($ip));
    readfile($ip); exit;
}
function x_acc_load() {
    $j = array(); $d = x_data();
    if (is_array($d) && isset($d['accounts']) && is_array($d['accounts'])) $j = $d['accounts'];
    else { $raw = @file_get_contents(ACCOUNTS_FILE); if ($raw !== false) { $p = strpos($raw, "\n"); if ($p !== false) { $t = json_decode(substr($raw, $p + 1), true); if (is_array($t)) $j = $t; } } }
    if (!isset($j['builtin']) || !is_array($j['builtin'])) $j['builtin'] = array();
    if (!isset($j['users']) || !is_array($j['users'])) $j['users'] = array();
    return $j;
}
function x_acc_save($a) {
    $d = x_data();
    if (!is_array($d)) return false;
    $d['accounts'] = $a;
    return x_save($d);
}
function x_acc_same($a) {
    $chk = x_acc_load();
    return json_encode($chk['builtin']) === json_encode($a['builtin']) && json_encode($chk['users']) === json_encode($a['users']);
}
function x_acc_commit($a) {
    if (x_acc_save($a) && x_acc_same($a)) return true;
    $_SESSION['x_acc_diag'] = 'veri dosyası '.(file_exists(DATA_FILE) ? 'var' : 'yok').', yazılabilir: '.(is_writable(DATA_FILE) ? 'evet' : 'hayır');
    return false;
}
function x_perm_groups() {
    return array(
        array('Dosya Arşivi', array('dosya_add'=>'Dosya ekleyebilsin (yükle / oluştur)', 'dosya_edit'=>'Dosyayı düzenleyebilsin', 'dosya_delete'=>'Dosya silebilsin', 'dosya_pin'=>'Dosyayı sabitleyebilsin')),
        array('GitHub', array('github_add'=>'Bağlantı ekleyebilsin', 'github_edit'=>'Bağlantıyı düzenleyebilsin', 'github_delete'=>'Bağlantı silebilsin', 'github_pin'=>'Bağlantıyı sabitleyebilsin')),
        array('Bilgiler', array('note_add'=>'Bilgi ekleyebilsin', 'note_edit'=>'Bilgiyi düzenleyebilsin', 'note_delete'=>'Bilgi silebilsin', 'note_pin'=>'Bilgiyi sabitleyebilsin')),
        array('Editör kuralları (yalnızca Editör rolü)', array('edit_others'=>'Başkalarının eklediklerini düzenleyebilsin', 'delete_others'=>'Başkalarının eklediklerini silebilsin', 'appr_add'=>'Eklediği şeyler süper admin onayına gitsin', 'appr_edit'=>'Düzenlemeleri süper admin onayına gitsin', 'appr_delete'=>'Silme işlemleri süper admin onayına gitsin', 'appr_cancel'=>'Bekleyen isteklerini iptal edebilsin')),
        array('Genel içerik', array('media_delete'=>'Resim / video / ek dosya silebilsin', 'media_main'=>'Ana resim / videoyu seçebilsin', 'reorder'=>'Sıralamayı (sürükle-bırak) değiştirebilsin', 'cat_add'=>'Kategori ekleyebilsin', 'cat_edit'=>'Kategori düzenleyebilsin', 'cat_delete'=>'Kategori silebilsin', 'appr_review'=>'Editörlerden gelen istekleri onaylayıp reddedebilsin', 'acc_block'=>'Kullanıcıları (ziyaretçi/editör/yönetici) engelleyebilsin ve engelini kaldırabilsin', 'history'=>'Düzenleme geçmişini görebilsin ve geri alabilsin', 'php_ext'=>'Dosyayı .php uzantısıyla sunucuya kaydetmeyi seçebilsin (yalnızca Süper Admin verebilir)', 'home_edit'=>'Ana sayfa yazısını düzenleyebilsin')),
        array('İstatistik', array('analytics'=>'İstatistik sekmesini görebilsin', 'logins'=>'Son girişler ve IP kayıtlarını görebilsin', 'ip_ban'=>'IP engelleyip engelini kaldırabilsin', 'analytics_reset'=>'İstatistikleri sıfırlayabilsin', 'hide_super'=>'Süper Admin\'in işlemlerini ve IP\'sini GİZLE (görmesin)', 'logs'=>'Son işlemleri görebilsin (İstatistik sekmesinde)')),
        array('Ayarlar', array('settings'=>'Ayarlar sekmesini görebilsin', 'settings_tabs'=>'Sekmeleri yönetebilsin (ekle / sil / ad / sıra)', 'settings_site'=>'Site, görünüm ve temaları değiştirebilsin', 'settings_ban'=>'Engelleme sayfasını düzenleyebilsin', 'settings_vpn'=>'VPN ayarlarını değiştirebilsin', 'settings_cf'=>'Cloudflare ayarını değiştirebilsin', 'acc_manage'=>'Hesapları yönetebilsin (ekle / sil / şifre)'))
    );
}
function x_perm_labels() { $o = array(); foreach (x_perm_groups() as $g) foreach ($g[1] as $k=>$l) $o[$k] = $l; return $o; }
function x_perm_keys() { return array_keys(x_perm_labels()); }
function x_ev_id($e) { return substr(md5(json_encode($e)), 0, 16); }
function x_stats_ok() { return x_perm('analytics') || x_perm('logins') || x_can_logs(); }
function x_perm_default($role) { if ($role==='editor') return x_ed_default(); return $role==='admin' ? array_values(array_diff(x_perm_keys(), array('logs','hide_super','php_ext','history','acc_block','appr_review'), x_ed_rule_keys())) : array(); }
function x_acc_perms($ac) {
    $all = x_perm_keys();
    if ((isset($ac['id']) && $ac['id']==='builtin_admin') || !empty($ac['super'])) return $all;
    $role = isset($ac['role']) ? $ac['role'] : 'visitor';
    if (isset($ac['perms']) && is_array($ac['perms'])) $p = array_values(array_intersect($all, $ac['perms'])); else $p = x_perm_default($role);
    $p = array_values(array_diff($p, array('logs')));
    if ($role==='editor') $p = array_values(array_intersect($p, x_ed_keys()));
    if (!empty($ac['can_logs']) && $role!=='editor') $p[] = 'logs';
    return $p;
}
function x_perm_panel($id, $cur, $attr) {
    $keys = x_perm_keys(); $n = 0; foreach ($keys as $k) if (in_array($k, $cur, true)) $n++;
    $h = '<details class="sx-pd" '.$attr.'><summary>Yetkiler <span class="sx-pc">'.$n.'/'.count($keys).'</span> <span class="muted">(açıp seçin)</span></summary>';
    $h .= '<div class="sx-ptb"><span class="muted" style="margin-right:4px">Şablon:</span><button type="button" class="btn btn-xs" onclick="sxPTpl(this,\'visitor\')" title="Hiç yetki yok">Ziyaretçi</button> <button type="button" class="btn btn-xs" onclick="sxPTpl(this,\'editor\')" title="Ekleme / düzenleme + onay kuralları">Editör</button> <button type="button" class="btn btn-xs" onclick="sxPTpl(this,\'admin\')" title="Tüm yönetim yetkileri">Yönetici</button> '.(x_super() ? '<button type="button" class="btn btn-xs" onclick="sxPTpl(this,\'super\')" title="Tüm yetkiler (Süper Admin dahil)">Süper Admin</button> ' : '').'<span style="margin:0 6px;color:var(--border)">|</span><button type="button" class="btn btn-xs" onclick="sxPAll(this,true)">Hepsini seç</button> <button type="button" class="btn btn-xs" onclick="sxPAll(this,false)">Hiçbirini seçme</button></div><div class="sx-pbox">';
    $edk = x_ed_keys(); $edr = x_ed_rule_keys();
    foreach (x_perm_groups() as $g) {
        $gk = array_keys($g[1]); $ged = count(array_intersect($gk, $edk)) > 0; $gonly = count(array_diff($gk, $edr)) === 0;
        $h .= '<div class="sx-pg'.($ged ? ' ed' : '').($gonly ? ' edonly' : '').'"><div class="sx-pgh"><span>'.x_h($g[0]).'</span><button type="button" class="btn btn-xs" onclick="sxPGrp(this)">Grubu seç / kaldır</button></div>';
        foreach ($g[1] as $k=>$l) $h .= '<label class="sx-pi'.(in_array($k, $edk, true) ? ' ed' : '').(in_array($k, $edr, true) ? ' edr' : '').'"><input type="checkbox" class="cbx" name="perm['.x_h($id).'][]" value="'.$k.'" onchange="sxPCnt(this.closest(\'.sx-pd\'))"'.(in_array($k, $cur, true) ? ' checked' : '').'> <span>'.x_h($l).'</span></label>';
        $h .= '</div>';
    }
    return $h.'</div><input type="hidden" name="permset['.x_h($id).']" value="1"></details>';
}
function x_perm_post($id) {
    $all = x_perm_keys(); $o = array();
    if (isset($_POST['perm']) && is_array($_POST['perm']) && isset($_POST['perm'][$id]) && is_array($_POST['perm'][$id])) foreach ($_POST['perm'][$id] as $pv) if (is_string($pv) && in_array($pv, $all, true) && !in_array($pv, $o, true)) $o[] = $pv;
    return $o;
}
function x_emoji_bar() {
    $l = array('⭐','🌟','👑','🔥','⚡','💎','🛡️','🚀','❤️','✅','🏆','💀','🎯','🍀','🌙','☀️','🦅','🐺','✨','💫');
    $h = '<span class="emo-wrap"><button type="button" class="emo-t" onclick="this.parentNode.classList.toggle(\'open\')" title="Rozete ikon / emoji ekle">'.svg('star',11).' İkon ekle</button><span class="emo-bar"><button type="button" class="emo-b emo-txt" onclick="emoPick(this)">Süper Admin</button>'; foreach ($l as $e) $h .= '<button type="button" class="emo-b" onclick="emoPick(this)">'.$e.'</button>'; return $h.'</span></span>';
}
function x_badge_clean($v) { return is_string($v) ? (function_exists('mb_substr') ? mb_substr(trim(preg_replace('/\s+/u', ' ', $v)), 0, 24, 'UTF-8') : substr(trim($v), 0, 24)) : ''; }
function x_acc_apply(&$t, $nm, $hash, $role, $badge, $perms, $logs, $bcol = null) {
    if ($bcol!==null) { if ($bcol==='') unset($t['badge_color']); else $t['badge_color'] = $bcol; }
    if ($nm!=='') $t['name'] = $nm;
    if ($hash!==null) $t['hash'] = password_hash($hash, PASSWORD_DEFAULT);
    if ($role!==null) $t['role'] = $role;
    if ($badge!==null) { if ($badge==='') unset($t['badge']); else $t['badge'] = $badge; }
    if ($perms!==null) $t['perms'] = $perms;
    if ($logs!==null) { if ($logs) $t['can_logs'] = true; else unset($t['can_logs']); }
}
function x_accounts() {
    $a = x_acc_load(); $out = array();
    $defs = array('admin'=>array(PASS_HASH_ADMIN,'Yönetici'), 'visitor'=>array(PASS_HASH_VISITOR,'Ziyaretçi'));
    foreach ($defs as $r=>$d) {
        $b = (isset($a['builtin'][$r]) && is_array($a['builtin'][$r])) ? $a['builtin'][$r] : array();
        if ($r==='visitor' && !empty($b['deleted'])) continue;
        $role = ($r==='visitor' && isset($b['role']) && ($b['role']==='admin' || $b['role']==='visitor')) ? $b['role'] : $r;
        $row = array('id'=>'builtin_'.$r, 'name'=>((isset($b['name']) && is_string($b['name']) && trim($b['name'])!=='') ? $b['name'] : $d[1]), 'role'=>$role, 'hash'=>((isset($b['hash']) && is_string($b['hash']) && $b['hash']!=='') ? $b['hash'] : $d[0]), 'builtin'=>true, 'badge'=>x_badge_clean(isset($b['badge']) ? $b['badge'] : ''), 'badge_color'=>((isset($b['badge_color']) && x_color_ok($b['badge_color'])) ? $b['badge_color'] : ''));
        if ($r==='visitor') { $row['can_logs'] = !empty($b['can_logs']); if (isset($b['perms']) && is_array($b['perms'])) $row['perms'] = $b['perms']; }
        $out[] = $row;
    }
    foreach ($a['users'] as $u) {
        if (!is_array($u) || !isset($u['id'],$u['name'],$u['role'],$u['hash']) || !is_string($u['id']) || !is_string($u['hash'])) continue;
        if ($u['role']!=='admin' && $u['role']!=='visitor' && $u['role']!=='editor') continue;
        $row = array('id'=>$u['id'], 'name'=>(string)$u['name'], 'role'=>$u['role'], 'hash'=>$u['hash'], 'builtin'=>false, 'super'=>($u['role']==='admin' && !empty($u['super'])), 'can_logs'=>!empty($u['can_logs']), 'badge'=>x_badge_clean(isset($u['badge']) ? $u['badge'] : ''), 'badge_color'=>((isset($u['badge_color']) && x_color_ok($u['badge_color'])) ? $u['badge_color'] : ''));
        if (isset($u['perms']) && is_array($u['perms'])) $row['perms'] = $u['perms'];
        $out[] = $row;
    }
    return $out;
}
function x_acc_self() {
    $uid = isset($_SESSION['uid']) ? $_SESSION['uid'] : (isset($_SESSION['role']) ? 'builtin_'.$_SESSION['role'] : '');
    foreach (x_accounts() as $ac) if ($ac['id']===$uid) return $ac;
    return null;
}
function x_acc_confirm() {
    $p = (isset($_POST['confirm']) && is_string($_POST['confirm'])) ? trim($_POST['confirm']) : '';
    $me = x_acc_self();
    return ($me && $p!=='' && password_verify($p, $me['hash']));
}
function x_pass_dup($pw, $accs, $exceptId) {
    foreach ($accs as $ac) if ($ac['id']!==$exceptId && password_verify($pw, $ac['hash'])) return true;
    return false;
}

function x_super_root() { return isset($_SESSION['role']) && $_SESSION['role']==='admin' && isset($_SESSION['uid']) && $_SESSION['uid']==='builtin_admin'; }
function x_super_flag() {
    if (!isset($_SESSION['role']) || $_SESSION['role']!=='admin' || !isset($_SESSION['uid']) || !is_string($_SESSION['uid']) || $_SESSION['uid']==='builtin_admin') return false;
    static $c = array(); $u = $_SESSION['uid']; if (isset($c[$u])) return $c[$u];
    $a = x_acc_load(); $r = false;
    foreach ($a['users'] as $x) if (is_array($x) && isset($x['id']) && $x['id']===$u && isset($x['role']) && $x['role']==='admin' && !empty($x['super'])) { $r = true; break; }
    return $c[$u] = $r;
}
function x_super() { return x_super_root() || x_super_flag(); }
function x_role_def($ac) { if ((isset($ac['id']) && $ac['id']==='builtin_admin') || !empty($ac['super'])) return 'Süper Admin'; if (isset($ac['role']) && $ac['role']==='editor') return 'Editör'; return (isset($ac['role']) && $ac['role']==='admin') ? 'Yönetici' : 'Ziyaretçi'; }
function x_role_label($ac) { if (isset($ac['badge']) && is_string($ac['badge']) && trim($ac['badge'])!=='') return $ac['badge']; return x_role_def($ac); }
function x_badge_custom($uid) {
    static $m = null;
    if ($m === null) { $m = array(); foreach (x_accounts() as $ac) if ($ac['badge']!=='') $m[$ac['id']] = $ac['badge']; }
    return (is_string($uid) && isset($m[$uid])) ? $m[$uid] : '';
}
function x_badge_style($uid, $kind) {
    static $m = null;
    if ($m === null) { $m = array(); foreach (x_accounts() as $ac) if ($ac['badge_color']!=='') $m[$ac['id']] = $ac['badge_color']; }
    if (!is_string($uid) || !isset($m[$uid])) return '';
    $c = $m[$uid];
    if ($kind==='sx') return ';color:'.$c.';border-color:'.$c;
    if ($kind==='b') return ';color:'.$c.';background:'.$c.'26';
    return ';color:'.$c;
}
function x_badge_or($uid, $def) { $c = x_badge_custom($uid); return $c!=='' ? $c : $def; }
function x_route_perm($route) {
    $m = array('appr_ok'=>'appr_review','acc_block'=>'acc_block','hist_do'=>'history','hist_restore'=>'history','hist_clear'=>'history','upload'=>'dosya_add','create'=>'dosya_add','edit'=>'dosya_edit','delete'=>'dosya_delete','pin'=>'dosya_pin',
        'github_add'=>'github_add','github_edit'=>'github_edit','github_delete'=>'github_delete','github_pin'=>'github_pin','github_archive'=>'dosya_add',
        'note_add'=>'note_add','note_edit'=>'note_edit','note_delete'=>'note_delete','note_pin'=>'note_pin',
        'img_remove'=>'media_delete','img_bulk_remove'=>'media_delete','note_remove_image'=>'media_delete','remove_screenshot'=>'media_delete','github_remove_image'=>'media_delete','nfile_remove'=>'media_delete','vid_remove'=>'media_delete',
        'img_main'=>'media_main','vid_main'=>'media_main','reorder'=>'reorder','cat_add'=>'cat_add','cat_edit'=>'cat_edit','cat_delete'=>'cat_delete','home_save'=>'home_edit',
        'ip_ban'=>'ip_ban','ip_unban'=>'ip_ban','analytics_reset'=>'analytics_reset',
        'settings_save'=>'settings_tabs','tab_add'=>'settings_tabs','tab_delete'=>'settings_tabs','tab_delete_bulk'=>'settings_tabs',
        'site_save'=>'settings_site','login_preview'=>'settings_site','theme_bulk_delete'=>'settings_site','theme_apply'=>'settings_site','theme_default'=>'settings_site','theme_delete'=>'settings_site',
        'ban_save'=>'settings_ban','empty_save'=>'settings_site','actbtn_save'=>'settings_site','ip_unban_bulk'=>'ip_ban','ban_preview'=>'settings_ban','vpn_save'=>'settings_vpn','vpn_test'=>'settings_vpn','vpn_preview'=>'settings_vpn','cf_save'=>'settings_cf','acc_add'=>'acc_manage','acc_save'=>'acc_manage');
    if ($route==='bulk_delete') { $t = (isset($_POST['type']) && is_string($_POST['type'])) ? $_POST['type'] : ''; return $t==='dosya' ? 'dosya_delete' : ($t==='github' ? 'github_delete' : 'note_delete'); }
    if ($route==='editor_upload') return array('dosya_add','dosya_edit','github_add','github_edit','note_add','note_edit','home_edit','settings_ban','settings_vpn');
    return isset($m[$route]) ? $m[$route] : null;
}
function x_route_gate($route) {
    $need = x_route_perm($route);
    if ($need === null) return;
    $ok = false;
    foreach ((array)$need as $nk) if (x_perm($nk)) $ok = true;
    if ($ok) { x_ed_gate($route); return; }
    if ($route==='editor_upload') { while (ob_get_level()) ob_end_clean(); http_response_code(403); header('Content-Type: application/json; charset=utf-8'); echo json_encode(array('ok'=>false,'error'=>'Bu işlem için yetkiniz yok')); exit; }
    $fe = x_first_entry();
    header('Location: '.$_SERVER['SCRIPT_NAME'].x_entry_href($fe).'&msg=perm_denied'); exit;
}

function x_can_logs() {
    if (!x_admin()) return false;
    return x_perm('logs');
}
function x_super_ip_note(&$d) {
    $ip = x_ip();
    if (!is_string($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) return;
    $ip = x_ip_norm($ip);
    if (!isset($d['super_ips']) || !is_array($d['super_ips'])) $d['super_ips'] = array();
    $d['super_ips'][$ip] = date('Y-m-d H:i:s');
    if (count($d['super_ips']) > 50) { asort($d['super_ips']); $d['super_ips'] = array_slice($d['super_ips'], -50, 50, true); }
}
function x_super_ips($d) {
    $o = array();
    if (is_array($d) && isset($d['super_ips']) && is_array($d['super_ips'])) foreach ($d['super_ips'] as $k=>$v) $o[x_ip_norm((string)$k)] = true;
    if (x_super()) $o[x_ip_norm((string)x_ip())] = true;
    $sn = '';
    foreach (x_accounts() as $ac) if ($ac['id']==='builtin_admin') $sn = $ac['name'];
    if (is_array($d) && isset($d['analytics']) && is_array($d['analytics'])) {
        foreach ($d['analytics'] as $e) {
            if (!is_array($e) || !isset($e['type'], $e['action'], $e['ip']) || $e['type']!=='auth' || $e['action']!=='login' || !is_string($e['ip'])) continue;
            if (isset($e['uid']) && $e['uid']!=='') { if ($e['uid']==='builtin_admin') $o[x_ip_norm($e['ip'])] = true; }
            elseif ($sn!=='' && isset($e['role'], $e['name']) && $e['role']==='admin' && $e['name']===$sn) $o[x_ip_norm($e['ip'])] = true;
        }
    }
    return array_keys($o);
}
function x_act_write($fd) {
    $fl = JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE;
    $j = json_encode($fd, $fl);
    if ($j === false) $j = json_encode(x_utf8_fix($fd), $fl);
    if ($j === false) return false;
    return x_write_verified(DATA_FILE, X_GUARD.$j);
}
function x_act_log_many($rows) {
    if (!$rows) return;
    $fd = x_data(); if (!is_array($fd)) return;
    if (!isset($fd['activity']) || !is_array($fd['activity'])) $fd['activity'] = array();
    $uid = (isset($_SESSION['uid']) && is_string($_SESSION['uid'])) ? $_SESSION['uid'] : '';
    $nm = (isset($_SESSION['uname']) && is_string($_SESSION['uname'])) ? $_SESSION['uname'] : '';
    $rl = (isset($_SESSION['role']) && is_string($_SESSION['role'])) ? $_SESSION['role'] : '';
    foreach ($rows as $r) {
        $fd['activity'][] = array('id'=>'ac'.bin2hex(random_bytes(6)), 'time'=>date('Y-m-d H:i:s'), 'uid'=>$uid, 'name'=>$nm, 'role'=>$rl, 'ip'=>x_ip(), 'cat'=>(string)$r[0], 'text'=>(string)$r[1]);
    }
    if (count($fd['activity']) > 5000) $fd['activity'] = array_slice($fd['activity'], -5000);
    x_act_write($fd);
}
function x_act_log($cat, $text) { x_act_log_many(array(array($cat, $text))); }
function x_act_q($s, $n = 80) {
    $s = trim(preg_replace('/\s+/u', ' ', (string)$s));
    if (function_exists('mb_strlen') && mb_strlen($s, 'UTF-8') > $n) $s = mb_substr($s, 0, $n, 'UTF-8').'…';
    return $s;
}
function x_act_item_name($d, $id) {
    foreach (array('dosya','github','notes') as $c) {
        if (!isset($d[$c]) || !is_array($d[$c])) continue;
        foreach ($d[$c] as $it) {
            if (is_array($it) && isset($it['id']) && (string)$it['id']===(string)$id) {
                $n = isset($it['name']) ? $it['name'] : (isset($it['title']) ? $it['title'] : '');
                return is_string($n) ? $n : '';
            }
        }
    }
    return '';
}
function x_act_prepare($d, $route) {
    $GLOBALS['x_act_name'] = '';
    $GLOBALS['x_act_bulk'] = array();
    if (isset($_GET['id']) && is_string($_GET['id'])) $GLOBALS['x_act_name'] = x_act_item_name($d, $_GET['id']);
    if ($route==='bulk_delete') {
        $t = (isset($_POST['type']) && is_string($_POST['type'])) ? $_POST['type'] : '';
        $ids = array();
        if (isset($_POST['ids']) && is_array($_POST['ids'])) foreach ($_POST['ids'] as $iv) if (is_scalar($iv)) $ids[] = (string)$iv;
        $nm = array();
        if (in_array($t, array('dosya','github','notes'), true) && isset($d[$t]) && is_array($d[$t])) {
            foreach ($d[$t] as $it) {
                if (!is_array($it) || !isset($it['id']) || !in_array((string)$it['id'], $ids, true)) continue;
                $n = isset($it['name']) ? $it['name'] : (isset($it['title']) ? $it['title'] : '');
                if (is_string($n) && $n!=='') $nm[] = $n;
            }
        }
        $GLOBALS['x_act_bulk'] = $nm;
    }
}
function x_act_shutdown() {
    if (!x_admin() || !isset($GLOBALS['route']) || !empty($GLOBALS['x_act_skip'])) return;
    $route = $GLOBALS['route'];
    $loc = '';
    foreach (headers_list() as $h) if (stripos($h, 'Location:') === 0) $loc = trim(substr($h, 9));
    if ($loc === '') return;
    $qs = array();
    parse_str((string)parse_url($loc, PHP_URL_QUERY), $qs);
    $msg = (isset($qs['msg']) && is_string($qs['msg'])) ? $qs['msg'] : '';
    $nm = isset($GLOBALS['x_act_name']) ? x_act_q($GLOBALS['x_act_name']) : '';
    $q = $nm!=='' ? ': '.$nm : '';
    $pn = ''; foreach (array('name','title') as $pk) if ($pn==='' && isset($_POST[$pk]) && is_string($_POST[$pk])) $pn = x_act_q($_POST[$pk]);
    $pq = $pn!=='' ? ': '.$pn : '';
    $pip = (isset($_POST['ip']) && is_string($_POST['ip'])) ? x_act_q($_POST['ip'], 45) : '';
    $rows = array();
    if (($msg==='acc_saved' || $msg==='act_deleted' || $msg==='auth_deleted') && !empty($GLOBALS['x_act_detail']) && is_array($GLOBALS['x_act_detail'])) {
        $rows = $GLOBALS['x_act_detail'];
    } else {
        $m = array(
            'settings_saved'=>array('Ayarlar','Sekme ayarlarını kaydetti'),
            'tab_added'=>array('Ayarlar','Yeni sekme ekledi'),
            'arch_ok'=>array('GitHub','Kaydı Dosya Arşivi\'ne yedekledi'),'arch_part'=>array('GitHub','Kaydı Dosya Arşivi\'ne yedekledi (bazı linkler indirilemedi)'),
            'tab_deleted'=>array('Ayarlar','Sekme(leri) ve içindeki kayıtları sildi'),
            'site_saved'=>array('Ayarlar','Site / görünüm ayarlarını kaydetti'),
            'site_reset'=>array('Ayarlar','Görünüm ve site ayarlarını varsayılana döndürdü'),
            'base_saved'=>array('Ayarlar','Mevcut ayarları ana varsayılan yaptı'),
            'theme_saved'=>array('Ayarlar','Ayarları kaydedip tema olarak sakladı'),
            'theme_applied'=>array('Ayarlar','Tema uyguladı'),
            'theme_default_set'=>array('Ayarlar','Temayı varsayılan yaptı'),
            'theme_default_cleared'=>array('Ayarlar','Varsayılan temayı kaldırdı'),
            'theme_deleted'=>array('Ayarlar','Tema sildi'),
            'theme_bulk_deleted'=>array('Ayarlar','Seçili temaları sildi'),
            'cf_saved'=>array('Ayarlar','Cloudflare ayarını kaydetti'),
            'home_saved'=>array('Ayarlar','Ana sayfa içeriğini kaydetti'),
            'ban_saved'=>array('IP Engelleme','Engelleme sayfasını kaydetti'),
            'ban_bulk_removed'=>array('IP Engelleme','Seçili IP engellerini kaldırdı'),
            'appr_sent'=>array('Onay','İşlemi süper admin onayına gönderdi'),
            'appr_no'=>array('Onay','Bekleyen isteği kaldırdı / reddetti'),
            'empty_saved'=>array('Ayarlar','Boş liste yazılarını kaydetti'),
            'actbtn_saved'=>array('Ayarlar','İşlem butonlarını kaydetti'),
            'ban_added'=>array('IP Engelleme','IP engelledi'.($pip!=='' ? ': '.$pip : '')),
            'ban_removed'=>array('IP Engelleme','IP engelini kaldırdı'.($pip!=='' ? ': '.$pip : '')),
            'ban_super'=>array('IP Engelleme', "Süper Admin'i engellemeye çalıştı".($pip!=='' ? ': '.$pip : '')),
            'vpn_saved'=>array('VPN','VPN ayarlarını kaydetti (durum: '.((isset($_POST['vpn_enabled']) && $_POST['vpn_enabled']==='1') ? 'Aktif' : ((isset($_POST['vpn_enabled']) && $_POST['vpn_enabled']==='2') ? 'Tamamen kapalı' : 'Pasif')).')'),
            'vpn_test'=>array('VPN','VPN bağlantı testi yaptı'),
            'analytics_reset'=>array('İstatistik','İstatistik kayıtlarını sıfırladı'),
            'cat_added'=>array('Kategori','Kategori ekledi'.$pq),
            'cat_edited'=>array('Kategori','Kategori düzenledi'.$pq),
            'cat_deleted'=>array('Kategori','Kategori sildi'),
            'uploaded'=>array('Dosya Arşivi','Dosya yükledi'.$pq),
            'created'=>array('Dosya Arşivi','Dosya oluşturdu'.$pq),
            'edited'=>array('Dosya Arşivi','Dosyayı düzenledi'.$q),
            'deleted'=>array('Dosya Arşivi','Dosya sildi'.$q),
            'github_added'=>array('GitHub','GitHub bağlantısı ekledi'.$pq),
            'github_edited'=>array('GitHub','GitHub bağlantısını düzenledi'.$q),
            'github_deleted'=>array('GitHub','GitHub bağlantısı sildi'.$q),
            'note_added'=>array('Bilgiler','Bilgi ekledi'.$pq),
            'note_edited'=>array('Bilgiler','Bilgiyi düzenledi'.$q),
            'note_deleted'=>array('Bilgiler','Bilgi sildi'.$q),
            'acc_added'=>array('Hesaplar','Yeni hesap oluşturdu'.$pq.' ('.((isset($_POST['role']) && $_POST['role']==='admin') ? 'Yönetici' : 'Ziyaretçi').')')
        );
        if ($msg==='bulk_deleted') {
            $bt = (isset($_POST['type']) && is_string($_POST['type'])) ? $_POST['type'] : '';
            $bc = $bt==='dosya' ? 'Dosya Arşivi' : ($bt==='github' ? 'GitHub' : 'Bilgiler');
            $bl = isset($GLOBALS['x_act_bulk']) && is_array($GLOBALS['x_act_bulk']) ? $GLOBALS['x_act_bulk'] : array();
            $bn = array(); foreach (array_slice($bl, 0, 5) as $bx) $bn[] = x_act_q($bx, 40);
            $m['bulk_deleted'] = array($bc, 'Toplu silme: '.count($bl).' kayıt'.($bn ? ' ('.implode(', ', $bn).(count($bl) > 5 ? ', …' : '').')' : ''));
        }
        if ($msg!=='' && isset($m[$msg])) $rows[] = $m[$msg];
        elseif ($msg==='') {
            $pins = array('pin'=>'Dosya Arşivi', 'github_pin'=>'GitHub', 'note_pin'=>'Bilgiler');
            $meds = array('img_remove','note_remove_image','remove_screenshot','github_remove_image','nfile_remove','vid_remove','img_bulk_remove');
            if (isset($pins[$route])) $rows[] = array($pins[$route], 'Sabitleme durumunu değiştirdi'.$q);
            elseif (in_array($route, $meds, true)) $rows[] = array('Medya', 'Resim / video / ek dosya sildi'.$q);
        }
    }
    if ($rows) x_act_log_many($rows);
}

function x_site_defaults() {
    return array('title'=>'Exlonea','app_name'=>'Exlonea','description'=>'','keywords'=>'','robots'=>'','og_title'=>'','og_description'=>'',
        'brand_a'=>'Exlonea-','brand_b'=>'2026','login_sub'=>'Yönetim','login_ph'=>'Erişim anahtarı','login_btn'=>'Panele Bağlan','login_hint'=>'','login_icon'=>'','brand_a_color'=>'','brand_b_color'=>'',
        'c_accent'=>'','c_bg'=>'','c_surface'=>'','c_border'=>'','c_text'=>'','c_text2'=>'','login_dim'=>'55',
        'theme_mode'=>'','l_accent'=>'','l_bg'=>'','l_surface'=>'','l_border'=>'','l_text'=>'','l_text2'=>'');
}
function x_site_all() {
    static $c = null; if ($c !== null) return $c;
    $d = @x_data();
    $st = (is_array($d) && isset($d['settings']['site']) && is_array($d['settings']['site'])) ? $d['settings']['site'] : array();
    $blank = array('login_ph');
    $out = array();
    foreach (x_site_defaults() as $k=>$v) {
        if (isset($st[$k]) && is_string($st[$k])) $out[$k] = $st[$k]; else $out[$k] = $v;
    }
    $out['files'] = (isset($st['files']) && is_array($st['files'])) ? $st['files'] : array();
    $c = $out; return $c;
}
function x_site_get($k) { $a = x_site_all(); return isset($a[$k]) ? $a[$k] : ''; }
function x_themes() { $d = x_data(); return (is_array($d) && isset($d['settings']['themes']) && is_array($d['settings']['themes'])) ? array_values($d['settings']['themes']) : array(); }
function x_theme_default_id() { $d = x_data(); return (is_array($d) && isset($d['settings']['theme_default']) && is_string($d['settings']['theme_default'])) ? $d['settings']['theme_default'] : ''; }
function x_theme_clean($vals) {
    $out = array();
    foreach (x_site_defaults() as $k=>$v) $out[$k] = (is_array($vals) && isset($vals[$k]) && is_string($vals[$k])) ? $vals[$k] : $v;
    return $out;
}
function x_theme_default_vals($d) {
    if (!is_array($d) || empty($d['settings']['theme_default']) || empty($d['settings']['themes']) || !is_array($d['settings']['themes'])) return null;
    foreach ($d['settings']['themes'] as $t) if (is_array($t) && isset($t['id']) && $t['id']===$d['settings']['theme_default'] && isset($t['vals']) && is_array($t['vals'])) return x_theme_clean($t['vals']);
    return null;
}
function x_site_file_keys() { return array('logo','login_bg','favicon','og'); }
function x_base_info() { $d = x_data(); return (is_array($d) && isset($d['settings']['base_default']['vals']) && is_array($d['settings']['base_default']['vals'])) ? (isset($d['settings']['base_default']['time']) && is_string($d['settings']['base_default']['time']) ? $d['settings']['base_default']['time'] : '-') : ''; }
function x_base_files_clear($d) {
    if (isset($d['settings']['base_default']['files']) && is_array($d['settings']['base_default']['files'])) foreach ($d['settings']['base_default']['files'] as $bf) if (is_string($bf) && preg_match('/^base_[a-z_]+\.(png|jpg|gif|webp|ico)$/', $bf) && is_file(SITE_DIR.'/'.$bf)) @unlink(SITE_DIR.'/'.$bf);
}
function x_default_pack($d) {
    if (is_array($d) && isset($d['settings']['base_default']['vals']) && is_array($d['settings']['base_default']['vals'])) {
        $bd = $d['settings']['base_default'];
        return array('vals'=>x_theme_clean($bd['vals']), 'files'=>(isset($bd['files']) && is_array($bd['files'])) ? $bd['files'] : array());
    }
    $tv = x_theme_default_vals($d);
    return $tv !== null ? array('vals'=>$tv, 'files'=>array()) : null;
}
function x_ban_ips($d) { return (is_array($d) && isset($d['settings']['banned_ips']) && is_array($d['settings']['banned_ips'])) ? $d['settings']['banned_ips'] : array(); }
function x_is_banned($d, $ip) { foreach (x_ban_ips($d) as $b) if (is_array($b) && isset($b['ip']) && $b['ip'] === $ip) return true; return false; }
function x_ban_settings($d) {
    $b = (is_array($d) && isset($d['settings']['ban']) && is_array($d['settings']['ban'])) ? $d['settings']['ban'] : array();
    return array(
        'title' => (isset($b['title']) && is_string($b['title'])) ? $b['title'] : 'Banlandınız',
        'html' => (isset($b['html']) && is_string($b['html'])) ? $b['html'] : '<p>Bu siteye erişiminiz engellendi.</p>',
        'btn' => (isset($b['btn']) && is_string($b['btn'])) ? $b['btn'] : '',
        'url' => (isset($b['url']) && is_string($b['url'])) ? $b['url'] : ''
    );
}
function x_ban_page($d, $status, $bsx = null) {
    while (ob_get_level()) ob_end_clean();
    if ($status) http_response_code(403);
    header('Content-Type: text/html; charset=UTF-8');
    $b = is_array($bsx) ? $bsx : x_ban_settings($d);
    $ok = ($b['btn'] !== '' && preg_match('~^(https?://|mailto:|tel:)~i', $b['url']));
    ?><!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><meta name="robots" content="noindex,nofollow"><title><?=x_h($b['title'])?></title>
<style>:root{--bg:#0a0b0f;--surface:#12141b;--border:#1e2130;--text:#e5e7ef;--text2:#9aa0b4;--green:#b71c1c}*{box-sizing:border-box}body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;padding:20px}.ban-card{max-width:520px;width:100%;background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:32px;text-align:center}.ban-card h1{margin:0 0 14px;font-size:26px;color:var(--green)}.ban-msg{color:var(--text2);line-height:1.6;font-size:15px;word-break:break-word}.ban-msg p{margin:0 0 10px}.ban-btn{display:inline-block;margin-top:18px;padding:10px 20px;background:var(--green);color:#fff;border-radius:8px;text-decoration:none;font-weight:600}</style><?=x_theme_css()?></head><body><div class="ban-card"><h1><?=x_h($b['title'])?></h1><div class="ban-msg"><?=x_rich($b['html'])?></div><?php if ($ok): ?><a class="ban-btn" href="<?=x_h($b['url'])?>" rel="noopener noreferrer"><?=x_h($b['btn'])?></a><?php endif; ?></div></body></html><?php
    exit;
}
function x_vpn_settings($d) {
    $b = (is_array($d) && isset($d['settings']['vpn']) && is_array($d['settings']['vpn'])) ? $d['settings']['vpn'] : array();
    return array(
        'off' => !empty($b['off']),
        'enabled' => (!empty($b['enabled']) && empty($b['off'])),
        'key' => (isset($b['key']) && is_string($b['key'])) ? $b['key'] : '',
        'title' => (isset($b['title']) && is_string($b['title'])) ? $b['title'] : 'VPN ile giriş tespit edildi',
        'html' => (isset($b['html']) && is_string($b['html'])) ? $b['html'] : '<p>VPN, proxy veya Tor kullanarak bu siteye erişemezsiniz. Lütfen bağlantınızı kapatıp tekrar deneyin.</p>',
        'btn' => (isset($b['btn']) && is_string($b['btn'])) ? $b['btn'] : '',
        'url' => (isset($b['url']) && is_string($b['url'])) ? $b['url'] : ''
    );
}
function x_http_get($url, $to) {
    if (function_exists('curl_init')) {
        $c = curl_init($url);
        if ($c) {
            curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($c, CURLOPT_TIMEOUT, (int)$to);
            curl_setopt($c, CURLOPT_CONNECTTIMEOUT, (int)$to);
            curl_setopt($c, CURLOPT_FOLLOWLOCATION, false);
            curl_setopt($c, CURLOPT_USERAGENT, 'Exlonea');
            $r = curl_exec($c);
            if (PHP_VERSION_ID < 80000) { curl_close($c); }
            return ($r !== false && $r !== '') ? $r : false;
        }
    }
    if (ini_get('allow_url_fopen')) {
        $ctx = stream_context_create(array('http' => array('timeout' => (int)$to, 'header' => "User-Agent: Exlonea\r\n", 'ignore_errors' => true)));
        $r = @file_get_contents($url, false, $ctx);
        return ($r !== false && $r !== '') ? $r : false;
    }
    return false;
}
function x_ip_norm($ip) { $b = @inet_pton($ip); if ($b === false) return $ip; $n = @inet_ntop($b); return $n === false ? $ip : $n; }
function x_vpn_public($ip) { return is_string($ip) && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false; }
function x_vpn_api($ip, $key) {
    $o = array('ok' => false, 'f' => -1, 'ty' => '', 'err' => '');
    $r = x_http_get('https://proxycheck.io/v3/'.rawurlencode($ip).($key !== '' ? '?key='.rawurlencode($key) : ''), 4);
    if ($r === false) { $o['err'] = 'bağlantı kurulamadı'; return $o; }
    $j = json_decode($r, true);
    if (!is_array($j) || !isset($j['status']) || !is_string($j['status'])) { $o['err'] = 'geçersiz yanıt'; return $o; }
    if ($j['status'] !== 'ok' && $j['status'] !== 'warning') { $o['err'] = (isset($j['message']) && is_string($j['message'])) ? mb_substr($j['message'], 0, 120) : $j['status']; return $o; }
    $k = (isset($j['ip']) && is_string($j['ip'])) ? $j['ip'] : $ip;
    $e = (isset($j[$k]) && is_array($j[$k])) ? $j[$k] : ((isset($j[$ip]) && is_array($j[$ip])) ? $j[$ip] : null);
    if (!is_array($e) || !isset($e['detections']) || !is_array($e['detections'])) { $o['err'] = 'sonuç okunamadı'; return $o; }
    $dt = $e['detections'];
    $tor = !empty($dt['tor']); $vpn = !empty($dt['vpn']); $px = !empty($dt['proxy']); $an = !empty($dt['anonymous']);
    $o['ok'] = true;
    if ($tor || $vpn || $px || $an) { $o['f'] = 1; $o['ty'] = $tor ? 'tor' : ($vpn ? 'vpn' : 'proxy'); } else { $o['f'] = 0; }
    return $o;
}
function x_vpn_brand($s) {
    return is_string($s) && $s!=='' && preg_match('/(^|[^a-z0-9])(nordvpn|nordlayer|expressvpn|surfshark|cyberghost|protonvpn|proton\s*ag|mullvad|private\s*internet\s*access|ipvanish|windscribe|hide\.me|hidemyass|tunnelbear|purevpn|hotspot\s*shield|torguard|vyprvpn|zenmate|astrill|airvpn|ivpn|perfect\s*privacy|m247|datacamp|cdn77|packethub|tefincom|quadranet|clouvider|frantech|vpn|proxy|proxies|anonymi[sz]er)([^a-z0-9]|$)/i', $s) === 1;
}
function x_vpn_api_ipapiis($ip) {
    $o = array('ok' => false, 'f' => -1, 'ty' => '', 'err' => '');
    $r = x_http_get('https://api.ipapi.is/?q='.rawurlencode($ip), 4);
    if ($r === false) { $o['err'] = 'bağlantı kurulamadı'; return $o; }
    $j = json_decode($r, true);
    if (!is_array($j) || !isset($j['ip']) || (!isset($j['is_vpn']) && !isset($j['is_proxy']) && !isset($j['is_tor']))) { $o['err'] = 'geçersiz yanıt'; return $o; }
    $o['ok'] = true; $o['f'] = 0;
    $co = (isset($j['company']) && is_array($j['company'])) ? $j['company'] : array();
    $as = (isset($j['asn']) && is_array($j['asn'])) ? $j['asn'] : array();
    if (!empty($j['is_tor'])) { $o['f'] = 1; $o['ty'] = 'tor'; }
    elseif (!empty($j['is_vpn'])) { $o['f'] = 1; $o['ty'] = 'vpn'; }
    elseif (!empty($j['is_proxy'])) { $o['f'] = 1; $o['ty'] = 'proxy'; }
    elseif (empty($j['is_crawler']) && (!empty($j['is_datacenter']) || (isset($co['type']) && $co['type']==='hosting') || (isset($as['type']) && $as['type']==='hosting'))) { $o['f'] = 1; $o['ty'] = 'dc'; }
    elseif (x_vpn_brand(isset($co['name']) ? $co['name'] : '') || x_vpn_brand(isset($as['org']) ? $as['org'] : '')) { $o['f'] = 1; $o['ty'] = 'vpn'; }
    return $o;
}
function x_vpn_api_ipapi($ip) {
    $o = array('ok' => false, 'f' => -1, 'ty' => '', 'err' => '');
    $r = x_http_get('http://ip-api.com/json/'.rawurlencode($ip).'?fields=status,message,proxy,hosting,isp,org,as,reverse', 4);
    if ($r === false) { $o['err'] = 'bağlantı kurulamadı'; return $o; }
    $j = json_decode($r, true);
    if (!is_array($j) || !isset($j['status']) || !is_string($j['status'])) { $o['err'] = 'geçersiz yanıt'; return $o; }
    if ($j['status'] !== 'success') { $o['err'] = (isset($j['message']) && is_string($j['message'])) ? mb_substr($j['message'], 0, 80) : $j['status']; return $o; }
    $o['ok'] = true; $o['f'] = 0;
    if (!empty($j['proxy'])) { $o['f'] = 1; $o['ty'] = 'vpn'; }
    elseif (!empty($j['hosting'])) { $o['f'] = 1; $o['ty'] = 'dc'; }
    else {
        foreach (array('isp', 'org', 'as', 'reverse') as $bk) { if (isset($j[$bk]) && x_vpn_brand($j[$bk])) { $o['f'] = 1; $o['ty'] = 'vpn'; break; } }
    }
    return $o;
}
function x_vpn_multi($ip, $key) {
    $okAny = false;
    $a = x_vpn_api($ip, $key);
    if ($a['ok']) { $okAny = true; if ($a['f'] === 1) return array('f' => 1, 'ty' => $a['ty']); }
    $b = x_vpn_api_ipapiis($ip);
    if ($b['ok']) { $okAny = true; if ($b['f'] === 1) return array('f' => 1, 'ty' => $b['ty']); }
    $c = x_vpn_api_ipapi($ip);
    if ($c['ok']) { $okAny = true; if ($c['f'] === 1) return array('f' => 1, 'ty' => $c['ty']); }
    return $okAny ? array('f' => 0, 'ty' => '') : array('f' => -1, 'ty' => '');
}
function x_vpn_headers() {
    foreach (array('HTTP_PROXY_CONNECTION', 'HTTP_X_PROXY_ID', 'HTTP_X_TINYPROXY', 'HTTP_PROXY_AUTHORIZATION', 'HTTP_X_PROXY_CONNECTION') as $h) if (!empty($_SERVER[$h])) return true;
    return false;
}
function x_vpn_detect($d, $ip) {
    $res = array('f' => 0, 'ty' => '');
    if (!x_vpn_public($ip)) return $res;
    $now = time();
    $c = (is_array($d) && isset($d['vpn_cache'][$ip]) && is_array($d['vpn_cache'][$ip])) ? $d['vpn_cache'][$ip] : null;
    if ($c && isset($c['f'], $c['t'])) {
        $age = $now - (int)$c['t'];
        if (((int)$c['f'] === 1 && $age < 43200) || ((int)$c['f'] === 0 && $age < 21600) || ((int)$c['f'] < 0 && $age < 300)) return array('f' => (int)$c['f'], 'ty' => isset($c['ty']) ? (string)$c['ty'] : '');
    }
    $vs = x_vpn_settings($d);
    $tor = (is_array($d) && isset($d['vpn_tor']) && is_array($d['vpn_tor'])) ? $d['vpn_tor'] : array();
    $torNew = null;
    if (!isset($tor['t']) || ($now - (int)$tor['t']) > 10800) {
        if (!isset($tor['rt']) || $now >= (int)$tor['rt']) {
            $txt = x_http_get('https://check.torproject.org/torbulkexitlist', 5);
            $arr = array();
            if ($txt !== false) { foreach (preg_split('/\s+/', $txt) as $l) { if ($l !== '' && filter_var($l, FILTER_VALIDATE_IP)) $arr[x_ip_norm($l)] = 1; } }
            if (count($arr) > 50) { $tor = array('t' => $now, 'n' => count($arr), 'ips' => ','.implode(',', array_keys($arr)).','); }
            else { $tor['rt'] = $now + 900; }
            $torNew = $tor;
        }
    }
    if (isset($tor['ips']) && is_string($tor['ips']) && strpos($tor['ips'], ','.x_ip_norm($ip).',') !== false) { $res = array('f' => 1, 'ty' => 'tor'); }
    else { $res = x_vpn_multi($ip, $vs['key']); }
    $fd = x_data();
    if (is_array($fd)) {
        if (!isset($fd['vpn_cache']) || !is_array($fd['vpn_cache'])) $fd['vpn_cache'] = array();
        $fd['vpn_cache'][$ip] = array('f' => $res['f'], 'ty' => $res['ty'], 't' => $now);
        if ($torNew !== null) $fd['vpn_tor'] = $torNew;
        if (count($fd['vpn_cache']) > 3000) { uasort($fd['vpn_cache'], function($a, $b) { return x_cmp((int)(isset($b['t']) ? $b['t'] : 0), (int)(isset($a['t']) ? $a['t'] : 0)); }); $fd['vpn_cache'] = array_slice($fd['vpn_cache'], 0, 2000, true); }
        x_save($fd);
    }
    return $res;
}
function x_vpn_log($ip, $act, $ty) {
    $fd = x_data(); if (!is_array($fd)) return;
    if (isset($fd['analytics']) && is_array($fd['analytics'])) {
        foreach (array_reverse($fd['analytics']) as $ve) {
            if (is_array($ve) && isset($ve['type'], $ve['action'], $ve['ip']) && $ve['type'] === 'auth' && $ve['action'] === $act && $ve['ip'] === $ip) { if (time() - (int)strtotime(isset($ve['time']) ? $ve['time'] : '') < 600) return; break; }
        }
    }
    x_track($fd, 'auth', $act, $act, 'VPN ile giriş tespit edildi');
    $n = count($fd['analytics']) - 1;
    if ($n >= 0) $fd['analytics'][$n]['vpn_type'] = $ty;
    x_save($fd);
}
function x_vpn_gate($d) {
    $vs0 = x_vpn_settings($d); if ($vs0['off']) return;
    $ip = x_ip();
    $r = x_vpn_detect($d, $ip);
    if ($r['f'] !== 1 && x_vpn_headers()) $r = array('f' => 1, 'ty' => 'proxy');
    if ($r['f'] !== 1) return;
    $vs = x_vpn_settings($d);
    x_vpn_log($ip, $vs['enabled'] ? 'vpn_block' : 'vpn', $r['ty']);
    if ($vs['enabled']) x_ban_page($d, true, $vs);
}
function x_color_ok($c) { return is_string($c) && preg_match('/^#[0-9a-fA-F]{6}$/', $c); }
function x_lighten($hex, $amt) {
    $r = hexdec(substr($hex,1,2)); $g = hexdec(substr($hex,3,2)); $b = hexdec(substr($hex,5,2));
    $f = function($v) use ($amt) { return max(0, min(255, (int)round($v + $amt))); };
    return sprintf('#%02x%02x%02x', $f($r), $f($g), $f($b));
}
function x_is_editor() { return isset($_SESSION['role']) && $_SESSION['role']==='editor'; }
function x_owner_uid() { if (!empty($GLOBALS['x_replay_uid']) && is_string($GLOBALS['x_replay_uid'])) return $GLOBALS['x_replay_uid']; return isset($_SESSION['uid']) && is_string($_SESSION['uid']) ? $_SESSION['uid'] : ''; }
function x_ed_rule_keys() { return array('edit_others','delete_others','appr_add','appr_edit','appr_delete','appr_cancel'); }
function x_ed_keys() { return array_merge(array('dosya_add','dosya_edit','dosya_delete','dosya_pin','github_add','github_edit','github_delete','github_pin','note_add','note_edit','note_delete','note_pin','media_delete','media_main'), x_ed_rule_keys()); }
function x_ed_default() { return array('dosya_add','github_add','note_add','dosya_edit','github_edit','note_edit','appr_add','appr_edit','appr_delete','appr_cancel'); }
function x_is_up($t) { if (is_string($t) && is_uploaded_file($t)) return true; if (empty($GLOBALS['x_replay']) || !is_string($t) || $t==='') return false; $b = str_replace('\\','/',APPR_DIR).'/'; return strpos(str_replace('\\','/',$t), $b)===0 && is_file($t); }
function x_mv_up($t, $d) { if (!is_string($t)) return false; if (@move_uploaded_file($t, $d)) return true; if (!is_uploaded_file($t) && x_is_up($t)) { if (@rename($t, $d)) return true; return @copy($t, $d); } return false; }
function x_rrmdir($d) { if (!is_dir($d)) return; foreach (scandir($d) as $f) { if ($f==='.'||$f==='..') continue; $p = $d.'/'.$f; if (is_dir($p)) x_rrmdir($p); else @unlink($p); } @rmdir($d); }
function x_item_find($d, $id) { foreach (array('dosya','github','notes') as $c) if (is_array($d) && isset($d[$c]) && is_array($d[$c])) foreach ($d[$c] as $it) if (is_array($it) && isset($it['id']) && (string)$it['id']===(string)$id) return array($c, $it); return null; }
function x_item_own($it) { return is_array($it) && isset($it['by']) && is_string($it['by']) && $it['by']!=='' && $it['by']===x_owner_uid(); }
function x_perm_it($k, $it) { if (!x_perm($k)) return false; if (!x_is_editor()) return true; if (x_item_own($it)) return true; if (substr($k,-5)==='_edit') return x_perm('edit_others'); if (substr($k,-7)==='_delete') return x_perm('delete_others'); return true; }
function x_appr_all($d) { return (is_array($d) && isset($d['approvals']) && is_array($d['approvals'])) ? array_values(array_filter($d['approvals'], 'is_array')) : array(); }
function x_files_stash($rid) {
    $o = array(); $dir = APPR_DIR.'/'.$rid; $n = 0;
    $mv = function($t) use (&$n, $dir) { if (!is_string($t) || $t==='' || !is_uploaded_file($t)) return $t; if (!is_dir($dir)) @mkdir($dir, 0755, true); $dst = $dir.'/f'.(++$n); return @move_uploaded_file($t, $dst) ? $dst : $t; };
    foreach ($_FILES as $k=>$f) {
        if (!is_array($f) || !isset($f['tmp_name'])) continue;
        if (is_array($f['tmp_name'])) { foreach ($f['tmp_name'] as $i=>$t) $f['tmp_name'][$i] = $mv($t); } else $f['tmp_name'] = $mv($f['tmp_name']);
        $o[$k] = $f;
    }
    return $o;
}
function x_appr_queue($route, $kind, $tab, $label) {
    $d = x_data(); if (!is_array($d)) return false;
    $rid = 'rq'.bin2hex(random_bytes(6));
    $post = $_POST; unset($post['_csrf']);
    $req = array('id'=>$rid, 'uid'=>(string)$_SESSION['uid'], 'name'=>(isset($_SESSION['uname']) ? (string)$_SESSION['uname'] : ''), 'time'=>date('Y-m-d H:i:s'), 'route'=>$route, 'kind'=>$kind, 'tab'=>$tab, 'label'=>mb_substr((string)$label, 0, 80), 'method'=>$_SERVER['REQUEST_METHOD'], 'get'=>$_GET, 'post'=>$post, 'files'=>x_files_stash($rid));
    if (!isset($d['approvals']) || !is_array($d['approvals'])) $d['approvals'] = array();
    $d['approvals'][] = $req;
    $cut = date('Y-m-d H:i:s', time() - 14*86400); $d['approvals'] = array_values(array_filter($d['approvals'], function($q) use ($cut) { return empty($q['status']) || $q['status']!=='cancelled' || (isset($q['cancelled']) && $q['cancelled'] > $cut); }));
    if (count($d['approvals']) > 300) $d['approvals'] = array_slice($d['approvals'], -300);
    return x_save($d);
}
function x_ed_gate($route) {
    if (!x_is_editor()) return;
    $post = $_SERVER['REQUEST_METHOD']==='POST';
    $deny = function() { $fe = x_first_entry(); header('Location: '.$_SERVER['SCRIPT_NAME'].x_entry_href($fe).'&msg=perm_denied'); exit; };
    $sent = function($tab) { header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab='.$tab.'&msg=appr_sent'); exit; };
    $d = x_data(); $me = (string)$_SESSION['uid'];
    $add = array('upload'=>'dosya','create'=>'dosya','github_add'=>'github','note_add'=>'notes');
    if (isset($add[$route])) {
        if (!$post || (empty($_POST) && empty($_FILES))) return;
        if (!x_perm('appr_add')) return;
        $lb = ''; foreach (array('name','title','url') as $k) if (isset($_POST[$k]) && is_string($_POST[$k]) && trim($_POST[$k])!=='') { $lb = trim($_POST[$k]); break; }
        if ($lb==='' && isset($_FILES['dosya_arsiv']['name']) && is_string($_FILES['dosya_arsiv']['name'])) $lb = $_FILES['dosya_arsiv']['name'];
        x_appr_queue($route, 'add', $add[$route], $lb); $sent($add[$route]);
    }
    $edit = array('edit','github_edit','note_edit','img_main','img_bulk_remove','img_remove','note_remove_image','remove_screenshot','github_remove_image','nfile_remove','vid_main','vid_remove');
    $del = array('delete','github_delete','note_delete');
    if (in_array($route, $edit, true) || in_array($route, $del, true)) {
        $isDel = in_array($route, $del, true);
        $id = (isset($_GET['id']) && is_string($_GET['id'])) ? $_GET['id'] : '';
        $f = $id!=='' ? x_item_find($d, $id) : null;
        if ($f === null) return;
        $own = x_item_own($f[1]);
        if (!$own && !x_perm($isDel ? 'delete_others' : 'edit_others')) $deny();
        $mut = in_array($route, array('edit','github_edit','note_edit'), true) ? $post : true;
        if ($mut && x_perm($isDel ? 'appr_delete' : 'appr_edit')) {
            $lb = isset($f[1]['name']) ? (string)$f[1]['name'] : (isset($f[1]['title']) ? (string)$f[1]['title'] : $id);
            x_appr_queue($route, $isDel ? 'delete' : 'edit', $f[0], $lb); $sent($f[0]);
        }
        return;
    }
    if ($route==='bulk_delete' && $post) {
        $type = (isset($_POST['type']) && is_string($_POST['type']) && in_array($_POST['type'], array('dosya','github','notes'), true)) ? $_POST['type'] : '';
        $ids = (isset($_POST['ids']) && is_array($_POST['ids'])) ? array_values(array_filter($_POST['ids'], 'is_string')) : array();
        if ($type==='' || !$ids) return;
        if (!x_perm('delete_others')) {
            $ok = array();
            foreach ($ids as $i) { $f = x_item_find($d, $i); if ($f !== null && $f[0]===$type && x_item_own($f[1])) $ok[] = $i; }
            if (!$ok) $deny();
            $ids = $ok; $_POST['ids'] = $ok;
        }
        if (x_perm('appr_delete')) { x_appr_queue($route, 'delete', $type, count($ids).' öğe'); $sent($type); }
    }
}
function x_appr_kind($r) { $k = isset($r['kind']) ? $r['kind'] : ''; $t = isset($r['tab']) ? $r['tab'] : ''; $tn = array('dosya'=>'Dosya Arşivi','github'=>'GitHub','notes'=>'Bilgiler'); $kn = array('add'=>'Ekleme','edit'=>'Düzenleme','delete'=>'Silme'); return (isset($kn[$k]) ? $kn[$k] : 'İşlem').' · '.(isset($tn[$t]) ? $tn[$t] : $t); }
function x_appr_mgr() { return x_super() || (x_admin() && !x_is_editor() && x_perm('appr_review')); }
function x_appr_tab() { return x_perm('settings') ? 'settings' : 'dosya'; }
function x_appr_pending($list) { return array_values(array_filter($list, function($r) { return empty($r['status']) || $r['status']!=='cancelled'; })); }
function x_appr_detail($r) {
    $d = x_data(); $lb = array('name'=>'Ad','title'=>'Başlık','description'=>'Açıklama','content'=>'İçerik','url'=>'Bağlantı','category_id'=>'Kategori','php_version'=>'PHP sürümü','image_url'=>'Resim bağlantısı','video_url'=>'Video bağlantısı','pack_url'=>'Paket bağlantıları','st_ext'=>'Kayıt uzantısı','source'=>'Kaynak');
    $skip = array('confirm','_csrf','_t'); $o = '<div style="margin:8px 0 2px;padding:9px 11px;border:1px solid var(--border);border-radius:var(--r-sm,6px);background:var(--surface2,transparent);font-size:12px;line-height:1.55;word-break:break-word">';
    $id = (isset($r['get']['id']) && is_string($r['get']['id'])) ? $r['get']['id'] : '';
    if ($id!=='') { $f = x_item_find($d, $id); $o .= '<div><span class="muted">Hedef kayıt:</span> '.x_h($f!==null ? (isset($f[1]['name']) ? $f[1]['name'] : (isset($f[1]['title']) ? $f[1]['title'] : $id)) : 'silinmiş ('.$id.')').'</div>'; }
    $o .= '<div><span class="muted">İşlem:</span> '.x_h(isset($r['route']) ? $r['route'] : '').'</div>';
    $flat = function($v) use (&$flat) { if (is_array($v)) { $x = array(); foreach ($v as $vv) { $t = $flat($vv); if ($t!=='') $x[] = $t; } return implode(', ', $x); } return (string)$v; };
    $n = 0;
    foreach ((isset($r['post']) && is_array($r['post']) ? $r['post'] : array()) as $k=>$v) {
        if (!is_string($k) || $k==='' || $k[0]==='_' || in_array($k, $skip, true)) continue;
        $t = $flat($v); $t = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($t), ENT_QUOTES, 'UTF-8'))); if ($t==='') continue;
        if (preg_match('/pass|sifre|şifre|pwd/i', $k)) $t = '••••••';
        if (mb_strlen($t) > 500) $t = mb_substr($t, 0, 500).'…';
        $o .= '<div><span class="muted">'.x_h(isset($lb[$k]) ? $lb[$k] : $k).':</span> '.x_h($t).'</div>'; $n++;
    }
    foreach ((isset($r['files']) && is_array($r['files']) ? $r['files'] : array()) as $k=>$f) {
        if (!is_array($f) || !isset($f['name'])) continue;
        $nm = (array)$f['name']; $sz = isset($f['size']) ? (array)$f['size'] : array(); $x = array();
        foreach ($nm as $i=>$one) { if (!is_string($one) || $one==='') continue; $b = isset($sz[$i]) ? (int)$sz[$i] : 0; $x[] = $one.($b ? ' ('.($b>=1048576 ? round($b/1048576,1).' MB' : max(1,round($b/1024)).' KB').')' : ''); }
        if ($x) $o .= '<div><span class="muted">Yüklenen dosya ('.x_h($k).'):</span> '.x_h(implode(', ', $x)).'</div>';
    }
    if (!$n && $id==='') $o .= '<div class="muted">Ek içerik yok.</div>';
    return $o.'</div>';
}
function x_appr_rows($list, $super) {
    $h = '';
    foreach ($list as $r) {
        $cx = isset($r['status']) && $r['status']==='cancelled';
        $h .= '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;padding:9px 0;border-top:1px solid var(--border)'.($cx ? ';opacity:.78' : '').'">';
        if ($super && !$cx) $h .= '<input type="checkbox" class="cbx appr-sel" value="'.x_h($r['id']).'" onchange="apprSync(this)">';
        $h .= '<div style="flex:1;min-width:220px"><details class="appr-d"><summary style="cursor:pointer;list-style:none"><span class="badge badge-b" style="text-transform:none">'.x_h(x_appr_kind($r)).'</span> '.($cx ? '<span class="badge badge-r" style="text-transform:none">İptal edildi</span> ' : '').'<b>'.x_h(isset($r['label']) ? $r['label'] : '').'</b> <span class="muted" style="font-size:11px">· ayrıntı ▾</span></summary>'.x_appr_detail($r).'</details><div class="muted" style="font-size:11px;margin-top:2px">'.($super ? x_h(isset($r['name']) ? $r['name'] : '').' · ' : '').x_h(isset($r['time']) ? $r['time'] : '').($cx && !empty($r['cancelled']) ? ' · iptal: '.x_h($r['cancelled']) : '').'</div></div>';
        if ($super && !$cx) $h .= '<form method="POST" action="?action=appr_ok&tab='.x_appr_tab().'" style="margin:0"><input type="hidden" name="rid" value="'.x_h($r['id']).'"><button type="submit" class="btn btn-g btn-xs" onclick="return confirm(\'Bu işlem onaylanıp uygulansın mı?\')">Onayla</button></form>';
        if ($super && $cx) $h .= '<form method="POST" action="?action=appr_no&tab='.x_appr_tab().'" style="margin:0"><input type="hidden" name="rid" value="'.x_h($r['id']).'"><button type="submit" class="btn btn-or btn-xs" onclick="return confirm(\'İptal edilen kayıt listeden kaldırılsın mı?\')">Kaldır</button></form>';
        elseif (!$cx && ($super || x_perm('appr_cancel'))) $h .= '<form method="POST" action="?action=appr_no&tab='.($super ? 'settings' : x_h(isset($r['tab']) ? $r['tab'] : 'dosya')).'" style="margin:0"><input type="hidden" name="rid" value="'.x_h($r['id']).'"><button type="submit" class="btn btn-or btn-xs" onclick="return confirm(\''.($super ? 'Bu istek reddedilsin mi?' : 'İsteğiniz iptal edilsin mi?').'\')">'.($super ? 'Reddet' : 'İptal et').'</button></form>';
        $h .= '</div>';
    }
    return $h;
}
function x_appr_box($list, $super) {
    $h = '<div class="appr-box">';
    if ($super) $h .= '<div style="display:flex;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:8px;font-size:12px;color:var(--text2)"><label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0"><input type="checkbox" class="cbx appr-all" onchange="apprAll(this)"> Tümünü seç</label><span class="appr-cnt" style="font-weight:600;color:var(--text)"></span><button type="button" class="btn btn-g btn-xs appr-bulk" disabled onclick="apprOk(this)">'.svg('check',11).' Seçilenleri onayla</button><button type="button" class="btn btn-or btn-xs appr-bulk" disabled onclick="apprNo(this)">'.svg('x',11).' Seçilenleri reddet</button></div>';
    return $h.'<div style="max-height:340px;overflow-y:auto">'.x_appr_rows($list, $super).'</div></div>';
}
function x_ab_keys() { return array('view'=>array('Görüntüle','eye'),'download'=>array('İndir','download'),'edit'=>array('Düzenle','edit'),'pin'=>array('Sabitle','pin'),'delete'=>array('Sil','trash'),'copy'=>array('Kopyala (GitHub)','copy'),'pack'=>array('Paket (indirme menüsü)','layers'),'arch'=>array('Arşive yedekle (GitHub)','folder')); }
function x_ab_all() { $o = array(); foreach (x_ab_keys() as $k=>$v) $o[$k] = array($v[0], $v[1], '.btn[data-ab="'.$k.'"]'); 
    $o['cat'] = array('Kategori rozeti', null, 'td.col-cat .badge');
    $o['pass_r'] = array('Durum: Şifreli rozeti', null, 'td.col-pass .badge-r');
    $o['pass_g'] = array('Durum: Açık rozeti', null, 'td.col-pass .badge-g');
    $o['php'] = array('PHP rozeti', null, 'td.col-php .badge');
    $o['close'] = array('Kapat düğmesi (pencereler)', null, '.modal-close');
    return $o; }
function x_ab_rads() { return array(''=>'Varsayılan','0'=>'Kare','4px'=>'Hafif yuvarlak','8px'=>'Yuvarlak köşeli','999px'=>'Oval / hap'); }
function x_ab_icons() { return array('eye','download','layers','trash','upload','lock','unlock','file','calendar','edit','pin','folder','code','tag','x','check','copy','info','book','link','cog','star','heart','bell','bookmark','zap','shield','key','search','plus','image','globe','user'); }
function x_ab_get($k) {
    static $c = null;
    if ($c === null) { $c = array(); $d = @x_data(); if (is_array($d) && isset($d['settings']['actbtn']) && is_array($d['settings']['actbtn'])) $c = $d['settings']['actbtn']; }
    $o = array('icon'=>'','color'=>'','bg'=>'','bgt'=>'','bd'=>'','rad'=>'');
    if (isset($c[$k]) && is_array($c[$k])) foreach ($o as $kk=>$vv) if (isset($c[$k][$kk]) && is_string($c[$k][$kk])) $o[$kk] = $c[$k][$kk];
    return $o;
}
function x_ab_icon($k, $def) { $o = x_ab_get($k); return in_array($o['icon'], x_ab_icons(), true) ? $o['icon'] : $def; }
function x_ab_css() {
    $o = '';
    foreach (x_ab_all() as $k=>$d) {
        $a = x_ab_get($k); $r = ''; $sv = '';
        if (x_color_ok($a['color'])) { $r .= 'color:'.$a['color'].'!important;'; $sv = $d[2].' svg{color:'.$a['color'].'!important}'; }
        if ($a['bgt']==='1') $r .= 'background:transparent!important;';
        elseif (x_color_ok($a['bg'])) $r .= 'background:'.$a['bg'].'!important;';
        if (x_color_ok($a['bd'])) $r .= 'border:1px solid '.$a['bd'].'!important;';
        $rr = x_ab_rads(); if ($a['rad']!=='' && isset($rr[$a['rad']])) $r .= 'border-radius:'.$a['rad'].'!important;';
        if ($r!=='') $o .= $d[2].($k==='cat'||$k==='pass_r'||$k==='pass_g'||$k==='php' ? ',.x-abp-'.$k : '').'{'.$r.'}'.$sv;
    }
    return $o;
}
function x_rgb_norm($v) {
    $v = strtolower(trim((string)$v));
    if (preg_match('/^#([0-9a-f])([0-9a-f])([0-9a-f])$/', $v, $m)) return hexdec($m[1].$m[1]).','.hexdec($m[2].$m[2]).','.hexdec($m[3].$m[3]);
    if (preg_match('/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/', $v, $m)) return hexdec($m[1]).','.hexdec($m[2]).','.hexdec($m[3]);
    if (preg_match('/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/', $v, $m)) return (int)$m[1].','.(int)$m[2].','.(int)$m[3];
    return '';
}
function x_rich_theme_set() {
    static $set = null;
    if ($set === null) {
        $set = array();
        $l = array('#0c0e14','#0a0b0f','#111318','#12141b','#1a1d28','#16181f','#1e2130','#e5e7ef','#d1d5e0','#8b8fa3','#9aa0b4','#696969','#1b1e2b','#4a5068','#f3f4f8','#f1f2f7','#d8dbe6');
        $sa = @x_site_all();
        if (is_array($sa)) foreach (array('c_bg','c_surface','c_border','c_text','c_text2','l_bg','l_surface','l_border','l_text','l_text2') as $k) if (isset($sa[$k]) && x_color_ok($sa[$k])) $l[] = $sa[$k];
        foreach ($l as $c) { $n = x_rgb_norm($c); if ($n !== '') $set[$n] = 1; }
    }
    return $set;
}
function x_empty_defs() { return array(
    'dosya'=>array('Dosya Arşivi','file','Henüz dosya eklenmedi','Yukarıdaki panelden dosya ekleyebilirsiniz.'),
    'github'=>array('GitHub','link','Henüz GitHub bağlantısı eklenmedi','Yukarıdaki panelden bağlantı ekleyebilirsiniz.'),
    'notes'=>array('Bilgiler','book','Henüz bilgi eklenmedi','Yukarıdaki formdan bilgi ekleyebilirsiniz.')); }
function x_empty_get($k) {
    $d = @x_data(); $df = x_empty_defs(); $o = array('title'=>$df[$k][2],'html'=>'','icon'=>'','vis'=>'');
    if (is_array($d) && isset($d['settings']['empty'][$k]) && is_array($d['settings']['empty'][$k])) { $e = $d['settings']['empty'][$k]; foreach ($o as $kk=>$vv) if (isset($e[$kk]) && is_string($e[$kk])) $o[$kk] = $e[$kk]; if ($o['title']==='') $o['title'] = $df[$k][2]; }
    return $o;
}
function x_empty_html($k) {
    $df = x_empty_defs(); $e = x_empty_get($k);
    $ic = $e['icon']==='none' ? '' : svg(x_icon_ok($e['icon']) ? $e['icon'] : $df[$k][1], 32);
    $o = '<div class="empty">'.$ic.'<h3>'.x_h($e['title']).'</h3>';
    if (trim(strip_tags($e['html']))!=='' || stripos($e['html'],'<img')!==false) { if (x_admin() || $e['vis']==='1') $o .= '<div class="empty-d">'.x_rich($e['html']).'</div>'; }
    elseif (x_admin()) $o .= '<p>'.x_h($df[$k][3]).'</p>';
    return $o.'</div>';
}
function x_light_defaults() { return array('l_accent'=>'#b71c1c','l_bg'=>'#f3f4f8','l_surface'=>'#ffffff','l_border'=>'#d8dbe6','l_text'=>'#696969','l_text2'=>'#1b1e2b'); }
function x_theme_light_css($s) {
    $d = x_light_defaults(); $c = array();
    foreach ($d as $k=>$dv) $c[$k] = x_color_ok($s[$k]) ? $s[$k] : $dv;
    if (!x_color_ok($s['l_accent']) && x_color_ok($s['c_accent'])) $c['l_accent'] = $s['c_accent'];
    $a = $c['l_accent'];
    $v = array('color-scheme:light','--green:'.$a,'--green-bg:'.$a.'12','--green-glow:'.$a.'30','--glow:'.$a.'30',
        '--bg:'.$c['l_bg'],'--surface:'.$c['l_surface'],'--surface2:'.x_lighten($c['l_surface'], -6),
        '--border:'.$c['l_border'],'--border2:'.x_lighten($c['l_border'], -14),
        '--text:'.$c['l_text'],'--text2:'.$c['l_text2'],'--text3:'.x_lighten($c['l_text'], 50),
        '--inp:'.x_lighten($c['l_surface'], 0),'--d1:'.x_lighten($c['l_surface'], -8),'--d2:'.x_lighten($c['l_surface'], -22),'--hi:'.$c['l_text2'],
        '--blue-bg:#448aff18');
    $o = '<style>:root{'.implode(';', $v).'}'
       .'body{background:var(--bg);color:var(--text)}'
       .'input,select,textarea{color:var(--text2)}'
       .'input::placeholder,textarea::placeholder{color:var(--text3)}'
       .'.toast{box-shadow:0 6px 24px rgba(0,0,0,.18)}'
       .'table .btn:not(.btn-or):not(.btn-g),.bulk-toolbar .btn:not(.btn-or):not(.btn-g){background:var(--surface)!important;border:1px solid var(--border2)}'
       .'.rich-toolbar button,.rich-toolbar select,.rich-toolbar input{color:var(--text2)}'
       .'.rich-content{color:var(--text2)}'
       .'</style>';
    return $o;
}
function x_theme_css() {
    $s = x_site_all(); $v = array();
    if ($s['theme_mode']==='light') return x_theme_light_css($s);
    if (x_color_ok($s['c_accent'])) { $a = $s['c_accent']; $v[] = '--green:'.$a; $v[] = '--green-bg:'.$a.'12'; $v[] = '--green-glow:'.$a.'30'; $v[] = '--glow:'.$a.'30'; }
    if (x_color_ok($s['c_bg'])) $v[] = '--bg:'.$s['c_bg'];
    if (x_color_ok($s['c_surface'])) { $v[] = '--surface:'.$s['c_surface']; $v[] = '--surface2:'.x_lighten($s['c_surface'], 6); }
    if (x_color_ok($s['c_border'])) { $v[] = '--border:'.$s['c_border']; $v[] = '--border2:'.x_lighten($s['c_border'], 10); }
    if (x_color_ok($s['c_text'])) $v[] = '--text:'.$s['c_text'];
    if (x_color_ok($s['c_text2'])) $v[] = '--text2:'.$s['c_text2'];
    return $v ? '<style>:root{'.implode(';', $v).'}</style>' : '';
}
function x_site_has($k) { $s = x_site_all(); return isset($s['files'][$k]) && is_string($s['files'][$k]) && $s['files'][$k]!=='' && is_file(SITE_DIR.'/'.basename($s['files'][$k])); }
function x_site_url($k) { $s = x_site_all(); return $_SERVER['SCRIPT_NAME'].'?action=site_asset&k='.$k.'&v='.substr(md5(isset($s['files'][$k]) ? $s['files'][$k] : ''), 0, 8); }
function x_base_url() {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off');
    $host = isset($_SERVER['HTTP_HOST']) ? preg_replace('/[^A-Za-z0-9.:\-\[\]]/', '', $_SERVER['HTTP_HOST']) : 'localhost';
    return ($https ? 'https://' : 'http://').$host;
}
function x_seo_meta() {
    $s = x_site_all(); $o = '';
    if ($s['description']!=='') $o .= '<meta name="description" content="'.x_h($s['description']).'">';
    if ($s['keywords']!=='') $o .= '<meta name="keywords" content="'.x_h($s['keywords']).'">';
    if ($s['robots']==='noindex') $o .= '<meta name="robots" content="noindex,nofollow">';
    $ogt = $s['og_title']!=='' ? $s['og_title'] : $s['title'];
    $ogd = $s['og_description']!=='' ? $s['og_description'] : $s['description'];
    $o .= '<meta property="og:type" content="website"><meta property="og:title" content="'.x_h($ogt).'">';
    if ($ogd!=='') $o .= '<meta property="og:description" content="'.x_h($ogd).'">';
    if (x_site_has('og')) $o .= '<meta property="og:image" content="'.x_h(x_base_url().x_site_url('og')).'"><meta name="twitter:card" content="summary_large_image">';
    if (x_site_has('favicon')) $o .= '<link rel="icon" href="'.x_h(x_site_url('favicon')).'">';
    if (x_color_ok($s['c_accent'])) $o .= '<meta name="theme-color" content="'.x_h($s['c_accent']).'">';
    return $o;
}
function x_brand_icon($size) {
    if (x_site_has('logo')) return '<img src="'.x_h(x_site_url('logo')).'" alt="" style="height:'.((int)$size+10).'px;width:auto;max-width:96px;object-fit:contain;flex:0 0 auto">';
    $li = x_site_get('login_icon');
    if ($li==='none') return '';
    return svg(x_icon_ok($li) ? $li : 'shield', $size);
}
function x_brand_html() {
    $s = x_site_all();
    $a = x_color_ok($s['brand_a_color']) ? ' style="color:'.$s['brand_a_color'].'"' : '';
    $b = x_h($s['brand_b']); if (x_color_ok($s['brand_b_color'])) $b = '<span style="color:'.$s['brand_b_color'].'">'.$b.'</span>';
    return '<b'.$a.'>'.x_h($s['brand_a']).'</b>'.$b;
}
function x_login_icon() {
    $li = x_site_get('login_icon');
    if (!x_site_has('logo') && $li==='none') return '';
    if (!x_site_has('logo') && x_icon_ok($li)) return '<div class="icon">'.svg($li,22).'</div>';
    if (x_site_has('logo')) return '<div class="icon" style="background:none;width:auto;height:auto"><img src="'.x_h(x_site_url('logo')).'" alt="" style="max-width:170px;max-height:80px;object-fit:contain"></div>';
    return '<div class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>';
}
function x_login_bg_css() {
    if (!x_site_has('login_bg')) return '';
    $d = (int)x_site_get('login_dim'); if ($d < 0) $d = 0; if ($d > 100) $d = 100;
    $al = number_format(min(0.95, (100 - $d)/100), 2, '.', '');
    return '<style>.bg{background:linear-gradient(rgba(0,0,0,'.$al.'),rgba(0,0,0,'.$al.')),url("'.x_site_url('login_bg').'") center/cover no-repeat !important}</style>';
}
function x_site_asset_serve($k) {
    if (!in_array($k, array('logo','login_bg','favicon','og'), true)) { header('HTTP/1.0 404 Not Found'); exit; }
    $s = x_site_all(); $f = (isset($s['files'][$k]) && is_string($s['files'][$k])) ? basename($s['files'][$k]) : '';
    $p = SITE_DIR.'/'.$f; $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
    $mt = array('png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','gif'=>'image/gif','webp'=>'image/webp','ico'=>'image/x-icon');
    if ($f==='' || !is_file($p) || !isset($mt[$ext])) { header('HTTP/1.0 404 Not Found'); exit; }
    session_write_close();
    while (ob_get_level()) ob_end_clean();
    header_remove('Pragma');
    header('Content-Type: '.$mt[$ext]); if (!ini_get('zlib.output_compression')) header('Content-Length: '.filesize($p));
    header('Cache-Control: public, max-age=86400'); header('X-Content-Type-Options: nosniff');
    readfile($p); exit;
}
function x_site_upload($field, $key, &$err) {
    if (!isset($_FILES[$field]) || !is_array($_FILES[$field]) || !isset($_FILES[$field]['error']) || is_array($_FILES[$field]['error'])) return null;
    $f = $_FILES[$field];
    if ($f['error']===UPLOAD_ERR_NO_FILE) return null;
    if ($f['error']===UPLOAD_ERR_INI_SIZE || $f['error']===UPLOAD_ERR_FORM_SIZE) { $err = 'big_ini'; return null; }
    if ($f['error']!==UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) { $err = 'upload'; return null; }
    if ($f['size'] > 3*1024*1024) { $err = 'big'; return null; }
    $info = @getimagesize($f['tmp_name']);
    $map = array(IMAGETYPE_PNG=>'png', IMAGETYPE_JPEG=>'jpg', IMAGETYPE_GIF=>'gif', IMAGETYPE_WEBP=>'webp', 17=>'ico');
    if (!$info || !isset($map[$info[2]]) || x_img_bad($f['tmp_name'])) { $err = 'type'; return null; }
    if (!is_dir(SITE_DIR)) @mkdir(SITE_DIR, 0755, true);
    $name = $key.'_'.substr(md5(uniqid('', true)), 0, 10).'.'.$map[$info[2]];
    if (!move_uploaded_file($f['tmp_name'], SITE_DIR.'/'.$name)) { $err = 'move'; return null; }
    @chmod(SITE_DIR.'/'.$name, 0644);
    return $name;
}
function x_settings_site_ui() {
    $s = x_site_all(); $accs = x_accounts(); $me = x_acc_self();
    $defCol = array('c_accent'=>'#b71c1c','c_bg'=>'#0a0b0f','c_surface'=>'#111318','c_border'=>'#1e2130','c_text'=>'#8b8fa3','c_text2'=>'#d1d5e0');
    $colLbl = array('c_accent'=>'Vurgu rengi (düğmeler, aktif sekme)','c_bg'=>'Sayfa arka planı','c_surface'=>'Kart ve menü zemini','c_border'=>'Kenarlıklar','c_text'=>'Yazı rengi','c_text2'=>'Başlık ve parlak yazılar');
    $fileLbl = array('logo'=>'Logo (giriş ekranı ve sol menü)','login_bg'=>'Giriş ekranı arka plan görseli','favicon'=>'Site simgesi (favicon)','og'=>'Paylaşım görseli (SEO / sosyal medya)');
    ?>
<style>
.sx{max-width:980px}.sx h3{font-size:14px;color:var(--text2);margin:0 0 4px}.sx .muted{color:var(--text3);font-size:12px}
.sx-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px;margin-top:12px}
.sx label{display:block;font-size:11px;font-weight:700;color:var(--text);margin-bottom:5px;text-transform:uppercase;letter-spacing:.3px}
.sx input[type=text],.sx input[type=password],.sx textarea,.sx select{width:100%;padding:10px 12px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text2);font-size:13px;outline:none;font-family:var(--font)}
.sx input:focus,.sx textarea:focus,.sx select:focus{border-color:var(--green)}
.sx textarea{min-height:64px;resize:vertical}
.sx-col{display:flex;align-items:center;gap:8px;padding:8px 10px;background:var(--surface2);border:1px solid var(--border);border-radius:6px}
.sx-col input[type=color]{width:34px;height:28px;padding:0;border:1px solid var(--border);border-radius:4px;background:none;cursor:pointer}
.sx-col span{font-size:12px;color:var(--text2);flex:1}
.sx input[type=range]{accent-color:var(--green)}.sx-file{padding:10px;background:var(--surface2);border:1px solid var(--border);border-radius:6px}
.sx-file img{max-height:56px;max-width:100%;display:block;margin:6px 0;border-radius:4px;background:#0003}
.sx-file input[type=file]{font-size:12px;color:var(--text);width:100%}
.sx-acc{width:100%;min-width:0;border-collapse:collapse;margin-top:10px;table-layout:fixed}.sx-acc th:nth-child(1){width:25%}.sx-acc th:nth-child(2){width:20%}.sx-acc th:nth-child(3),.sx-acc th:nth-child(4){width:24%}.sx-acc th:nth-child(5){width:8%}.sx-acc input{min-width:0}.sx-acc th{font-size:10px;color:var(--text3);text-align:left;padding:4px 6px;text-transform:uppercase}
.sx-acc td{padding:5px 6px;vertical-align:middle}.sx-acc input[type=text],.sx-acc input[type=password]{padding:8px 10px}
.sx-badge{display:inline-block;font-size:10px;font-weight:700;padding:2px 7px;border-radius:10px;background:var(--surface2);border:1px solid var(--border);color:var(--text2)}
.sx-badge.ad{color:var(--green);border-color:var(--green)}
.sx-badge.on{color:#fff;background:#1e9e55;border-color:#1e9e55}.sx-badge.off{color:#9aa0a6;background:#3a3d44;border-color:#555962}.sx-badge.sa{color:#1a1200;background:#f5b301;border-color:#f5b301}
.acc-sec>summary .sx-badge{margin-left:4px;font-size:10px;letter-spacing:.3px}
.sx .sx-rsel{width:auto;max-width:100%;padding:3px 8px;font-size:11px;font-weight:700;border-radius:10px;background:var(--surface2);color:var(--text2)}.sx .sx-rsel.ad{color:var(--green);border-color:var(--green)}
.sx .sx-perm{display:flex;align-items:center;gap:5px;margin:6px 0 0;font-size:10px;font-weight:600;text-transform:none;letter-spacing:0;color:var(--text2);cursor:pointer}
.acc-sec>summary{list-style:none;cursor:pointer;padding:13px 16px;display:flex;align-items:center;gap:8px;font-size:14px;font-weight:700;color:var(--text2);user-select:none}.acc-sec>summary::-webkit-details-marker{display:none}.acc-sec>summary h3{margin:0;font-size:14px;line-height:1.5}.acc-sec>summary:hover{background:var(--surface2)}.acc-sec>summary::after{content:"";margin-left:auto;width:7px;height:7px;border-right:2px solid var(--text3);border-bottom:2px solid var(--text3);transform:rotate(45deg);transition:transform .2s}.acc-sec[open]>summary::after{transform:rotate(-135deg)}.acc-sec[open]>summary{border-bottom:1px solid var(--border)}
@media(max-width:700px){.sx-acc thead{display:none}.sx-acc tr{display:block;padding:8px 0;border-bottom:1px solid var(--border)}.sx-acc td{display:block;padding:3px 0}}
.sx .sx-del{display:inline-flex;align-items:center;gap:6px;margin:0;font-size:12px;font-weight:700;text-transform:none;letter-spacing:0;color:var(--text2);cursor:pointer}.sx .sx-del span{display:none}
.sx .sx-bdg{margin-top:6px;font-size:12px;padding:6px 9px}
.sx-acc tr.sx-prow>td{padding:0 6px 8px}.sx-acc tr.sx-prow{border-bottom:1px solid var(--border)}
.sx-pd[data-role=editor] .sx-pi:not(.ed),.sx-pd[data-role=editor] .sx-pg:not(.ed),.sx-pd:not([data-role=editor]) .sx-pg.edonly,.sx-pd:not([data-role=editor]) .sx-pi.edr{display:none}
.sx-pd{border:1px solid var(--border);border-radius:6px;background:var(--surface2)}.sx-pd>summary{cursor:pointer;padding:8px 10px;font-size:12px;font-weight:700;color:var(--text2);list-style:none;user-select:none}.sx-pd>summary::-webkit-details-marker{display:none}.sx-pd>summary .sx-pc{display:inline-block;margin-left:4px;padding:1px 7px;border-radius:10px;background:var(--surface);border:1px solid var(--border);font-size:10px;color:var(--green)}
.sx-ptb{display:flex;gap:6px;flex-wrap:wrap;padding:6px 10px;border-top:1px solid var(--border)}
.sx-pbox{max-height:250px;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;padding:8px 10px 2px;border-top:1px solid var(--border)}
.sx-pg{margin-bottom:12px}.sx-pgh{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px;font-size:11px;font-weight:800;color:var(--text);text-transform:uppercase;letter-spacing:.3px}
.sx .sx-pi{display:flex;align-items:center;gap:8px;margin:0 0 7px;font-size:12px;font-weight:500;text-transform:none;letter-spacing:0;color:var(--text2);cursor:pointer}
@media(max-width:700px){.sx .sx-del span{display:inline}.sx-pbox{max-height:300px}}
</style>
<div class="sx">
<?php if (x_perm('settings_site')): ?>
<form method="POST" action="?action=site_save&tab=settings" enctype="multipart/form-data" id="siteForm">
<details class="panel acc-sec" style="margin-top:14px"><summary><h3>Site başlığı ve SEO</h3></summary><div style="padding:16px">
<p class="muted">Tarayıcı sekmesinde ve arama motorlarında görünen bilgiler. Giriş ekranı herkese açık olduğu için bu bilgiler orada kullanılır.</p>
<div class="sx-grid">
<div><label>Site başlığı (sekme adı)</label><input type="text" name="title" maxlength="80" value="<?=x_h($s['title'])?>"></div>
<div><label>Üst başlıktaki küçük yazı</label><input type="text" name="app_name" maxlength="60" value="<?=x_h($s['app_name'])?>"></div>
<div style="grid-column:1/-1"><label>Açıklama (meta description)</label><textarea name="description" maxlength="300"><?=x_h($s['description'])?></textarea></div>
<div style="grid-column:1/-1"><label>Anahtar kelimeler (virgülle ayırın)</label><input type="text" name="keywords" maxlength="300" value="<?=x_h($s['keywords'])?>"></div>
<div><label>Paylaşım başlığı (boşsa site başlığı)</label><input type="text" name="og_title" maxlength="100" value="<?=x_h($s['og_title'])?>"></div>
<div><label>Paylaşım açıklaması (boşsa açıklama)</label><input type="text" name="og_description" maxlength="300" value="<?=x_h($s['og_description'])?>"></div>
<div><label>Arama motorları</label><select name="robots"><option value="">Dizinlenebilir (varsayılan)</option><option value="noindex"<?=$s['robots']==='noindex'?' selected':''?>>Gizle (noindex, nofollow)</option></select></div>
<?php foreach (array('favicon','og') as $fk): ?>
<div class="sx-file"><label><?=x_h($fileLbl[$fk])?></label><?php if (x_site_has($fk)): ?><a href="<?=x_h(x_site_url($fk))?>" target="_blank" rel="noopener" title="Görseli yeni sekmede aç"><img src="<?=x_h(x_site_url($fk))?>" alt=""></a><label style="text-transform:none;font-weight:500"><input type="checkbox" class="cbx" name="rm_<?=$fk?>" value="1"> Görseli kaldır</label><?php endif; ?><div class="file-zone" id="sfz_<?=$fk?>"><?=svg('upload',14)?> <span class="fzt">Görsel seçmek için tıklayın</span><span class="fzn" style="display:none"></span><input type="file" name="f_<?=$fk?>" accept="image/png,image/jpeg,image/gif,image/webp,image/x-icon" onchange="fu(this,'sfz_<?=$fk?>')"></div></div>
<?php endforeach; ?>
</div>
<div style="margin-top:16px"><button type="submit" class="btn btn-g"><?=svg('check',13)?> Kaydet</button></div>
</div></details>

<details class="panel acc-sec" style="margin-top:14px"><summary><h3>Görünüm ve giriş ekranı</h3></summary><div style="padding:16px">
<p class="muted">İlk açılışta ve sol menüde görünen yazılar, logo ve renkler. Boş bıraktığınız renk ve metinler varsayılan haliyle kalır.</p>
<div class="sx-grid">
<div><label>Marka yazısı (kalın, vurgulu kısım)</label><input type="text" name="brand_a" maxlength="40" value="<?=x_h($s['brand_a'])?>"></div>
<div><label>Marka yazısı (devamı)</label><input type="text" name="brand_b" maxlength="40" value="<?=x_h($s['brand_b'])?>"></div>
<?php foreach (array('brand_a_color'=>array('Marka yazısı (kalın kısım) rengi',isset($s['c_accent'])&&x_color_ok($s['c_accent'])?$s['c_accent']:$defCol['c_accent']),'brand_b_color'=>array('Marka yazısı (devamı) rengi',x_color_ok($s['c_text2'])?$s['c_text2']:$defCol['c_text2'])) as $bk=>$bv): $bon = x_color_ok($s[$bk]); ?>
<div class="sx-col"><input type="checkbox" class="cbx" id="use_<?=$bk?>" name="use_<?=$bk?>" value="1"<?=$bon?' checked':''?> title="Özel rengi kullan"><input type="color" name="<?=$bk?>" value="<?=x_h($bon ? $s[$bk] : $bv[1])?>" onchange="document.getElementById('use_<?=$bk?>').checked=true"><span><?=x_h($bv[0])?></span></div>
<?php endforeach; ?>
<div><label>Giriş ekranı ikonu</label><div class="ico-pick"><input type="hidden" name="login_icon" value="<?=x_h($s['login_icon'])?>"><button type="button" class="ico-cur btn btn-xs" onclick="icoToggle(this)" title="İkon seç"><?=$s['login_icon']==='none' ? '<span style="font-size:10px">Yok</span>' : svg(x_icon_ok($s['login_icon']) ? $s['login_icon'] : 'shield',15)?></button>
<div class="ico-grid"><span class="ico-opt" data-none="1" onclick="icoSet(this,'none')" title="İkonu kaldır">Yok</span><span class="ico-opt" data-none="1" onclick="icoSet(this,'')" title="Varsayılan ikon">Varsayılan</span><?php foreach (x_icon_names() as $in): ?><span class="ico-opt" onclick="icoSet(this,'<?=x_h($in)?>')" title="<?=x_h($in)?>"><?=svg($in,16)?></span><?php endforeach; ?></div></div><div class="muted" style="margin-top:4px">Logo yüklüyse logo görünür.</div></div>
<div><label>Giriş ekranı alt başlığı</label><input type="text" name="login_sub" maxlength="80" value="<?=x_h($s['login_sub'])?>"></div>
<div><label>Şifre kutusu yazısı</label><input type="text" name="login_ph" maxlength="60" value="<?=x_h($s['login_ph'])?>"></div>
<div><label>Giriş düğmesi yazısı</label><input type="text" name="login_btn" maxlength="40" value="<?=x_h($s['login_btn'])?>"></div>
<div><label>Giriş ekranı alt notu</label><input type="text" name="login_hint" maxlength="200" value="<?=x_h($s['login_hint'])?>"></div>
<?php foreach (array('logo','login_bg') as $fk): ?>
<div class="sx-file"><label><?=x_h($fileLbl[$fk])?></label><?php if (x_site_has($fk)): ?><a href="<?=x_h(x_site_url($fk))?>" target="_blank" rel="noopener" title="Görseli yeni sekmede aç"><img src="<?=x_h(x_site_url($fk))?>" alt=""></a><label style="text-transform:none;font-weight:500"><input type="checkbox" class="cbx" name="rm_<?=$fk?>" value="1"> Görseli kaldır</label><?php endif; ?><div class="file-zone" id="sfz_<?=$fk?>"><?=svg('upload',14)?> <span class="fzt">Görsel seçmek için tıklayın</span><span class="fzn" style="display:none"></span><input type="file" name="f_<?=$fk?>" accept="image/png,image/jpeg,image/gif,image/webp" onchange="fu(this,'sfz_<?=$fk?>')"></div></div>
<?php endforeach; ?>
<div><label>Arka plan görselinin parlaklığı (%<?=(int)$s['login_dim']?>) · düşürdükçe koyulaşır</label><input type="range" name="login_dim" min="0" max="100" value="<?=(int)$s['login_dim']?>" style="width:100%" oninput="this.previousElementSibling.textContent='Arka plan görselinin parlaklığı (%'+this.value+') · düşürdükçe koyulaşır'"></div>
</div>
<div class="sx-grid" style="margin-top:16px;grid-template-columns:minmax(200px,320px)"><div><label>Tema modu</label><select name="theme_mode" id="thMode" onchange="thModeSync()"><option value="">Koyu (varsayılan)</option><option value="light"<?=$s['theme_mode']==='light'?' selected':''?>>Açık (Light)</option></select><div class="muted" style="margin-top:4px">Açık seçilince panel, giriş ve düzenleme sayfaları açık renkli olur; aşağıdaki Açık tema renkleri kullanılır.</div></div></div>
<div id="thDark" class="sx-grid" style="margin-top:16px">
<?php foreach ($colLbl as $ck=>$cl): $on = x_color_ok($s[$ck]); $val = $on ? $s[$ck] : $defCol[$ck]; ?>
<div class="sx-col"><input type="checkbox" class="cbx" id="use_<?=$ck?>" name="use_<?=$ck?>" value="1"<?=$on?' checked':''?> title="Özel rengi kullan"><input type="color" name="<?=$ck?>" value="<?=x_h($val)?>" onchange="document.getElementById('use_<?=$ck?>').checked=true"><span><?=x_h($cl)?></span></div>
<?php endforeach; ?>
</div>
<div id="thLight" class="sx-grid" style="margin-top:16px">
<?php $ldef = x_light_defaults(); $llbl = array('l_accent'=>'Açık tema: Vurgu rengi (düğmeler, aktif sekme)','l_bg'=>'Açık tema: Sayfa arka planı','l_surface'=>'Açık tema: Kart ve menü zemini','l_border'=>'Açık tema: Kenarlıklar','l_text'=>'Açık tema: Yazı rengi','l_text2'=>'Açık tema: Başlık ve parlak yazılar'); foreach ($llbl as $ck=>$cl): $on = x_color_ok($s[$ck]); $val = $on ? $s[$ck] : $ldef[$ck]; ?>
<div class="sx-col"><input type="checkbox" class="cbx" id="use_<?=$ck?>" name="use_<?=$ck?>" value="1"<?=$on?' checked':''?> title="Özel rengi kullan"><input type="color" name="<?=$ck?>" value="<?=x_h($val)?>" onchange="document.getElementById('use_<?=$ck?>').checked=true"><span><?=x_h($cl)?></span></div>
<?php endforeach; ?>
</div>
<script>function thModeSync(){var m=document.getElementById('thMode').value==='light';var a=document.getElementById('thDark'),b=document.getElementById('thLight');if(a)a.style.display=m?'none':'';if(b)b.style.display=m?'':'none'}thModeSync();</script>
<div class="sx-grid" style="margin-top:16px;grid-template-columns:minmax(200px,320px) auto;align-items:end"><div><label>Tema adı</label><input type="text" name="theme_name" maxlength="30" placeholder="örn. Tema 1"></div><div><button type="submit" name="theme_save" value="1" class="btn btn-g btn-xs">Temayı kaydet</button></div></div>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px;align-items:center">
<button type="submit" class="btn btn-g"><?=svg('check',13)?> Kaydet</button>
<button type="submit" name="reset_colors" value="1" class="btn btn-xs">Renkleri varsayılana döndür</button>
<button type="submit" name="base_save" value="1" class="btn btn-or btn-xs" title="Şu anki ayarlar kalıcı ana varsayılan olur" onclick="return confirm('! DİKKAT: Şu anki tüm ayarlar ve görseller ana varsayılan olarak kaydedilecek.\n\nVarsa önceki ana varsayılan bunlarla DEĞİŞTİRİLİR ve geri getirilemez. Ana varsayılan kaldırılamaz, sadece yenisiyle değiştirilebilir. Tümünü sıfırla her zaman bu ayarlara dönecek.\n\nDevam edilsin mi?')"><b>!</b> Ana varsayılan yap</button>
<button type="submit" name="reset_all" value="1" class="btn btn-or btn-xs" onclick="return confirm('Tüm site, SEO ve görünüm ayarları ile yüklenen görseller silinip ana varsayılana (yoksa fabrika ayarlarına) dönecek. Emin misiniz?')">Tümünü sıfırla</button>
<button type="button" class="btn btn-xs" onclick="window.open('?action=login_preview','_blank')">Giriş ekranını önizle</button>
</div>
<?php if (x_base_info() !== ''): ?><div class="muted" style="margin-top:8px"><b>!</b> Ana varsayılan ayarlı (<?=x_h(x_base_info())?>): kaldırılamaz, yalnızca Ana varsayılan yap ile yenisiyle değiştirilebilir. Tümünü sıfırla ve Renkleri varsayılana döndür bu ayarlara döner.</div><?php endif; ?>
</div></details>
</form>
<script>
(function(){
var MAXD={f_logo:[600,300,0],f_login_bg:[1920,1080,1],f_og:[1200,630,1],f_favicon:[256,256,0]},pending=0,waiting=null,sf=document.getElementById('siteForm');
if(sf)sf.addEventListener('submit',function(e){if(pending>0){e.preventDefault();e.stopImmediatePropagation();waiting=e.submitter||null;var bs=sf.querySelectorAll('button[type=submit]');bs.forEach(function(b){b.disabled=true});sf._resume=function(){bs.forEach(function(b){b.disabled=false});if(sf.requestSubmit){try{sf.requestSubmit(waiting||undefined)}catch(x){sf.requestSubmit()}}else{sf.submit()}}}},true);
function done(){pending--;if(pending<=0){pending=0;if(sf&&sf._resume){var r=sf._resume;sf._resume=null;r()}}}
document.querySelectorAll('#siteForm input[type=file]').forEach(function(inp){
  var note=document.createElement('div');note.className='muted';note.style.marginTop='4px';inp.parentNode.appendChild(note);
  inp.addEventListener('change',function(){
    note.textContent='';var f=inp.files&&inp.files[0];if(!f||!/^image\/(png|jpeg|webp)$/.test(f.type))return;pending++;
    var lim=MAXD[inp.name]||[1600,1600,0],img=new Image(),url=URL.createObjectURL(f);
    img.onload=function(){URL.revokeObjectURL(url);var w=img.naturalWidth,h=img.naturalHeight,sc=Math.min(1,lim[0]/w,lim[1]/h);
      if(sc>=1&&f.size<=900*1024){done();return}
      var c=document.createElement('canvas');c.width=Math.max(1,Math.round(w*sc));c.height=Math.max(1,Math.round(h*sc));
      var ctx=c.getContext('2d'),jpg=!!lim[2]||f.type==='image/jpeg';
      if(jpg){ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height)}
      ctx.drawImage(img,0,0,c.width,c.height);
      c.toBlob(function(b){
        if(!b||(sc>=1&&b.size>=f.size)){done();return}
        try{var dt=new DataTransfer();dt.items.add(new File([b],f.name.replace(/\.[^.]+$/,'')+(jpg?'.jpg':'.png'),{type:jpg?'image/jpeg':'image/png'}));inp.files=dt.files;
          note.textContent='Görsel yüklemeden önce küçültüldü: '+Math.round(f.size/1024)+' KB → '+Math.round(b.size/1024)+' KB ('+c.width+'×'+c.height+')'}catch(e){}
        done();
      },jpg?'image/jpeg':'image/png',0.86)};
    img.onerror=function(){URL.revokeObjectURL(url);done()};img.src=url});
});
})();
</script>

<?php $thl = x_themes(); $thd = x_theme_default_id(); ?>
<details class="panel acc-sec" style="margin-top:14px"><summary><h3>Kayıtlı temalar</h3></summary><div style="padding:16px">
<p class="muted" style="margin:0 0 10px">Görünüm bölümünde istediğiniz ayarları yapıp ad yazarak "Temayı kaydet"e basın. Varsayılan yaptığınız tema, "Renkleri varsayılana döndür" ve "Tümünü sıfırla" düğmelerinde geri yüklenir.</p>
<?php if (!$thl): ?><p class="muted">Henüz kayıtlı tema yok.</p><?php else: ?>
<div style="display:flex;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:10px;font-size:12px;color:var(--text2)">
<label style="display:flex;align-items:center;gap:8px;cursor:pointer"><input type="checkbox" class="cbx" id="thSelAll" onchange="thSelectAll(this)"> Tümünü seç</label>
<span id="thSelCount" style="font-weight:600;color:var(--text)"></span>
<button type="button" class="btn btn-or btn-xs" onclick="thBulk()"><?=svg('trash',11)?> Seçilenleri sil</button>
</div>
<div style="max-height:340px;overflow-y:auto;border:1px solid var(--border);border-radius:6px;padding:0 10px">
<?php endif; ?>
<?php foreach ($thl as $th): $tvv = (isset($th['vals']) && is_array($th['vals'])) ? $th['vals'] : array(); $thid = isset($th['id']) ? $th['id'] : ''; $isd = ($thd !== '' && $thd === $thid); ?>
<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:9px 0;border-top:1px solid var(--border)">
<input type="checkbox" class="th-sel cbx" value="<?=x_h($thid)?>" onchange="thSelSync()" title="Silmek için seç">
<b><?=x_h(isset($th['name']) ? $th['name'] : '')?></b>
<?php foreach ((isset($tvv['theme_mode']) && $tvv['theme_mode']==='light') ? array('l_accent','l_bg','l_surface','l_text','brand_a_color','brand_b_color') : array('c_accent','c_bg','c_surface','c_text','brand_a_color','brand_b_color') as $tk): if (isset($tvv[$tk]) && x_color_ok($tvv[$tk])): ?><span style="display:inline-block;width:14px;height:14px;border-radius:50%;background:<?=x_h($tvv[$tk])?>;border:1px solid var(--border)"></span><?php endif; endforeach; ?>
<?php if ($isd): ?><span class="badge badge-b" style="font-size:10px">Varsayılan</span><?php endif; ?>
<span style="flex:1"></span>
<form method="POST" action="?action=theme_apply&tab=settings" style="display:inline"><input type="hidden" name="id" value="<?=x_h($thid)?>"><button type="submit" class="btn btn-g btn-xs">Uygula</button></form>
<?php if (x_base_info() === ''): ?><form method="POST" action="?action=theme_default&tab=settings" style="display:inline"><input type="hidden" name="id" value="<?=$isd ? '' : x_h($thid)?>"><button type="submit" class="btn btn-xs"><?=$isd ? 'Varsayılanı kaldır' : 'Varsayılan yap'?></button></form><?php endif; ?>
<form method="POST" action="?action=theme_delete&tab=settings" style="display:inline" onsubmit="return confirm('Bu tema silinsin mi?')"><input type="hidden" name="id" value="<?=x_h($thid)?>"><button type="submit" class="btn btn-or btn-xs">Sil</button></form>
</div>
<?php endforeach; ?>
<?php if ($thl): ?></div>
<script>
function thSelSync(){var b=document.querySelectorAll('.th-sel'),n=0;b.forEach(function(x){if(x.checked)n++});var c=document.getElementById('thSelCount');if(c)c.textContent=n?n+' tema seçildi':'';var a=document.getElementById('thSelAll');if(a)a.checked=b.length>0&&n===b.length}
function thSelectAll(a){document.querySelectorAll('.th-sel').forEach(function(x){x.checked=a.checked});thSelSync()}
function thBulk(){var ids=[];document.querySelectorAll('.th-sel').forEach(function(x){if(x.checked)ids.push(x.value)});if(!ids.length){alert('Silmek için en az bir tema seçin.');return}if(!confirm(ids.length+' tema silinecek. Emin misiniz?'))return;var f=document.createElement('form');f.method='POST';f.action='?action=theme_bulk_delete&tab=settings';ids.forEach(function(v){var i=document.createElement('input');i.type='hidden';i.name='ids[]';i.value=v;f.appendChild(i)});document.body.appendChild(f);f.submit()}
</script>
<?php endif; ?>
</div></details>
<?php endif; ?>

<?php $xd = x_data(); $bs = x_ban_settings($xd); $bl = x_ban_ips($xd); ?>
<?php if (x_perm('settings_site')): ?>
<details class="panel acc-sec" style="margin-top:14px"><summary><h3>Buton ayarları</h3></summary><div style="padding:16px">
<p class="muted" style="margin:0 0 12px">İşlem butonları, Kategori / Durum / PHP rozetleri ve pencerelerdeki Kapat düğmesi için ikon (işlem butonlarında), yazı/ikon rengi, arka plan, kenarlık ve köşe biçimi (kare, yuvarlak, oval) seçebilirsiniz. İşaretlemediğiniz renk varsayılan kalır.</p>
<form method="POST" action="?action=actbtn_save&tab=settings">
<?php foreach (x_ab_all() as $ak=>$av): $aa = x_ab_get($ak); $ic = in_array($aa['icon'], x_ab_icons(), true) ? $aa['icon'] : ''; ?>
<div style="display:flex;flex-wrap:wrap;gap:14px;align-items:center;padding:10px 0;border-top:1px solid var(--border)">
<div style="min-width:190px"><?php if ($av[1]!==null): ?><span class="btn btn-o btn-xs" data-ab="<?=$ak?>" style="pointer-events:none"><?=svg($ic!=='' ? $ic : $av[1],11)?></span><?php elseif ($ak==='close'): ?><span class="modal-close" style="position:static;float:none;margin:0;display:inline-flex;pointer-events:none"><?=svg('x',14)?></span><?php elseif ($ak==='cat'): ?><span class="badge badge-b x-abp-cat" style="pointer-events:none">Kategori</span><?php elseif ($ak==='pass_r'): ?><span class="badge badge-r x-abp-pass_r" style="pointer-events:none"><?=svg('lock',9)?> Şifreli</span><?php elseif ($ak==='pass_g'): ?><span class="badge badge-g x-abp-pass_g" style="pointer-events:none"><?=svg('unlock',9)?> Açık</span><?php else: ?><span class="badge badge-a x-abp-php" style="pointer-events:none">PHP 8</span><?php endif; ?> <b style="margin-left:6px"><?=x_h($av[0])?></b></div>
<?php if ($av[1]!==null): ?><div class="ico-pick"><input type="hidden" name="ab_<?=$ak?>_icon" value="<?=x_h($ic)?>"><button type="button" class="ico-cur btn btn-xs" onclick="icoToggle(this)" title="İkon seç"><?=svg($ic!=='' ? $ic : $av[1],15)?></button>
<div class="ico-grid"><span class="ico-opt" data-none="1" onclick="icoSet(this,'')" title="Varsayılan ikon">Varsayılan</span><?php foreach (x_ab_icons() as $in): ?><span class="ico-opt" onclick="icoSet(this,'<?=x_h($in)?>')" title="<?=x_h($in)?>"><?=svg($in,16)?></span><?php endforeach; ?></div></div><?php endif; ?>
<select name="ab_<?=$ak?>_rad" title="Köşe biçimi" style="width:auto"><?php foreach (x_ab_rads() as $rv=>$rl): ?><option value="<?=x_h($rv)?>"<?=$aa['rad']===$rv?' selected':''?>><?=x_h($rl)?></option><?php endforeach; ?></select>
<?php foreach (array('color'=>'Yazı/ikon','bg'=>'Arka plan','bd'=>'Kenarlık') as $f=>$fl): $on = x_color_ok($aa[$f]); ?>
<label style="display:inline-flex;align-items:center;gap:6px;text-transform:none;font-weight:500;margin:0"><input type="checkbox" class="cbx" id="abu_<?=$ak.'_'.$f?>" name="abu_<?=$ak.'_'.$f?>" value="1"<?=$on?' checked':''?>><input type="color" name="ab_<?=$ak.'_'.$f?>" value="<?=x_h($on ? $aa[$f] : '#888888')?>" onchange="document.getElementById('abu_<?=$ak.'_'.$f?>').checked=true"> <?=$fl?></label>
<?php endforeach; ?>
<label style="display:inline-flex;align-items:center;gap:6px;text-transform:none;font-weight:500;margin:0"><input type="checkbox" class="cbx" name="ab_<?=$ak?>_bgt" value="1"<?=$aa['bgt']==='1'?' checked':''?>> Şeffaf arka plan</label>
</div>
<?php endforeach; ?>
<script>(function(){function hx(c){var m=c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);if(!m)return null;if(m[4]!==undefined&&parseFloat(m[4])===0)return null;return '#'+[1,2,3].map(function(i){return ('0'+parseInt(m[i],10).toString(16)).slice(-2)}).join('')}
var pg=hx(getComputedStyle(document.body).backgroundColor)||'#ffffff';
document.querySelectorAll('form[action*=actbtn_save] > div').forEach(function(row){var pv=row.querySelector('div > span.btn,div > span.badge,div > span.modal-close');if(!pv)return;var cs=getComputedStyle(pv);
var vals={color:hx(cs.color),bg:hx(cs.backgroundColor)||pg,bd:hx(cs.borderTopColor)};
Object.keys(vals).forEach(function(f){var cb=row.querySelector('input[type=checkbox][name$="_'+f+'"]');if(!cb||cb.checked)return;var inp=row.querySelector('input[type=color][name$="_'+f+'"]');if(inp&&vals[f])inp.value=vals[f]})})})();</script>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button type="submit" class="btn btn-g"><?=svg('check',13)?> Kaydet</button><button type="submit" name="ab_reset" value="1" class="btn btn-xs" onclick="return confirm('Tüm işlem butonları varsayılana dönsün mü?')">Varsayılana döndür</button></div>
</form></div></details>
<?php endif; ?>

<?php if (x_perm('settings_site')): ?>
<details class="panel acc-sec" style="margin-top:14px"><summary><h3>Boş liste yazıları</h3></summary><div style="padding:16px">
<p class="muted" style="margin:0 0 12px">Dosya Arşivi, GitHub ve Bilgiler boşken görünen başlık, açıklama ve ikon. Açıklamayı boş bırakırsanız varsayılan yazı (yalnızca yöneticilere) görünür.</p>
<form method="POST" action="?action=empty_save&tab=settings" onsubmit="this.querySelectorAll('.rich-content').forEach(function(e){syncRich(e)});return true">
<?php foreach (x_empty_defs() as $ek=>$ed): $ee = x_empty_get($ek); $eh = trim(strip_tags($ee['html']))!=='' ? $ee['html'] : '<p>'.x_h($ed[3]).'</p>'; ?>
<div style="border:1px solid var(--border);border-radius:8px;padding:12px;margin-bottom:12px"><b><?=x_h($ed[0])?></b>
<div class="sx-grid" style="margin-top:8px"><div><label>Başlık</label><input type="text" name="e_<?=$ek?>_title" maxlength="120" value="<?=x_h($ee['title'])?>"></div>
<div><label>İkon</label><div class="ico-pick"><input type="hidden" name="e_<?=$ek?>_icon" value="<?=x_h($ee['icon'])?>"><button type="button" class="ico-cur btn btn-xs" onclick="icoToggle(this)" title="İkon seç"><?=$ee['icon']==='none' ? '<span style="font-size:10px">Yok</span>' : svg(x_icon_ok($ee['icon']) ? $ee['icon'] : $ed[1],15)?></button>
<div class="ico-grid"><span class="ico-opt" data-none="1" onclick="icoSet(this,'none')" title="İkonu kaldır">Yok</span><span class="ico-opt" data-none="1" onclick="icoSet(this,'')" title="Varsayılan ikon">Varsayılan</span><?php foreach (x_icon_names() as $in): ?><span class="ico-opt" onclick="icoSet(this,'<?=x_h($in)?>')" title="<?=x_h($in)?>"><?=svg($in,16)?></span><?php endforeach; ?></div></div></div></div>
<div style="margin-top:10px"><label>Açıklama</label><?=x_rich_editor('emptyEd_'.$ek,'e_'.$ek.'_html',$eh,'Açıklamayı yazın...')?></div>
<label style="display:inline-flex;align-items:center;gap:6px;text-transform:none;font-weight:500;margin-top:8px"><input type="checkbox" class="cbx" name="e_<?=$ek?>_vis" value="1"<?=$ee['vis']==='1'?' checked':''?>> Açıklama ziyaretçilere de görünsün</label></div>
<?php endforeach; ?>
<div style="display:flex;gap:8px;flex-wrap:wrap"><button type="submit" class="btn btn-g"><?=svg('check',13)?> Kaydet</button><button type="submit" name="empty_reset" value="1" class="btn btn-xs" onclick="return confirm('Üç liste de varsayılan yazı ve ikonlara dönsün mü?')">Varsayılana döndür</button></div>
</form></div></details>
<?php endif; ?>

<?php if (x_perm('settings_ban')): ?>
<details class="panel acc-sec" style="margin-top:14px"><summary><h3>Engelleme sayfası ve engelli IP'ler</h3></summary><div style="padding:16px">
<p class="muted" style="margin:0 0 12px">Engellenen bir IP siteye girmek istediğinde bu sayfayı görür. İstatistik sekmesindeki giriş listesinden IP engelleyebilir veya aşağıdan elle ekleyebilirsiniz.</p>
<form method="POST" action="?action=ban_save&tab=settings" onsubmit="return prepareRichForm(this,'banContent')">
<div class="sx-grid">
<div><label>Başlık</label><input type="text" name="ban_title" maxlength="80" value="<?=x_h($bs['title'])?>"></div>
<div><label>Buton yazısı (boşsa buton görünmez)</label><input type="text" name="ban_btn" maxlength="40" value="<?=x_h($bs['btn'])?>" placeholder="örn. İletişime geç"></div>
<div><label>Buton adresi (https://, mailto: veya tel:)</label><input type="text" name="ban_url" maxlength="300" value="<?=x_h($bs['url'])?>" placeholder="https://..."></div>
</div>
<div style="margin-top:12px"><label>Mesaj</label><?=x_rich_editor('banContent','content',$bs['html'],'Engellenen kişiye gösterilecek mesajı yazın...')?></div>
<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap"><button type="submit" class="btn btn-g"><?=svg('check',13)?> Kaydet</button><button type="button" class="btn btn-xs" onclick="window.open('?action=ban_preview','_blank')">Kayıtlı sayfayı önizle</button></div>
</form>
<h3 style="margin:20px 0 8px">Engelli IP'ler (<?=count($bl)?>)</h3>
<form method="POST" action="?action=ip_ban&tab=settings" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px"><input type="text" name="ip" placeholder="IP adresi (örn. 203.0.113.5)" maxlength="45" style="max-width:260px" required><button type="submit" class="btn btn-or btn-xs">IP engelle</button></form>
<?php if (!$bl): ?><p class="muted">Engelli IP yok.</p><?php else: ?>
<form method="POST" action="?action=ip_unban_bulk&tab=settings" id="banBulk">
<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:8px"><label style="display:inline-flex;align-items:center;gap:6px;text-transform:none;font-weight:500;margin:0"><input type="checkbox" class="cbx" id="banAll" onchange="document.querySelectorAll('#banBulk .ban-sel').forEach(function(c){c.checked=document.getElementById('banAll').checked});banSync()"> Tümünü seç</label>
<button type="submit" class="btn btn-g btn-xs" id="banSelBtn" disabled onclick="return confirm('Seçili IP engelleri kaldırılsın mı?')">Seçilenlerin engelini kaldır</button>
<button type="submit" name="all" value="1" class="btn btn-or btn-xs" onclick="return confirm('Tüm IP engelleri kaldırılsın mı?')">Tümünü kaldır</button><span class="muted" id="banCnt"></span></div>
<div style="max-height:260px;overflow-y:auto;border:1px solid var(--border);border-radius:6px;padding:0 10px">
<?php foreach (array_reverse($bl) as $bb): if (!is_array($bb) || empty($bb['ip'])) continue; ?>
<label style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:8px 0;border-top:1px solid var(--border);cursor:pointer;text-transform:none;font-weight:500;margin:0"><input type="checkbox" class="cbx ban-sel" name="ips[]" value="<?=x_h($bb['ip'])?>" onchange="banSync()"><code><?=x_h($bb['ip'])?></code><span class="muted"><?=x_h(isset($bb['time']) ? $bb['time'] : '')?></span></label>
<?php endforeach; ?>
</div></form>
<script>function banSync(){var a=document.querySelectorAll('#banBulk .ban-sel'),n=0;a.forEach(function(c){if(c.checked)n++});var b=document.getElementById('banSelBtn');if(b)b.disabled=n===0;var t=document.getElementById('banCnt');if(t)t.textContent=n?n+' seçili':'';var al=document.getElementById('banAll');if(al)al.checked=a.length>0&&n===a.length}</script>
<?php endif; ?>
</div></details>
<?php endif; ?>

<?php if (x_perm('settings_vpn')): ?>
<?php $vps = x_vpn_settings($xd); $vdiag = (isset($_SESSION['x_vpn_diag']) && is_string($_SESSION['x_vpn_diag'])) ? $_SESSION['x_vpn_diag'] : ''; unset($_SESSION['x_vpn_diag']); ?>
<details class="panel acc-sec" style="margin-top:14px"<?=($vdiag!==''?' open':'')?>><summary><h3>VPN / Proxy / Tor engelleme</h3><span class="sx-badge <?=$vps['enabled']?'on':'off'?>"><?=$vps['enabled']?'Aktif':($vps['off']?'Kapalı':'Pasif')?></span></summary><div style="padding:16px">
<p class="muted" style="margin:0 0 12px">VPN, proxy veya Tor ile gelen ziyaretçiler otomatik tespit edilir ve İstatistik sekmesinde "VPN ile giriş tespit edildi" olarak listelenir (buradan IP engelleyebilirsiniz). Aşağıdaki durum "Aktif" olursa bu kişiler siteye hiç giremez ve aşağıdaki sayfayı görür. Yönetici girişi yapmış hesaplar engellenmez. Tespit ülkeden bağımsızdır: Tor çıkış listesi, proxycheck.io, ipapi.is ve ip-api kaynakları birlikte kullanılır; VPN, proxy, Tor ve sunucu/hosting (datacenter) IP'leri yakalanır.</p>
<?php if ($vdiag!==''): ?><div style="margin:0 0 12px;padding:10px 12px;border:1px solid var(--border);border-radius:6px;background:var(--surface2);font-size:12px"><?=x_h($vdiag)?></div><?php endif; ?>
<form method="POST" action="?action=vpn_save&tab=settings" onsubmit="return prepareRichForm(this,'vpnContent')">
<div class="sx-grid">
<div><label>VPN engelleme</label><select name="vpn_enabled"><option value="0"<?=(!$vps['enabled'] && !$vps['off'])?' selected':''?>>Pasif (sadece tespit et ve kaydet)</option><option value="1"<?=$vps['enabled']?' selected':''?>>Aktif (VPN ile girişi engelle)</option><option value="2"<?=$vps['off']?' selected':''?>>Tamamen kapalı (tespit etme, kaydetme, listede gösterme)</option></select></div>
<div><label>proxycheck.io API anahtarı (isteğe bağlı)</label><input type="text" name="vpn_key" maxlength="80" value="<?=x_h($vps['key'])?>" placeholder="ücretsiz anahtar: proxycheck.io" autocomplete="off"></div>
<div><label>Başlık</label><input type="text" name="vpn_title" maxlength="80" value="<?=x_h($vps['title'])?>"></div>
<div><label>Buton yazısı (boşsa buton görünmez)</label><input type="text" name="vpn_btn" maxlength="40" value="<?=x_h($vps['btn'])?>" placeholder="örn. İletişime geç"></div>
<div><label>Buton adresi (https://, mailto: veya tel:)</label><input type="text" name="vpn_url" maxlength="300" value="<?=x_h($vps['url'])?>" placeholder="https://..."></div>
</div>
<div style="margin-top:12px"><label>Mesaj</label><?=x_rich_editor('vpnContent','content',$vps['html'],'VPN ile girenlere gösterilecek mesajı yazın...')?></div>
<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap"><button type="submit" class="btn btn-g"><?=svg('check',13)?> Kaydet</button><button type="button" class="btn btn-xs" onclick="window.open('?action=vpn_preview','_blank')">Kayıtlı sayfayı önizle</button></div>
</form>
<form method="POST" action="?action=vpn_test&tab=settings" style="margin-top:10px"><button type="submit" class="btn btn-xs">Bağlantıyı dene</button> <span class="muted">Sunucunun Tor listesine ve VPN servisine ulaşıp ulaşamadığını kontrol eder.</span></form>
</div></details>
<?php endif; ?>

<?php if (x_perm('settings_cf')): ?>
<?php $cfOn = x_cf_enabled(); $cfRa = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : ''; $cfHd = (isset($_SERVER['HTTP_CF_CONNECTING_IP']) && is_string($_SERVER['HTTP_CF_CONNECTING_IP'])) ? trim($_SERVER['HTTP_CF_CONNECTING_IP']) : ''; ?>
<details class="panel acc-sec" style="margin-top:14px"><summary><h3>Cloudflare arkasında çalışma</h3></summary><div style="padding:16px">
<p class="muted" style="margin:0 0 12px">Siteniz Cloudflare (veya benzeri bir koruma/CDN) arkasındaysa sunucu herkesi Cloudflare'in IP'si olarak görür; IP kayıtları, IP engelleme, VPN tespiti ve yanlış şifre kilidi bu yüzden yanlış çalışır. Aktif yaparsanız ziyaretçinin gerçek IP'si Cloudflare'in gönderdiği bilgiden okunur. Güvenlik için bu bilgiye yalnızca bağlantı gerçekten Cloudflare sunucularından geldiğinde güvenilir, kimse sahte IP gönderemez. Cloudflare kullanmıyorsanız Pasif bırakın.</p>
<form method="POST" action="?action=cf_save&tab=settings" style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
<div><label>Cloudflare modu</label><select name="cf_enabled"><option value="0"<?=$cfOn?'':' selected'?>>Pasif (normal sunucu)</option><option value="1"<?=$cfOn?' selected':''?>>Aktif (Cloudflare arkasındayım)</option></select></div>
<button type="submit" class="btn btn-g"><?=svg('check',13)?> Kaydet</button>
</form>
<div style="margin-top:12px;padding:10px 12px;border:1px solid var(--border);border-radius:6px;background:var(--surface2);font-size:12px;line-height:1.7">
Sunucuya gelen bağlantı IP'si: <code><?=x_h($cfRa)?></code><br>
Cloudflare'in gönderdiği ziyaretçi IP'si: <code><?=x_h($cfHd!=='' ? $cfHd : 'yok')?></code><br>
Sitenin şu an kullandığı IP: <code><?=x_h(x_ip())?></code>
<?php if ($cfHd!=='' && !$cfOn): ?><br><b>Cloudflare başlığı görünüyor; aktif yapmanız önerilir.</b><?php elseif ($cfHd!=='' && $cfOn && !x_is_cf_ip($cfRa)): ?><br><b>Başlık geliyor ama bağlantı Cloudflare aralığında değil, güvenilmediği için kullanılmıyor.</b><?php elseif ($cfHd==='' && $cfOn): ?><br><b>Şu an Cloudflare başlığı gelmiyor; site Cloudflare üzerinden açılmıyor olabilir.</b><?php endif; ?>
</div>
<p class="muted" style="margin:10px 0 0">Cloudflare panelinde alan adınızın DNS kaydı turuncu bulutlu (Proxied) olmalıdır.</p>
</div></details>
<?php endif; ?>

<?php if (x_perm('acc_manage')): ?>
<details class="panel acc-sec" style="margin-top:14px"><summary><h3>Hesaplar ve şifreler</h3></summary><div style="padding:16px">
<p class="muted">Giriş yalnızca şifreyle yapılır; hangi şifrenin hangi hesaba ait olduğu buradan belirlenir. Her hesabın şifresi farklı olmalı (en az 6 karakter). Şifreyi değiştirmek için yeni şifreyi bir kez yazmanız yeterli.</p>
<form method="POST" action="?action=acc_save&tab=settings" autocomplete="off">
<table class="sx-acc"><thead><tr><th>Hesap adı</th><th>Rol ve rozet</th><th>Yeni şifre</th><th>Sil</th></tr></thead><tbody>
<?php foreach ($accs as $ac): $isMe = ($me && $me['id']===$ac['id']); $isSA = ($ac['id']==='builtin_admin'); $isSup = !empty($ac['super']); $lockSA = (($isSA && !x_super_root()) || ($isSup && !x_super())); $canRole = (!$isSA && !$isMe && !($isSup && !x_super())); ?>
<tr>
<td><input type="text" name="name[<?=x_h($ac['id'])?>]" value="<?=x_h($ac['name'])?>" maxlength="30"<?=$lockSA ? ' disabled' : ''?>><?php if ($ac['builtin']): ?><div class="muted" style="margin-top:3px">varsayılan hesap</div><?php elseif ($isMe): ?><div class="muted" style="margin-top:3px">şu an giriş yaptığınız hesap</div><?php endif; ?></td>
<td><?php if ($canRole): ?><select name="role[<?=x_h($ac['id'])?>]" class="sx-rsel <?=$ac['role']==='admin'?'ad':''?>" style="<?=x_h(ltrim(x_badge_style($ac['id'],'sx'),';'))?>" title="Rolü değiştir" onchange="this.classList.toggle('ad',this.value==='admin'||this.value==='super');sxPRole(this,'<?=x_h($ac['id'])?>')"><option value="visitor"<?=$ac['role']==='visitor'?' selected':''?>><?=x_h(($ac['role']==='visitor' && $ac['badge']!=='') ? $ac['badge'] : 'Ziyaretçi')?></option><?php if (x_super() || $ac['role']==='editor'): ?><option value="editor"<?=$ac['role']==='editor'?' selected':''?>><?=x_h(($ac['role']==='editor' && $ac['badge']!=='') ? $ac['badge'] : 'Editör')?></option><?php endif; ?><option value="admin"<?=($ac['role']==='admin' && !$isSup)?' selected':''?>><?=x_h(($ac['role']==='admin' && !$isSup && $ac['badge']!=='') ? $ac['badge'] : 'Yönetici')?></option><?php if (x_super()): ?><option value="super"<?=$isSup?' selected':''?>><?=x_h(($isSup && $ac['badge']!=='') ? $ac['badge'] : 'Süper Admin')?></option><?php endif; ?></select><?php else: ?><span class="sx-badge <?=$ac['role']==='admin'?'ad':''?>" style="<?=x_h(ltrim(x_badge_style($ac['id'],'sx'),';'))?>"><?=x_h(x_role_label($ac))?></span><?php endif; ?><?php if (x_super()): ?><input type="text" class="sx-bdg" name="badge[<?=x_h($ac['id'])?>]" value="<?=x_h($ac['badge'])?>" maxlength="24" placeholder="Rozet adı (boşsa: <?=x_h(x_role_def($ac))?>)" title="Rozet yazısını değiştir" autocomplete="off"><?=x_emoji_bar()?><div style="display:flex;align-items:center;gap:8px;margin-top:6px"><input type="color" name="bcolor[<?=x_h($ac['id'])?>]" value="<?=x_h($ac['badge_color']!=='' ? $ac['badge_color'] : '#35d07f')?>" style="width:34px;height:26px;padding:0;border:1px solid var(--border);border-radius:4px;background:none;cursor:pointer" onchange="this.nextElementSibling.firstElementChild.checked=true" title="Rozet rengi"><label class="sx-perm" style="margin:0"><input type="checkbox" class="cbx" name="bcolor_on[<?=x_h($ac['id'])?>]" value="1"<?=$ac['badge_color']!=='' ? ' checked' : ''?>> Özel renk</label></div><?php endif; ?></td>
<td><input type="password" name="pass[<?=x_h($ac['id'])?>]" placeholder="<?=$lockSA ? 'bu hesabın şifresi değiştirilemez' : 'yeni şifre (değiştirmek için yazın)'?>" autocomplete="new-password" data-lpignore="true"<?=$lockSA ? ' disabled' : ''?>></td>
<td><?php if (!$isSA && !$isMe && !($isSup && !x_super())): ?><label class="sx-del"><input type="checkbox" class="cbx" name="del[]" value="<?=x_h($ac['id'])?>" title="Bu hesabı sil"><span>Sil</span></label><?php else: ?><span class="muted">—</span><?php endif; ?></td>
</tr>
<?php if (x_super() && !$isSA && !$isSup): ?><tr class="sx-prow"><td colspan="4"><?=x_perm_panel($ac['id'], x_acc_perms($ac), 'data-acc="'.x_h($ac['id']).'" data-role="'.x_h($ac['role']).'"')?></td></tr><?php endif; ?>
<?php endforeach; ?>
</tbody></table>
<script>
function sxPCnt(d){if(!d)return;var t=d.querySelectorAll('.sx-pbox input[type=checkbox]'),n=0;t.forEach(function(x){if(x.checked)n++});var c=d.querySelector('.sx-pc');if(c)c.textContent=n+'/'+t.length}
function sxPAll(b,on){var d=b.closest('.sx-pd');d.querySelectorAll('.sx-pbox input[type=checkbox]').forEach(function(x){x.checked=on});sxPCnt(d)}
function sxPGrp(b){var g=b.closest('.sx-pg'),bx=g.querySelectorAll('input[type=checkbox]'),all=true;bx.forEach(function(x){if(!x.checked)all=false});bx.forEach(function(x){x.checked=!all});sxPCnt(b.closest('.sx-pd'))}
document.addEventListener('DOMContentLoaded',function(){
var pw=document.querySelectorAll('.sx input[type=password]');
pw.forEach(function(i){i.readOnly=true;i.addEventListener('focus',function(){i.readOnly=false});['input','change','keydown'].forEach(function(ev){i.addEventListener(ev,function(){i.dataset.t='1'})})});
function wipe(){pw.forEach(function(i){if(!i.dataset.t)i.value=''})}
setTimeout(wipe,300);setTimeout(wipe,1200);
document.querySelectorAll('.sx form').forEach(function(f){f.addEventListener('submit',function(){f.querySelectorAll('input[type=password]').forEach(function(i){if(!i.dataset.t)i.value=''})})});
});
var sxTpl=<?=json_encode(array('super'=>x_perm_keys(),'visitor'=>x_perm_default('visitor'),'editor'=>x_perm_default('editor'),'admin'=>x_perm_default('admin')))?>;function sxPApply(d,r){var t=sxTpl[r]||[];d.querySelectorAll('.sx-pbox input[type=checkbox]').forEach(function(x){x.checked=t.indexOf(x.value)>=0});sxPCnt(d)}function sxPTpl(b,r){var d=b.closest('.sx-pd');if(d)sxPApply(d,r)}function sxPRole(sel,id){var d=document.querySelector('.sx-pd[data-acc="'+id+'"]');if(!d)return;var r=sel.value;d.setAttribute('data-role',r);sxPApply(d,r)}
</script>
<div style="margin-top:12px"><button type="submit" class="btn btn-g"><?=svg('check',13)?> Hesapları kaydet</button></div>
</form>
<hr style="border:0;border-top:1px solid var(--border);margin:18px 0">
<h3>Yeni hesap oluştur</h3>
<form method="POST" action="?action=acc_add&tab=settings" autocomplete="off">
<div class="sx-grid">
<div><label>Hesap adı</label><input type="text" name="name" maxlength="30" required placeholder="Örn: Ahmet"></div>
<div><label>Rol</label><select name="role" onchange="sxPRole(this,'new')"><option value="visitor">Ziyaretçi</option><?php if (x_super()): ?><option value="editor">Editör</option><?php endif; ?><option value="admin">Yönetici</option><?php if (x_super()): ?><option value="super">Süper Admin</option><?php endif; ?></select></div>
<div><label>Şifre</label><input type="password" name="pass" required autocomplete="new-password" data-lpignore="true" placeholder="en az 6 karakter"></div>
<?php if (x_super()): ?><div><label>Rozet (isteğe bağlı)</label><input type="text" name="badge" maxlength="24" placeholder="Boşsa rol adı görünür" autocomplete="off"><?=x_emoji_bar()?><div style="display:flex;align-items:center;gap:8px;margin-top:6px"><input type="color" name="bcolor" value="#35d07f" style="width:34px;height:26px;padding:0;border:1px solid var(--border);border-radius:4px;background:none;cursor:pointer" onchange="this.nextElementSibling.firstElementChild.checked=true" title="Rozet rengi"><label class="sx-perm" style="margin:0"><input type="checkbox" class="cbx" name="bcolor_on" value="1"> Özel renk</label></div></div><?php endif; ?>
</div>
<?php if (x_super()): ?><div style="margin-top:12px"><?=x_perm_panel('new', array(), 'data-acc="new" data-role="visitor"')?></div><?php endif; ?>
<div style="margin-top:12px"><button type="submit" class="btn btn-g"><?=svg('plus',13)?> Hesabı oluştur</button></div>
</form>
</div></details>
<?php endif; ?>
</div>
<?php
}
function svg($n,$s=16) {
    $icons=[
        'layers'=>'<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
        'shield'=>'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        'home'=>'<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
        'star'=>'<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
        'heart'=>'<path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>',
        'bell'=>'<path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/>',
        'user'=>'<path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'mail'=>'<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
        'music'=>'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
        'video'=>'<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>',
        'globe'=>'<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/>',
        'bookmark'=>'<path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z"/>',
        'clipboard'=>'<path d="M16 4h2a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/>',
        'briefcase'=>'<rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/>',
        'camera'=>'<path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/><circle cx="12" cy="13" r="4"/>',
        'gift'=>'<polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 010-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 000-5C13 2 12 7 12 7z"/>',
        'key'=>'<path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>',
        'map-pin'=>'<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/>',
        'zap'=>'<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
        'grid'=>'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
        'eye'=>'<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
        'download'=>'<path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
        'trash'=>'<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>',
        'upload'=>'<path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
        'lock'=>'<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/>',
        'unlock'=>'<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 019.9-1"/>',
        'file'=>'<path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/>',
        'calendar'=>'<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
        'logout'=>'<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
        'plus'=>'<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
        'chevron-down'=>'<polyline points="6 9 12 15 18 9"/>',
        'image'=>'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>',
        'search'=>'<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
        'edit'=>'<path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>',
        'pin'=>'<line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14v-1.76a2 2 0 00-1.11-1.79l-1.78-.9A2 2 0 0115 10.76V6h1a2 2 0 000-4H8a2 2 0 000 4h1v4.76a2 2 0 01-1.11 1.79l-1.78.9A2 2 0 005 15.24V17z"/>',
        'folder'=>'<path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>',
        'code'=>'<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>',
        'menu'=>'<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
        'tag'=>'<path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/>',
        'x'=>'<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
        'check'=>'<polyline points="20 6 9 17 4 12"/>',
        'copy'=>'<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>',
        'info'=>'<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
        'book'=>'<path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/>',
        'link'=>'<path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/>',
        'cog'=>'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"/>',
    ];
    $p=(isset($icons[$n]) ? $icons[$n] : '');
    return "<svg width=\"$s\" height=\"$s\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">$p</svg>";
}

function x_lg_load() { $d = x_data(); return (is_array($d) && isset($d['login_attempts']) && is_array($d['login_attempts'])) ? $d['login_attempts'] : array(); }
function x_lg_save($j) { $d = x_data(); if (!is_array($d)) return; if ($j) $d['login_attempts'] = $j; else unset($d['login_attempts']); x_save($d); }
function x_lg_key() { $i = x_ip(); return md5($i === 'unknown' ? '' : (string)$i); }
function x_lg_locked() { $j = x_lg_load(); $k = x_lg_key(); return isset($j[$k]) && is_array($j[$k]) && (int)$j[$k]['n'] >= 5 && (time() - (int)$j[$k]['t']) < 900; }
function x_lg_fail() { $j = x_lg_load(); $k = x_lg_key(); $now = time(); foreach ($j as $kk => $v) if (!is_array($v) || $now - (int)$v['t'] > 86400) unset($j[$kk]); if (!isset($j[$k]) || $now - (int)$j[$k]['t'] >= 900) $j[$k] = array('n' => 0, 't' => $now); $j[$k]['n']++; $j[$k]['t'] = $now; x_lg_save($j); }
function x_lg_clear() { $j = x_lg_load(); $k = x_lg_key(); if (isset($j[$k])) { unset($j[$k]); x_lg_save($j); } }
function x_sec_cfg() {
    $d = x_data(); $st = (is_array($d) && isset($d['settings']) && is_array($d['settings'])) ? $d['settings'] : array();
    $i = isset($st['sess_idle']) ? (int)$st['sess_idle'] : 30; if ($i < 5 || $i > 1440) $i = 30;
    $l = isset($st['dl_lim']) ? (int)$st['dl_lim'] : 0; if ($l < 0 || $l > 100000) $l = 0;
    $w = isset($st['dl_win']) ? (int)$st['dl_win'] : 60; if ($w < 1 || $w > 1440) $w = 60;
    return array('idle'=>$i, 'lim'=>$l, 'win'=>$w, 'adm'=>!empty($st['dl_adm']), 'show'=>!empty($st['dl_show']), 'zip'=>!isset($st['zip_on']) || !empty($st['zip_on']));
}
function x_sess_ep($uid) {
    $d = x_data(); $e = (is_array($d) && isset($d['settings']['sess_ep']) && is_array($d['settings']['sess_ep'])) ? $d['settings']['sess_ep'] : array();
    return (int)(isset($e['*']) ? $e['*'] : 0).'.'.(int)(isset($e[(string)$uid]) ? $e[(string)$uid] : 0);
}
function x_sess_bump($key) {
    $d = x_data(); if (!is_array($d)) return;
    if (!isset($d['settings']) || !is_array($d['settings'])) $d['settings'] = array();
    if (!isset($d['settings']['sess_ep']) || !is_array($d['settings']['sess_ep'])) $d['settings']['sess_ep'] = array();
    $d['settings']['sess_ep'][$key] = (int)(isset($d['settings']['sess_ep'][$key]) ? $d['settings']['sess_ep'][$key] : 0) + 1;
    x_save($d);
}
function x_dl_block($win) {
    while (ob_get_level()) ob_end_clean();
    http_response_code(429); header('Retry-After: '.(int)($win*60)); header('Content-Type: text/html; charset=UTF-8');
    echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>İndirme sınırı</title></head><body style="font-family:system-ui,sans-serif;background:#0f1117;color:#e7e9ee;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0"><div style="max-width:420px;padding:24px;text-align:center"><h2 style="margin:0 0 10px">İndirme sınırına ulaşıldı</h2><p style="color:#9aa1b2;line-height:1.5">Kısa sürede çok fazla indirme yaptınız. Lütfen bir süre sonra tekrar deneyin.</p><p><a href="'.htmlspecialchars($_SERVER['SCRIPT_NAME'], ENT_QUOTES, 'UTF-8').'" style="color:#5eead4">Geri dön</a></p></div></body></html>';
    exit;
}
function x_dl_gate(&$d) {
    $c = x_sec_cfg(); if (x_admin() && !$c['adm']) return;
    if ($c['lim'] < 1) return;
    $ip = (string)x_ip(); $now = time(); $from = $now - $c['win']*60;
    if (!isset($d['dlrate']) || !is_array($d['dlrate'])) $d['dlrate'] = array();
    foreach ($d['dlrate'] as $k=>$l) { $n = array(); if (is_array($l)) foreach ($l as $t) if ((int)$t > $from) $n[] = (int)$t; if ($n) $d['dlrate'][$k] = $n; else unset($d['dlrate'][$k]); }
    $cur = isset($d['dlrate'][$ip]) ? $d['dlrate'][$ip] : array();
    if (count($cur) >= $c['lim']) x_dl_block($c['win']);
    $cur[] = $now; $d['dlrate'][$ip] = $cur;
}
function x_dl_inc(&$d, $kind, $id) {
    if (!isset($d[$kind]) || !is_array($d[$kind])) return;
    foreach ($d[$kind] as $i=>$it) if (is_array($it) && isset($it['id']) && $it['id']===$id) { $d[$kind][$i]['dl'] = (int)(isset($it['dl']) ? $it['dl'] : 0) + 1; return; }
}
function x_dl_badge($it) {
    if (!x_admin() || !is_array($it) || empty($it['dl'])) return '';
    $c = x_sec_cfg(); if (empty($c['show'])) return '';
    return ' <span class="muted" style="font-size:11px;white-space:nowrap" title="İndirme sayısı">↓ '.(int)$it['dl'].'</span>';
}
function x_rm($p) {
    if (!empty($GLOBALS['x_trash_id']) && is_file($p)) {
        $dd = TRASH_DIR.'/'.$GLOBALS['x_trash_id']; if (!is_dir($dd)) @mkdir($dd, 0755, true);
        $tn = count($GLOBALS['x_trash_map']).'_'.preg_replace('/[^A-Za-z0-9._-]/', '_', basename($p)).'.bin';
        $rp = str_replace('\\', '/', $p); $bs = str_replace('\\', '/', __DIR__).'/';
        if (strpos($rp, $bs)===0 && is_dir($dd) && @rename($p, $dd.'/'.$tn)) { $GLOBALS['x_trash_map'][] = array(substr($rp, strlen($bs)), $tn); return; }
    }
    @unlink($p);
}
function x_hist_begin() { $id = bin2hex(random_bytes(6)); $GLOBALS['x_trash_id'] = $id; $GLOBALS['x_trash_map'] = array(); return $id; }
function x_hist_filekeys($t) { $k = array('id','dl','stored_name','original_name','download_name','screenshot','gallery','videos','main_video','files','image','main_image','date_added'); if ($t==='dosya') $k[] = 'pack'; return $k; }
function x_hist_add(&$d, $t, $kind, $snaps, $id, $files) {
    if (!isset($d['history']) || !is_array($d['history'])) $d['history'] = array();
    $nm = array(); foreach ($snaps as $sn) $nm[] = mb_substr((string)(isset($sn['name']) ? $sn['name'] : (isset($sn['title']) ? $sn['title'] : (isset($sn['id']) ? $sn['id'] : ''))), 0, 60);
    $d['history'][] = array('id'=>$id, 'ts'=>time(), 'by'=>(isset($_SESSION['uname']) ? (string)$_SESSION['uname'] : ''), 'type'=>$t, 'kind'=>$kind, 'names'=>$nm, 'snaps'=>array_values($snaps), 'files'=>$files);
    $cut = time() - 30*86400;
    while (count($d['history']) > 100 || ($d['history'] && (int)$d['history'][0]['ts'] < $cut)) { $o = array_shift($d['history']); if (!empty($o['id']) && preg_match('/^[a-f0-9]{12}$/', $o['id'])) x_rrmdir(TRASH_DIR.'/'.$o['id']); }
}
function x_hist_end(&$d, $t, $snaps, $id) {
    $files = isset($GLOBALS['x_trash_map']) ? $GLOBALS['x_trash_map'] : array();
    $GLOBALS['x_trash_id'] = null; $GLOBALS['x_trash_map'] = array();
    if ($snaps) x_hist_add($d, $t, 'delete', $snaps, $id, $files);
}
function x_hist_edit(&$d, $t, $item) { x_hist_add($d, $t, 'edit', array($item), bin2hex(random_bytes(6)), array()); }
function x_hist_diff($hl, $hk, $d) {
    $e = $hl[$hk]; $t = $e['type']; $old = isset($e['snaps'][0]) ? $e['snaps'][0] : array(); if (!is_array($old) || empty($old['id'])) return array();
    $new = null;
    foreach ($hl as $k2=>$e2) if ($k2 > $hk && $e2['type']===$t && in_array($e2['kind'], array('edit','delete','media'), true) && isset($e2['snaps'][0]['id']) && $e2['snaps'][0]['id']===$old['id']) { $new = $e2['snaps'][0]; break; }
    if ($new===null && isset($d[$t]) && is_array($d[$t])) foreach ($d[$t] as $it) if (isset($it['id']) && $it['id']===$old['id']) { $new = $it; break; }
    if (!is_array($new)) return array('Kayıt sonradan silinmiş');
    $lb = array('name'=>'Ad','description'=>'Açıklama','category_id'=>'Kategori','php_version'=>'PHP sürümü','has_password'=>'Şifre','pinned'=>'Sabitleme','url'=>'Bağlantı','title'=>'Başlık','content'=>'İçerik','text'=>'İçerik','screenshot'=>'Ekran görüntüsü','gallery'=>'Galeri','image'=>'Resim','videos'=>'Videolar','files'=>'Ek dosyalar','stored_name'=>'Dosya','original_name'=>'Dosya adı','download_name'=>'İndirme adı','pack'=>'Paket','gh_dl'=>'İndirme açık','gh_dl_ext'=>'İndirme uzantısı','enabled'=>'Görünürlük','visible'=>'Görünürlük','tags'=>'Etiketler');
    $sk = array('dl','order','sort','pos','updated','date_updated','screenshot','gallery','image','videos','files','pack');
    $ol = x_hist_lists($old, $t); $nl2 = x_hist_lists($new, $t); $mout = array();
    foreach ($ol as $l=>$arr) { $ad = array_values(array_diff($nl2[$l], $arr)); $rm = array_values(array_diff($arr, $nl2[$l])); if ($ad) $mout[] = $l.' eklendi: '.implode(', ', array_slice($ad, 0, 15)); if ($rm) $mout[] = $l.' silindi: '.implode(', ', array_slice($rm, 0, 15)); }
    $strip = function($v) { if (is_array($v)) return '(değişti)'; if (is_bool($v)) return $v ? 'evet' : 'hayır'; $v = trim(preg_replace('/\s+/', ' ', strip_tags((string)$v))); return mb_strlen($v) > 50 ? mb_substr($v, 0, 50).'…' : ($v==='' ? '(boş)' : $v); };
    $out = array(); $keys = array_unique(array_merge(array_keys($old), array_keys($new)));
    foreach ($keys as $k) {
        if (in_array($k, $sk, true)) continue;
        $o = isset($old[$k]) ? $old[$k] : null; $n = isset($new[$k]) ? $new[$k] : null;
        if (json_encode($o)===json_encode($n)) continue;
        $name = isset($lb[$k]) ? $lb[$k] : $k;
        if (is_array($o) || is_array($n)) $out[] = $name.' değişti';
        else $out[] = $name.': '.$strip($o===null ? '' : $o).' → '.$strip($n===null ? '' : $n);
    }
    return array_merge($mout, $out);
}
function x_media_cnt($it, $mk) { return array(count(x_item_images($it, $mk)), count(x_item_videos($it)), count(x_item_files($it))); }
function x_hist_media(&$d, $mh) {
    $files = isset($GLOBALS['x_trash_map']) ? $GLOBALS['x_trash_map'] : array(); $hid = $mh['hid'];
    $GLOBALS['x_trash_id'] = null; $GLOBALS['x_trash_map'] = array();
    $t = $mh['t']; $mk = $t==='dosya' ? 'screenshot' : 'image'; $before = $mh['item']; $now = null;
    if (isset($d[$t]) && is_array($d[$t])) foreach ($d[$t] as $it) if (isset($it['id']) && $it['id']===$before['id']) { $now = $it; break; }
    if ($now===null) { x_rrmdir(TRASH_DIR.'/'.$hid); return; }
    $b = x_media_cnt($before, $mk); $a = x_media_cnt($now, $mk); $info = array();
    if ($b[0] > $a[0]) $info[] = ($b[0]-$a[0]).' resim silindi';
    if ($b[1] > $a[1]) $info[] = ($b[1]-$a[1]).' video silindi';
    if ($b[2] > $a[2]) $info[] = ($b[2]-$a[2]).' ek dosya silindi';
    if (!$info) { x_rrmdir(TRASH_DIR.'/'.$hid); return; }
    x_hist_add($d, $t, 'media', array($before), $hid, $files);
    $d['history'][count($d['history'])-1]['info'] = implode(', ', $info);
    $bl = x_hist_lists($before, $t); $al = x_hist_lists($now, $t); $rm = array();
    foreach ($bl as $l=>$arr) { $x = array_values(array_diff($arr, $al[$l])); if ($x) $rm[$l] = $x; }
    $d['history'][count($d['history'])-1]['rm'] = $rm;
}
function x_hist_files_back($hid, $files) {
    foreach ((array)$files as $f) {
        if (!is_array($f) || count($f)<2) continue;
        $rel = str_replace('\\', '/', (string)$f[0]); $tn = basename((string)$f[1]);
        if (strpos($rel, '..')!==false || strpos($rel, basename(FILES_DIR).'/')!==0) continue;
        $src = TRASH_DIR.'/'.$hid.'/'.$tn; $dst = __DIR__.'/'.$rel;
        if (!is_file($src) || file_exists($dst)) continue;
        if (!is_dir(dirname($dst))) @mkdir(dirname($dst), 0755, true);
        @rename($src, $dst);
    }
}
function x_hist_media_merge(&$cur, $sn, $mk) {
    $li = x_item_images($cur, $mk); foreach (x_item_images($sn, $mk) as $f) if (!in_array($f, $li, true)) $li[] = $f;
    $si = x_item_images($sn, $mk); $ex = array(); foreach (x_item_images($cur, $mk) as $f) if (!in_array($f, $si, true)) $ex[] = $f;
    $all = array_merge($si, $ex); $cur[$mk] = $all ? array_shift($all) : null; $cur['gallery'] = $all;
    $cv = x_item_videos($cur); $sv = x_item_videos($sn); $mvEl = null;
    if (isset($cur['main_video']) && $cur['main_video']!==null && isset($cv[(int)$cur['main_video']])) $mvEl = $cv[(int)$cur['main_video']];
    elseif (isset($sn['main_video']) && $sn['main_video']!==null && isset($sv[(int)$sn['main_video']])) $mvEl = $sv[(int)$sn['main_video']];
    $nv = $sv; foreach ($cv as $v) if (!in_array($v, $nv, true)) $nv[] = $v;
    $cur['videos'] = $nv; $cur['main_video'] = null; if ($mvEl!==null) { $k = array_search($mvEl, $nv, true); if ($k!==false) $cur['main_video'] = $k; }
    $cf = x_item_files($cur); $sf = x_item_files($sn); $nf = $sf;
    foreach ($cf as $f) { $has = false; foreach ($nf as $g) if ($g['stored_name']===$f['stored_name']) { $has = true; break; } if (!$has) $nf[] = $f; }
    $cur['files'] = $nf;
}
function x_hist_reject(&$d, $r) {
    $hid = bin2hex(random_bytes(6)); $rid = basename((string)$r['id']); $src = APPR_DIR.'/'.$rid;
    if (is_dir($src)) { if (!is_dir(TRASH_DIR)) @mkdir(TRASH_DIR, 0755, true); @rename($src, TRASH_DIR.'/'.$hid); }
    $tab = (isset($r['tab']) && in_array($r['tab'], array('dosya','github','notes'), true)) ? $r['tab'] : 'dosya';
    x_hist_add($d, $tab, 'reject', array(array('name'=>(isset($r['label']) ? (string)$r['label'] : ''))), $hid, array());
    $k = count($d['history']) - 1; $d['history'][$k]['req'] = $r;
    $d['history'][$k]['info'] = 'Gönderen: '.(isset($r['name']) ? $r['name'] : '').' · '.x_appr_kind($r);
}
function x_hist_gen(&$d, $type, $kind, $names, $payload, $id, $files, $info) {
    $sn = array(); foreach ($names as $n) $sn[] = array('name'=>$n);
    x_hist_add($d, $type, $kind, $sn, $id, $files);
    $k = count($d['history']) - 1; $d['history'][$k]['payload'] = $payload; $d['history'][$k]['info'] = $info;
}
function x_hist_tab_snap($d, $dk) {
    $t = $GLOBALS['x_all_tabs'][$dk]; $dt = $t['type']; $items = array();
    if ($dt!=='home' && isset($d[$dt]) && is_array($d[$dt])) foreach ($d[$dt] as $it) if (x_item_tabkey($dt, $it)===$dk) $items[] = $it;
    $base = !empty($t['base']);
    return array('key'=>$dk, 'type'=>$dt, 'label'=>(string)(isset($t['label']) ? $t['label'] : $dk), 'base'=>$base,
        'def'=>($base ? (isset($d['settings']['tabs'][$dk]) ? $d['settings']['tabs'][$dk] : null) : (isset($d['settings']['custom_tabs'][$dk]) ? $d['settings']['custom_tabs'][$dk] : null)), 'items'=>$items);
}
function x_hist_tabs_end(&$d, $snaps, $hid) {
    $files = isset($GLOBALS['x_trash_map']) ? $GLOBALS['x_trash_map'] : array(); $GLOBALS['x_trash_id'] = null; $GLOBALS['x_trash_map'] = array();
    $names = array(); $n = 0; foreach ($snaps as $sp) { $names[] = $sp['label']; $n += count($sp['items']); }
    x_hist_gen($d, 'tab', 'tabdel', $names, array('tabs'=>$snaps), $hid, $files, 'Sekme ve içindeki '.$n.' kayıt silindi');
}
function x_hist_gen_restore(&$d, $e, $hid) {
    $p = isset($e['payload']) && is_array($e['payload']) ? $e['payload'] : array(); $k = $e['kind']; $done = false;
    if (!isset($d['settings']) || !is_array($d['settings'])) $d['settings'] = array();
    if ($k==='tabdel') {
        foreach ((array)(isset($p['tabs']) ? $p['tabs'] : array()) as $sp) {
            $dk = $sp['key']; $dt = $sp['type'];
            if (!empty($sp['base'])) { if (isset($d['settings']['deleted_tabs'][$dk])) { unset($d['settings']['deleted_tabs'][$dk]); $done = true; } if ($sp['def']!==null) $d['settings']['tabs'][$dk] = $sp['def']; }
            else { if (!isset($d['settings']['custom_tabs']) || !is_array($d['settings']['custom_tabs'])) $d['settings']['custom_tabs'] = array(); if (!isset($d['settings']['custom_tabs'][$dk]) && is_array($sp['def'])) { $d['settings']['custom_tabs'][$dk] = $sp['def']; $done = true; } }
            if (!isset($d[$dt]) || !is_array($d[$dt])) $d[$dt] = array();
            foreach ((array)$sp['items'] as $it) { $has = false; foreach ($d[$dt] as $x) if (isset($x['id']) && $x['id']===$it['id']) { $has = true; break; } if (!$has) { $d[$dt][] = $it; $done = true; } }
        }
        x_hist_files_back($hid, isset($e['files']) ? $e['files'] : array());
    } elseif ($k==='catdel') {
        if (!isset($d['categories']) || !is_array($d['categories'])) $d['categories'] = array();
        foreach ((array)(isset($p['cats']) ? $p['cats'] : array()) as $c) { $has = false; foreach ($d['categories'] as $x) if ($x['id']===$c['id']) { $has = true; break; } if (!$has) { $d['categories'][] = $c; $done = true; } }
        foreach ((array)(isset($p['items']) ? $p['items'] : array()) as $pr) foreach ($d['dosya'] as $i=>$it) if ($it['id']===$pr[0] && empty($it['category_id'])) { $d['dosya'][$i]['category_id'] = $pr[1]; $done = true; }
    } elseif ($k==='themedel') {
        if (!isset($d['settings']['themes']) || !is_array($d['settings']['themes'])) $d['settings']['themes'] = array();
        foreach ((array)(isset($p['themes']) ? $p['themes'] : array()) as $t) { $has = false; foreach ($d['settings']['themes'] as $x) if (isset($x['id']) && $x['id']===$t['id']) { $has = true; break; } if (!$has) { $d['settings']['themes'][] = $t; $done = true; } }
    } elseif ($k==='accdel') {
        if (!isset($d['accounts']) || !is_array($d['accounts'])) $d['accounts'] = x_acc_load();
        if (!isset($d['accounts']['users']) || !is_array($d['accounts']['users'])) $d['accounts']['users'] = array();
        foreach ((array)(isset($p['users']) ? $p['users'] : array()) as $u) { $has = false; foreach ($d['accounts']['users'] as $x) if (isset($x['id']) && $x['id']===$u['id']) { $has = true; break; } if (!$has) { $d['accounts']['users'][] = $u; $done = true; } }
        foreach ((array)(isset($p['builtin']) ? $p['builtin'] : array()) as $r) if (isset($d['accounts']['builtin'][$r]['deleted'])) { unset($d['accounts']['builtin'][$r]['deleted']); $done = true; }
    }
    return $done;
}
function x_hist_lists($it, $t) {
    $mk = $t==='dosya' ? 'screenshot' : 'image'; $o = array();
    $o['Resim'] = array_map('strval', x_item_images($it, $mk));
    $v = array(); foreach (x_item_videos($it) as $x) $v[] = ($x['t']==='f' ? '(dosya) ' : '(bağlantı) ').$x['v']; $o['Video'] = $v;
    $f = array(); foreach (x_item_files($it) as $x) $f[] = (string)$x['name']; $o['Ek dosya'] = $f;
    $pk = array(); if (!empty($it['pack']) && is_array($it['pack'])) foreach ($it['pack'] as $x) if (is_array($x)) $pk[] = isset($x['original_name']) ? (string)$x['original_name'] : (isset($x['url']) ? (string)$x['url'] : ''); $o['Paket dosyası'] = array_values(array_filter($pk, 'strlen'));
    return $o;
}
function x_hist_row($l, $v) { return '<div><span class="muted">'.x_h($l).':</span> '.$v.'</div>'; }
function x_hist_list_html($l, $arr) {
    if (!$arr) return ''; $show = array_slice($arr, 0, 25);
    return x_hist_row($l.' ('.count($arr).')', x_h(implode(', ', $show)).(count($arr) > 25 ? ' … (+'.(count($arr)-25).')' : ''));
}
function x_hist_item_html($sn, $t, $d) {
    if (!is_array($sn)) return ''; $o = '';
    $cn = ''; if (!empty($sn['category_id']) && isset($d['categories']) && is_array($d['categories'])) foreach ($d['categories'] as $c) if ($c['id']===$sn['category_id']) { $cn = $c['name']; break; }
    $nm = isset($sn['name']) ? $sn['name'] : (isset($sn['title']) ? $sn['title'] : '');
    $o .= x_hist_row('Ad', x_h($nm));
    foreach (array('description'=>'Açıklama','content'=>'İçerik','text'=>'İçerik') as $k=>$lb) if (!empty($sn[$k]) && is_string($sn[$k])) { $tx = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($sn[$k]), ENT_QUOTES, 'UTF-8'))); if ($tx!=='') { $o .= x_hist_row($lb, x_h(mb_strlen($tx) > 300 ? mb_substr($tx, 0, 300).'…' : $tx)); break; } }
    if ($cn!=='') $o .= x_hist_row('Kategori', x_h($cn));
    if (!empty($sn['php_version'])) $o .= x_hist_row('PHP sürümü', x_h((string)$sn['php_version']));
    if (!empty($sn['url'])) $o .= x_hist_row('Bağlantı', x_h((string)$sn['url']));
    if (!empty($sn['original_name'])) $o .= x_hist_row('Ana dosya', x_h((string)$sn['original_name']));
    foreach (x_hist_lists($sn, $t) as $l=>$arr) $o .= x_hist_list_html($l, $arr);
    return $o;
}
function x_hist_detail($e, $hl, $hk, $d) {
    $t = $e['type']; $k = $e['kind']; $o = '<div style="margin:8px 0 2px;padding:9px 11px;border:1px solid var(--border);border-radius:var(--r-sm,6px);font-size:12px;line-height:1.6;word-break:break-word">';
    $p = isset($e['payload']) && is_array($e['payload']) ? $e['payload'] : array();
    if ($k==='delete') {
        foreach ((array)$e['snaps'] as $i=>$sn) { if ($i) $o .= '<hr style="border:0;border-top:1px dashed var(--border);margin:6px 0">'; $o .= '<div class="muted" style="font-weight:600">Silinen kayıt</div>'.x_hist_item_html($sn, $t, $d); }
        if (!empty($e['files'])) $o .= x_hist_row('Çöpe taşınan dosya', count($e['files']).' adet (geri yüklenince yerine döner)');
    } elseif ($k==='media') {
        $o .= '<div class="muted" style="font-weight:600">Silinen medya</div>'.x_hist_row('Özet', x_h(isset($e['info']) ? $e['info'] : ''));
        if (!empty($e['rm'])) foreach ($e['rm'] as $l=>$arr) $o .= x_hist_list_html('Silinen '.mb_strtolower($l, 'UTF-8'), $arr);
        $o .= '<div class="muted" style="font-weight:600;margin-top:6px">Silmeden önceki kayıt</div>'.x_hist_item_html(isset($e['snaps'][0]) ? $e['snaps'][0] : array(), $t, $d);
    } elseif ($k==='edit') {
        $df = x_hist_diff($hl, $hk, $d);
        $o .= '<div class="muted" style="font-weight:600">Değişiklikler</div>'.($df ? '<div>'.implode('<br>', array_map('x_h', $df)).'</div>' : '<div class="muted">Değişen alan tespit edilemedi</div>');
        $o .= '<div class="muted" style="font-weight:600;margin-top:6px">Düzenlemeden önceki hali</div>'.x_hist_item_html(isset($e['snaps'][0]) ? $e['snaps'][0] : array(), $t, $d);
    } elseif ($k==='tabdel') {
        foreach ((array)(isset($p['tabs']) ? $p['tabs'] : array()) as $sp) {
            $nmz = array(); foreach ((array)$sp['items'] as $it) $nmz[] = isset($it['name']) ? (string)$it['name'] : (isset($it['title']) ? (string)$it['title'] : '');
            $o .= '<div style="margin-bottom:6px"><b>Sekme: '.x_h($sp['label']).'</b> <span class="muted">('.x_h($sp['type']).(!empty($sp['base']) ? ', hazır sekme' : '').')</span>'.x_hist_list_html('İçindeki kayıtlar', $nmz);
            $mc = array('Resim'=>0, 'Video'=>0, 'Ek dosya'=>0); foreach ((array)$sp['items'] as $it) foreach (x_hist_lists($it, $sp['type']) as $l=>$arr) if (isset($mc[$l])) $mc[$l] += count($arr);
            $o .= x_hist_row('Toplam medya', x_h($mc['Resim'].' resim, '.$mc['Video'].' video, '.$mc['Ek dosya'].' ek dosya')).'</div>';
        }
        if (!empty($e['files'])) $o .= x_hist_row('Çöpe taşınan dosya', count($e['files']).' adet');
    } elseif ($k==='catdel') {
        $cn = array(); foreach ((array)(isset($p['cats']) ? $p['cats'] : array()) as $c) $cn[] = $c['name'].(!empty($c['parent']) ? ' (alt kategori)' : '');
        $o .= x_hist_list_html('Silinen kategoriler', $cn).x_hist_row('Kategorisi kaldırılan dosya', (int)count(isset($p['items']) ? $p['items'] : array()).' adet (geri yüklenince kategorisi döner)');
    } elseif ($k==='accdel') {
        $rl = array('admin'=>'Yönetici', 'visitor'=>'Ziyaretçi', 'editor'=>'Editör');
        foreach ((array)(isset($p['users']) ? $p['users'] : array()) as $u) $o .= x_hist_row('Hesap', x_h((isset($u['name']) ? $u['name'] : '').' · '.(isset($rl[isset($u['role']) ? $u['role'] : '']) ? $rl[$u['role']] : '').(!empty($u['super']) ? ' · Süper Admin' : '').(isset($u['perms']) && is_array($u['perms']) ? ' · '.count($u['perms']).' yetki' : '')));
        foreach ((array)(isset($p['builtin']) ? $p['builtin'] : array()) as $r) $o .= x_hist_row('Hazır hesap', x_h((string)$r));
    } elseif ($k==='themedel') {
        foreach ((array)(isset($p['themes']) ? $p['themes'] : array()) as $th) $o .= x_hist_row('Tema', x_h(isset($th['name']) ? $th['name'] : (isset($th['id']) ? $th['id'] : '')));
    } elseif ($k==='reject') {
        $o .= x_hist_row('Özet', x_h(isset($e['info']) ? $e['info'] : '')).(isset($e['req']) ? x_appr_detail($e['req']) : '').'<div class="muted" style="margin-top:3px">Geri yüklenirse istek tekrar onay bekleyenlere döner.</div>';
    }
    return $o.'</div>';
}
function x_hist_restore(&$d, $hid) {
    if (!is_string($hid) || !preg_match('/^[a-f0-9]{12}$/', $hid) || empty($d['history'])) return 'skip';
    foreach ($d['history'] as $hi=>$e) {
        if ($e['id']!==$hid) continue;
        if ($e['kind']==='reject') {
            $r = isset($e['req']) ? $e['req'] : null; if (!is_array($r) || empty($r['id']) || !empty($e['restored'])) return 'skip';
            foreach (x_appr_all($d) as $q) if (isset($q['id']) && $q['id']===$r['id']) return 'skip';
            $src = TRASH_DIR.'/'.$hid; if (is_dir($src) && !file_exists(APPR_DIR.'/'.basename((string)$r['id']))) @rename($src, APPR_DIR.'/'.basename((string)$r['id']));
            unset($r['status'], $r['cancelled']); if (!isset($d['approvals']) || !is_array($d['approvals'])) $d['approvals'] = array(); $d['approvals'][] = $r;
            $d['history'][$hi]['restored'] = time(); return 'ok';
        }
        if (in_array($e['kind'], array('tabdel','catdel','themedel','accdel'), true)) {
            if (!empty($e['restored'])) return 'skip';
            if (!x_hist_gen_restore($d, $e, $hid)) return 'skip';
            x_rrmdir(TRASH_DIR.'/'.$hid); $d['history'][$hi]['files'] = array(); $d['history'][$hi]['restored'] = time(); return 'ok';
        }
        $t = $e['type']; if (!in_array($t, array('dosya','github','notes'), true) || !isset($d[$t]) || !is_array($d[$t])) return 'skip';
        $done = 0;
        foreach ((array)$e['snaps'] as $sn) {
            if (!is_array($sn) || empty($sn['id'])) continue;
            $ix = null; foreach ($d[$t] as $i=>$it) if (isset($it['id']) && $it['id']===$sn['id']) { $ix = $i; break; }
            if ($e['kind']==='media') {
                if ($ix===null) continue;
                x_hist_files_back($hid, $e['files']); x_hist_media_merge($d[$t][$ix], $sn, $t==='dosya' ? 'screenshot' : 'image'); $done++;
            } elseif ($e['kind']==='edit') {
                if ($ix===null) continue;
                x_hist_edit($d, $t, $d[$t][$ix]);
                $fk = x_hist_filekeys($t);
                foreach ($sn as $k=>$v) if (!in_array($k, $fk, true)) $d[$t][$ix][$k] = $v;
                $done++;
            } else {
                if ($ix!==null) continue;
                x_hist_files_back($hid, $e['files']);
                $d[$t][] = $sn; $done++;
            }
        }
        if (($e['kind']==='delete' || $e['kind']==='media') && $done) { x_rrmdir(TRASH_DIR.'/'.$hid); $d['history'][$hi]['files'] = array(); }
        if ($done) $d['history'][$hi]['restored'] = time();
        return $done ? 'ok' : 'skip';
    }
    return 'skip';
}
function x_acc_blocked($uid) {
    $d = x_data(); return is_array($d) && isset($d['settings']['blocked']) && is_array($d['settings']['blocked']) && isset($d['settings']['blocked'][(string)$uid]);
}
function x_acc_is_super_row($ac) { return $ac['id']==='builtin_admin' || (!empty($ac['super']) && $ac['role']==='admin'); }
function x_block_ui() {
    global $data; $me = isset($_SESSION['uid']) ? (string)$_SESSION['uid'] : ''; $bl = (isset($data['settings']['blocked']) && is_array($data['settings']['blocked'])) ? $data['settings']['blocked'] : array();
    $rl = array('admin'=>'Yönetici', 'visitor'=>'Ziyaretçi', 'editor'=>'Editör'); $rows = array();
    foreach (x_accounts() as $ac) { if ($ac['id']===$me || x_acc_is_super_row($ac)) continue; $rows[] = $ac; }
    echo '<details class="panel acc-sec" style="margin-top:14px;max-width:980px"><summary><h3>Kullanıcı engelleme ('.count($bl).' engelli)</h3></summary><div style="padding:14px">';
    if (!$rows) { echo '<p class="muted" style="margin:0">Engellenebilecek başka hesap yok.</p></div></details>'; return; }
    echo '<p class="muted" style="margin:0 0 10px">Engellenen kullanıcı giriş yapamaz ve açık oturumu hemen kapanır. Hesabı ve verileri silinmez; engeli kaldırınca eskisi gibi girer. Süper Admin hesapları ve kendi hesabınız listede görünmez, engellenemez.</p>';
    echo '<form method="POST" action="?action=acc_block&tab=settings" id="blkForm"><div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px"><label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12.5px;margin:0"><input type="checkbox" class="cbx" onchange="document.querySelectorAll(\'#blkForm .bsel\').forEach(function(c){c.checked=this.checked}.bind(this))"> Tümünü seç</label><span style="flex:1"></span><button class="btn btn-or btn-xs" type="submit" name="act" value="block" onclick="return blkChk(\'Seçilen kullanıcılar engellensin mi?\')">'.svg('shield',11).' Seçilenleri engelle</button><button class="btn btn-g btn-xs" type="submit" name="act" value="unblock" onclick="return blkChk(\'Seçilenlerin engeli kaldırılsın mı?\')">'.svg('check',11).' Engeli kaldır</button></div>';
    echo '<div style="max-height:320px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--r-sm,6px)">';
    foreach ($rows as $ac) {
        $b = isset($bl[$ac['id']]) ? $bl[$ac['id']] : null;
        echo '<label style="display:flex;align-items:center;gap:10px;padding:9px 10px;border-bottom:1px solid var(--border);font-size:13px;cursor:pointer;margin:0"><input type="checkbox" class="cbx bsel" name="ids[]" value="'.x_h($ac['id']).'"><span style="flex:1;min-width:0"><b>'.x_h($ac['name']).'</b> <span class="muted">· '.x_h(isset($rl[$ac['role']]) ? $rl[$ac['role']] : $ac['role']).'</span></span>';
        if ($b) echo '<span class="sx-badge" style="color:#ff6b6b;border-color:#ff6b6b">Engelli · '.x_h(date('d.m.Y H:i', (int)(isset($b['t']) ? $b['t'] : 0))).'</span>'; else echo '<span class="muted" style="font-size:12px">Aktif</span>';
        echo '</label>';
    }
    echo '</div></form><script>function blkChk(m){var n=document.querySelectorAll("#blkForm .bsel:checked").length;if(!n){alert("Önce en az bir kullanıcı seçin.");return false}return confirm(m)}</script></div></details>';
}
function x_sec_ui() {
    global $data; $c = x_sec_cfg(); $sup = x_super();
    $in = 'padding:9px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:var(--r-sm,6px);color:var(--text);width:100%';
    echo '<details class="panel acc-sec" style="margin-top:14px;max-width:980px"><summary><h3>Oturum ve indirme güvenliği</h3></summary><div style="padding:14px">';
    echo '<p class="muted" style="margin:0 0 10px">Hesabınız başka bir yerde açık kalmış olabilir ya da şifreniz başkasının eline geçmiş olabilir. Bu durumda aşağıdaki düğmeyle bu tarayıcı dışındaki tüm oturumlarınızı kapatın (şifrenizi de değiştirmeniz önerilir).</p>';
    echo '<form method="POST" action="?action=sess_kill&tab=settings" style="display:inline-block;margin:0 8px 8px 0"><input type="hidden" name="scope" value="me"><button class="btn btn-o" type="submit" onclick="return confirm(\'Bu tarayıcı dışındaki tüm oturumlarınız kapatılacak. Devam edilsin mi?\')">'.svg('lock',13).' Diğer oturumlarımı kapat</button></form>';
    if ($sup) echo '<form method="POST" action="?action=sess_kill&tab=settings" style="display:inline-block;margin:0 0 8px"><input type="hidden" name="scope" value="all"><button class="btn btn-or" type="submit" onclick="return confirm(\'Siz hariç TÜM kullanıcıların oturumları kapatılacak ve yeniden giriş yapmaları gerekecek. Emin misiniz?\')">'.svg('shield',13).' Herkesin oturumunu kapat</button></form>';
    if ($sup) {
        echo '<form method="POST" action="?action=sec_save&tab=settings" style="margin-top:12px"><div style="display:flex;gap:12px;flex-wrap:wrap">';
        echo '<div class="fg" style="flex:1;min-width:200px"><label>Boşta kalınca oturumu kapat (dakika)</label><input type="number" name="sess_idle" min="5" max="1440" value="'.(int)$c['idle'].'" style="'.$in.'"></div>';
        echo '<div class="fg" style="flex:1;min-width:200px"><label>İndirme sınırı (kaç dosya)</label><input type="number" name="dl_lim" min="0" max="100000" value="'.(int)$c['lim'].'" style="'.$in.'"></div>';
        echo '<div class="fg" style="flex:1;min-width:200px"><label>Sınır süresi (kaç dakika)</label><input type="number" name="dl_win" min="1" max="1440" value="'.(int)$c['win'].'" style="'.$in.'"></div></div>';
        echo '<div style="margin:8px 0 10px;padding:10px 12px;border:1px dashed var(--border);border-radius:var(--r-sm,6px);font-size:12.5px;line-height:1.6;color:var(--text2)"><b style="color:var(--text)">İndirme sınırı nasıl çalışır?</b><br>• <b>İndirme sınırı</b>: Aynı IP adresinin, aşağıdaki <i>sınır süresi</i> içinde en fazla kaç dosya indirebileceğini belirler. <b>0</b> yazarsanız sınır kapalıdır (sınırsız indirme). <b>2</b> yazarsanız bir kişi süre dolmadan en fazla 2 dosya indirebilir, 3. denemede "İndirme sınırına ulaşıldı" uyarısı alır.<br>• <b>Sınır süresi</b>: Sayımın kaç dakikalık dönemde yapılacağıdır. Örnek: sınır <b>2</b>, süre <b>60</b> ise bir IP, 1 saat içinde en fazla 2 dosya indirir; 1 saat geçince hak yenilenir.<br>• Paket ZIP indirmesi de 1 indirme sayılır.</div>';
        echo '<label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0 0 10px;font-size:13px"><label class="sw" style="margin:0"><input type="checkbox" name="zip_on" value="1" '.($c['zip'] ? 'checked' : '').'><span class="sl"></span></label> Paket ZIP indirme <span class="muted">(açıkken paket penceresinde "ZIP indir" görünür, kapalıyken görünmez ve çalışmaz)</span></label>';
        echo '<label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0 0 10px;font-size:13px"><label class="sw" style="margin:0"><input type="checkbox" name="dl_show" value="1" '.($c['show'] ? 'checked' : '').'><span class="sl"></span></label> Listelerde indirme sayısını göster <span class="muted">(Dosya Arşivi ve GitHub; yalnızca yöneticiler görür, kapalıyken sayı gizlenir ama sayım sürer)</span></label>';
        echo '<label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0 0 12px;font-size:13px"><label class="sw" style="margin:0"><input type="checkbox" name="dl_adm" value="1" '.($c['adm'] ? 'checked' : '').'><span class="sl"></span></label> Sınır yöneticileri de etkilesin <span class="muted">(kapalıysa yönetici hesapları sınırsız indirir)</span></label>';
        echo '<button class="btn btn-g" type="submit">'.svg('check',13).' Kaydet</button></form>';
    }
    echo '</div></details>';
    if (x_perm('acc_block')) x_block_ui();
    if (!x_perm('history')) return;
    $hl = (isset($data['history']) && is_array($data['history'])) ? $data['history'] : array(); $h = array_reverse($hl, true);
    $tl = array('dosya'=>'Dosya', 'github'=>'GitHub', 'notes'=>'Bilgi', 'tab'=>'Sekme', 'cat'=>'Kategori', 'acc'=>'Hesap', 'theme'=>'Tema');
    $kl = array('delete'=>'Silme', 'edit'=>'Düzenleme', 'media'=>'Medya silme', 'reject'=>'Reddedilen istek', 'tabdel'=>'Silme', 'catdel'=>'Silme', 'accdel'=>'Silme', 'themedel'=>'Silme');
    echo '<details class="panel acc-sec" style="margin-top:14px;max-width:980px"><summary><h3>Düzenleme geçmişi ('.count($h).')</h3></summary><div style="padding:14px">';
    if (!$h) echo '<p class="muted" style="margin:0">Henüz kayıt yok. Düzenleme ve silme işlemleri burada 30 gün saklanır (en fazla 100 kayıt).</p>';
    else {
        echo '<p class="muted" style="margin:0 0 10px">İstediğiniz kayıtları kutucuklarla seçip geri yükleyebilir ya da geçmişten silebilirsiniz. Düzenleme geri alınırken yalnızca yazı alanları döner; sonradan değişen dosya ve resimler eski haline gelmez. Silinen kayıtlar dosyalarıyla birlikte geri gelir.</p>';
        echo '<form method="POST" action="?action=hist_do&tab=settings" id="histForm"><div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px"><label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12.5px;margin:0"><input type="checkbox" class="cbx" onchange="document.querySelectorAll(\'#histForm .hsel\').forEach(function(c){c.checked=this.checked}.bind(this))"> Tümünü seç</label><span style="flex:1"></span><button class="btn btn-o btn-xs" type="submit" name="act" value="restore" onclick="return histChk(\'Seçilen kayıtlar geri yüklensin mi?\')">'.svg('layers',11).' Seçilenleri geri yükle</button><button class="btn btn-or btn-xs" type="submit" name="act" value="delete" onclick="return histChk(\'Seçilen kayıtlar geçmişten KALICI olarak silinsin mi? (Silme kayıtlarının çöpteki dosyaları da gider)\')">'.svg('trash',11).' Seçilenleri sil</button></div>';
        echo '<div style="max-height:380px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--r-sm,6px)">';
        foreach ($h as $hk=>$e) {
            $dl = $e['kind']==='delete'; $nm = implode(', ', array_slice((array)$e['names'], 0, 3)).(count((array)$e['names'])>3 ? ' (+'.(count($e['names'])-3).')' : '');
            echo '<div style="display:flex;align-items:flex-start;gap:10px;padding:9px 10px;border-bottom:1px solid var(--border);font-size:12.5px"><input type="checkbox" class="cbx hsel" name="hid[]" value="'.x_h($e['id']).'" style="margin-top:3px"><details class="hd" style="flex:1;min-width:0"><summary style="cursor:pointer;list-style:none"><b>'.x_h(isset($tl[$e['type']]) ? $tl[$e['type']] : '').' · '.(isset($kl[$e['kind']]) ? $kl[$e['kind']] : 'Düzenleme').'</b> — '.x_h($nm).' <span class="muted" style="font-size:11px">· ayrıntı ▾</span><br><span class="muted">'.x_h(date('d.m.Y H:i', (int)$e['ts'])).($e['by']!=='' ? ' · '.x_h($e['by']) : '').(!empty($e['restored']) ? ' · geri yüklendi' : '').'</span>'.(isset($e['info']) && $e['kind']!=='edit' ? '<span style="display:block;margin-top:2px;color:var(--text2)">'.x_h($e['info']).'</span>' : '').'</summary>'.x_hist_detail($e, $hl, $hk, $data).'</details></div>';
        }
        echo '</div></form><script>function histChk(m){var n=document.querySelectorAll("#histForm .hsel:checked").length;if(!n){alert("Önce en az bir kayıt seçin.");return false}return confirm(m)}</script>';
    }
    echo '</div></details>';
}
function x_sec_migrate() {
    $d = x_data(); if (!is_array($d) || !empty($d['settings']['sec_mig1'])) return;
    $ch = false;
    $fix = function(&$it) use (&$ch) {
        if (!is_array($it) || empty($it['stored_name'])) return;
        $sn = basename((string)$it['stored_name']); $e = strtolower(pathinfo($sn, PATHINFO_EXTENSION));
        if (!in_array($e, x_danger_exts(), true)) return;
        $nn = preg_replace('/\.[^.]*$/', '', $sn).'.bin'; $f = FILES_DIR.'/'.$sn;
        if (is_file($f) && !file_exists(FILES_DIR.'/'.$nn) && @rename($f, FILES_DIR.'/'.$nn)) { $it['stored_name'] = $nn; $ch = true; }
    };
    if (isset($d['dosya']) && is_array($d['dosya'])) foreach ($d['dosya'] as $k=>$it) {
        $fix($d['dosya'][$k]);
        if (isset($d['dosya'][$k]['pack']) && is_array($d['dosya'][$k]['pack'])) foreach ($d['dosya'][$k]['pack'] as $pk=>$_p) $fix($d['dosya'][$k]['pack'][$pk]);
    }
    foreach ((array)@scandir(FILES_DIR) as $f) {
        if ($f==='.' || $f==='..' || $f==='.htaccess') continue; $pp = FILES_DIR.'/'.$f;
        if (is_file($pp) && in_array(strtolower(pathinfo($f, PATHINFO_EXTENSION)), x_danger_exts(), true)) { $nn = preg_replace('/\.[^.]*$/', '', $f).'.bin'; if (!file_exists(FILES_DIR.'/'.$nn)) @rename($pp, FILES_DIR.'/'.$nn); }
    }
    $d['settings']['sec_mig1'] = 1; x_save($d);
}
x_init();
if (x_admin()) x_sec_migrate();

$route = (isset($_GET['action']) ? $_GET['action'] : 'list');
$tab = (isset($_GET['tab']) ? $_GET['tab'] : 'dosya');
if (!is_string($route) || !preg_match('/^[a-z_]{1,40}$/', $route)) $route = 'list';
if (!is_string($tab) || !preg_match('/^[a-z0-9_]{1,40}$/', $tab)) $tab = 'dosya';

$xban = x_data();
if (!x_admin_role() && x_is_banned($xban, x_ip())) { x_ban_page($xban, true); }
if (!x_admin_role() && is_array($xban)) { x_vpn_gate($xban); }
if (isset($_GET['logout'])) { if (x_admin()) x_act_log('Oturum', 'Çıkış yaptı'); session_destroy(); header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
if ($route==='site_asset' && isset($_GET['k']) && is_string($_GET['k'])) { x_site_asset_serve($_GET['k']); }

if (!x_logged() && $_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['password'])) {
    $p = is_string($_POST['password']) ? trim($_POST['password']) : '';
    $matched = null;
    if (x_lg_locked()) { $login_error = true; $GLOBALS['x_login_locked'] = true; usleep(400000); }
    else {
        if ($p!=='' && strlen($p) <= 200) { foreach (x_accounts() as $ac) { if (password_verify($p, $ac['hash'])) { $matched = $ac; break; } } }
        if ($matched && x_acc_blocked($matched['id'])) { $matched = null; $login_error = true; $GLOBALS['x_login_blocked'] = true; usleep(400000); }
        elseif ($matched) { $_SESSION['role']=$matched['role']; $_SESSION['uid']=$matched['id']; $_SESSION['uname']=$matched['name']; x_lg_clear(); $_SESSION['x_ep']=x_sess_ep($matched['id']); }
        else { $login_error=true; x_lg_fail(); $fd = x_data(); if (is_array($fd)) { x_track($fd, 'auth', 'fail', 'fail', 'fail'); x_save($fd); } usleep(400000); }
    }
    if (!isset($login_error)) {
        session_regenerate_id(true);
        $loginData = x_data();
        x_track($loginData, 'auth', $_SESSION['role'], 'login', $_SESSION['role']); if (isset($_SESSION['uid']) && $_SESSION['uid']==='builtin_admin') x_super_ip_note($loginData);
        x_save($loginData); if (x_admin()) x_act_log('Oturum', 'Panele giriş yaptı');
        header('Location: '.$_SERVER['SCRIPT_NAME']); exit;
    }
}
if (x_logged()) {
    $xuid = isset($_SESSION['uid']) ? $_SESSION['uid'] : ('builtin_'.$_SESSION['role']); $xfound = false;
    foreach (x_accounts() as $xac) { if ($xac['id']===$xuid && $xac['role']===$_SESSION['role']) { $xfound = true; $_SESSION['uid']=$xuid; $_SESSION['uname']=$xac['name']; } }
    if (!$xfound) { session_destroy(); header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
    if (x_acc_blocked($xuid)) { session_destroy(); header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
    $xep = x_sess_ep($xuid);
    if (!isset($_SESSION['x_ep'])) $_SESSION['x_ep'] = $xep;
    elseif ($_SESSION['x_ep'] !== $xep) { session_destroy(); header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
    $xsc = x_sec_cfg();
    if (!empty($GLOBALS['x_prev_act']) && (time() - (int)$GLOBALS['x_prev_act']) > $xsc['idle']*60) { session_destroy(); header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
}
if (!x_logged() && $_SERVER['REQUEST_METHOD']==='GET' && empty($_SESSION['x_visit_logged'])) {
    $_SESSION['x_visit_logged'] = 1;
    $vd = x_data();
    if (is_array($vd)) {
        $vip = x_ip(); $vdup = false;
        if (isset($vd['analytics']) && is_array($vd['analytics'])) { foreach (array_reverse($vd['analytics']) as $ve) { if (is_array($ve) && isset($ve['type'], $ve['action'], $ve['ip']) && $ve['type']==='auth' && $ve['action']==='visit' && $ve['ip']===$vip) { if (time() - (int)strtotime(isset($ve['time']) ? $ve['time'] : '') < 600) $vdup = true; break; } } }
        if (!$vdup) { x_track($vd, 'auth', 'visit', 'visit', 'Ziyaret tespit edildi'); x_save($vd); }
    }
}
if (!x_logged()) { x_login_page(isset($login_error)); exit; }
$GLOBALS['x_csrf_on'] = true;
if ($_SERVER['REQUEST_METHOD']==='POST' || in_array($route, array('tab_delete','cat_delete','delete','pin','github_delete','github_pin','note_pin','note_delete','img_remove','note_remove_image','remove_screenshot','github_remove_image','nfile_remove','vid_remove','vid_main','img_main'), true)) {
    if (!x_csrf_ok()) { while (ob_get_level()) ob_end_clean(); http_response_code(403); header('Content-Type: text/plain; charset=UTF-8'); echo 'Güvenlik doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.'; exit; }
}

$data = x_data();
if (!isset($data['github']) || !is_array($data['github'])) { $data['github'] = []; }
if (!isset($data['notes']) || !is_array($data['notes'])) { $data['notes'] = []; }
if (!isset($data['analytics']) || !is_array($data['analytics'])) { $data['analytics'] = []; }
if (x_admin()) { x_act_prepare($data, $route); register_shutdown_function('x_act_shutdown'); }
$GLOBALS['x_all_tabs'] = x_all_tabs_build($data);
foreach ($GLOBALS['x_all_tabs'] as $_k=>$_e) { $GLOBALS['x_all_tabs'][$_k]['enabled_raw'] = $_e['enabled']; if (x_tab_hidden_me($_e)) { $GLOBALS['x_all_tabs'][$_k]['enabled'] = false; $GLOBALS['x_all_tabs'][$_k]['hidden_me'] = true; } }
$GLOBALS['x_ws'] = x_ws_init();
$GLOBALS['x_tabs'] = x_tabs_active($GLOBALS['x_all_tabs'],$GLOBALS['x_ws']);
if (x_migrate_bin($data)) { x_save($data); }
if (!isset($_GET['tab'])) { $fe = x_first_entry(); $tab = $fe['type']; $GLOBALS['x_ws'][$tab] = $fe['base'] ? '' : $fe['key']; $_SESSION['x_ws'] = $GLOBALS['x_ws']; $GLOBALS['x_tabs'] = x_tabs_active($GLOBALS['x_all_tabs'],$GLOBALS['x_ws']); }
x_route_gate($route);
if ($_SERVER['REQUEST_METHOD']==='POST' && x_logged() && $route==='sess_kill') {
    $sc = (isset($_POST['scope']) && is_string($_POST['scope'])) ? $_POST['scope'] : 'me'; $uid = isset($_SESSION['uid']) ? (string)$_SESSION['uid'] : '';
    if ($sc==='all' && x_super()) { x_sess_bump('*'); $_SESSION['x_ep'] = x_sess_ep($uid); if (x_admin()) x_act_log('Oturum', 'Tüm kullanıcıların oturumlarını kapattı'); header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=sess_all'); exit; }
    x_sess_bump($uid); $_SESSION['x_ep'] = x_sess_ep($uid); if (x_admin()) x_act_log('Oturum', 'Diğer oturumlarını kapattı');
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=sess_killed'); exit;
}
if ($_SERVER['REQUEST_METHOD']==='POST' && x_super() && $route==='sec_save') {
    if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
    $iv = function($k,$lo,$hi,$df) { $v = (isset($_POST[$k]) && is_scalar($_POST[$k])) ? (int)$_POST[$k] : $df; return ($v < $lo || $v > $hi) ? $df : $v; };
    $data['settings']['sess_idle'] = $iv('sess_idle',5,1440,30); $data['settings']['dl_lim'] = $iv('dl_lim',0,100000,0); $data['settings']['dl_win'] = $iv('dl_win',1,1440,60); $data['settings']['dl_adm'] = !empty($_POST['dl_adm']) ? 1 : 0; $data['settings']['dl_show'] = !empty($_POST['dl_show']) ? 1 : 0; $data['settings']['zip_on'] = !empty($_POST['zip_on']) ? 1 : 0;
    x_save($data); header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=sec_saved'); exit;
}
if ($_SERVER['REQUEST_METHOD']==='POST' && x_admin() && $route==='hist_restore') {
    $r = x_hist_restore($data, isset($_POST['hid']) ? $_POST['hid'] : '');
    if ($r==='ok') { x_save($data); x_act_log('Geçmiş', 'Kaydı geri yükledi'); }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg='.($r==='ok' ? 'hist_ok' : 'hist_skip')); exit;
}
if ($_SERVER['REQUEST_METHOD']==='POST' && x_admin() && $route==='acc_block') {
    $ids = (isset($_POST['ids']) && is_array($_POST['ids'])) ? array_values(array_filter($_POST['ids'], 'is_string')) : array(); $act = (isset($_POST['act']) && $_POST['act']==='unblock') ? 'unblock' : 'block'; $ok = 0; $me = isset($_SESSION['uid']) ? (string)$_SESSION['uid'] : ''; $names = array();
    if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
    if (!isset($data['settings']['blocked']) || !is_array($data['settings']['blocked'])) $data['settings']['blocked'] = array();
    foreach (x_accounts() as $ac) {
        if (!in_array($ac['id'], $ids, true) || $ac['id']===$me || x_acc_is_super_row($ac)) continue;
        if ($act==='block') { $data['settings']['blocked'][$ac['id']] = array('t'=>time(), 'by'=>$_SESSION['uname']); $ok++; $names[] = $ac['name']; }
        elseif (isset($data['settings']['blocked'][$ac['id']])) { unset($data['settings']['blocked'][$ac['id']]); $ok++; $names[] = $ac['name']; }
    }
    if ($ok) { x_save($data); x_act_log('Engelleme', implode(', ', $names).($act==='block' ? ' kullanıcılarını engelledi' : ' kullanıcılarının engelini kaldırdı')); }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg='.($ok ? ($act==='block' ? 'acc_blocked' : 'acc_unblocked') : 'hist_skip')); exit;
}
if ($_SERVER['REQUEST_METHOD']==='POST' && x_admin() && $route==='hist_do') {
    $ids = (isset($_POST['hid']) && is_array($_POST['hid'])) ? array_values(array_filter($_POST['hid'], 'is_string')) : array(); $act = (isset($_POST['act']) && $_POST['act']==='delete') ? 'delete' : 'restore'; $ok = 0;
    foreach ($ids as $hid) {
        if (!preg_match('/^[a-f0-9]{12}$/', $hid)) continue;
        if ($act==='restore') { if (x_hist_restore($data, $hid)==='ok') $ok++; }
        else { foreach ((array)(isset($data['history']) ? $data['history'] : array()) as $hk=>$he) if ($he['id']===$hid) { x_rrmdir(TRASH_DIR.'/'.$hid); unset($data['history'][$hk]); $ok++; break; } }
    }
    if (isset($data['history'])) $data['history'] = array_values($data['history']);
    if ($ok) { x_save($data); x_act_log('Geçmiş', $ok.' kaydı '.($act==='delete' ? 'geçmişten sildi' : 'geri yükledi')); }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg='.($ok ? ($act==='delete' ? 'hist_del' : 'hist_ok') : 'hist_skip')); exit;
}
if ($_SERVER['REQUEST_METHOD']==='POST' && x_admin() && $route==='hist_clear') {
    foreach ((array)(isset($data['history']) ? $data['history'] : array()) as $he) if (!empty($he['id']) && preg_match('/^[a-f0-9]{12}$/', $he['id'])) x_rrmdir(TRASH_DIR.'/'.$he['id']);
    $data['history'] = array(); x_save($data); header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=hist_clr'); exit;
}
if (x_admin() && isset($_GET['id']) && is_string($_GET['id']) && in_array($route, array('img_remove','img_bulk_remove','note_remove_image','remove_screenshot','github_remove_image','nfile_remove','vid_remove'), true)) {
    if ($route==='note_remove_image') $mt = 'notes'; elseif ($route==='remove_screenshot') $mt = 'dosya'; elseif ($route==='github_remove_image') $mt = 'github';
    elseif ($route==='nfile_remove' || $route==='vid_remove') $mt = x_vcoll(x_vtype());
    else { $mt = (isset($_GET['type']) && is_string($_GET['type'])) ? $_GET['type'] : ''; $mt = $mt==='dosya' ? 'dosya' : ($mt==='github' ? 'github' : ($mt==='note' ? 'notes' : '')); }
    if ($mt!=='' && isset($data[$mt]) && is_array($data[$mt])) foreach ($data[$mt] as $mit) if (isset($mit['id']) && $mit['id']===$_GET['id']) { $GLOBALS['x_media_hook'] = array('t'=>$mt, 'item'=>$mit, 'hid'=>x_hist_begin()); break; }
}
if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && isset($_GET['id']) && is_string($_GET['id']) && in_array($route, array('edit','github_edit','note_edit'), true)) {
    $ht = $route==='edit' ? 'dosya' : ($route==='github_edit' ? 'github' : 'notes');
    foreach ($data[$ht] as $hit) if (isset($hit['id']) && $hit['id']===$_GET['id']) { x_hist_edit($data, $ht, $hit); break; }
}
if ($route==='list') {
    if ($tab==='analytics') $tabOk = x_stats_ok();
    elseif ($tab==='settings') $tabOk = x_perm('settings');
    elseif ($tab==='home') { $hk0 = x_ws_cur('home'); $tabOk = ($hk0!=='' && isset($GLOBALS['x_all_tabs'][$hk0]) && $GLOBALS['x_all_tabs'][$hk0]['type']==='home' && $GLOBALS['x_all_tabs'][$hk0]['enabled']); }
    elseif ($tab==='all') $tabOk = x_type_any_on('dosya') || x_type_any_on('github');
    else $tabOk = x_tab_on($tab);
    if (!$tabOk) { header('Location: '.$_SERVER['SCRIPT_NAME'].x_entry_href(x_first_entry())); exit; }
}
if (!x_admin_role() && !x_is_editor() && $route!=='list' && isset($_GET['id']) && is_string($_GET['id'])) {
    foreach (x_types() as $gc) foreach ($data[$gc] as $git) if (isset($git['id']) && (string)$git['id']===$_GET['id']) { if (!x_item_on($gc,$git)) { header('HTTP/1.0 404 Not Found'); exit; } break 2; }
}
if (x_admin() && $route==='appr_no' && $_SERVER['REQUEST_METHOD']==='POST') {
    $rids = array();
    if (isset($_POST['rid']) && is_string($_POST['rid'])) $rids[] = $_POST['rid'];
    if (isset($_POST['rids']) && is_array($_POST['rids'])) foreach ($_POST['rids'] as $_x) if (is_string($_x)) $rids[] = $_x;
    $allr = isset($_POST['all']) && $_POST['all']==='1';
    $keep = array(); $gone = 0; $me = isset($_SESSION['uid']) ? (string)$_SESSION['uid'] : '';
    foreach (x_appr_all($data) as $r) {
        $mine = isset($r['uid']) && $r['uid']===$me; $hit = ($allr ? (x_super() || $mine) : in_array($r['id'], $rids, true));
        if (x_appr_mgr() && $hit) { if (empty($r['status']) || $r['status']!=='cancelled') x_hist_reject($data, $r); x_rrmdir(APPR_DIR.'/'.basename((string)$r['id'])); $gone++; }
        elseif ($mine && x_perm('appr_cancel') && $hit && !x_appr_mgr()) {
            if (empty($r['status']) || $r['status']!=='cancelled') { x_rrmdir(APPR_DIR.'/'.basename((string)$r['id'])); $r['status'] = 'cancelled'; $r['cancelled'] = date('Y-m-d H:i:s'); $gone++; }
            $keep[] = $r;
        }
        else $keep[] = $r;
    }
    if ($gone) { $data['approvals'] = $keep; x_save($data); }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab='.(x_appr_mgr() ? x_appr_tab() : (isset($_GET['tab']) && is_string($_GET['tab']) && preg_match('/^[a-z0-9_]{1,40}$/', $_GET['tab']) ? $_GET['tab'] : 'dosya')).'&msg='.($gone ? 'appr_no' : 'appr_gone')); exit;
}
if (x_appr_mgr() && $route==='appr_ok' && $_SERVER['REQUEST_METHOD']==='POST') {
    $rid = (isset($_POST['rid']) && is_string($_POST['rid'])) ? $_POST['rid'] : '';
    $req = null; $keep = array();
    foreach (x_appr_all($data) as $r) { if ($req===null && isset($r['id']) && $r['id']===$rid) $req = $r; else $keep[] = $r; }
    if ($req === null || (isset($req['status']) && $req['status']==='cancelled')) { header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab='.x_appr_tab().'&msg=appr_gone'); exit; }
    $data['approvals'] = $keep; x_save($data);
    $kl = array('add'=>'ekleme','edit'=>'düzenleme','delete'=>'silme');
    x_act_log('Onay', 'Editör işlemini onayladı: '.(isset($req['name']) ? $req['name'] : '').' — '.(isset($kl[$req['kind']]) ? $kl[$req['kind']] : '').' ('.(isset($req['label']) ? $req['label'] : '').')');
    $xfd = x_data(); if (is_array($xfd) && isset($xfd['activity'])) $data['activity'] = $xfd['activity'];
    $GLOBALS['x_act_skip'] = true;
    $GLOBALS['x_replay'] = true; $GLOBALS['x_replay_uid'] = isset($req['uid']) ? (string)$req['uid'] : '';
    $route = (string)$req['route']; $_GET = is_array($req['get']) ? $req['get'] : array(); $_GET['action'] = $route;
    $_POST = is_array($req['post']) ? $req['post'] : array(); $_FILES = is_array($req['files']) ? $req['files'] : array();
    $_SERVER['REQUEST_METHOD'] = (isset($req['method']) && $req['method']==='POST') ? 'POST' : 'GET';
    $tab = (isset($_GET['tab']) && is_string($_GET['tab']) && preg_match('/^[a-z0-9_]{1,40}$/', $_GET['tab'])) ? $_GET['tab'] : 'dosya';
    $_REQUEST = array_merge($_GET, $_POST);
    $xw = array('dosya'=>'','github'=>'','notes'=>'','home'=>'');
    $xwp = isset($_GET['ws']) ? $_GET['ws'] : (isset($_POST['ws']) ? $_POST['ws'] : null);
    if (is_string($xwp) && $xwp!=='base' && isset($GLOBALS['x_all_tabs'][$xwp]) && empty($GLOBALS['x_all_tabs'][$xwp]['base'])) $xw[$GLOBALS['x_all_tabs'][$xwp]['type']] = $xwp;
    $GLOBALS['x_ws'] = $xw;
}
if (x_admin() && $route==='settings_save' && $_SERVER['REQUEST_METHOD']==='POST') {
    $new = array(); $newc = array(); $any = false;
    foreach ($GLOBALS['x_all_tabs'] as $k=>$e) {
        $lbl = (isset($_POST['label']) && is_array($_POST['label']) && isset($_POST['label'][$k]) && is_string($_POST['label'][$k])) ? trim($_POST['label'][$k]) : '';
        $en = (isset($_POST['enabled']) && is_array($_POST['enabled']) && isset($_POST['enabled'][$k]));
        $lbl = $lbl!=='' ? mb_substr($lbl,0,30) : x_type_label($e['type']);
        $ic = (isset($_POST['icon']) && is_array($_POST['icon']) && isset($_POST['icon'][$k]) && is_string($_POST['icon'][$k])) ? $_POST['icon'][$k] : ''; if ($ic!=='none' && !x_icon_ok($ic)) $ic = '';
        if (!empty($e['hidden_me'])) $en = !empty($e['enabled_raw']);
        if (x_super()) { $vh = (isset($_POST['hide']) && is_array($_POST['hide']) && isset($_POST['hide'][$k])); $vs = (isset($_POST['show']) && is_array($_POST['show']) && isset($_POST['show'][$k]) && is_array($_POST['show'][$k])) ? $_POST['show'][$k] : array(); $vv = x_tab_vis(array('hide'=>$vh,'show'=>$vs)); }
        else $vv = array('hide'=>!empty($e['hide']), 'show'=>(isset($e['show']) ? $e['show'] : array()));
        if ($en) $any = true;
        if ($e['base']) $new[$k] = array('label'=>$lbl, 'enabled'=>$en, 'icon'=>$ic) + $vv;
        else { $newc[$k] = array('type'=>$e['type'], 'label'=>$lbl, 'enabled'=>$en, 'icon'=>$ic) + $vv; if ($e['type']==='home') $newc[$k]['content'] = isset($e['content']) ? $e['content'] : ''; }
    }
    if (!$any) { header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=settings_none'); exit; }
    $ord = array(); if (isset($_POST['order']) && is_array($_POST['order'])) foreach ($_POST['order'] as $ok) if (is_string($ok) && isset($GLOBALS['x_all_tabs'][$ok]) && !in_array($ok,$ord,true)) $ord[] = $ok;
    $data['settings']['tab_order'] = $ord;
    $data['settings']['tabs'] = $new;
    $data['settings']['custom_tabs'] = $newc;
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=settings_saved'); exit;
}
if (x_admin() && $route==='tab_add' && $_SERVER['REQUEST_METHOD']==='POST') {
    $nt = (isset($_POST['type']) && is_string($_POST['type'])) ? $_POST['type'] : '';
    if (in_array($nt,array_merge(x_types(),array('home')),true)) {
        $nl = (isset($_POST['label']) && is_string($_POST['label'])) ? trim($_POST['label']) : '';
        $nl = $nl!=='' ? mb_substr($nl,0,30) : x_type_label($nt);
        do { $nk = 'ws_'.substr(md5(uniqid(mt_rand(), true)),0,8); } while (isset($GLOBALS['x_all_tabs'][$nk]));
        if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
        if (!isset($data['settings']['custom_tabs']) || !is_array($data['settings']['custom_tabs'])) $data['settings']['custom_tabs'] = array();
        $data['settings']['custom_tabs'][$nk] = array('type'=>$nt, 'label'=>$nl, 'enabled'=>true); if ($nt==='home') $data['settings']['custom_tabs'][$nk]['content'] = '';
        x_save($data);
        header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=tab_added'); exit;
    }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings'); exit;
}
if (x_admin() && $route==='login_preview') { x_login_page(false); exit; }
if (x_admin() && $route==='site_save' && $_SERVER['REQUEST_METHOD']==='POST') {
    if (empty($_POST) && empty($_FILES) && !empty($_SERVER['CONTENT_LENGTH'])) { header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=site_post_big&lim='.urlencode((string)ini_get('post_max_size'))); exit; }
    if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
    $cur = (isset($data['settings']['site']) && is_array($data['settings']['site'])) ? $data['settings']['site'] : array();
    $files = (isset($cur['files']) && is_array($cur['files'])) ? $cur['files'] : array();
    $msg = 'site_saved'; $lim = '';
    if (isset($_POST['reset_all'])) {
        foreach ($files as $fk=>$fv) { if (is_string($fv) && is_file(SITE_DIR.'/'.basename($fv))) @unlink(SITE_DIR.'/'.basename($fv)); }
        $pk = x_default_pack($data);
        if ($pk !== null) {
            $nf = array();
            foreach ($pk['files'] as $fk=>$bf) {
                if (in_array($fk, x_site_file_keys(), true) && is_string($bf) && preg_match('/^base_[a-z_]+\.(png|jpg|gif|webp|ico)$/', $bf) && is_file(SITE_DIR.'/'.$bf)) {
                    $nn = $fk.'_'.substr(md5(uniqid('', true)), 0, 10).'.'.pathinfo($bf, PATHINFO_EXTENSION);
                    if (@copy(SITE_DIR.'/'.$bf, SITE_DIR.'/'.$nn)) { @chmod(SITE_DIR.'/'.$nn, 0644); $nf[$fk] = $nn; }
                }
            }
            $dv = $pk['vals']; $dv['files'] = $nf; $data['settings']['site'] = $dv;
        } else unset($data['settings']['site']);
        x_save($data);
        header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=site_reset'); exit;
    }
    $new = array();
    $lens = array('title'=>80,'app_name'=>60,'description'=>300,'keywords'=>300,'og_title'=>100,'og_description'=>300,'brand_a'=>40,'brand_b'=>40,'login_sub'=>80,'login_ph'=>60,'login_btn'=>40,'login_hint'=>200);
    foreach ($lens as $k=>$mx) { $v = (isset($_POST[$k]) && is_string($_POST[$k])) ? trim(str_replace(array("\r","\n"),' ',$_POST[$k])) : ''; $new[$k] = mb_substr($v,0,$mx); }
    $new['robots'] = (isset($_POST['robots']) && $_POST['robots']==='noindex') ? 'noindex' : '';
    $dim = isset($_POST['login_dim']) ? (int)$_POST['login_dim'] : 55; $new['login_dim'] = (string)max(0,min(100,$dim));
    $li = (isset($_POST['login_icon']) && is_string($_POST['login_icon'])) ? $_POST['login_icon'] : '';
    $new['login_icon'] = ($li==='none' || x_icon_ok($li)) ? $li : '';
    $dpk = isset($_POST['reset_colors']) ? x_default_pack($data) : null; $dvc = $dpk !== null ? $dpk['vals'] : null;
    $new['theme_mode'] = isset($_POST['reset_colors']) ? (($dvc !== null && isset($dvc['theme_mode']) && $dvc['theme_mode']==='light') ? 'light' : '') : ((isset($_POST['theme_mode']) && $_POST['theme_mode']==='light') ? 'light' : '');
    foreach (array('c_accent','c_bg','c_surface','c_border','c_text','c_text2','l_accent','l_bg','l_surface','l_border','l_text','l_text2','brand_a_color','brand_b_color') as $ck) {
        if (isset($_POST['reset_colors'])) { $new[$ck] = ($dvc !== null && isset($dvc[$ck]) && x_color_ok($dvc[$ck])) ? $dvc[$ck] : ''; }
        else { $new[$ck] = (isset($_POST['use_'.$ck]) && isset($_POST[$ck]) && x_color_ok($_POST[$ck])) ? strtolower($_POST[$ck]) : ''; }
    }
    foreach (array('logo'=>'f_logo','login_bg'=>'f_login_bg','favicon'=>'f_favicon','og'=>'f_og') as $key=>$field) {
        $err = '';
        $old = (isset($files[$key]) && is_string($files[$key])) ? $files[$key] : '';
        if (isset($_POST['rm_'.$key]) && $old!=='') { if (is_file(SITE_DIR.'/'.basename($old))) @unlink(SITE_DIR.'/'.basename($old)); unset($files[$key]); $old = ''; }
        $nf = x_site_upload($field, $key, $err);
        if ($nf !== null) { if ($old!=='' && is_file(SITE_DIR.'/'.basename($old))) @unlink(SITE_DIR.'/'.basename($old)); $files[$key] = $nf; }
        elseif ($err !== '') { if ($err==='big_ini') { $msg = 'site_upload_big'; $lim = (string)ini_get('upload_max_filesize'); } elseif ($err==='big') { $msg = 'site_upload_big'; $lim = '3M'; } elseif ($err==='type') { $msg = 'site_upload_type'; } else { $msg = 'site_upload_err'; } }
    }
    $new['files'] = $files;
    $data['settings']['site'] = $new;
    if (isset($_POST['base_save']) && $msg === 'site_saved') {
        x_base_files_clear($data);
        $bfs = array();
        foreach ($files as $fk=>$fv) {
            if (in_array($fk, x_site_file_keys(), true) && is_string($fv) && is_file(SITE_DIR.'/'.basename($fv))) {
                $ex = strtolower(pathinfo($fv, PATHINFO_EXTENSION));
                if (preg_match('/^(png|jpg|gif|webp|ico)$/', $ex)) { $bn = 'base_'.$fk.'.'.$ex; if (@copy(SITE_DIR.'/'.basename($fv), SITE_DIR.'/'.$bn)) { @chmod(SITE_DIR.'/'.$bn, 0644); $bfs[$fk] = $bn; } }
            }
        }
        $bv = $new; unset($bv['files']);
        $data['settings']['base_default'] = array('vals'=>$bv, 'files'=>$bfs, 'time'=>date('d.m.Y H:i'));
        unset($data['settings']['theme_default']);
        $msg = 'base_saved';
    }
    if (isset($_POST['theme_save']) && $msg === 'site_saved') {
        $tn = (isset($_POST['theme_name']) && is_string($_POST['theme_name'])) ? trim(mb_substr($_POST['theme_name'], 0, 30)) : '';
        if ($tn === '') { $msg = 'theme_noname'; }
        else {
            $tv = $new; unset($tv['files']);
            $tl = (isset($data['settings']['themes']) && is_array($data['settings']['themes'])) ? array_values($data['settings']['themes']) : array();
            $tf = false;
            foreach ($tl as $ti=>$tt) if (is_array($tt) && isset($tt['name']) && mb_strtolower($tt['name'])===mb_strtolower($tn)) { $tl[$ti]['name'] = $tn; $tl[$ti]['vals'] = $tv; $tf = true; break; }
            if (!$tf && count($tl) >= 20) { $msg = 'theme_full'; }
            else { if (!$tf) $tl[] = array('id'=>'th_'.bin2hex(random_bytes(4)), 'name'=>$tn, 'vals'=>$tv); $data['settings']['themes'] = $tl; $msg = 'theme_saved'; }
        }
    }
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg='.$msg.($lim!=='' ? '&lim='.urlencode($lim) : '')); exit;
}
if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && in_array($route, array('ip_ban','ip_unban'), true)) {
    $bip = (isset($_POST['ip']) && is_string($_POST['ip'])) ? trim($_POST['ip']) : '';
    $rm = 'ban_invalid';
    if (filter_var($bip, FILTER_VALIDATE_IP)) {
        $bl = x_ban_ips($data); $nl = array();
        foreach ($bl as $bb) if (is_array($bb) && isset($bb['ip']) && $bb['ip'] !== $bip) $nl[] = $bb;
        if ($route==='ip_unban') { $rm = 'ban_removed'; }
        elseif ($bip === x_ip()) { $nl = $bl; $rm = 'ban_self'; }
        elseif (in_array(x_ip_norm($bip), x_super_ips($data), true)) { $nl = $bl; $rm = 'ban_super'; }
        elseif (count($nl) >= 500) { $nl = $bl; $rm = 'ban_full'; }
        else { $nl[] = array('ip'=>$bip, 'time'=>date('d.m.Y H:i')); $rm = 'ban_added'; }
        if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
        $data['settings']['banned_ips'] = array_values($nl);
        x_save($data);
    }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab='.$tab.'&msg='.$rm); exit;
}
if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && $route==='ip_unban_bulk') {
    $bl = x_ban_ips($data); $rm = 'ban_bulk_none';
    if (isset($_POST['all']) && $_POST['all']==='1') { if ($bl) $rm = 'ban_bulk_removed'; $nl = array(); }
    else {
        $sel = (isset($_POST['ips']) && is_array($_POST['ips'])) ? array_filter($_POST['ips'], 'is_string') : array();
        $nl = array();
        foreach ($bl as $bb) { if (is_array($bb) && isset($bb['ip']) && in_array($bb['ip'], $sel, true)) { $rm = 'ban_bulk_removed'; continue; } $nl[] = $bb; }
    }
    if ($rm === 'ban_bulk_removed') {
        if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
        $data['settings']['banned_ips'] = array_values($nl);
        x_save($data);
    }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg='.$rm); exit;
}
if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && $route==='actbtn_save') {
    $ab = array();
    if (!isset($_POST['ab_reset'])) foreach (array_keys(x_ab_all()) as $k) {
        $ic = (isset($_POST['ab_'.$k.'_icon']) && is_string($_POST['ab_'.$k.'_icon'])) ? $_POST['ab_'.$k.'_icon'] : '';
        if (!in_array($ic, x_ab_icons(), true)) $ic = '';
        $r = array('icon'=>$ic);
        foreach (array('color','bg','bd') as $f) { $v = (isset($_POST['ab_'.$k.'_'.$f]) && is_string($_POST['ab_'.$k.'_'.$f])) ? $_POST['ab_'.$k.'_'.$f] : ''; $r[$f] = (!empty($_POST['abu_'.$k.'_'.$f]) && x_color_ok($v)) ? $v : ''; }
        $r['bgt'] = !empty($_POST['ab_'.$k.'_bgt']) ? '1' : '';
        $rd = (isset($_POST['ab_'.$k.'_rad']) && is_string($_POST['ab_'.$k.'_rad'])) ? $_POST['ab_'.$k.'_rad'] : ''; $r['rad'] = isset(x_ab_rads()[$rd]) ? $rd : '';
        $ab[$k] = $r;
    }
    if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
    $data['settings']['actbtn'] = $ab;
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=actbtn_saved'); exit;
}
if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && $route==='empty_save') {
    $es = array();
    foreach (array_keys(x_empty_defs()) as $ek) {
        $ti = (isset($_POST['e_'.$ek.'_title']) && is_string($_POST['e_'.$ek.'_title'])) ? trim(mb_substr(str_replace(array("\r","\n"),' ',$_POST['e_'.$ek.'_title']),0,120)) : '';
        $ht = x_rich(trim((isset($_POST['e_'.$ek.'_html']) && is_string($_POST['e_'.$ek.'_html'])) ? $_POST['e_'.$ek.'_html'] : ''));
        $ic = (isset($_POST['e_'.$ek.'_icon']) && is_string($_POST['e_'.$ek.'_icon'])) ? $_POST['e_'.$ek.'_icon'] : '';
        if ($ic!=='none' && !x_icon_ok($ic)) $ic = '';
        $es[$ek] = array('title'=>$ti, 'html'=>$ht, 'icon'=>$ic, 'vis'=>!empty($_POST['e_'.$ek.'_vis']) ? '1' : '');
    }
    if (isset($_POST['empty_reset'])) $es = array();
    if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
    $data['settings']['empty'] = $es;
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=empty_saved'); exit;
}
if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && $route==='ban_save') {
    $bt = (isset($_POST['ban_title']) && is_string($_POST['ban_title'])) ? trim(mb_substr($_POST['ban_title'], 0, 80)) : '';
    $bh = x_rich(trim((isset($_POST['content']) && is_string($_POST['content'])) ? $_POST['content'] : ''));
    $bb = (isset($_POST['ban_btn']) && is_string($_POST['ban_btn'])) ? trim(mb_substr($_POST['ban_btn'], 0, 40)) : '';
    $bu = (isset($_POST['ban_url']) && is_string($_POST['ban_url'])) ? trim($_POST['ban_url']) : '';
    if (!preg_match('~^(https?://|mailto:|tel:)~i', $bu)) $bu = '';
    if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
    $data['settings']['ban'] = array('title'=>$bt, 'html'=>$bh, 'btn'=>$bb, 'url'=>$bu);
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=ban_saved'); exit;
}
if (x_admin() && $route==='ban_preview') { x_ban_page($data, false); }
if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && $route==='vpn_save') {
    $vt = (isset($_POST['vpn_title']) && is_string($_POST['vpn_title'])) ? trim(mb_substr($_POST['vpn_title'], 0, 80)) : '';
    $vh = x_rich(trim((isset($_POST['content']) && is_string($_POST['content'])) ? $_POST['content'] : ''));
    $vb = (isset($_POST['vpn_btn']) && is_string($_POST['vpn_btn'])) ? trim(mb_substr($_POST['vpn_btn'], 0, 40)) : '';
    $vu = (isset($_POST['vpn_url']) && is_string($_POST['vpn_url'])) ? trim($_POST['vpn_url']) : '';
    if (!preg_match('~^(https?://|mailto:|tel:)~i', $vu)) $vu = '';
    $vk = (isset($_POST['vpn_key']) && is_string($_POST['vpn_key'])) ? substr(preg_replace('/[^A-Za-z0-9_\-]/', '', $_POST['vpn_key']), 0, 80) : '';
    $vo = (isset($_POST['vpn_enabled']) && $_POST['vpn_enabled']==='2');
    $ve = (isset($_POST['vpn_enabled']) && $_POST['vpn_enabled']==='1');
    if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
    $data['settings']['vpn'] = array('off'=>$vo, 'enabled'=>$ve, 'key'=>$vk, 'title'=>$vt, 'html'=>$vh, 'btn'=>$vb, 'url'=>$vu);
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=vpn_saved'); exit;
}
if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && $route==='vpn_test') {
    $vs = x_vpn_settings($data);
    $tl = x_http_get('https://check.torproject.org/torbulkexitlist', 6); $tc = 0;
    if ($tl !== false) { foreach (preg_split('/\s+/', $tl) as $l) { if ($l !== '' && filter_var($l, FILTER_VALIDATE_IP)) $tc++; } }
    $va = x_vpn_api('1.1.1.1', $vs['key']);
    $vb = x_vpn_api_ipapiis('1.1.1.1'); $vc = x_vpn_api_ipapi('1.1.1.1'); $_SESSION['x_vpn_diag'] = 'ipapi.is: '.($vb['ok'] ? 'çalışıyor' : 'ulaşılamadı ('.$vb['err'].')').' | ip-api: '.($vc['ok'] ? 'çalışıyor' : 'ulaşılamadı ('.$vc['err'].')').' | Tor listesi: '.($tc > 50 ? $tc.' çıkış IP\'si alındı' : 'alınamadı (sunucu dış bağlantıya izin vermiyor olabilir)').' | VPN servisi: '.($va['ok'] ? 'çalışıyor' : 'ulaşılamadı veya reddetti ('.$va['err'].')');
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=vpn_test'); exit;
}
if (x_admin() && $route==='vpn_preview') { x_ban_page($data, false, x_vpn_settings($data)); }
if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && $route==='cf_save') {
    if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
    $data['settings']['cf'] = array('enabled'=>(isset($_POST['cf_enabled']) && $_POST['cf_enabled']==='1'));
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=cf_saved'); exit;
}
if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && $route==='theme_bulk_delete') {
    $bids = (isset($_POST['ids']) && is_array($_POST['ids'])) ? array_values(array_filter($_POST['ids'], 'is_string')) : array();
    if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
    $tl = (isset($data['settings']['themes']) && is_array($data['settings']['themes'])) ? array_values($data['settings']['themes']) : array();
    $keep = array(); $hth = array();
    foreach ($tl as $tt) { if (!(is_array($tt) && isset($tt['id']) && in_array($tt['id'], $bids, true))) $keep[] = $tt; elseif (is_array($tt)) $hth[] = $tt; }
    if ($hth) x_hist_gen($data, 'theme', 'themedel', array_map(function($t) { return isset($t['name']) ? (string)$t['name'] : (string)$t['id']; }, $hth), array('themes'=>$hth), bin2hex(random_bytes(6)), array(), count($hth).' tema silindi');
    $data['settings']['themes'] = $keep;
    if (isset($data['settings']['theme_default']) && in_array($data['settings']['theme_default'], $bids, true)) unset($data['settings']['theme_default']);
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=theme_bulk_deleted'); exit;
}
if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && in_array($route, array('theme_apply','theme_default','theme_delete'), true)) {
    $tid = (isset($_POST['id']) && is_string($_POST['id'])) ? $_POST['id'] : '';
    if (!isset($data['settings']) || !is_array($data['settings'])) $data['settings'] = array();
    $tl = (isset($data['settings']['themes']) && is_array($data['settings']['themes'])) ? array_values($data['settings']['themes']) : array();
    $ix = -1; foreach ($tl as $ti=>$tt) if (is_array($tt) && isset($tt['id']) && $tt['id']===$tid) { $ix = $ti; break; }
    $rm = 'theme_none';
    if ($route==='theme_default' && x_base_info() !== '') { $rm = 'base_locked'; }
    elseif ($route==='theme_default' && $tid==='') { unset($data['settings']['theme_default']); $rm = 'theme_default_cleared'; }
    elseif ($ix >= 0) {
        if ($route==='theme_apply') {
            $cs = (isset($data['settings']['site']) && is_array($data['settings']['site'])) ? $data['settings']['site'] : array();
            $nv = x_theme_clean(isset($tl[$ix]['vals']) ? $tl[$ix]['vals'] : array());
            $nv['files'] = (isset($cs['files']) && is_array($cs['files'])) ? $cs['files'] : array();
            $data['settings']['site'] = $nv; $rm = 'theme_applied';
        } elseif ($route==='theme_default') { $data['settings']['theme_default'] = $tid; $rm = 'theme_default_set'; }
        else {
            x_hist_gen($data, 'theme', 'themedel', array(isset($tl[$ix]['name']) ? (string)$tl[$ix]['name'] : $tid), array('themes'=>array($tl[$ix])), bin2hex(random_bytes(6)), array(), '1 tema silindi');
            unset($tl[$ix]); $data['settings']['themes'] = array_values($tl);
            if (isset($data['settings']['theme_default']) && $data['settings']['theme_default']===$tid) unset($data['settings']['theme_default']);
            $rm = 'theme_deleted';
        }
    }
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg='.$rm); exit;
}
if (x_admin() && $route==='acc_add' && $_SERVER['REQUEST_METHOD']==='POST') {
    $back = $_SERVER['SCRIPT_NAME'].'?tab=settings&msg=';
    $nm = (isset($_POST['name']) && is_string($_POST['name'])) ? trim($_POST['name']) : '';
    $mkSuper = (isset($_POST['role']) && $_POST['role']==='super' && x_super());
    $rl = ((isset($_POST['role']) && $_POST['role']==='admin') || $mkSuper) ? 'admin' : ((isset($_POST['role']) && $_POST['role']==='editor' && x_super()) ? 'editor' : 'visitor');
    $p1 = (isset($_POST['pass']) && is_string($_POST['pass'])) ? trim($_POST['pass']) : '';
    if ($nm==='') { header('Location: '.$back.'acc_name'); exit; }
    if (strlen($p1) < 6) { header('Location: '.$back.'acc_short'); exit; }
    $accs = x_accounts();
    if (x_pass_dup($p1, $accs, '')) { header('Location: '.$back.'acc_dup'); exit; }
    $a = x_acc_load();
    $ne = array('id'=>'acc_'.substr(md5(uniqid(mt_rand(), true)), 0, 10), 'name'=>mb_substr($nm,0,30), 'role'=>$rl, 'hash'=>password_hash($p1, PASSWORD_DEFAULT), 'created'=>date('Y-m-d H:i:s'));
    if ($mkSuper) $ne['super'] = true;
    if (x_super()) {
        $bd = x_badge_clean(isset($_POST['badge']) ? $_POST['badge'] : '');
        if ($bd!=='') $ne['badge'] = $bd;
        if (isset($_POST['bcolor_on']) && isset($_POST['bcolor']) && is_string($_POST['bcolor']) && x_color_ok($_POST['bcolor'])) $ne['badge_color'] = strtolower($_POST['bcolor']);
        if (isset($_POST['permset']) && is_array($_POST['permset']) && isset($_POST['permset']['new'])) {
            $pp = x_perm_post('new');
            $ne['perms'] = array_values(array_diff($pp, array('logs')));
            if ($rl==='editor') $ne['perms'] = array_values(array_intersect($ne['perms'], x_ed_keys()));
            if (in_array('logs', $pp, true) && $rl!=='editor') $ne['can_logs'] = true;
        }
    } else {
        $mine = x_acc_self();
        $ne['perms'] = ($rl==='admin' && $mine) ? array_values(array_diff(x_acc_perms($mine), array('logs','logins','hide_super','php_ext','history','acc_block','appr_review'))) : array();
    }
    $a['users'][] = $ne;
    if (!x_acc_commit($a)) { header('Location: '.$back.'acc_verify'); exit; }
    header('Location: '.$back.'acc_added'); exit;
}
if (x_admin() && $route==='acc_save' && $_SERVER['REQUEST_METHOD']==='POST') {
    $back = $_SERVER['SCRIPT_NAME'].'?tab=settings&msg=';
    $accs = x_accounts(); $me = x_acc_self(); $a = x_acc_load();
    $names = (isset($_POST['name']) && is_array($_POST['name'])) ? $_POST['name'] : array();
    $pw1 = (isset($_POST['pass']) && is_array($_POST['pass'])) ? $_POST['pass'] : array();
    $dels = array(); if (isset($_POST['del']) && is_array($_POST['del'])) foreach ($_POST['del'] as $dv) if (is_string($dv) && $dv!=='builtin_admin') $dels[] = $dv;
    if (!x_super_root()) { unset($pw1['builtin_admin'], $names['builtin_admin']); }
    $prot = array(); if (!x_super()) foreach (x_accounts() as $_pa) if (!empty($_pa['super'])) $prot[] = $_pa['id'];
    foreach ($prot as $_pid) unset($pw1[$_pid], $names[$_pid]);
    $dels = array_values(array_diff($dels, $prot));
    $newHash = array();
    foreach ($accs as $ac) {
        $id = $ac['id'];
        $p1 = (isset($pw1[$id]) && is_string($pw1[$id])) ? trim($pw1[$id]) : '';
        if ($p1==='') continue;
        if (in_array($id, $dels, true)) continue;
        if (strlen($p1) < 6) { header('Location: '.$back.'acc_short&w='.rawurlencode($ac['name'])); exit; }
        if (x_pass_dup($p1, $accs, $id)) { header('Location: '.$back.'acc_dup&w='.rawurlencode($ac['name'])); exit; }
        foreach ($newHash as $oid=>$op) { if ($oid!==$id && $op===$p1) { header('Location: '.$back.'acc_dup'); exit; } }
        $newHash[$id] = $p1;
    }
    foreach ($dels as $dv) { if ($me && $dv===$me['id']) { header('Location: '.$back.'acc_self'); exit; } }
    $rolesIn = (isset($_POST['role']) && is_array($_POST['role'])) ? $_POST['role'] : array();
    foreach ($prot as $_pid) unset($rolesIn[$_pid]);
    $newSuper = array();
    $badIn = (isset($_POST['badge']) && is_array($_POST['badge'])) ? $_POST['badge'] : array();
    $permSet = (isset($_POST['permset']) && is_array($_POST['permset'])) ? $_POST['permset'] : array();
    $plab = x_perm_labels(); $mePerms = $me ? x_acc_perms($me) : array();
    $det = array(); $newRole = array(); $newLogs = array(); $newPerms = array(); $newBadge = array(); $newColor = array();
    $colIn = (isset($_POST['bcolor']) && is_array($_POST['bcolor'])) ? $_POST['bcolor'] : array(); $colOn = (isset($_POST['bcolor_on']) && is_array($_POST['bcolor_on'])) ? $_POST['bcolor_on'] : array();
    foreach ($accs as $ac) {
        $id = $ac['id']; $lbl = x_role_label($ac).' '.$ac['name'];
        if (in_array($id, $dels, true)) { $det[] = array('Hesaplar', 'Hesabı sildi: '.$lbl); continue; }
        $nn = (isset($names[$id]) && is_string($names[$id])) ? mb_substr(trim($names[$id]),0,30) : '';
        if ($nn!=='' && $nn!==$ac['name']) $det[] = array('Hesaplar', 'Hesap adını değiştirdi: '.$ac['name'].' → '.$nn);
        if (isset($newHash[$id])) $det[] = array('Hesaplar', 'Şifre değiştirdi: '.$lbl);
        if ($id!=='builtin_admin' && !($me && $me['id']===$id) && isset($rolesIn[$id]) && is_string($rolesIn[$id]) && x_super()) {
            $wantSup = ($rolesIn[$id]==='super'); if ($wantSup) $rolesIn[$id] = 'admin';
            if ($wantSup !== !empty($ac['super'])) { $newSuper[$id] = $wantSup; $det[] = array('Hesaplar', ($wantSup ? 'Süper Admin yetkisi verdi: ' : 'Süper Admin yetkisini aldı: ').$ac['name']); }
        }
        if ($id!=='builtin_admin' && !($me && $me['id']===$id) && isset($rolesIn[$id]) && is_string($rolesIn[$id]) && ($rolesIn[$id]==='admin' || $rolesIn[$id]==='visitor' || ($rolesIn[$id]==='editor' && x_super())) && $rolesIn[$id]!==$ac['role']) {
            $newRole[$id] = $rolesIn[$id];
            $det[] = array('Hesaplar', 'Rolü değiştirdi: '.$ac['name'].' ('.($ac['role']==='admin' ? 'Yönetici' : ($ac['role']==='editor' ? 'Editör' : 'Ziyaretçi')).' → '.($newRole[$id]==='admin' ? 'Yönetici' : ($newRole[$id]==='editor' ? 'Editör' : 'Ziyaretçi')).')');
        }
        if (x_super()) {
            if (isset($badIn[$id]) && is_string($badIn[$id])) {
                $nb = x_badge_clean($badIn[$id]);
                if ($nb !== $ac['badge']) { $newBadge[$id] = $nb; $det[] = array('Hesaplar', 'Rozeti değiştirdi: '.$ac['name'].' ('.x_role_label($ac).' → '.($nb!=='' ? $nb : x_role_def($ac)).')'); }
            }
            if (array_key_exists($id, $colIn)) {
                $wc = (isset($colOn[$id]) && is_string($colIn[$id]) && x_color_ok($colIn[$id])) ? strtolower($colIn[$id]) : '';
                if ($wc !== $ac['badge_color']) { $newColor[$id] = $wc; $det[] = array('Hesaplar', 'Rozet rengini değiştirdi: '.$ac['name'].($wc!=='' ? ' ('.$wc.')' : ' (varsayılan)')); }
            }
            if ($id!=='builtin_admin' && isset($permSet[$id])) {
                $pp = x_perm_post($id);
                $old = x_acc_perms($ac);
                $add = array_values(array_diff($pp, $old)); $rem = array_values(array_diff($old, $pp));
                $nl = function($ks) use ($plab) { $o = array(); foreach (array_slice($ks, 0, 6) as $k) $o[] = isset($plab[$k]) ? $plab[$k] : $k; return implode(', ', $o).(count($ks) > 6 ? ' (+'.(count($ks)-6).' yetki daha)' : ''); };
                if ($add) $det[] = array('Hesaplar', 'Yetki verdi: '.$ac['name'].' → '.$nl($add));
                if ($rem) $det[] = array('Hesaplar', 'Yetki aldı: '.$ac['name'].' → '.$nl($rem));
                $fr = isset($newRole[$id]) ? $newRole[$id] : $ac['role'];
                $newPerms[$id] = array_values(array_diff($pp, array('logs')));
                if ($fr==='editor') $newPerms[$id] = array_values(array_intersect($newPerms[$id], x_ed_keys()));
                $newLogs[$id] = in_array('logs', $pp, true) && $fr!=='editor';
            }
        } elseif (isset($newRole[$id])) {
            $newPerms[$id] = $newRole[$id]==='admin' ? array_values(array_diff($mePerms, array('logs','logins','hide_super','php_ext','history','acc_block','appr_review'))) : array();
            $newLogs[$id] = false;
        }
    }
    $hacc = array('users'=>array(), 'builtin'=>array(), 'names'=>array());
    foreach ($accs as $ac) {
        $id = $ac['id'];
        $nm = (isset($names[$id]) && is_string($names[$id])) ? mb_substr(trim($names[$id]),0,30) : '';
        $isDel = in_array($id, $dels, true);
        $hs = isset($newHash[$id]) ? $newHash[$id] : null;
        $rl = isset($newRole[$id]) ? $newRole[$id] : null;
        $bg = array_key_exists($id, $newBadge) ? $newBadge[$id] : null;
        $pm = array_key_exists($id, $newPerms) ? $newPerms[$id] : null;
        $lg = array_key_exists($id, $newLogs) ? $newLogs[$id] : null;
        $bc = array_key_exists($id, $newColor) ? $newColor[$id] : null;
        if ($ac['builtin']) {
            $r = substr($id, 8);
            if (!isset($a['builtin'][$r]) || !is_array($a['builtin'][$r])) $a['builtin'][$r] = array();
            if ($isDel) { $hacc['builtin'][] = $r; $hacc['names'][] = $ac['name']; $a['builtin'][$r]['deleted'] = true; continue; }
            x_acc_apply($a['builtin'][$r], $nm, $hs, $rl, $bg, $pm, $lg, $bc);
        } else {
            foreach ($a['users'] as $ui=>$u) {
                if (!is_array($u) || !isset($u['id']) || $u['id']!==$id) continue;
                if ($isDel) { $hacc['users'][] = $u; $hacc['names'][] = $ac['name']; unset($a['users'][$ui]); continue; }
                x_acc_apply($a['users'][$ui], $nm, $hs, $rl, $bg, $pm, $lg, $bc);
                if (array_key_exists($id, $newSuper)) { if ($newSuper[$id]) $a['users'][$ui]['super'] = true; else unset($a['users'][$ui]['super']); }
            }
        }
    }
    $a['users'] = array_values($a['users']); $GLOBALS['x_act_detail'] = $det;
    if (!x_acc_commit($a)) { header('Location: '.$back.'acc_verify'); exit; }
    if ($hacc['names']) { $d2 = x_data(); x_hist_gen($d2, 'acc', 'accdel', $hacc['names'], array('users'=>$hacc['users'], 'builtin'=>$hacc['builtin']), bin2hex(random_bytes(6)), array(), count($hacc['names']).' hesap silindi (giriş şifresi korunur)'); x_save($d2); }
    header('Location: '.$back.'acc_saved'); exit;
}
if (x_admin() && $route==='home_save' && $_SERVER['REQUEST_METHOD']==='POST') {
    $hk = (isset($_POST['key']) && is_string($_POST['key'])) ? $_POST['key'] : '';
    if (isset($GLOBALS['x_all_tabs'][$hk]) && $GLOBALS['x_all_tabs'][$hk]['type']==='home' && isset($data['settings']['custom_tabs'][$hk]) && is_array($data['settings']['custom_tabs'][$hk])) {
        $data['settings']['custom_tabs'][$hk]['content'] = x_rich(trim((isset($_POST['content']) && is_string($_POST['content'])) ? $_POST['content'] : ''));
        x_save($data);
        header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=home&ws='.$hk.'&msg=home_saved'); exit;
    }
    header('Location: '.$_SERVER['SCRIPT_NAME']); exit;
}
if (x_admin() && $route==='tab_delete' && isset($_GET['key']) && is_string($_GET['key'])) {
    $dk = $_GET['key'];
    if (isset($GLOBALS['x_all_tabs'][$dk])) {
        $others = false; foreach ($GLOBALS['x_all_tabs'] as $ek=>$ee) if ($ek!==$dk && $ee['enabled']) $others = true;
        if (!$others) { header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=settings_none'); exit; }
        $hid = x_hist_begin(); $hs = array(x_hist_tab_snap($data,$dk));
        x_tab_purge($data,$dk); x_hist_tabs_end($data,$hs,$hid);
        x_save($data);
        header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=tab_deleted'); exit;
    }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings'); exit;
}
if (x_admin() && $route==='tab_delete_bulk' && $_SERVER['REQUEST_METHOD']==='POST') {
    $keys = array();
    if (isset($_POST['all'])) { foreach ($GLOBALS['x_all_tabs'] as $ek=>$ee) if (empty($ee['base'])) $keys[] = $ek; }
    elseif (isset($_POST['sel']) && is_array($_POST['sel'])) { foreach ($_POST['sel'] as $sk) if (is_string($sk) && isset($GLOBALS['x_all_tabs'][$sk]) && !in_array($sk,$keys,true)) $keys[] = $sk; }
    if ($keys) {
        $others = false; foreach ($GLOBALS['x_all_tabs'] as $ek=>$ee) if (!in_array($ek,$keys,true) && $ee['enabled']) $others = true;
        if (!$others) { header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=settings_none'); exit; }
        $hid = x_hist_begin(); $hs = array(); foreach ($keys as $dk) $hs[] = x_hist_tab_snap($data,$dk);
        foreach ($keys as $dk) x_tab_purge($data,$dk);
        x_hist_tabs_end($data,$hs,$hid);
        x_save($data);
        header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings&msg=tab_deleted'); exit;
    }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=settings'); exit;
}
if (x_admin() && $route==='act_delete' && $_SERVER['REQUEST_METHOD']==='POST') {
    $back = $_SERVER['SCRIPT_NAME'].'?tab=analytics&msg=';
    if (!x_super()) { header('Location: '.$back.'act_denied'); exit; }
    $acts = (isset($data['activity']) && is_array($data['activity'])) ? $data['activity'] : array();
    $before = count($acts);
    if (isset($_POST['all'])) { $acts = array(); }
    else {
        $dids = array();
        if (isset($_POST['one']) && is_string($_POST['one'])) $dids[] = $_POST['one'];
        elseif (isset($_POST['ids']) && is_array($_POST['ids'])) foreach ($_POST['ids'] as $iv) if (is_string($iv)) $dids[] = $iv;
        $acts = array_values(array_filter($acts, function($ax) use ($dids) { return !(is_array($ax) && isset($ax['id']) && in_array($ax['id'], $dids, true)); }));
    }
    $removed = $before - count($acts);
    $data['activity'] = $acts;
    x_save($data);
    $GLOBALS['x_act_detail'] = array(array('İşlem Geçmişi', isset($_POST['all']) ? 'Tüm işlem kayıtlarını sildi ('.$removed.' kayıt)' : 'İşlem kaydı sildi ('.$removed.' kayıt)'));
    if (isset($_POST['all'])) $GLOBALS['x_act_skip'] = true;
    header('Location: '.$back.'act_deleted'); exit;
}
if (x_admin() && $route==='auth_delete' && $_SERVER['REQUEST_METHOD']==='POST') {
    $back = $_SERVER['SCRIPT_NAME'].'?tab=analytics&msg=';
    if (!x_super()) { header('Location: '.$back.'act_denied'); exit; }
    $an = (isset($data['analytics']) && is_array($data['analytics'])) ? $data['analytics'] : array(); $before = count($an);
    if (isset($_POST['all'])) { $an = array_filter($an, function($ax) { return !(is_array($ax) && isset($ax['type']) && $ax['type']==='auth'); }); }
    else {
        $dids = array(); if (isset($_POST['ids']) && is_array($_POST['ids'])) foreach ($_POST['ids'] as $iv) if (is_string($iv)) $dids[] = $iv;
        $an = array_filter($an, function($ax) use ($dids) { return !(is_array($ax) && isset($ax['type']) && $ax['type']==='auth' && in_array(x_ev_id($ax), $dids, true)); });
    }
    $data['analytics'] = array_values($an); x_save($data);
    $GLOBALS['x_act_detail'] = array(array('İstatistik', 'Son giriş / IP kayıtlarını sildi ('.($before - count($data['analytics'])).' kayıt)'));
    header('Location: '.$back.'auth_deleted'); exit;
}
if (x_admin() && $route==='analytics_reset' && $_SERVER['REQUEST_METHOD']==='POST') {
    $data['analytics'] = array_values(array_filter((array)$data['analytics'], function($ax) { return is_array($ax) && isset($ax['type']) && $ax['type']==='auth'; }));
    if (x_super() && isset($_POST['clear_acts'])) { $data['activity'] = array(); $GLOBALS['x_act_skip'] = true; }
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=analytics&msg=analytics_reset'); exit;
}
if ($route==='analytics_event' && $_SERVER['REQUEST_METHOD']==='POST') {
    x_track($data, (isset($_POST['type']) ? $_POST['type'] : 'other'), (isset($_POST['id']) ? $_POST['id'] : ''), (isset($_POST['event']) ? $_POST['event'] : 'view'), (isset($_POST['label']) ? $_POST['label'] : ''));
    x_save($data); header('Content-Type: application/json'); echo json_encode(['ok'=>true]); exit;
}
if (x_admin() && $route==='reorder' && $_SERVER['REQUEST_METHOD']==='POST') {
    $type=(isset($_POST['type']) ? $_POST['type'] : '');
    $ids=array_values(array_filter((array)((isset($_POST['ids']) ? $_POST['ids'] : [])),'is_string'));
    header('Content-Type: application/json');
    if (!in_array($type,['dosya','github','notes'],true) || !$ids) { echo json_encode(['ok'=>false]); exit; }
    $map=array_flip($ids);
    foreach ($data[$type] as &$it) { if (isset($map[(isset($it['id']) ? $it['id'] : '')])) $it['sort_order']=$map[$it['id']]; }
    unset($it);
    x_save($data);
    echo json_encode(['ok'=>true]); exit;
}
$cats = &$data['categories'];
$role = $_SESSION['role'];


if (x_admin() && $route==='cat_add' && $_SERVER['REQUEST_METHOD']==='POST') {
    $cn=trim((isset($_POST['cat_name']) ? $_POST['cat_name'] : '')); $cp=trim((isset($_POST['cat_parent']) ? $_POST['cat_parent'] : ''))?:null;
    if ($cn) { $cats[]=['id'=>'cat_'.uniqid(),'name'=>$cn,'parent'=>$cp,'order'=>count($cats)+1]; x_save($data); }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=cat_added&tab='.$tab); exit;
}

if (x_admin() && $route==='cat_edit' && $_SERVER['REQUEST_METHOD']==='POST') {
    $cid=trim((isset($_POST['cat_id']) ? $_POST['cat_id'] : '')); $cn=trim((isset($_POST['cat_name']) ? $_POST['cat_name'] : ''));
    if ($cid && $cn) {
        foreach ($cats as &$category) if (((isset($category['id']) ? $category['id'] : ''))===$cid) { $category['name']=$cn; break; }
        unset($category);
        x_save($data);
    }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=cat_edited&tab='.$tab); exit;
}

if (x_admin() && $route==='cat_delete' && isset($_GET['id'])) {
    $cid=$_GET['id']; $hc = array(); foreach ($cats as $c0) if ($c0['id']===$cid || $c0['parent']===$cid) $hc[] = $c0; $hi = array(); foreach ($data['dosya'] as $s0) if (((isset($s0['category_id']) ? $s0['category_id'] : null))===$cid) $hi[] = array($s0['id'], $cid);
    if ($hc) x_hist_gen($data, 'cat', 'catdel', array_map(function($c) { return $c['name']; }, $hc), array('cats'=>$hc, 'items'=>$hi), bin2hex(random_bytes(6)), array(), count($hc).' kategori silindi'.($hi ? ', '.count($hi).' dosyanın kategorisi kaldırıldı' : ''));
    foreach ($data['dosya'] as &$s) { if (((isset($s['category_id']) ? $s['category_id'] : null))===$cid) $s['category_id']=null; }
    $cats=array_values(array_filter($cats, function($c) use ($cid) { return $c['id']!==$cid&&$c['parent']!==$cid; }));
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=cat_deleted&tab='.$tab); exit;
}

if (x_admin() && $route==='bulk_delete' && $_SERVER['REQUEST_METHOD']==='POST') {
    $type=(isset($_POST['type']) ? $_POST['type'] : '');
    $ids=array_values(array_map('strval', array_filter((array)((isset($_POST['ids']) ? $_POST['ids'] : [])), 'is_scalar')));
    if ($ids && in_array($type,['dosya','github','notes'],true)) {
        $hid=x_hist_begin();
        if ($type==='dosya') {
            foreach ($data['dosya'] as $s) if (in_array((string)(isset($s['id']) ? $s['id'] : ''), $ids, true)) {
                $bf=FILES_DIR.'/'.$s['stored_name']; if (is_file($bf)) x_rm($bf); x_pack_unlink($s); x_delete_all_images($s,'screenshot'); x_delete_all_videos($s); x_delete_note_files($s);
            }
        } elseif ($type==='github') {
            foreach ($data['github'] as $g) if (in_array((string)(isset($g['id']) ? $g['id'] : ''), $ids, true)) { x_delete_all_images($g,'image'); x_delete_all_videos($g); x_delete_note_files($g); }
        } else {
            foreach ($data['notes'] as $n) if (in_array((string)(isset($n['id']) ? $n['id'] : ''), $ids, true)) { x_delete_all_images($n,'image'); x_delete_all_videos($n); x_delete_note_files($n); }
        }
        $removed=array(); foreach ($data[$type] as $rit) if (in_array((string)(isset($rit['id']) ? $rit['id'] : ''), $ids, true)) $removed[]=$rit;
        $data[$type]=array_values(array_filter($data[$type], function($item) use ($ids) { return !in_array((string)(isset($item['id']) ? $item['id'] : ''), $ids, true); }));
        x_purge_extras($data,$removed); x_hist_end($data,$type,$removed,$hid);
        x_save($data);
    }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=bulk_deleted&tab='.($type==='dosya'?'dosya':($type==='github'?'github':'notes'))); exit;
}

if (x_admin() && $route==='delete' && isset($_GET['id'])) {
    foreach ($data['dosya'] as $i=>$s) {
        if ($s['id']===$_GET['id']) {
            $sf=FILES_DIR.'/'.$s['stored_name']; $ss=$s['screenshot']?SCREENSHOTS_DIR.'/'.$s['screenshot']:null;
            $th=$s['screenshot']?THUMBS_DIR.'/'.$s['screenshot']:null;
            $hid=x_hist_begin(); if (is_file($sf)) x_rm($sf); x_pack_unlink($s); x_delete_all_images($s,'screenshot'); x_delete_all_videos($s); x_delete_note_files($s);
            array_splice($data['dosya'],$i,1); x_purge_extras($data,array($s)); x_hist_end($data,'dosya',array($s),$hid); x_save($data); break;
        }
    }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=deleted&tab='.$tab); exit;
}

if (x_admin() && !x_is_editor() && $route==='github_archive' && isset($_GET['id']) && is_string($_GET['id'])) {
    $ag = null; foreach ($data['github'] as $gx) if (isset($gx['id']) && $gx['id']===$_GET['id']) { $ag = $gx; break; }
    $res = $ag ? x_gh_archive($data, $ag) : array('fail', null, 0);
    if ($res[0]==='ok') x_save($data);
    $m = $res[0]==='ok' ? ($res[2] ? 'arch_part' : 'arch_ok') : ($res[0]==='dup' ? 'arch_dup' : 'arch_fail');
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=github&msg='.$m); exit;
}
if (x_admin() && $route==='pin' && isset($_GET['id'])) {
    foreach ($data['dosya'] as &$s) { if ($s['id']===$_GET['id']) { $s['pinned']=!((isset($s['pinned']) ? $s['pinned'] : false)); $s['pinned_at']=$s['pinned']?date('Y-m-d H:i:s'):null; break; } }
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab='.$tab); exit;
}

if (x_admin() && $_SERVER['REQUEST_METHOD']==='POST' && in_array($route,array('upload','create','edit','github_add','github_edit','note_add','note_edit'),true) && empty($_POST) && empty($_FILES) && !empty($_SERVER['CONTENT_LENGTH'])) {
    $bt = in_array($route,array('upload','create','edit'),true) ? 'dosya' : (strpos($route,'github')===0 ? 'github' : 'notes');
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab='.$bt.'&msg=post_big&lim='.urlencode((string)ini_get('post_max_size'))); exit;
}
if (x_admin() && $route==='upload' && $_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim((isset($_POST['name']) ? $_POST['name'] : ''))?:'İsimsiz Dosya'; $desc=x_rich(trim((isset($_POST['description']) ? $_POST['description'] : '')));
    $hasPass=isset($_POST['has_password']); $catId=(isset($_POST['category_id']) ? $_POST['category_id'] : null); $phpVer=x_php_post();
    $sid=('sh_'.bin2hex(random_bytes(12))); $stored=null; $orig=null; $ssStored=null; $dlName=null;
    if (isset($_FILES['dosya_arsiv'])&&$_FILES['dosya_arsiv']['error']===UPLOAD_ERR_OK) {
        $orig=basename($_FILES['dosya_arsiv']['name']);
        $ext=pathinfo($orig,PATHINFO_EXTENSION);
        $dlName=$sid.'.'.x_dl_pick($orig);
        $stored=$sid.'.'.x_st_pick($ext?:'txt');
        if (!x_move_upload($_FILES['dosya_arsiv']['tmp_name'],FILES_DIR.'/'.$stored)) $stored=null;
    }
    $pk=x_pack_new_dosya($sid);
    if (!$stored && $pk) { $f0=array_shift($pk); $stored=$f0['stored_name']; $orig=$f0['original_name']; $dlName=$f0['download_name']; $phpVer=($f0['php']!=='' ? $f0['php'] : null); $hasPass=!empty($f0['enc']); }
    $newImgs=x_save_images('screenshot','screenshot_url',SCREENSHOTS_DIR,$sid);
    $ssStored=$newImgs?array_shift($newImgs):null; $gallery=$newImgs;
    foreach (array_merge($ssStored?array($ssStored):array(),$gallery) as $_f) x_thumb(SCREENSHOTS_DIR.'/'.$_f, THUMBS_DIR.'/'.$_f, 80);
    if ($stored) {
        $data['dosya'][]=['id'=>$sid,'by'=>x_owner_uid(),'zip_on'=>x_zip_post(),'name'=>$name,'description'=>$desc,'has_password'=>$hasPass,'show_code'=>isset($_POST['show_code']),'category_id'=>$catId,'php_version'=>$phpVer,'pack'=>$pk,'original_name'=>$orig,'stored_name'=>$stored,'download_name'=>$dlName,'screenshot'=>$ssStored,'gallery'=>$gallery,'videos'=>x_save_videos($sid),'files'=>x_new_files(),'date_added'=>date('Y-m-d H:i:s'),'pinned'=>false]; x_stamp_ws($data['dosya'],'dosya');
        x_save($data);
    } else { header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=upload_fail&tab=dosya&lim='.urlencode((string)ini_get('upload_max_filesize'))); exit; }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=uploaded&tab=dosya'.x_img_redirect_flag().x_vid_redirect_flag()); exit;
}

if (x_admin() && $route==='create' && $_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim((isset($_POST['name']) ? $_POST['name'] : ''))?:'Yeni Dosya'; $desc=x_rich(trim((isset($_POST['description']) ? $_POST['description'] : '')));
    $hasPass=isset($_POST['has_password']); $catId=(isset($_POST['category_id']) ? $_POST['category_id'] : null); $phpVer=x_php_post();
    $fname=trim((isset($_POST['filename']) ? $_POST['filename'] : ''))?:'dosya.php'; $content=(isset($_POST['content']) ? $_POST['content'] : '');
    $sid=('sh_'.bin2hex(random_bytes(12))); $ext=pathinfo($fname,PATHINFO_EXTENSION);
    $dlName=$sid.'.'.x_dl_pick($fname);
    $stored=$sid.'.'.x_st_pick($ext?:'txt');
    file_put_contents(FILES_DIR.'/'.$stored,$content);
    $ssStored=null;
    $newImgs=x_save_images('screenshot','screenshot_url',SCREENSHOTS_DIR,$sid);
    $ssStored=$newImgs?array_shift($newImgs):null; $gallery=$newImgs;
    foreach (array_merge($ssStored?array($ssStored):array(),$gallery) as $_f) x_thumb(SCREENSHOTS_DIR.'/'.$_f, THUMBS_DIR.'/'.$_f, 80);
    $data['dosya'][]=['id'=>$sid,'by'=>x_owner_uid(),'zip_on'=>x_zip_post(),'name'=>$name,'description'=>$desc,'has_password'=>$hasPass,'show_code'=>isset($_POST['show_code']),'category_id'=>$catId,'php_version'=>$phpVer,'original_name'=>$fname,'stored_name'=>$stored,'download_name'=>$dlName,'screenshot'=>$ssStored,'gallery'=>$gallery,'videos'=>x_save_videos($sid),'files'=>x_new_files(),'date_added'=>date('Y-m-d H:i:s'),'pinned'=>false]; x_stamp_ws($data['dosya'],'dosya');
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=created&tab=dosya'.x_img_redirect_flag().x_vid_redirect_flag()); exit;
}

if (x_admin() && $route==='edit' && isset($_GET['id'])) {
    $dosya=null;
    foreach ($data['dosya'] as $i=>$s) { if ($s['id']===$_GET['id']) { $dosya=&$data['dosya'][$i]; break; } }
    if (!$dosya) { header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        $dosya['name']=trim((isset($_POST['name']) ? $_POST['name'] : ''))?:$dosya['name'];
        $dosya['description']=x_rich(trim((isset($_POST['description']) ? $_POST['description'] : '')));
$dosya['has_password']=isset($_POST['has_password']);
        $dosya['show_code']=isset($_POST['show_code']);
        $dosya['category_id']=(isset($_POST['category_id']) ? $_POST['category_id'] : $dosya['category_id']);
        $dosya['php_version']=x_php_post(); x_pack_apply_dosya($dosya,$dosya['id']);
        if (isset($_FILES['dosya_arsiv'])&&$_FILES['dosya_arsiv']['error']===UPLOAD_ERR_OK) {
            $newOriginal=basename($_FILES['dosya_arsiv']['name']);
            $newExt=pathinfo($newOriginal,PATHINFO_EXTENSION);
            $newBase=$dosya['id'].'_'.time();
            $newStored=$newBase.'.'.x_st_pick($newExt?:'txt');
            $newDl=$newBase.'.'.x_dl_pick($newOriginal);
            if (x_mv_up($_FILES['dosya_arsiv']['tmp_name'],FILES_DIR.'/'.$newStored)) {
                $oldFile=FILES_DIR.'/'.$dosya['stored_name']; if (file_exists($oldFile)) unlink($oldFile);
                $dosya['stored_name']=$newStored; $dosya['original_name']=$newOriginal; $dosya['download_name']=$newDl;
            }
        } elseif (isset($_POST['content'])) file_put_contents(FILES_DIR.'/'.$dosya['stored_name'],$_POST['content']);
        if (empty($newStored) && x_st_post()!=='' && !empty($dosya['stored_name'])) { $ob=basename($dosya['stored_name']); $nb=preg_replace('/\.[^.]*$/','',$ob).'.'.x_st_post(); if ($nb!==$ob && is_file(FILES_DIR.'/'.$ob) && !file_exists(FILES_DIR.'/'.$nb) && @rename(FILES_DIR.'/'.$ob,FILES_DIR.'/'.$nb)) $dosya['stored_name']=$nb; }
        if (!isset($newDl) && isset($_POST['dl_ext']) && empty($newStored)) { $obn=preg_replace('/\.[^.]*$/','',basename(!empty($dosya['download_name'])?$dosya['download_name']:$dosya['stored_name'])); $dosya['download_name']=$obn.'.'.x_dl_pick(isset($dosya['original_name'])?$dosya['original_name']:''); }
        x_add_images($dosya,'screenshot',x_save_images('screenshot','screenshot_url',SCREENSHOTS_DIR,$dosya['id'].'_'.uniqid()),true);
        x_apply_media_edit($dosya);
        x_save($data);
        header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=edited&tab=dosya'.x_img_redirect_flag().x_vid_redirect_flag()); exit;
    }
    x_edit_page($dosya,$cats); exit;
}

if (x_admin() && $route==='github_add' && $_SERVER['REQUEST_METHOD']==='POST') {
    $url=x_gh_norm(trim((isset($_POST['url']) ? $_POST['url'] : '')));
    $pkg=x_pack_new_gh(); $promo=null; if ($url==='' && $pkg) { $promo=array_shift($pkg); $url=$promo['url']; }
    $host = parse_url($url, PHP_URL_HOST);
    $isGithubRaw = $host && preg_match('#^https?://#i', $url);
    if (filter_var($url,FILTER_VALIDATE_URL) && $isGithubRaw) {
        $gid=('gh_'.bin2hex(random_bytes(8)));
        $newImgs=x_save_images('image','image_url',SCREENSHOTS_DIR,$gid);
        $image=$newImgs?array_shift($newImgs):null; $gallery=$newImgs;
        $data['github'][]=array('id'=>$gid,'by'=>x_owner_uid(),'zip_on'=>x_zip_post(),'name'=>trim((isset($_POST['name']) ? $_POST['name'] : ''))?:'İsimsiz GitHub','description'=>x_rich(trim((isset($_POST['description']) ? $_POST['description'] : ''))),'url'=>$url,'image'=>$image,'gallery'=>$gallery,'videos'=>x_save_videos($gid),'files'=>x_new_files(),'category_id'=>trim((isset($_POST['category_id']) ? $_POST['category_id'] : ''))?:null,'php_version'=>($promo ? ($promo['php']!=='' ? $promo['php'] : null) : x_php_post()),'pack'=>$pkg,'pack_only'=>($promo ? true : false),'encrypted'=>($promo ? !empty($promo['enc']) : ((isset($_POST['encrypted']) ? $_POST['encrypted'] : ''))==='1'),'show_code'=>isset($_POST['show_code']),'date_added'=>date('Y-m-d H:i:s'),'pinned'=>false); x_gh_post($data['github'][count($data['github'])-1]); x_stamp_ws($data['github'],'github');
        x_save($data);
    }
    $status = isset($gid) ? 'github_added' : 'github_invalid';
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg='.$status.'&tab=github'.x_img_redirect_flag().x_vid_redirect_flag()); exit;
}
if (x_admin() && $route==='github_delete' && isset($_GET['id'])) {
    foreach ($data['github'] as $i=>$g) if ($g['id']===$_GET['id']) { $hid=x_hist_begin(); x_delete_all_images($g,'image'); x_delete_all_videos($g); x_delete_note_files($g); array_splice($data['github'],$i,1); x_purge_extras($data,array($g)); x_hist_end($data,'github',array($g),$hid); x_save($data); break; }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=github_deleted&tab=github'); exit;
}
if (x_admin() && $route==='github_pin' && isset($_GET['id'])) {
    foreach ($data['github'] as &$g) if ($g['id']===$_GET['id']) { $g['pinned']=!((isset($g['pinned']) ? $g['pinned'] : false)); $g['pinned_at']=$g['pinned']?date('Y-m-d H:i:s'):null; break; }
    x_save($data); header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=github'); exit;
}
if (x_admin() && $route==='github_edit' && isset($_GET['id'])) {
    foreach ($data['github'] as &$g) if ($g['id']===$_GET['id']) {
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            $g['name']=trim((isset($_POST['name']) ? $_POST['name'] : ''))?:$g['name'];
$g['description']=x_rich(trim((isset($_POST['description']) ? $_POST['description'] : '')));
  $g['category_id']=trim((isset($_POST['category_id']) ? $_POST['category_id'] : ''))?:null;
  $g['php_version']=x_php_post(); x_pack_apply_gh($g);
$g['encrypted']=((isset($_POST['encrypted']) ? $_POST['encrypted'] : ''))==='1';
  $g['show_code']=isset($_POST['show_code']); x_gh_post($g);
  $newUrl=x_gh_norm(isset($_POST['url']) ? $_POST['url'] : $g['url']);
            $newHost=parse_url($newUrl, PHP_URL_HOST);
            if (filter_var($newUrl,FILTER_VALIDATE_URL) && $newHost && preg_match('#^https?://#i',$newUrl)) $g['url']=$newUrl;
            x_add_images($g,'image',x_save_images('image','image_url',SCREENSHOTS_DIR,$g['id'].'_'.uniqid()),false);
            x_apply_media_edit($g);
            x_save($data); header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=github_edited&tab=github'.x_img_redirect_flag().x_vid_redirect_flag()); exit;
        }
        $github_edit=$g; break;
    }
    if (isset($github_edit)) { x_github_edit_page($github_edit,$cats); exit; }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=github'); exit;
}

if (x_admin() && in_array($route,array('img_bulk_remove','img_main'),true) && isset($_GET['id'],$_GET['type']) && is_string($_GET['id']) && is_string($_GET['type'])) {
    $cfg=array('dosya'=>array('dosya','screenshot'),'github'=>array('github','image'),'note'=>array('notes','image'));
    $t=$_GET['type'];
    if (isset($cfg[$t])) {
        foreach ($data[$cfg[$t][0]] as &$it) if ($it['id']===$_GET['id']) {
            if ($route==='img_main') { $it['main_video']=null; x_set_main_image($it,$cfg[$t][1],(int)(isset($_GET['n'])?$_GET['n']:0)); }
            else x_remove_images($it,$cfg[$t][1],array_map('intval',(array)(isset($_POST['ns'])?$_POST['ns']:array())));
            break;
        }
        unset($it);
        x_save($data);
        if ($t==='dosya') $back='?action=edit&id='.rawurlencode($_GET['id']);
        elseif ($t==='github') $back='?action=github_edit&id='.rawurlencode($_GET['id']).'&tab=github';
        else $back='?tab=notes';
        header('Location: '.$_SERVER['SCRIPT_NAME'].$back); exit;
    }
}
if (x_admin() && $route==='img_remove' && isset($_GET['id'],$_GET['type'],$_GET['n']) && is_string($_GET['id']) && is_string($_GET['type'])) {
    $cfg=array('dosya'=>array('dosya','screenshot'),'github'=>array('github','image'),'note'=>array('notes','image'));
    $t=$_GET['type'];
    if (isset($cfg[$t])) {
        foreach ($data[$cfg[$t][0]] as &$it) if ($it['id']===$_GET['id']) { x_remove_image_at($it,$cfg[$t][1],(int)$_GET['n']); break; }
        unset($it);
        x_save($data);
        if ($t==='dosya') $back='?action=edit&id='.rawurlencode($_GET['id']);
        elseif ($t==='github') $back='?action=github_edit&id='.rawurlencode($_GET['id']).'&tab=github';
        else $back='?tab=notes';
        header('Location: '.$_SERVER['SCRIPT_NAME'].$back); exit;
    }
}
if (x_admin() && $route==='note_remove_image' && isset($_GET['id'])) {
    foreach ($data['notes'] as &$n) if ($n['id']===$_GET['id']) {
        x_remove_image_at($n,'image',0);
        break;
    }
    x_save($data); header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=notes'); exit;
}
if (x_admin() && $route==='remove_screenshot' && isset($_GET['id'])) {
    foreach ($data['dosya'] as &$s) if ($s['id']===$_GET['id']) {
        x_remove_image_at($s,'screenshot',0);
        break;
    }
    x_save($data); header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=dosya'); exit;
}
if (x_admin() && $route==='github_remove_image' && isset($_GET['id'])) {
    foreach ($data['github'] as &$g) if ($g['id']===$_GET['id']) {
        x_remove_image_at($g,'image',0);
        break;
    }
    x_save($data); header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=github'); exit;
}



if (x_admin() && $route==='note_add' && $_SERVER['REQUEST_METHOD']==='POST') {
    $title=trim((isset($_POST['title']) ? $_POST['title'] : ''));
    $content=x_rich(trim((isset($_POST['content']) ? $_POST['content'] : '')));
    if ($title==='') { $tt=trim(preg_replace('/\s+/u',' ',html_entity_decode(strip_tags($content),ENT_QUOTES,'UTF-8'))); $title=$tt!=='' ? mb_substr($tt,0,40) : ''; }
    $nid=('note_'.bin2hex(random_bytes(8)));
    $newImgs=x_save_images('image','image_url',SCREENSHOTS_DIR,$nid);
    $noteImage=$newImgs?array_shift($newImgs):null; $noteGallery=$newImgs;
    $nVid=x_save_videos($nid); $nFiles=x_new_files();
    if ($title==='' && trim(strip_tags($content,'<img><video><iframe>'))==='' && !$noteImage && !$noteGallery && !$nVid && !$nFiles) { header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=notes&msg=note_empty'); exit; }
    if ($title==='') $title='Not';
    $data['notes'][]=['id'=>$nid,'by'=>x_owner_uid(),'title'=>$title,'content'=>$content,'image'=>$noteImage,'gallery'=>$noteGallery,'videos'=>$nVid,'files'=>$nFiles,'date_added'=>date('Y-m-d H:i:s'),'pinned'=>false]; x_stamp_ws($data['notes'],'notes');
    x_save($data);
    if (!x_saved_has('notes',$nid)) { header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=notes&msg=save_failed'); exit; }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=note_added&tab=notes'.x_img_redirect_flag().x_vid_redirect_flag()); exit;
}

if (x_admin() && $route==='note_edit' && isset($_GET['id'])) {
    foreach ($data['notes'] as &$n) {
        if ($n['id']===$_GET['id']) {
            $n['title']=trim((isset($_POST['title']) ? $_POST['title'] : ''))?:$n['title'];
            $n['content']=x_rich(trim((isset($_POST['content']) ? $_POST['content'] : '')));
            x_add_images($n,'image',x_save_images('image','image_url',SCREENSHOTS_DIR,$n['id'].'_'.uniqid()),false);
            $nv=x_item_videos($n); foreach (x_save_videos($n['id'].'_'.uniqid()) as $vv) $nv[]=$vv; $n['videos']=$nv;
            x_apply_files($n);
            break;
        }
    }
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=note_edited&tab=notes'.x_img_redirect_flag().x_vid_redirect_flag()); exit;
}

if (x_admin() && $route==='note_pin' && isset($_GET['id'])) {
    foreach ($data['notes'] as &$n) { if ($n['id']===$_GET['id']) { $n['pinned']=!((isset($n['pinned']) ? $n['pinned'] : false)); $n['pinned_at']=$n['pinned']?date('Y-m-d H:i:s'):null; break; } }
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=notes'); exit;
}

if (x_admin() && $route==='note_delete' && isset($_GET['id'])) {
    foreach ($data['notes'] as $i=>$n) { if ($n['id']===$_GET['id']) { $hid=x_hist_begin(); x_delete_all_images($n,'image'); x_delete_all_videos($n); x_delete_note_files($n); array_splice($data['notes'],$i,1); x_purge_extras($data,array($n)); x_hist_end($data,'notes',array($n),$hid); x_save($data); break; } }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?msg=note_deleted&tab=notes'); exit;
}

if (x_admin() && $route==='nfile_remove' && isset($_GET['id']) && is_string($_GET['id'])) {
    $vt=x_vtype(); $vc=x_vcoll($vt);
    foreach ($data[$vc] as &$it) if ($it['id']===$_GET['id']) {
        x_remove_note_files($it,array_map('intval',(array)(isset($_POST['fns'])?$_POST['fns']:array())));
        break;
    }
    unset($it);
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].x_vback($vt,$_GET['id'])); exit;
}
if (x_admin() && $route==='editor_upload' && $_SERVER['REQUEST_METHOD']==='POST') {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    $out = array('ok'=>false,'error'=>'Dosya alınamadı (boyut sınırını kontrol edin)');
    $f = isset($_FILES['file']) ? $_FILES['file'] : null;
    if ($f && !is_array($f['name']) && ($f['error']===UPLOAD_ERR_INI_SIZE || $f['error']===UPLOAD_ERR_FORM_SIZE)) $out['error'] = 'Dosya sunucu sınırını aşıyor (en fazla '.ini_get('upload_max_filesize').')';
    if ($f && !is_array($f['name']) && $f['error']===UPLOAD_ERR_OK && is_uploaded_file($f['tmp_name'])) {
        $ext = strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
        $vidExt = array('mp4','m4v','webm','ogv','ogg','mov');
        $info = @getimagesize($f['tmp_name']);
        $imgMap = array(IMAGETYPE_JPEG=>'jpg',IMAGETYPE_PNG=>'png',IMAGETYPE_GIF=>'gif',IMAGETYPE_WEBP=>'webp');
        if ($info && isset($imgMap[$info[2]]) && x_img_bad($f['tmp_name'])) {
            $out['error'] = 'Güvenlik nedeniyle bu resim kabul edilmedi';
        } elseif ($info && isset($imgMap[$info[2]])) {
            $nm = 'e_'.bin2hex(random_bytes(10)).'.'.$imgMap[$info[2]];
            if (move_uploaded_file($f['tmp_name'],EDITOR_DIR.'/'.$nm)) $out = array('ok'=>true,'type'=>'image','url'=>'?action=eimg&f='.$nm,'name'=>$f['name']);
        } elseif (in_array($ext,$vidExt,true)) {
            $nm = 'e_'.bin2hex(random_bytes(10)).'.'.$ext;
            if (move_uploaded_file($f['tmp_name'],EDITOR_DIR.'/'.$nm)) $out = array('ok'=>true,'type'=>'video','url'=>'?action=evid&f='.$nm,'name'=>$f['name']);
        } else {
            $out['error'] = 'Desteklenmeyen dosya (resim: jpg, png, gif, webp — video: mp4, webm, ogg, mov)';
        }
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE); exit;
}
if ($route==='eimg' && isset($_GET['f']) && is_string($_GET['f']) && preg_match('/^e_[a-f0-9]{20}\.(jpg|png|gif|webp)$/',$_GET['f'])) {
    header('X-Content-Type-Options: nosniff');
    if (!x_img_send(EDITOR_DIR.'/'.$_GET['f'])) { header('HTTP/1.0 404 Not Found'); }
    exit;
}
if ($route==='evid' && isset($_GET['f']) && is_string($_GET['f']) && preg_match('/^e_[a-f0-9]{20}\.(mp4|m4v|webm|ogv|ogg|mov)$/',$_GET['f'],$em)) {
    $ep = EDITOR_DIR.'/'.$_GET['f'];
    header('X-Content-Type-Options: nosniff');
    if (is_file($ep)) x_video_send($ep,$em[1]);
    header('HTTP/1.0 404 Not Found'); exit;
}
if ($route==='nfile' && isset($_GET['id'],$_GET['n']) && is_string($_GET['id'])) {
    $vt=x_vtype(); $vc=x_vcoll($vt);
    if (!x_admin_role() && !x_type_any_on($vc)) { header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
    foreach ($data[$vc] as $ni=>$it) if ($it['id']===$_GET['id']) {
        $fl = x_item_files($it); $fn = (int)$_GET['n'];
        if (isset($fl[$fn])) {
            $ff = $fl[$fn];
            $fp = BFILES_DIR.'/'.basename($ff['stored_name']);
            if (is_file($fp)) {
                $dl = isset($ff['dl_name']) ? basename((string)$ff['dl_name']) : '';
                if ($dl === '') {
                    $dl = x_dl_name($ff['name']);
                    foreach ($data[$vc][$ni]['files'] as $rk=>$rf) if (is_array($rf) && isset($rf['stored_name']) && $rf['stored_name']===$ff['stored_name']) { $data[$vc][$ni]['files'][$rk]['dl_name']=$dl; break; }
                }
                x_track($data,'nfile',$it['id'],'download',$ff['name']); x_save($data);
                while (ob_get_level()) ob_end_clean();
                $dl = preg_replace('/[^A-Za-z0-9._\-]/','_',$dl);
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="'.$dl.'"');
                header('Content-Length: '.filesize($fp));
                header('X-Content-Type-Options: nosniff');
                readfile($fp); exit;
            }
        }
        break;
    }
    header('HTTP/1.0 404'); exit;
}
if (!x_admin_role() && in_array($route,array('download','preview','archive_content'),true) && !x_type_any_on('dosya')) { header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }

if ($route==='pack_zip' && isset($_GET['id']) && is_string($_GET['id'])) {
    $zi=null; $zk=''; $zc0=x_sec_cfg(); if (!$zc0['zip']) { header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
    foreach ($data['dosya'] as $s) if (isset($s['id']) && $s['id']===$_GET['id']) { $zi=$s; $zk='dosya'; break; }
    if (!$zi) foreach ($data['github'] as $g) if (isset($g['id']) && $g['id']===$_GET['id']) { $zi=$g; $zk='github'; break; }
    if ($zi && isset($zi['zip_on']) && !$zi['zip_on']) { header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
    $bk = $_SERVER['SCRIPT_NAME'].($zk==='github' ? '?tab=github&msg=github_dl_fail' : '?tab=dosya');
    if (!$zi || !class_exists('ZipArchive')) { header('Location: '.$bk); exit; }
    if ($zk==='dosya' && !x_admin_role() && !x_type_any_on('dosya')) { header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
    if ($zk==='github' && !x_admin() && (!x_gh_flag($zi,'gh_dl',false) || !x_item_on('github',$zi))) { header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
    x_dl_gate($data);
    $tmp = tempnam(sys_get_temp_dir(), 'xz'); $za = new ZipArchive(); $used = array(); $cnt = 0; $tot = 0;
    if ($tmp===false || $za->open($tmp, ZipArchive::OVERWRITE)!==true) { header('Location: '.$bk); exit; }
    $zn = function($n, $php) use (&$used) { $n = preg_replace('/[^A-Za-z0-9._\-]/','_',basename((string)$n)); if ($n==='' || $n==='.') $n='dosya'; $b=$n; $k=1; if (isset($used[strtolower($n)])) $n = ($php!=='' ? 'php'.preg_replace('/[^A-Za-z0-9.]/','',$php).'_' : '').$b; while (isset($used[strtolower($n)])) $n = (++$k).'_'.$b; $used[strtolower($n)]=1; return $n; };
    $ents = array();
    if ($zk==='dosya') {
        $ents[] = array((string)(isset($zi['php_version']) ? $zi['php_version'] : ''), (string)(isset($zi['original_name']) ? $zi['original_name'] : ''), (string)(isset($zi['stored_name']) ? $zi['stored_name'] : ''), '');
        foreach (x_pack_list($zi) as $p) $ents[] = array((string)(isset($p['php']) ? $p['php'] : ''), (string)(isset($p['original_name']) ? $p['original_name'] : ''), (string)(isset($p['stored_name']) ? $p['stored_name'] : ''), '');
    } else {
        $ents[] = array((string)(isset($zi['php_version']) ? $zi['php_version'] : ''), '', '', (string)(isset($zi['url']) ? $zi['url'] : ''));
        foreach (x_pack_list($zi) as $p) $ents[] = array((string)(isset($p['php']) ? $p['php'] : ''), '', '', (string)(isset($p['url']) ? $p['url'] : ''));
    }
    foreach ($ents as $e) {
        if ($zk==='dosya') { $f = FILES_DIR.'/'.basename($e[2]); if ($e[2]!=='' && is_file($f)) { $za->addFile($f, $zn($e[1], $e[0])); $cnt++; } }
        else { $u = x_gh_norm($e[3]); if ($u==='' || !x_pack_gh_ok($u) || $tot > 31457280) continue; $body = x_gh_get($u, 25); if ($body===false) continue; $tot += strlen($body); $za->addFromString($zn(basename((string)parse_url($u, PHP_URL_PATH)), $e[0]), $body); $cnt++; }
    }
    $za->close();
    if ($cnt===0) { @unlink($tmp); header('Location: '.$bk); exit; }
    x_dl_inc($data, $zk, $zi['id']);
    x_track($data, $zk, $zi['id'], 'download', (isset($zi['name']) ? $zi['name'] : '')); x_save($data);
    $zf = trim(preg_replace('/[^A-Za-z0-9._\-]+/','_',(string)(isset($zi['name']) ? $zi['name'] : 'paket')), '_'); if ($zf==='') $zf='paket';
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: application/zip'); header('Content-Disposition: attachment; filename="'.$zf.'.zip"'); header('X-Content-Type-Options: nosniff'); header('Content-Length: '.filesize($tmp));
    readfile($tmp); @unlink($tmp); exit;
}
if ($route==='download' && isset($_GET['id'])) {
    foreach ($data['dosya'] as $s) {
        if ($s['id']===$_GET['id']) {
            $pv=$s; $pn=(isset($_GET['n']) && is_scalar($_GET['n'])) ? (int)$_GET['n'] : 0; if ($pn>0) { $pl=x_pack_list($s); if (!isset($pl[$pn-1])) break; $pv=$pl[$pn-1]; }
            $fp=FILES_DIR.'/'.basename((string)(isset($pv['stored_name']) ? $pv['stored_name'] : ''));
            if (is_file($fp)) {
                x_dl_gate($data); x_dl_inc($data, 'dosya', $s['id']);
                x_track($data, 'dosya', $s['id'], 'download', (isset($s['name']) ? $s['name'] : '')); x_save($data);
                header('Content-Type: application/octet-stream');
                $dlf=!empty($pv['download_name'])?$pv['download_name']:$pv['stored_name'];
                header('Content-Disposition: attachment; filename="'.preg_replace('/[^A-Za-z0-9._\-]/','_',basename($dlf)).'"');
                header('X-Content-Type-Options: nosniff');
                header('Content-Length: '.filesize($fp));
                readfile($fp); exit;
            }
        }
    }
    header('Location: '.$_SERVER['SCRIPT_NAME']); exit;
}

if ($route==='archive_content' && isset($_GET['id'])) {
    foreach ($data['dosya'] as $s) {
        if ($s['id']===$_GET['id']) {
            $pv=$s; $pn=(isset($_GET['n']) && is_scalar($_GET['n'])) ? (int)$_GET['n'] : 0; if ($pn>0) { $pl=x_pack_list($s); if (!isset($pl[$pn-1])) break; $pv=$pl[$pn-1]; }
            $fp=FILES_DIR.'/'.basename((string)$pv['stored_name']);
            x_track($data, 'dosya', $s['id'], 'read', (isset($s['name']) ? $s['name'] : '')); x_save($data);
            header('Content-Type: text/plain; charset=UTF-8');
            echo file_exists($fp)?file_get_contents($fp):'Dosya bulunamadı.';
            exit;
        }
    }
    header('HTTP/1.0 404'); exit;
}

if ($route==='preview' && isset($_GET['id'])) {
    foreach ($data['dosya'] as $s) { if ($s['id']===$_GET['id']) { $dosya=$s; break; } }
    if (isset($dosya)) {
        $fp=FILES_DIR.'/'.basename((string)$dosya['stored_name']);
        $content=file_exists($fp)?file_get_contents($fp):'Dosya bulunamadı.';
        x_preview_page($dosya,$content,$cats); exit;
    }
    header('Location: '.$_SERVER['SCRIPT_NAME']); exit;
}

if ($route==='github_download' && isset($_GET['id']) && is_string($_GET['id'])) {
    foreach ($data['github'] as $g) if (isset($g['id']) && $g['id']===$_GET['id']) {
        if (!x_admin() && (!x_gh_flag($g,'gh_dl',false) || !x_item_on('github',$g))) { header('Location: '.$_SERVER['SCRIPT_NAME']); exit; }
        $u = isset($g['url']) ? (string)$g['url'] : ''; $pn=(isset($_GET['n']) && is_scalar($_GET['n'])) ? (int)$_GET['n'] : 0; if ($pn>0) { $pl=x_pack_list($g); $u = isset($pl[$pn-1]['url']) ? (string)$pl[$pn-1]['url'] : ''; } $u = x_gh_norm($u); $h = parse_url($u, PHP_URL_HOST); $sc = strtolower((string)parse_url($u, PHP_URL_SCHEME));
        if (($sc==='https' || $sc==='http') && $h) {
            x_dl_gate($data);
            $body = x_gh_get($u, 25);
            if ($body !== false && strlen($body) <= 31457280) {
                $bn = preg_replace('/[^A-Za-z0-9._\-]/','_',basename((string)parse_url($u, PHP_URL_PATH))); if ($bn==='' || $bn==='.') $bn='dosya';
                $ne = (!empty($g['gh_dl_ext']) && in_array($g['gh_dl_ext'], x_ext_opts(), true)) ? $g['gh_dl_ext'] : '';
                if ($ne!=='') { $bb = preg_replace('/\.[^.]*$/','',$bn); $bn = ($bb!=='' ? $bb : 'dosya').'.'.$ne; }
                x_dl_inc($data, 'github', $g['id']);
                x_track($data, 'github', $g['id'], 'download', (isset($g['name']) ? $g['name'] : '')); x_save($data);
                while (ob_get_level()) ob_end_clean();
                header('Content-Type: application/octet-stream'); header('Content-Disposition: attachment; filename="'.$bn.'"'); header('X-Content-Type-Options: nosniff'); header('Content-Length: '.strlen($body));
                echo $body; exit;
            }
        }
        header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=github&msg=github_dl_fail'); exit;
    }
    header('Location: '.$_SERVER['SCRIPT_NAME'].'?tab=github'); exit;
}
if ($route==='github_image' && isset($_GET['id'])) {
    foreach ($data['github'] as $g) {
        if ($g['id']===$_GET['id'] && !empty($g['image'])) {
            $ip=SCREENSHOTS_DIR.'/'.$g['image'];
            if (file_exists($ip)) { x_img_send($ip); }
        }
    }
    header('HTTP/1.0 404'); exit;
}

  if ($route==='note_image' && isset($_GET['id'])) {
  foreach ($data['notes'] as $n) if ($n['id']===$_GET['id'] && !empty($n['image'])) { $ip=SCREENSHOTS_DIR.'/'.$n['image']; if (file_exists($ip)) { x_img_send($ip); } }
  header('HTTP/1.0 404'); exit;
  }

  if ($route==='screenshot' && isset($_GET['id'])) {
    foreach ($data['dosya'] as $s) {
        if ($s['id']===$_GET['id']&&$s['screenshot']) { $sp=SCREENSHOTS_DIR.'/'.$s['screenshot']; if (file_exists($sp)) { x_img_send($sp); } }
    }
    header('HTTP/1.0 404'); exit;
}
if ($route==='vid' && isset($_GET['id'],$_GET['n']) && is_string($_GET['id'])) {
    foreach ($data[x_vcoll(x_vtype())] as $it) if ($it['id']===$_GET['id']) {
        $vl=x_item_videos($it); $vn=(int)$_GET['n'];
        if (isset($vl[$vn]) && $vl[$vn]['t']==='f') {
            $vp=VIDEOS_DIR.'/'.basename($vl[$vn]['v']);
            if (is_file($vp)) x_video_send($vp,strtolower(pathinfo($vp,PATHINFO_EXTENSION)));
        }
        break;
    }
    header('HTTP/1.0 404'); exit;
}
if (x_admin() && $route==='vid_main' && isset($_GET['id'],$_GET['n']) && is_string($_GET['id'])) {
    $vt=x_vtype(); $vc=x_vcoll($vt);
    foreach ($data[$vc] as &$it) if ($it['id']===$_GET['id']) {
        $vn=(int)$_GET['n'];
        if (isset(x_item_videos($it)[$vn])) $it['main_video']=$vn;
        break;
    }
    unset($it);
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].x_vback($vt,$_GET['id'])); exit;
}
if (x_admin() && $route==='vid_remove' && isset($_GET['id']) && is_string($_GET['id'])) {
    $vt=x_vtype(); $vc=x_vcoll($vt);
    foreach ($data[$vc] as &$it) if ($it['id']===$_GET['id']) {
        x_remove_videos($it,array_map('intval',(array)(isset($_POST['vns'])?$_POST['vns']:array())));
        break;
    }
    unset($it);
    x_save($data);
    header('Location: '.$_SERVER['SCRIPT_NAME'].x_vback($vt,$_GET['id'])); exit;
}
if ($route==='gimg' && isset($_GET['id'],$_GET['type']) && is_string($_GET['id']) && is_string($_GET['type'])) {
    $cfg=array('dosya'=>array('dosya','screenshot'),'github'=>array('github','image'),'note'=>array('notes','image'));
    $t=$_GET['type'];
    if (isset($cfg[$t])) {
        foreach ($data[$cfg[$t][0]] as $it) if ($it['id']===$_GET['id']) {
            $l=x_item_images($it,$cfg[$t][1]); $n=(int)((isset($_GET['n']) ? $_GET['n'] : 0));
            if (isset($l[$n])) {
                $sp=SCREENSHOTS_DIR.'/'.basename($l[$n]);
                if (!empty($_GET['t'])) {
                    $tp=THUMBS_DIR.'/'.basename($l[$n]);
                    if (is_file($tp)) x_img_send($tp);
                    if (is_file($sp) && x_thumb($sp,$tp,80)) x_img_send($tp);
                }
                if (is_file($sp)) x_img_send($sp);
            }
        }
    }
    header('HTTP/1.0 404'); exit;
}
if ($route==='thumb' && isset($_GET['id'])) {
    foreach ($data['dosya'] as $s) {
        if ($s['id']===$_GET['id']&&$s['screenshot']) {
            $tp=THUMBS_DIR.'/'.$s['screenshot'];
            if (file_exists($tp)) { x_img_send($tp); }
            $sp=SCREENSHOTS_DIR.'/'.$s['screenshot'];
            if (file_exists($sp)&&x_thumb($sp,$tp,80)) { x_img_send($tp); }
            x_img_send($sp); exit;
        }
    }
    header('HTTP/1.0 404'); exit;
}

$filterCat = ($tab==='dosya' || $tab==='github') ? '__all__' : ((isset($_GET['cat']) ? $_GET['cat'] : '__all__'));
$msg = (isset($_GET['msg']) ? $_GET['msg'] : '');

$dataEn = $data; foreach (x_types() as $xc) { $dataEn[$xc] = array(); foreach ($data[$xc] as $xit) if (x_item_on($xc,$xit)) $dataEn[$xc][] = $xit; }
$xcur = array(); foreach (x_types() as $xc) $xcur[$xc] = x_ws_cur($xc)!=='' ? x_ws_cur($xc) : $xc; $xcur['home'] = x_ws_cur('home');
$dosya = x_view_items($dataEn['dosya'],'dosya',$tab,$xcur);
usort($dosya, 'x_sort_cmp');
if ($filterCat!=='__all__') $dosya=array_values(array_filter($dosya,function($s) use ($filterCat) { return x_cat_matches($s,$filterCat); }));

$notes = x_view_items($dataEn['notes'],'notes',$tab,$xcur);
usort($notes, 'x_sort_cmp');

$github = x_view_items($dataEn['github'],'github',$tab,$xcur);
usort($github, 'x_sort_cmp');
if ($filterCat!=='__all__') $github=array_values(array_filter($github,function($g) use ($filterCat) { return x_cat_matches($g,$filterCat); }));
$canSort = x_perm('reorder') && in_array($tab,['dosya','github','notes'],true);

  $catTree = x_cat_tree($cats);
  $activeCat = $filterCat;
$categoryHasdosya = $activeCat !== '__all__' && count(array_filter($dataEn['dosya'], function($s) use ($activeCat) { return x_cat_matches($s,$activeCat); })) > 0;
  $categoryHasGithub = $activeCat !== '__all__' && count(array_filter($dataEn['github'], function($g) use ($activeCat) { return x_cat_matches($g,$activeCat); })) > 0;
  $archiveTopActive = $tab === 'dosya' || $tab === 'all' && ($activeCat === '__all__' ? count($dataEn['dosya']) > 0 : $categoryHasdosya);
  $githubTopActive = $tab === 'github' || $tab === 'all' && ($activeCat === '__all__' ? count($dataEn['github']) > 0 : $categoryHasGithub);
  
  $toast='';
if (in_array($msg,['uploaded','created'])) $toast='Dosya eklendi';
elseif ($msg==='sess_killed') $toast='Diğer oturumlarınız kapatıldı'; elseif ($msg==='sess_all') $toast='Tüm oturumlar kapatıldı'; elseif ($msg==='sec_saved') $toast='Güvenlik ayarları kaydedildi'; elseif ($msg==='hist_ok') $toast='Kayıt geri yüklendi'; elseif ($msg==='hist_skip') $toast='Geri yüklenecek bir şey bulunamadı (kayıt zaten mevcut olabilir)'; elseif ($msg==='hist_clr') $toast='Geçmiş temizlendi'; elseif ($msg==='acc_blocked') $toast='Seçilen kullanıcılar engellendi'; elseif ($msg==='acc_unblocked') $toast='Seçilenlerin engeli kaldırıldı'; elseif ($msg==='hist_del') $toast='Seçilen kayıtlar geçmişten silindi';
elseif ($msg==='deleted') $toast='Dosya silindi';
elseif ($msg==='edited') $toast='Dosya güncellendi';
elseif ($msg==='cat_added') $toast='Kategori eklendi';
elseif ($msg==='cat_edited') $toast='Kategori adı güncellendi';
elseif ($msg==='cat_deleted') $toast='Kategori silindi';
elseif ($msg==='note_added') $toast='Not eklendi';
elseif ($msg==='note_edited') $toast='Not güncellendi';
elseif ($msg==='note_deleted') $toast='Not silindi';
elseif ($msg==='github_added') $toast='GitHub bağlantısı eklendi';
elseif ($msg==='settings_saved') $toast='Ayarlar kaydedildi';
elseif ($msg==='settings_none') $toast='En az bir sekme açık kalmalı';
elseif ($msg==='tab_added') $toast='Yeni sekme eklendi';
elseif ($msg==='arch_ok') $toast='Dosya Arşivi\'ne yedeklendi';
elseif ($msg==='arch_part') $toast='Yedeklendi, ancak bazı linkler indirilemedi';
elseif ($msg==='arch_dup') $toast='Bu kayıt zaten Dosya Arşivi\'nde';
elseif ($msg==='arch_fail') $toast='Yedekleme başarısız (linkler indirilemedi veya çok büyük)';
elseif ($msg==='note_empty') $toast='Başlık, yazı, resim, video ya da dosya ekleyin';
elseif ($msg==='site_saved') $toast='Site ayarları kaydedildi';
elseif ($msg==='base_saved') $toast='Şu anki ayarlar ana varsayılan yapıldı: Tümünü sıfırla artık bu ayarlara döner';
elseif ($msg==='base_locked') $toast='Ana varsayılan ayarlı olduğu için tema varsayılanı yapılamaz: temayı uygulayıp Ana varsayılan yap düğmesine basın';
elseif ($msg==='theme_saved') $toast='Ayarlar kaydedildi ve tema olarak saklandı';
elseif ($msg==='theme_noname') $toast='Ayarlar kaydedildi, ancak tema için bir ad yazmalısınız';
elseif ($msg==='theme_full') $toast='Ayarlar kaydedildi, ancak en fazla 20 tema saklanabilir';
elseif ($msg==='theme_applied') $toast='Tema uygulandı';
elseif ($msg==='theme_default_set') $toast='Bu tema varsayılan yapıldı: sıfırlama düğmeleri artık bu temayı geri yükler';
elseif ($msg==='theme_default_cleared') $toast='Varsayılan tema kaldırıldı: sıfırlama düğmeleri fabrika ayarlarına döner';
elseif ($msg==='theme_deleted') $toast='Tema silindi';
elseif ($msg==='theme_bulk_deleted') $toast='Seçilen temalar silindi';
elseif ($msg==='ban_added') $toast='IP engellendi';
elseif ($msg==='ban_removed') $toast='IP engeli kaldırıldı';
elseif ($msg==='ban_bulk_removed') $toast='Seçili IP engelleri kaldırıldı';
elseif ($msg==='ban_bulk_none') $toast='Hiç IP seçilmedi';
elseif ($msg==='empty_saved') $toast='Boş liste yazıları kaydedildi';
elseif ($msg==='actbtn_saved') $toast='İşlem butonları kaydedildi';
elseif ($msg==='ban_self') $toast='Kendi IP adresinizi engelleyemezsiniz';
elseif ($msg==='ban_full') $toast='En fazla 500 IP engellenebilir';
elseif ($msg==='ban_invalid') $toast='Geçersiz IP adresi';
elseif ($msg==='ban_saved') $toast='Engelleme sayfası kaydedildi';
elseif ($msg==='vpn_saved') $toast='VPN ayarları kaydedildi';
elseif ($msg==='vpn_test') $toast='VPN bağlantısı denendi, sonuç aşağıda';
elseif ($msg==='cf_saved') $toast='Cloudflare ayarı kaydedildi';
elseif ($msg==='site_reset') $toast='Görünüm ve site ayarları varsayılana döndürüldü';
elseif ($msg==='site_upload_err') $toast='Ayarlar kaydedildi ama bir görsel yüklenemedi (PNG/JPG/GIF/WEBP/ICO, en fazla 3 MB)';
elseif ($msg==='site_upload_big') $toast='Ayarlar kaydedildi ama görsel çok büyük, yüklenmedi'.(isset($_GET['lim']) && is_string($_GET['lim']) && preg_match('/^\d+[KMG]?B?$/i',$_GET['lim']) ? ' (en fazla '.strtoupper($_GET['lim']).')' : '').'. Daha küçük bir görsel seçin.';
elseif ($msg==='site_upload_type') $toast='Ayarlar kaydedildi ama görsel yüklenmedi: yalnızca PNG, JPG, GIF, WEBP veya ICO yüklenebilir.';
elseif ($msg==='post_big') $toast='Gönderilen dosyaların toplam boyutu sunucu sınırını aştı'.(isset($_GET['lim']) && is_string($_GET['lim']) && preg_match('/^\\d+[KMG]?B?$/i',$_GET['lim']) ? ' (en fazla '.strtoupper($_GET['lim']).')' : '').'; hiçbir şey kaydedilmedi. Daha küçük dosya/resim/video seçin.';
elseif ($msg==='upload_fail') $toast='Dosya yüklenemedi (sunucu dosya sınırını aşmış olabilir'.(isset($_GET['lim']) && is_string($_GET['lim']) && preg_match('/^\\d+[KMG]?B?$/i',$_GET['lim']) ? ': en fazla '.strtoupper($_GET['lim']) : '').'); hiçbir şey kaydedilmedi.';
elseif ($msg==='site_post_big') $toast='Gönderilen veri sunucunun sınırını aştı'.(isset($_GET['lim']) && is_string($_GET['lim']) && preg_match('/^\d+[KMG]?B?$/i',$_GET['lim']) ? ' (en fazla '.strtoupper($_GET['lim']).')' : '').'; hiçbir ayar değiştirilmedi. Daha küçük görsel seçin.';
elseif ($msg==='acc_saved') $toast='Hesaplar güncellendi'; elseif ($msg==='acc_verify') { $toast='Hesaplar dosyaya yazılamadı veya yazılan değer okunamadı: xfile_accounts.php dosyasının yazma iznini kontrol edin'.(isset($_SESSION['x_acc_diag']) && is_string($_SESSION['x_acc_diag']) ? ' ('.x_h($_SESSION['x_acc_diag']).')' : ''); unset($_SESSION['x_acc_diag']); }
elseif ($msg==='acc_added') $toast='Yeni hesap oluşturuldu';
elseif ($msg==='acc_confirm') $toast='Onay için kendi şifrenizi doğru girin';
elseif ($msg==='acc_short') $toast='Şifre en az 6 karakter olmalı'.(isset($_GET['w']) && is_string($_GET['w']) ? ' ('.x_h(mb_substr($_GET['w'],0,30)).' hesabı)' : '');
elseif ($msg==='acc_mismatch') $toast='Şifreler birbiriyle aynı değil';
elseif ($msg==='acc_dup') $toast='Bu şifre başka bir hesapta kullanılıyor, farklı bir şifre seçin'.(isset($_GET['w']) && is_string($_GET['w']) ? ' ('.x_h(mb_substr($_GET['w'],0,30)).' hesabı)' : '');
elseif ($msg==='acc_name') $toast='Hesap adı gerekli';
elseif ($msg==='acc_self') $toast='Kendi hesabınızı silemezsiniz';
elseif ($msg==='act_deleted') $toast='İşlem kayıtları silindi';
elseif ($msg==='act_denied') $toast='Bu işlem için yetkiniz yok';
elseif ($msg==='ban_super') $toast=x_super() ? 'Süper Admin engellenemez' : 'Bu IP engellenemez';
elseif ($msg==='github_dl_fail') $toast='GitHub dosyası indirilemedi (adres erişilemiyor veya çok büyük)';
elseif ($msg==='auth_deleted') $toast='Giriş ve IP kayıtları silindi';
elseif ($msg==='perm_denied') $toast='Bu işlem için yetkiniz yok';
elseif ($msg==='appr_sent') $toast='İşleminiz süper admin onayına gönderildi';
elseif ($msg==='appr_no') $toast=x_appr_mgr() ? 'İstek kaldırıldı' : 'İstek iptal edildi';
elseif ($msg==='appr_ok') $toast='Seçilen işlemler onaylandı';
elseif ($msg==='appr_gone') $toast='İstek bulunamadı';
elseif ($msg==='save_failed') $toast='Kaydedilemedi! Veri dosyası yazılamıyor; sunucuda dosya izinlerini kontrol edin.';
elseif ($msg==='home_saved') $toast='Ana sayfa kaydedildi';
elseif ($msg==='tab_deleted') $toast='Sekme ve içindeki tüm kayıtlar silindi';

 elseif ($msg==='github_invalid') $toast='Geçerli bir bağlantı girin (GitHub raw veya kendi sitenizdeki dosya adresi, http/https)';
 elseif ($msg==='github_edited') $toast='GitHub bağlantısı güncellendi';
elseif ($msg==='github_deleted') $toast='GitHub bağlantısı silindi';
	elseif ($msg==='bulk_deleted') $toast='Seçilen kayıtlar silindi';
if (!empty($_GET['viderr'])) $toast=($toast?$toast.' — ':'').'Video eklenemedi (desteklenmeyen biçim, geçersiz adres veya sunucu yükleme sınırı aşıldı)';
if (isset($_GET['imgfile']) && is_string($_GET['imgfile'])) { $imf = array('size'=>'Resim yüklenemedi: dosya sunucunun yükleme sınırını aşıyor (daha küçük bir resim seçin)','type'=>'Resim yüklenemedi: desteklenen biçimler jpg, png, gif, webp, bmp','move'=>'Resim kaydedilemedi: sunucu dosyayı taşıyamadı (klasör izni veya geçici klasör sorunu)','dir'=>'Resim kaydedilemedi: ekran klasörüne yazma izni yok (klasör izni 755 veya 775 olmalı)','tmp'=>'Resim kaydedilemedi: yüklenen geçici dosya sunucuda bulunamadı (sunucunun geçici klasörü dolu veya yazılamıyor olabilir)'); if (isset($imf[$_GET['imgfile']])) $toast=($toast?$toast.' — ':'').$imf[$_GET['imgfile']]; }
if (!empty($_GET['imgerr'])) $toast=($toast?$toast.' — ':'').'Resim URL\'sinden indirilemedi (geçersiz adres, geçersiz resim veya 10MB üzeri)';
	ob_clean();
	?>
	<!DOCTYPE html>
<html lang="tr"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title><?=x_h(x_site_get('title'))?></title>
<style>
:root {
    --bg:#0a0b0f; --surface:#111318; --surface2:#16181f; --border:#1e2130;
    --border2:#242836; --text:#8b8fa3; --text2:#d1d5e0; --text3:#555a6e;
    --green:#b71c1c; --green-bg:#b71c1c12; --green-glow:#b71c1c30;
    --red:var(--green); --red-bg:var(--green-bg); --blue:#448aff; --blue-bg:#448aff12;
    --amber:#ffab00; --amber-bg:#ffab0012;
    --r:8px; --r-sm:6px;
    --font:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
    --mono:'JetBrains Mono','Fira Code','Consolas',monospace;
}
*{margin:0;padding:0;box-sizing:border-box}
body{background:var(--bg);color:var(--text);font-family:var(--font);font-size:13px;line-height:1.5}
a{color:inherit;text-decoration:none}
.layout{display:flex;min-height:100vh}

.sb{width:220px;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:sticky;top:0;height:100vh;height:100dvh;flex-shrink:0;z-index:20}
.sb-brand{padding:16px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px}
.sb-brand svg{color:var(--green);flex-shrink:0}
.sb-brand .t{font-size:16px;font-weight:800;color:var(--text2);letter-spacing:-.4px}
.sb-brand .t b{color:var(--green)}
.sb-nav{flex:1;min-height:0;overflow-y:auto;padding:8px 8px}
.sb-nav .sec{font-size:9px;color:var(--text3);text-transform:uppercase;letter-spacing:1.2px;padding:10px 10px 5px;font-weight:600}
.sb-nav .it{display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:var(--r-sm);font-size:12px;font-weight:500;transition:all .1s;margin-bottom:1px;color:var(--text)}
.sb-nav .it:hover{background:var(--surface2);color:var(--text2)}
.sb-nav .it.act{background:var(--green-bg);color:var(--green)}
.sb-nav .it .n{margin-left:auto;font-size:9px;padding:1px 6px;border-radius:7px;background:var(--border);color:var(--text3);font-weight:600}
.sb-nav .cat-row{display:flex;align-items:center;gap:2px}.sb-nav .cat-row>.it{flex:1;min-width:0}.sb-nav .cat-tg{flex:none;display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;margin-right:2px;border:1px solid var(--border);background:var(--surface2);color:var(--text3);padding:0;cursor:pointer;border-radius:6px;transition:color .15s,background .15s,border-color .15s}.sb-nav .cat-tg svg{transition:transform .2s ease}.sb-nav .cat-tg[aria-expanded=true] svg{transform:rotate(90deg)}.sb-nav .cat-tg[aria-expanded=true]{color:var(--green);border-color:var(--green);background:var(--green-bg)}.sb-nav .cat-tg-e{width:20px;height:20px;margin-right:2px;border:0;background:none;cursor:default}.sb-nav .cat-tg:hover{color:var(--green);border-color:var(--green)}.sb-nav .cat-subs{display:none}.sb-nav .cat-grp.open .cat-subs{display:block}.sb-nav .sub{position:relative;margin-left:22px;padding:5px 8px 5px 14px;font-size:11.5px;font-weight:400;color:var(--text2);border-left:1px solid var(--border);border-radius:0 var(--r-sm) var(--r-sm) 0}.sb-nav .sub::before{content:'';position:absolute;left:0;top:50%;width:8px;border-top:1px solid var(--border)}.sb-nav .sub-ar{color:var(--text3);font-size:12px;line-height:1}
.sb-nav .sub .it{font-size:11px}
.sb-footer{padding:10px;border-top:1px solid var(--border);flex-shrink:0}
.sb-user{display:flex;align-items:center;gap:7px;padding:7px 9px;border-radius:var(--r-sm);background:var(--surface2)}
.sb-user .av{width:26px;height:26px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:10px;flex-shrink:0}
.av-a{background:var(--red-bg);color:var(--red)}.av-z{background:var(--green-bg);color:var(--green)}
.sb-user .um{font-size:10px;line-height:1.3}
.sb-user .um .rn{color:var(--text2);font-weight:600}
.sb-user .um .rl{display:inline-block;margin-top:2px;padding:1px 7px;border-radius:20px;color:var(--green);background:var(--green-bg);font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.5px}
.btn-logout{display:flex;align-items:center;gap:6px;width:100%;padding:7px 10px;margin-top:7px;background:transparent;border:1px solid var(--border);border-radius:var(--r-sm);color:var(--text);font-size:10px;cursor:pointer;font-family:var(--font);justify-content:center;transition:.1s}
.btn-logout:hover{border-color:var(--red);color:var(--red)}

.main{flex:1;display:flex;flex-direction:column;min-width:0;overflow:hidden}
.main-top{padding:12px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;justify-content:space-between;flex-wrap:wrap}
.main-top h1{font-size:15px;font-weight:700;color:var(--text2)}
.main-top .cr{font-size:10px;color:var(--text3)}
.top-r{display:flex;align-items:center;gap:8px}
.search-w{position:relative}
.search-w input{padding:7px 10px 7px 30px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:var(--r-sm);color:var(--text2);font-size:11px;outline:none;width:180px;font-family:var(--font);transition:.15s}
.search-w input:focus{border-color:var(--green);box-shadow:0 0 0 3px var(--green-glow);width:210px}
.search-w input::placeholder{color:var(--text3)}
.search-w .si{position:absolute;left:9px;top:50%;transform:translateY(-50%);color:var(--text3);pointer-events:none}
.btn-mob{display:none;align-items:center;gap:5px;padding:6px 10px;background:var(--surface);border:1px solid var(--border);border-radius:var(--r-sm);color:var(--text2);cursor:pointer;font-family:var(--font);font-size:11px}

.tabs{display:flex;gap:0;border-bottom:1px solid var(--border);padding:0 18px;overflow-x:auto;overflow-y:hidden;-webkit-overflow-scrolling:touch;scrollbar-width:none;-ms-overflow-style:none}.tabs::-webkit-scrollbar{display:none}
.tabs a{white-space:nowrap;flex:0 0 auto;padding:10px 16px;font-size:12px;font-weight:600;color:var(--text3);border-bottom:2px solid transparent;transition:.12s}
.tabs a:hover{color:var(--text2)}
.tabs a.act{color:var(--green);border-bottom-color:var(--green)}

.main-body{padding:14px 18px;flex:1;overflow-x:auto}

.btn{display:inline-flex;align-items:center;justify-content:center;gap:5px;padding:7px 14px;border-radius:var(--r-sm);font-size:11.5px;font-weight:600;cursor:pointer;border:none;font-family:var(--font);transition:.12s;text-decoration:none;white-space:nowrap}
.btn-g{background:var(--green);color:#fff}.btn-g:hover{filter:brightness(1.1);box-shadow:0 3px 12px var(--green-glow)}
.btn-o{background:transparent;border:1px solid var(--border);color:var(--text2)}.btn-o:hover{border-color:var(--green);color:var(--green)}
.btn-cp{background:transparent;border:1px solid var(--border);color:#35d07f}.btn-cp:hover{border-color:#35d07f;background:#35d07f12}.btn-ob{background:transparent;border:1px solid var(--border);color:var(--blue)}.btn-ob:hover{border-color:var(--blue);background:var(--blue-bg)}
  .btn-or{background:#8f111c;border:1px solid #8f111c;color:#fff}.btn-or:hover{border-color:#a91422;background:#a91422;filter:brightness(1.08)}
  input[type="checkbox"]{appearance:none;-webkit-appearance:none;width:14px;height:14px;margin:0;background:var(--surface2);border:1px solid var(--border);border-radius:3px;cursor:pointer;display:inline-grid;place-content:center;flex:none}input[type="checkbox"]::before{content:"";width:8px;height:8px;transform:scale(0);transition:transform .1s ease;background:#fff;clip-path:polygon(14% 44%,0 59%,39% 100%,100% 18%,84% 4%,38% 71%)}input[type="checkbox"]:checked{background:var(--red);border-color:var(--red)}input[type="checkbox"]:checked::before{transform:scale(1)}input[type="checkbox"]:focus-visible{outline:2px solid var(--red);outline-offset:2px}
  .btn-xs{font-size:10px;padding:3px 8px}
.btn-sm{font-size:10px;padding:5px 10px}

.panel{background:var(--surface);border:1px solid var(--border);border-radius:var(--r);margin-bottom:12px;overflow:hidden}
.panel-toggle{display:flex;align-items:center;gap:7px;width:100%;padding:11px 14px;background:transparent;border:none;color:var(--hi,#fff);font-size:12px;font-weight:600;cursor:pointer;font-family:var(--font)}
.panel-toggle:hover{background:var(--surface2)}
.panel-toggle .ar{color:var(--text3);margin-left:auto;transition:transform .2s}
.panel-toggle.open .ar{transform:rotate(180deg)}
.panel-body{display:none;padding:0 14px 14px}
.panel-body.open{display:block}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.form-grid .fw{grid-column:1/-1}
.fg{display:flex;flex-direction:column;gap:4px}
.fg label{font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:.5px;font-weight:600}
.fg input[type=text],.fg input[type=url],.fg textarea,.fg select{padding:8px 10px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:var(--r-sm);color:var(--text2);font-size:12px;outline:none;font-family:var(--font);transition:.15s;resize:vertical}
.fg input:focus,.fg textarea:focus,.fg select:focus{border-color:var(--green);box-shadow:0 0 0 3px var(--green-glow)}
.fg textarea{min-height:90px;font-family:var(--mono);font-size:11px;tab-size:2}
.fg select{appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='%23555a6e' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 8px center;padding-right:26px}
.file-zone{position:relative;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:4px;padding:14px;border:2px dashed var(--border);border-radius:var(--r-sm);cursor:pointer;background:var(--inp,#0c0e14);text-align:center;transition:.15s}
.file-zone:hover{border-color:var(--green);background:var(--green-bg)}
.file-zone.has{border-color:var(--green);border-style:solid;background:var(--green-bg)}
.file-zone input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer}
.file-zone .fzt{font-size:10px;color:var(--text3)}
.file-zone .fzn{font-size:11px;color:var(--green);font-weight:600}
.gal-main{display:block;margin:0 auto 8px;cursor:pointer}.gal-strip{display:flex;gap:6px;overflow-x:auto;padding:4px 2px 10px;margin-bottom:6px;scrollbar-width:thin;scrollbar-color:var(--border) transparent}.gal-th{width:56px;height:56px;flex:0 0 auto;object-fit:cover;border-radius:6px;border:2px solid var(--border);cursor:pointer;opacity:.65;transition:.15s;background:var(--surface2)}.gal-th:hover{opacity:1}.gal-th.on{border-color:var(--green);opacity:1}
.toggle-row{display:flex;align-items:center;gap:10px;padding:4px 0}
.sw{position:relative;width:36px;height:20px;flex-shrink:0}
.sw input{opacity:0;width:0;height:0}
.sw .sl{position:absolute;inset:0;background:var(--d2,#1a1d28);border-radius:20px;cursor:pointer;transition:.15s}
.sw .sl::before{content:'';position:absolute;width:14px;height:14px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.15s}
.sw input:checked+.sl{background:var(--green)}
.sw input:checked+.sl::before{background:#fff;transform:translateX(16px)}
  .toggle-row .swl{font-size:11px;color:var(--hi,#fff)}

.cat-chips{display:flex;flex-wrap:wrap;gap:5px}
.cat-chip{display:flex;align-items:center;gap:4px;padding:4px 8px;border-radius:var(--r-sm);font-size:10px;font-weight:500;background:var(--surface2);border:1px solid var(--border);color:var(--text)}
.cat-edit-form{display:flex;align-items:center;gap:3px}.cat-name-input{width:110px;padding:2px 4px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:3px;color:var(--text2);font:inherit}.cat-name-input:focus{outline:none;border-color:var(--green)}.cat-edit{display:inline-flex;padding:2px;background:transparent;border:0;color:var(--green);cursor:pointer}.cat-edit:hover{color:var(--hi,#fff)}
.cat-chip .del{color:var(--red);cursor:pointer;font-weight:700;font-size:12px;line-height:1;opacity:.6;transition:.1s;padding:0 2px}
.cat-chip .del:hover{opacity:1}
.cat-sub{font-size:9px;color:var(--text3)}
.add-cat-form{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-top:5px}
.add-cat-form select,.add-cat-form input{padding:5px 8px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:var(--r-sm);color:var(--text2);font-size:11px;font-family:var(--font);outline:none}
.add-cat-form select:focus,.add-cat-form input:focus{border-color:var(--green)}

.table-wrap{overflow-x:auto;border:1px solid var(--border);border-radius:var(--r)}
table{width:100%;border-collapse:collapse;min-width:900px}
.bulk-toolbar{display:flex;align-items:center;justify-content:flex-start;width:100%;margin:0 0 8px;padding:0;background:transparent;border:0}
.bulk-toolbar .bulk-delete{margin:0}.bulk-toolbar .bulk-count{margin-left:10px;font-size:12px;font-weight:600;color:var(--text2)}
table th{padding:8px 10px;background:var(--surface);color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:.5px;font-weight:600;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap;position:sticky;top:0;z-index:2}
table td{padding:8px 7px;border-bottom:1px solid var(--border2);font-size:12px;vertical-align:middle}
table tr:hover td{background:#ffffff02}
table tr.pinned td{background:var(--amber-bg)}
.select-cell{width:22px;padding-left:3px!important;padding-right:3px!important;text-align:center}
.col-pin{width:18px;padding-left:2px!important;padding-right:2px!important;text-align:center}
.col-thumb{width:44px;padding-left:2px!important;padding-right:2px!important;text-align:center}
.col-name{min-width:170px}
.col-desc{min-width:150px;max-width:210px}
.img-remove{display:block;white-space:nowrap;font-size:9px;margin-top:2px}
.col-cat{width:100px;text-align:center;white-space:nowrap}
.col-pass{width:80px;text-align:center}
.col-php{width:92px;text-align:center}
.col-file{width:130px}
.col-date{width:100px;white-space:nowrap}
.col-actions{width:150px;text-align:right}
.td-name{font-weight:600;color:var(--text2)}
.td-desc{color:var(--text);font-size:11px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.td-file{font-family:var(--mono);font-size:10px;color:var(--text3)}
.td-date{font-size:10px;color:var(--text3);white-space:nowrap}
.thumb-img{width:36px;height:36px;border-radius:4px;object-fit:cover;border:1px solid var(--border);cursor:pointer;background:var(--surface2)}
.thumb-placeholder{width:36px;height:36px;border-radius:4px;border:1px solid var(--border);display:inline-flex;align-items:center;justify-content:center;color:var(--text3);background:var(--surface2)}
.badge{font-size:9px;padding:2px 6px;border-radius:4px;font-weight:700;text-transform:uppercase;letter-spacing:.3px;display:inline-flex;align-items:center;gap:3px;white-space:nowrap}
.badge-r{background:#ff4d4d1f;color:#ff4d4d}.badge-g{background:var(--green-bg);color:#35d07f}.badge-b{background:var(--green-bg);color:var(--green)}.badge-a{background:var(--amber-bg);color:var(--amber)}

.note-table{min-width:600px}
.note-table .col-n-title{min-width:160px}
.note-table .col-n-content{min-width:300px}
.note-table .col-n-date{width:110px}
.note-table .col-n-actions{width:120px}

.note-content{font-size:11px;color:var(--text);max-width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.note-title{font-weight:600;color:var(--text2)}
.note-title-button{border:0;background:none;padding:0;font:inherit;text-align:left;cursor:pointer}
.note-title-button:hover{color:var(--green)}

.empty{padding:40px 20px;text-align:center;color:var(--text3)}
.empty svg{opacity:.2;margin-bottom:10px}
.empty h3{font-size:13px;font-weight:500}
.empty p{font-size:11px;margin-top:2px}
.empty-d{font-size:11px;margin-top:4px}.empty-d p{margin:2px 0}

.toast{position:fixed;bottom:18px;right:18px;padding:9px 16px;border-radius:var(--r-sm);font-size:11px;font-weight:600;z-index:99;animation:tu .2s ease,to 2.5s 1.8s ease forwards;pointer-events:none;background:#14532d;border:1px solid #166534;color:#dcfce7;box-shadow:0 6px 20px #00000040}
@keyframes tu{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
@keyframes to{to{opacity:0;transform:translateY(-5px)}}

.modal-overlay{display:none;position:fixed;inset:0;background:#00000088;z-index:200;align-items:center;justify-content:center}
.modal-overlay.open{display:flex}
.modal-box{--mp:16px;background:var(--surface);border:1px solid var(--border);border-radius:var(--r);padding:16px;max-width:90vw;max-height:85vh;overflow:auto}
.modal-box img{max-width:100%;max-height:70vh;display:block;border-radius:4px}
.modal-close{position:sticky;top:calc(2px - var(--mp,16px));float:right;z-index:6;margin:calc(2px - var(--mp,16px)) calc(2px - var(--mp,16px)) 6px 10px;width:30px;height:30px;padding:0;display:inline-flex;align-items:center;justify-content:center;border-radius:0;background:#e11d2e;color:#fff;border:2px solid #ff4d5a;cursor:pointer;line-height:0;font-family:var(--font);box-shadow:0 2px 8px rgba(225,29,46,.45)}.modal-close svg{display:block;stroke:currentColor;stroke-width:3}.modal-close:hover{background:#ff2b3f}

@media(max-width:768px){
    .sb{display:none;position:fixed;inset:0;width:100%;height:100vh;height:100dvh;z-index:100;overflow:hidden}.sb.open{display:flex}
    .sb-footer{padding:10px 10px calc(10px + env(safe-area-inset-bottom))}
    .btn-mob{display:flex}
    .main-top{padding:10px 12px}.main-body{padding:10px 12px}
    .tabs{padding:0 12px}
    .form-grid{grid-template-columns:1fr}
    .search-w input{width:110px}.search-w input:focus{width:140px}
    table{min-width:700px}
}
.stats-head{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:14px}.stats-head h2{font-size:18px;color:var(--text2)}.stats-head p,.muted{color:var(--text3);font-size:11px}.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:12px}.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--r);padding:14px}.stat-card b{display:block;font-size:24px;color:var(--green)}.stat-card span{font-size:10px;color:var(--text3)}.stats-columns{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.stats-title{padding:12px 14px;border-bottom:1px solid var(--border);font-weight:700;color:var(--text2)}.rank-list{padding:10px 14px;max-height:260px;overflow-y:auto;scrollbar-width:thin;scrollbar-color:var(--border2) transparent}.rank-list::-webkit-scrollbar{width:6px}.rank-list::-webkit-scrollbar-thumb{background:var(--border2);border-radius:6px}.rank-row{position:relative;display:grid;grid-template-columns:minmax(0,1fr) auto auto auto auto;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--border);font-size:11px;overflow:hidden}.rank-row span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rank-row strong{color:var(--text2);white-space:nowrap}.rank-row em{font-style:normal;color:var(--green);font-size:10px}.rank-percent{display:none;color:var(--red);font-size:10px;font-weight:800;white-space:nowrap;min-width:38px;padding:4px 7px;text-align:center;background:var(--surface2);border:1px solid var(--border);border-radius:4px;line-height:1}.rank-row.show-percent .rank-percent{display:block}.rank-row i{position:absolute;left:0;bottom:0;height:2px;background:var(--green);opacity:.7;cursor:pointer}.rank-link-info{display:flex;align-items:center;gap:5px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rank-name-toggle{display:flex;align-items:center;gap:5px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border:0;padding:0;background:none;color:inherit;font:inherit;text-align:left;cursor:pointer}.rank-name-toggle:hover{color:var(--text2)}.rank-link-action{display:inline-flex;align-items:center;justify-content:center;flex:none;color:var(--blue);cursor:pointer}.rank-link-action:hover{color:var(--red)}.rank-link-info>svg{color:var(--text3);flex-shrink:0}.rank-action-info{display:flex;align-items:center;gap:5px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rank-action-info svg{color:var(--text3);flex-shrink:0}.rank-action-icon{display:inline-flex;align-items:center;justify-content:center;flex:none;padding:2px;border:0;background:transparent;color:var(--blue);cursor:pointer}.rank-action-icon:hover{color:var(--green)}.rank-action-icon svg{display:block}.stats-columns+.panel{margin-top:12px}@media(max-width:900px){.stats-grid{grid-template-columns:repeat(2,1fr)}.stats-columns{grid-template-columns:1fr}}@media(max-width:500px){.stats-head{align-items:flex-start;flex-direction:column}.stats-grid{grid-template-columns:1fr 1fr}}
table tr.pinned td {
    background: rgba(127,29,29,.16);
}
table tr.pinned:hover td {
    background: rgba(127,29,29,.24);
}
table .col-pin{color:#ff4d4d}
  table tr.pinned .col-pin{color:#ff4d4d}
  td.col-actions{height:60px;white-space:nowrap}
.row-actions{display:flex;gap:3px;justify-content:flex-end;align-items:center}<?=x_ab_css()?>.archive-pin-action{color:var(--text3)!important}.archive-pin-action.is-pinned{color:var(--amber)!important}
table .btn.btn.btn:not(.btn-or):not(.btn-g):hover,table .btn.btn.btn:not(.btn-or):not(.btn-g):hover svg{color:var(--green)!important;border-color:var(--green)!important}
.pack-item{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border);flex-wrap:nowrap}.pack-item:last-child{border-bottom:0}.pack-item .pk-b{flex:0 0 88px;text-align:center}.pack-item .pk-p{flex:0 0 76px;text-align:center}.pack-item .pk-n{flex:1 1 auto;min-width:0;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text)}.pack-item .pk-n a{color:var(--text)}.pack-item .pk-a{flex:0 0 auto;display:flex;gap:6px}.pack-zip{width:100%;justify-content:center;margin-top:12px}

table tr.pinned td{background:color-mix(in srgb,var(--green) 24%,transparent)}
table tr.pinned:hover td{background:color-mix(in srgb,var(--green) 34%,transparent)}
table tr.pinned td:first-child{box-shadow:inset 3px 0 0 var(--green)}
table tr.pinned .col-pin{color:#ff4d4d}
  #dosyaTable{min-width:900px}
    table .row-actions a.archive-pin-action:not(.is-pinned),
  table .row-actions a.archive-pin-action:not(.is-pinned) svg {
    color: var(--text3) !important;
    stroke: currentColor !important;
  }
  table .row-actions a.archive-pin-action.is-pinned,
  table .row-actions a.archive-pin-action.is-pinned svg {
    color: var(--amber) !important;
    stroke: currentColor !important;
  }
	.rich-editor{width:100%;min-width:0}

.rich-toolbar{display:flex;align-items:center;gap:5px;flex-wrap:wrap;width:100%;min-width:0;padding:6px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-bottom:0;border-radius:var(--r-sm) var(--r-sm) 0 0}
.rich-toolbar button{display:inline-flex;align-items:center;justify-content:center;flex:0 0 28px;width:28px;height:28px;padding:0;background:var(--surface2);border:1px solid var(--border);border-radius:4px;color:var(--text2);font:600 12px var(--font);cursor:pointer}
.rich-toolbar button:hover{border-color:var(--green);color:var(--green);background:var(--green-bg)}
.rich-toolbar .rich-size-select{flex:0 0 116px;width:116px;min-width:116px;height:28px;padding:4px 28px 4px 8px;background-color:var(--surface2);background-position:right 7px center;border:1px solid var(--border);border-radius:4px;color:var(--text2);font:500 11px var(--font);line-height:18px;white-space:nowrap;overflow:visible}
.rich-toolbar input[type=color]{flex:0 0 28px;width:28px;height:28px;padding:2px;background:var(--surface2);border:1px solid var(--border);border-radius:4px;cursor:pointer}
.rich-content{min-height:90px;padding:9px 10px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:0 0 var(--r-sm) var(--r-sm);color:var(--text2);font:12px var(--font);line-height:1.5;outline:none;overflow-wrap:anywhere}
.rich-content:focus{border-color:var(--green);box-shadow:0 0 0 3px var(--green-glow)}
.rich-content:empty::before{content:attr(data-placeholder);color:var(--text3);pointer-events:none}
.rich-value{display:none}
@media(max-width:420px){.rich-toolbar .rich-size-select{flex-basis:116px;width:116px;min-width:116px}.rich-toolbar{gap:4px}}
.col-drag{width:22px;min-width:22px;max-width:22px;padding:0!important;text-align:center}
.drag-h{display:inline-block;padding:8px 5px;color:var(--text3);cursor:grab;font-size:13px;line-height:1;letter-spacing:-3px;user-select:none;-webkit-user-select:none;touch-action:none}
.drag-h:hover{color:var(--green)}
tr.dragging td{background:var(--green-bg)!important;box-shadow:0 0 0 1px var(--green) inset}
tr.dragging .drag-h{cursor:grabbing}
body.drag-on{cursor:grabbing;user-select:none;-webkit-user-select:none}
</style><?=x_theme_css()?><?=x_seo_meta()?>
</head>
<body>
<div class="layout">
<aside class="sb" id="sb">
    <div class="sb-brand"><?=x_brand_icon(18)?><div class="t"><?=x_brand_html()?></div></div>
    <nav class="sb-nav">
        <div class="sec">Menü</div>
        <?php foreach ($GLOBALS['x_all_tabs'] as $ne): if (!$ne['enabled']) continue; $nt=$ne['type']; $nk=$ne['base']?$nt:$ne['key']; $ncnt=0; if ($nt!=='home') foreach ($data[$nt] as $nit) if (x_item_tabkey($nt,$nit)===$nk) $ncnt++; $nlist=$nt==='dosya'?$dosya:($nt==='github'?$github:array()); $nact=($tab===$nt && $xcur[$nt]===$nk) || ($tab==='all' && $nt!=='notes' && x_list_has_tab($nlist,$nt,$nk)); $nic=x_entry_icon($ne,'side'); ?><a href="<?=x_h(x_entry_href($ne))?><?=(($nt==='dosya' || $nt==='github') && $activeCat!=='__all__')?'&cat='.$activeCat:''?>" class="it <?=$nact?'act':''?>"><?=$nic!=='' ? svg($nic,13).' ' : ''?><?=x_h($ne['label'])?><?=$nt==='home'?'':'<span class="n">'.$ncnt.'</span>'?></a>
        <?php endforeach; ?>
        <?php if (x_stats_ok()): ?><a href="?tab=analytics" class="it <?=$tab==='analytics'?'act':''?>"><?=svg('eye',13)?> İstatistik <span class="n">ADMIN</span></a><?php endif; ?><?php if (x_perm('settings')): ?><a href="?tab=settings" class="it <?=$tab==='settings'?'act':''?>"><?=svg('cog',13)?> Ayarlar <span class="n">ADMIN</span></a><?php endif; ?>
        <?php if (x_type_any_on('dosya')||x_type_any_on('github')): ?>
        <div class="sec" style="margin-top:8px">Kategoriler</div>
        <a href="?tab=all" class="it <?=$tab==='all'&&$activeCat==='__all__'?'act':''?>"><?=svg('tag',13)?> Tümü<span class="n"><?=count($dataEn['dosya']) + count($dataEn['github'])?></span></a>
        <?php foreach ($catTree as $cat):
            $cnt=count(array_filter($dataEn['dosya'],function($s) use ($cat) { return ((isset($s['category_id']) ? $s['category_id'] : null))===$cat['id']; })) + count(array_filter($dataEn['github'],function($g) use ($cat) { return ((isset($g['category_id']) ? $g['category_id'] : null))===$cat['id']; }));
            $subs=x_cat_tree($cats,$cat['id']); $gopen=($tab==='all' && $activeCat===$cat['id']); foreach ($subs as $sb0) if ($tab==='all' && $activeCat===$sb0['id']) $gopen=true; ?>
        <div class="cat-grp<?=$gopen?' open':''?>" data-cg="<?=x_h($cat['id'])?>">
        <div class="cat-row"><?php if ($subs): ?><button type="button" class="cat-tg" onclick="catTg(event,this)" title="Alt kategorileri aç / kapat (<?=count($subs)?>)" aria-expanded="<?=$gopen?'true':'false'?>"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg></button><?php else: ?><span class="cat-tg cat-tg-e"></span><?php endif; ?><a href="?tab=all&cat=<?=$cat['id']?>" class="it <?=$tab==='all'&&$activeCat===$cat['id']?'act':''?>"><?=svg('tag',12)?> <?=x_h($cat['name'])?><span class="n"><?=$cnt?></span></a></div>
        <?php if ($subs): ?><div class="cat-subs"><?php foreach ($subs as $sub):
            $scnt=count(array_filter($dataEn['dosya'],function($s) use ($sub) { return ((isset($s['category_id']) ? $s['category_id'] : null))===$sub['id']; })) + count(array_filter($dataEn['github'],function($g) use ($sub) { return ((isset($g['category_id']) ? $g['category_id'] : null))===$sub['id']; })); ?>
        <a href="?tab=all&cat=<?=$sub['id']?>" class="it sub <?=$tab==='all'&&$activeCat===$sub['id']?'act':''?>" title="<?=x_h($cat['name'])?> kategorisinin alt kategorisi"><span class="sub-ar">↳</span> <?=x_h($sub['name'])?><span class="n"><?=$scnt?></span></a>
        <?php endforeach; ?></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
        <script>function catTg(e,b){e.preventDefault();var g=b.closest('.cat-grp'),o=!g.classList.contains('open');g.classList.toggle('open',o);b.setAttribute('aria-expanded',o?'true':'false');try{var m=JSON.parse(localStorage.getItem('x_cg')||'{}');m[g.getAttribute('data-cg')]=o?1:0;localStorage.setItem('x_cg',JSON.stringify(m))}catch(x){}}(function(){try{var m=JSON.parse(localStorage.getItem('x_cg')||'{}');document.querySelectorAll('.cat-grp').forEach(function(g){var id=g.getAttribute('data-cg'),b=g.querySelector('.cat-tg');if(b&&m[id]===1&&!g.classList.contains('open')){g.classList.add('open');b.setAttribute('aria-expanded','true')}})}catch(x){}})()</script>
        <div class="sec" style="margin-top:8px">İstatistik</div>
        <div class="it" style="pointer-events:none"><?=svg('lock',12)?> Şifreli <span class="n"><?=count(array_filter($dataEn['dosya'],function($s) { return !empty($s['has_password']); })) + count(array_filter($dataEn['github'],function($g) { return !empty($g['encrypted']); }))?></span></div>
        <div class="it" style="pointer-events:none"><?=svg('unlock',12)?> Açık <span class="n"><?=count(array_filter($dataEn['dosya'],function($s) { return empty($s['has_password']); })) + count(array_filter($dataEn['github'],function($g) { return empty($g['encrypted']); }))?></span></div>
        <div class="it" style="pointer-events:none"><?=svg('pin',12)?> Sabitli <span class="n"><?=count(array_filter($dataEn['dosya'],function($s) { return (isset($s['pinned']) ? $s['pinned'] : false); }))?></span></div>
        <?php endif; ?>
    </nav>
    <div class="sb-footer">
        <div class="sb-user">
            <div class="av <?=$role==='admin'?'av-a':'av-z'?>"><?php $xun = isset($_SESSION['uname']) && is_string($_SESSION['uname']) && $_SESSION['uname']!=='' ? $_SESSION['uname'] : ($role==='admin'?'Yönetici':'Ziyaretçi'); echo x_h(mb_strtoupper(mb_substr($xun,0,1))); ?></div>
            <div class="um"><div class="rn"><?=x_h(isset($_SESSION['uname']) ? $_SESSION['uname'] : ($role==='admin'?'Yönetici':'Ziyaretçi'))?></div><div class="rl" style="<?=x_h(ltrim(x_badge_style(isset($_SESSION['uid']) ? $_SESSION['uid'] : '','b'),';'))?>"><?=x_h(x_badge_or(isset($_SESSION['uid']) ? $_SESSION['uid'] : '', x_super()?'Süper Admin':($role==='admin'?'Admin':($role==='editor'?'Editör':'Kullanıcı'))))?></div></div>
        </div>
        <a class="btn-logout" href="?logout=1"><?=svg('logout',11)?> Çıkış</a>
    </div>
</aside>

<main class="main">
    <div class="main-top">
        <div>
            <h1><?=x_h($tab==='home'?x_home_title():($tab==='notes'?x_tab_label('notes'):($tab==='dosya'?x_tab_label('dosya'):($tab==='github'?x_tab_label('github'):($tab==='settings'?'Ayarlar':($tab==='analytics'?'İstatistik':($activeCat==='__all__'?'Tüm Dosyalar':x_cat_name($cats,$activeCat))))))))?></h1>
            <div class="cr"><?=x_h(x_site_get('app_name'))?><?php if ($tab!=='settings'&&$tab!=='analytics'&&$tab!=='home'): ?> / <?=$tab==='notes'?count($notes):($tab==='all'?count($dosya)+count($github):count($dosya))?> öğe<?php endif; ?></div>
        </div>
        <div class="top-r">
            <button class="btn-mob" onclick="document.getElementById('sb').classList.toggle('open')"><?=svg('menu',14)?> Menü</button>
            <div class="search-w">
                <span class="si"><?=svg('search',12)?></span>
                <input type="text" id="search" placeholder="Ara...">
            </div>
        </div>
    </div>

  <div class="tabs">
  <?php foreach ($GLOBALS['x_all_tabs'] as $ne): if (!$ne['enabled']) continue; $nt=$ne['type']; $nk=$ne['base']?$nt:$ne['key']; $nlist=$nt==='dosya'?$dosya:($nt==='github'?$github:array()); $nact=($tab===$nt && $xcur[$nt]===$nk) || ($tab==='all' && $nt!=='notes' && x_list_has_tab($nlist,$nt,$nk)); $nic=x_entry_icon($ne,'top'); ?><a href="<?=x_h(x_entry_href($ne))?><?=(($nt==='dosya' || $nt==='github') && $activeCat!=='__all__')?'&cat='.$activeCat:''?>" class="<?=$nact?'act':''?>"><?=$nic!=='' ? svg($nic,13).' ' : ''?><?=x_h($ne['label'])?></a>
        <?php endforeach; ?>
  </div>
  <script>(function(){var t=document.querySelector('.tabs'),a=t&&t.querySelector('a.act');if(a){t.scrollLeft=a.offsetLeft-(t.clientWidth-a.offsetWidth)/2}})()</script>

    <div class="main-body">
<?php $xApAll = x_appr_all($data); $xApP = count(x_appr_pending($xApAll)); if (x_appr_mgr() && $xApAll && $tab!=='settings'): ?><div class="panel" style="margin-bottom:12px"><button class="panel-toggle" type="button" onclick="tPanel(this)"><?=svg('clipboard',13)?> <?=$xApP ? $xApP.' işlem onayınızı bekliyor' : 'İptal edilen istekler ('.count($xApAll).')'?><?=($xApP && count($xApAll)>$xApP) ? ' · '.(count($xApAll)-$xApP).' iptal' : ''?><span class="ar"><?=svg('chevron-down',11)?></span></button><div class="panel-body"><?=x_appr_box($xApAll, true)?></div></div><?php endif; ?>
<?php if (x_is_editor() && in_array($tab, array('dosya','github','notes','all'), true)): $xMy = array(); foreach ($xApAll as $xr) if (isset($xr['uid']) && $xr['uid']===(string)$_SESSION['uid']) $xMy[] = $xr; if ($xMy): ?><div class="panel" style="margin-bottom:12px"><button class="panel-toggle" type="button" onclick="tPanel(this)"><?=svg('clipboard',13)?> Onay bekleyen isteklerim (<?=count(x_appr_pending($xMy))?>)<?=(count($xMy)>count(x_appr_pending($xMy))) ? ' · '.(count($xMy)-count(x_appr_pending($xMy))).' iptal' : ''?><span class="ar"><?=svg('chevron-down',11)?></span></button><div class="panel-body"><div style="max-height:300px;overflow-y:auto"><?=x_appr_rows($xMy, false)?></div></div></div><?php endif; endif; ?>

<?php if ($tab==='analytics' && x_stats_ok()): ?>
<?php
  $events=$data['analytics']; $xVpnOff = x_vpn_settings($data)['off']; $xHideSup = (!x_super() && x_perm('hide_super'));
  if ($xVpnOff || $xHideSup) $events = array_values(array_filter($events, function($e) use ($xVpnOff, $xHideSup) { if (!is_array($e)) return false; if ($xVpnOff && isset($e['type'],$e['action']) && $e['type']==='auth' && ($e['action']==='vpn' || $e['action']==='vpn_block')) return false; if ($xHideSup && isset($e['uid']) && $e['uid']==='builtin_admin') return false; return true; })); $total=count($events); $countBy=function($type,$action)use($events){return count(array_filter($events,function($e) use ($type, $action) { return ((isset($e['type']) ? $e['type'] : ''))===$type&&((isset($e['action']) ? $e['action'] : ''))===$action; }));};
  $rank=function($type,$action)use($events){$r=[];foreach($events as $e)if(((isset($e['type']) ? $e['type'] : ''))===$type&&((isset($e['action']) ? $e['action'] : ''))===$action){$k=$e['id']?:((isset($e['label']) ? $e['label'] : 'Bilinmiyor'));if(!isset($r[$k]))$r[$k]=['id'=>$k,'label'=>(isset($e['label']) ? $e['label'] : $k),'count'=>0];$r[$k]['count']++;}usort($r,function($a,$b) { return x_cmp($b['count'], $a['count']); });return $r;};
  $downloads=$rank('dosya','download'); $reads=$rank('note','read'); $copies=$rank('github','copy'); $logins=$rank('auth','login');
  foreach($copies as &$copy) { foreach($data['github'] as $githubItem) if(((isset($githubItem['id']) ? $githubItem['id'] : ''))===((isset($copy['id']) ? $copy['id'] : ''))) { $copy['label']=(isset($githubItem['name']) ? $githubItem['name'] : $copy['label']); $copy['url']=(isset($githubItem['url']) ? $githubItem['url'] : ''); break; } } unset($copy);
  $percent=function($n,$sum){return $sum?round($n/$sum*100,1):0;}; $xSupIps = $xHideSup ? array() : x_super_ips($data);
?>
<div class="stats-head"><div><h2>Gelişmiş İstatistik Paneli</h2><p>Dosya arşivi, GitHub, bilgiler ve giriş hareketleri</p></div><?php if (x_perm('analytics_reset')): ?><form method="POST" action="?action=analytics_reset" onsubmit="return confirm(this.clear_acts&&this.clear_acts.checked?'İstatistik kayıtları ve son işlem kayıtları sıfırlansın mı? (Son girişler ve IP kayıtları silinmez)':'İstatistik kayıtları sıfırlansın mı? (Son girişler ve IP kayıtları silinmez)')"><?php if (x_super()): ?><label style="display:inline-flex;align-items:center;gap:6px;margin:0 10px 6px 0;font-size:12px;cursor:pointer;color:var(--text2)"><input type="checkbox" name="clear_acts" value="1"> Son işlemleri de sil</label><?php endif; ?><button class="btn btn-or btn-sm" type="submit"><?=svg('trash',12)?> İstatistikleri Sıfırla</button></form><?php endif; ?></div>
<div class="stats-grid"><div class="stat-card"><b><?=number_format($countBy('dosya','download'))?></b><span>Dosya indirme</span></div><div class="stat-card"><b><?=number_format($countBy('github','copy'))?></b><span>GitHub kopyalama</span></div><div class="stat-card"><b><?=number_format($countBy('dosya','read')+$countBy('note','read'))?></b><span>İçerik okuma</span></div><div class="stat-card"><b><?=number_format($countBy('auth','login'))?></b><span>Giriş</span></div></div>
  <div class="stats-columns"><div class="panel"><div class="stats-title">En çok indirilen dosyalar</div><div class="rank-list"><?php foreach($downloads as $r):?><div class="rank-row"><button class="rank-name-toggle" type="button" onclick="this.closest('.rank-row').classList.toggle('show-percent')" title="Yüzdeyi göster/gizle"><?=svg('download',11)?> <?=x_h($r['label'])?></button><strong><?=$r['count']?></strong><a class="rank-action-icon" href="?action=download&id=<?=x_h($r['id'])?>" title="Dosyayı indir" aria-label="Dosyayı indir"><?=svg('download',12)?></a><span class="rank-percent"><?=$percent($r['count'],$countBy('dosya','download'))?>%</span><i onclick="this.parentElement.classList.toggle('show-percent')" style="width:<?=$percent($r['count'],$countBy('dosya','download'))?>%"></i></div><?php endforeach;if(!$downloads):?><p class="muted">Henüz kayıt yok.</p><?php endif;?></div></div>
  <div class="panel"><div class="stats-title">En çok okunan bilgiler</div><div class="rank-list"><?php foreach($reads as $r):?><div class="rank-row"><button class="rank-name-toggle" type="button" onclick="this.closest('.rank-row').classList.toggle('show-percent')" title="Yüzdeyi göster/gizle"><?=svg('eye',11)?> <?=x_h($r['label'])?></button><strong><?=$r['count']?></strong><?php foreach($data['notes'] as $noteItem) if(((isset($noteItem['id']) ? $noteItem['id'] : ''))===((isset($r['id']) ? $r['id'] : ''))):?><button class="rank-action-icon" type="button" onclick="viewNote(<?=htmlspecialchars(json_encode(x_ci($noteItem,'content')+['_v'=>x_img_v((isset($noteItem['image']) ? $noteItem['image'] : ''))]+x_gal_meta($noteItem,'image'),JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)" title="Bilgiyi görüntüle" aria-label="Bilgiyi görüntüle"><?=svg('eye',12)?></button><?php endif;?><span class="rank-percent"><?=$percent($r['count'],$countBy('note','read'))?>%</span><i onclick="this.parentElement.classList.toggle('show-percent')" style="width:<?=$percent($r['count'],$countBy('note','read'))?>%"></i></div><?php endforeach;if(!$reads):?><p class="muted">Henüz kayıt yok.</p><?php endif;?></div></div>
  <div class="panel"><div class="stats-title">En çok kopyalanan GitHub linkleri</div><div class="rank-list"><?php foreach($copies as $r):?><div class="rank-row"><button class="rank-name-toggle rank-link-info" type="button" onclick="this.closest('.rank-row').classList.toggle('show-percent')" title="Yüzdeyi göster/gizle"><?=svg('link',11)?> <?=x_h($r['label'])?></button><strong><?=$r['count']?></strong><?php if (!empty($r['url'])):?><a class="rank-link-action" href="<?=x_h($r['url'])?>" target="_blank" rel="noopener noreferrer" title="GitHub linkini aç" aria-label="GitHub linkini aç"><?=svg('link',11)?></a><button class="rank-action-icon" type="button" onclick="copyGithub(this,<?=htmlspecialchars(json_encode($r['url']), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)" title="GitHub linkini kopyala" aria-label="GitHub linkini kopyala"><?=svg('copy',12)?></button><?php endif;?><span class="rank-percent"><?=$percent($r['count'],$countBy('github','copy'))?>%</span><i onclick="this.parentElement.classList.toggle('show-percent')" style="width:<?=$percent($r['count'],$countBy('github','copy'))?>%"></i></div><?php endforeach;if(!$copies):?><p class="muted">Henüz kayıt yok.</p><?php endif;?></div></div></div>
<?php if (x_perm('logins')): $xAuthSup = x_super(); ?><div class="panel" id="authPanel"><div class="stats-title">Son girişler ve IP kayıtları</div>
<?php if ($xAuthSup): ?><form method="POST" action="?action=auth_delete&tab=analytics" id="authForm"></form><div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px;font-size:12px;color:var(--text2)"><label style="display:flex;align-items:center;gap:8px;cursor:pointer"><input type="checkbox" id="authAll" onchange="authSel(this)"> Tümünü seç</label><span id="authCnt" style="display:none;font-weight:600;color:var(--text)"></span><button class="btn btn-or btn-xs" type="submit" form="authForm" id="authDel" disabled style="display:none" onclick="return confirm('Seçili giriş kayıtları silinsin mi?')"><?=svg('trash',11)?> Seçilenleri sil</button><button class="btn btn-or btn-xs" type="submit" form="authForm" name="all" value="1" onclick="return confirm('Tüm giriş ve IP kayıtları silinsin mi?')"><?=svg('trash',11)?> Tümünü temizle</button></div>
<script>function authSync(){var b=[].slice.call(document.querySelectorAll('.auth-sel')),n=b.filter(function(x){return x.checked}).length,c=document.getElementById('authCnt'),d=document.getElementById('authDel'),a=document.getElementById('authAll');if(c){c.textContent=n+' kayıt seçildi';c.style.display=n?'':'none'}if(d){d.disabled=n===0;d.style.display=n?'':'none'}if(a)a.checked=b.length>0&&n===b.length}function authSel(m){document.querySelectorAll('.auth-sel').forEach(function(x){x.checked=m.checked});authSync()}</script><?php endif; ?>
<div class="table-wrap" style="max-height:440px;overflow-y:auto"><table><thead><tr><?php if ($xAuthSup): ?><th class="select-cell"></th><?php endif; ?><th>Hesap</th><th>Zaman</th><th>IP</th><th>İşlem</th></tr></thead><tbody><?php foreach(array_reverse($events) as $e)if(((isset($e['type']) ? $e['type'] : ''))==='auth'):?><tr><?php if ($xAuthSup): ?><td class="select-cell"><input type="checkbox" class="auth-sel" form="authForm" name="ids[]" value="<?=x_h(x_ev_id($e))?>" onchange="authSync()"></td><?php endif; ?><td><?php $ea = isset($e['action']) ? $e['action'] : 'login'; $er = isset($e['label']) ? $e['label'] : (isset($e['id']) ? $e['id'] : ''); if ($ea==='fail'): ?><span class="badge badge-r" style="font-size:11px;text-transform:none">Yanlış şifre</span><?php elseif ($ea==='vpn' || $ea==='vpn_block'): ?><span class="badge badge-r" style="font-size:11px;text-transform:none">VPN ile giriş tespit edildi</span><?php if (!empty($e['vpn_type'])): ?> <span class="badge" style="font-size:11px;text-transform:none;background:var(--surface2);color:var(--text);border:1px solid var(--border)"><?=x_h($e['vpn_type']==='tor'?'Tor':($e['vpn_type']==='vpn'?'VPN':($e['vpn_type']==='dc'?'Sunucu IP':'Proxy')))?></span><?php endif; if ($ea==='vpn_block'): ?> <span class="badge badge-r" style="font-size:11px;text-transform:none">Engellendi</span><?php endif; ?><?php elseif ($ea==='visit'): ?><span class="badge badge-a" style="font-size:11px;text-transform:none">Ziyaret tespit edildi</span><?php else: ?><span class="badge <?=$er==='admin'?'badge-b':'badge-g'?>" style="font-size:11px;text-transform:none<?=x_h(x_badge_style(isset($e['uid']) ? $e['uid'] : '','b'))?>"><?=x_h(x_badge_or(isset($e['uid']) ? $e['uid'] : '', $er==='admin'?((isset($e['uid']) && $e['uid']==='builtin_admin')?'Süper Admin':'Yönetici'):($er==='visitor'?'Ziyaretçi':$er)))?></span><?php if (!empty($e['name'])): ?> <span class="badge" style="font-size:11px;text-transform:none;background:var(--surface2);color:var(--text);border:1px solid var(--border)"><?=x_h($e['name'])?></span><?php endif; endif; ?></td><td><?=x_h(date('d.m.y - H:i',strtotime((isset($e['time']) ? $e['time'] : 'now'))))?></td><td><code><?=x_h((isset($e['ip']) ? $e['ip'] : 'unknown'))?></code><?php if (!$xVpnOff && $ea!=='vpn' && $ea!=='vpn_block' && isset($e['ip']) && isset($data['vpn_cache'][$e['ip']]['f']) && (int)$data['vpn_cache'][$e['ip']]['f']===1): ?> <span class="badge badge-r" style="font-size:10px;text-transform:none">VPN</span><?php endif; ?></td><td><?php $eip = isset($e['ip']) ? $e['ip'] : ''; if (filter_var($eip, FILTER_VALIDATE_IP)): $isb = x_is_banned($data, $eip); ?><?php if (!$isb && in_array(x_ip_norm($eip), $xSupIps, true)): ?><span class="badge badge-b" style="font-size:10px;text-transform:none">Süper Admin IP</span> <?php endif; if (x_perm('ip_ban')): ?><form method="POST" action="?action=<?=$isb ? 'ip_unban' : 'ip_ban'?>&tab=analytics" style="display:inline"<?=$isb ? '' : ' onsubmit="return confirm(\'Bu IP engellensin mi?\')"'?>><input type="hidden" name="ip" value="<?=x_h($eip)?>"><button type="submit" class="btn btn-xs <?=$isb ? 'btn-g' : 'btn-or'?>"><?=$isb ? 'Engeli kaldır' : 'IP engelle'?></button></form><?php if ($isb): ?> <span class="badge badge-r" style="font-size:10px">Engelli</span><?php endif; endif; endif; ?></td></tr><?php endif; ?></tbody></table></div></div><?php endif; ?>
<?php if (x_can_logs()): $xActs = (isset($data['activity']) && is_array($data['activity'])) ? array_reverse($data['activity']) : array(); if ($xHideSup) $xActs = array_values(array_filter($xActs, function($xz) { return !(is_array($xz) && isset($xz['uid']) && $xz['uid']==='builtin_admin'); })); $xActSup = x_super(); ?>
<style>.act-wrap{max-height:440px;overflow-y:auto;border:1px solid var(--border);border-radius:8px}.act-wrap table{margin:0}.act-wrap thead th{position:sticky;top:0;background:var(--surface);z-index:1}.act-tx{white-space:normal;word-break:break-word;min-width:200px}.act-tb{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px;font-size:12px;color:var(--text2)}.act-tb label{display:flex;align-items:center;gap:8px;cursor:pointer}</style>
<div class="panel" id="actPanel" style="margin-top:14px"><div class="stats-title">Son işlemler <span class="muted">(<?=count($xActs)?> kayıt<?=$xActSup?'':' · yalnızca görüntüleme'?>)</span></div>
<?php if (!$xActs): ?><p class="muted">Henüz işlem kaydı yok.</p><?php else: ?>
<form method="POST" action="?action=act_delete&tab=analytics" class="bulk-form" id="actForm">
<?php if ($xActSup): ?><div class="act-tb"><label><input type="checkbox" class="select-all" onchange="toggleBulk(this)"> Tümünü seç</label><span class="bulk-count" style="display:none;font-weight:600;color:var(--text)"></span><button class="btn btn-or btn-xs bulk-delete" type="submit" disabled style="display:none" onclick="return confirm('Seçili işlem kayıtları silinsin mi?')"><?=svg('trash',11)?> Seçilenleri sil</button><button class="btn btn-or btn-xs" type="submit" name="all" value="1" onclick="return confirm('Tüm işlem kayıtları silinsin mi?')"><?=svg('trash',11)?> Tümünü temizle</button></div><?php endif; ?>
<div class="act-wrap"><table><thead><tr><?php if ($xActSup): ?><th class="select-cell"></th><?php endif; ?><th>Kişi</th><th>Bölüm</th><th>İşlem</th><th>Zaman</th><th>IP</th><?php if ($xActSup): ?><th></th><?php endif; ?></tr></thead><tbody>
<?php foreach ($xActs as $xa): if (!is_array($xa) || !isset($xa['id'])) continue; $xaSup = (isset($xa['uid']) && $xa['uid']==='builtin_admin'); ?>
<tr><?php if ($xActSup): ?><td class="select-cell"><input type="checkbox" name="ids[]" value="<?=x_h($xa['id'])?>" onchange="syncBulk(this)"></td><?php endif; ?>
<td><span class="badge badge-b" style="font-size:11px;text-transform:none<?=x_h(x_badge_style(isset($xa['uid']) ? $xa['uid'] : '','b'))?>"><?=x_h(x_badge_or(isset($xa['uid']) ? $xa['uid'] : '', $xaSup?'Süper Admin':((isset($xa['role']) && $xa['role']==='visitor')?'Ziyaretçi':'Yönetici')))?></span><?php if (!empty($xa['name'])): ?> <span class="badge" style="font-size:11px;text-transform:none;background:var(--surface2);color:var(--text);border:1px solid var(--border)"><?=x_h($xa['name'])?></span><?php endif; ?></td>
<td><span class="badge badge-g" style="font-size:11px;text-transform:none"><?=x_h(isset($xa['cat']) ? $xa['cat'] : '')?></span></td>
<td class="act-tx"><?=x_h(isset($xa['text']) ? $xa['text'] : '')?></td>
<td><?=x_h(date('d.m.y - H:i:s', strtotime(isset($xa['time']) ? $xa['time'] : 'now')))?></td>
<td><code><?=x_h(isset($xa['ip']) ? $xa['ip'] : '')?></code></td>
<?php if ($xActSup): ?><td><button type="submit" name="one" value="<?=x_h($xa['id'])?>" class="btn btn-or btn-xs" title="Bu kaydı sil" onclick="return confirm('Bu kayıt silinsin mi?')"><?=svg('trash',11)?></button></td><?php endif; ?></tr>
<?php endforeach; ?>
</tbody></table></div>
</form>
<?php endif; ?>
</div>
<?php endif; ?>
<?php elseif ($tab==='settings' && x_perm('settings')): ?>
<div class="stats-head"><div><h2>Ayarlar</h2><p>Sekmeleri aç/kapat ve menü adlarını değiştir</p></div></div>
<?php if (x_appr_mgr()): $xAp = x_appr_all($data); ?>
<details class="panel acc-sec" style="max-width:980px;margin-bottom:14px"<?=$xAp?' open':''?>><summary><h3>Onay bekleyenler (<?=count(x_appr_pending($xAp))?>)<?=(count($xAp)>count(x_appr_pending($xAp))) ? ' · '.(count($xAp)-count(x_appr_pending($xAp))).' iptal edildi' : ''?></h3></summary><div style="padding:16px">
<?php if (!$xAp): ?><p class="muted" style="margin:0">Onay bekleyen işlem yok.</p><?php else: ?>
<p class="muted" style="margin:0 0 6px">Editörlerin gönderdiği işlemler. Satıra tıklayınca yüklenen içeriğin ayrıntısı açılır. Onaylayınca işlem uygulanır, reddedince silinir. Editörün iptal ettiği istekler “İptal edildi” etiketiyle burada kalır; “Kaldır” ile listeden silebilirsiniz.</p>
<?=x_appr_box($xAp, true)?>
<form method="POST" action="?action=appr_no&tab=<?=x_appr_tab()?>" style="margin-top:10px"><input type="hidden" name="all" value="1"><button type="submit" class="btn btn-xs" onclick="return confirm('Tüm bekleyen istekler reddedilsin mi?')">Hepsini reddet</button></form>
<?php endif; ?></div></details>
<?php endif; ?>
<?php if (x_perm('settings_tabs')): ?>
<details class="panel acc-sec" style="max-width:980px"><summary><h3>Sekmeler</h3></summary><div style="padding:14px">
<form method="POST" action="?action=settings_save&tab=settings" id="setForm">
<div class="tab-bulk" style="display:flex;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:10px;font-size:12px;color:var(--text2)">
    <label style="display:flex;align-items:center;gap:8px;cursor:pointer"><input type="checkbox" class="cbx" id="tabSelAll" onchange="tabSelectAll(this)"> Tümünü seç</label>
    <span id="tabSelCount" style="font-weight:600;color:var(--text)"></span>
    <button type="button" class="btn btn-or btn-xs" onclick="tabBulk(false)"><?=svg('trash',11)?> Seçilenleri sil</button>
</div>
<?php foreach ($GLOBALS['x_all_tabs'] as $k=>$c): ?>
<div class="set-row" style="flex-wrap:wrap">
    <input type="checkbox" class="tab-sel cbx" name="sel[]" value="<?=x_h($k)?>" onchange="tabSelSync()" title="Silmek için seç"><input type="hidden" name="order[]" value="<?=x_h($k)?>"><span class="ord" style="display:flex;flex-direction:column;gap:2px"><button type="button" class="btn btn-xs" onclick="tabMove(this,-1)" title="Yukarı taşı" style="padding:1px 6px;line-height:1">&#9650;</button><button type="button" class="btn btn-xs" onclick="tabMove(this,1)" title="Aşağı taşı" style="padding:1px 6px;line-height:1">&#9660;</button></span>
    <div class="ico-pick"><?php $cic = x_entry_icon($c,'side'); ?><input type="hidden" name="icon[<?=x_h($k)?>]" value="<?=x_h(isset($c['icon']) ? $c['icon'] : '')?>"><button type="button" class="ico-cur btn btn-xs" onclick="icoToggle(this)" title="İkon seç"><?=$cic!=='' ? svg($cic,15) : '<span style="font-size:10px">Yok</span>'?></button>
        <div class="ico-grid"><span class="ico-opt" data-none="1" onclick="icoSet(this,'none')" title="İkonsuz">Yok</span><span class="ico-opt" data-none="1" onclick="icoSet(this,'')" title="Varsayılan ikon">Varsayılan</span><?php foreach (x_icon_names() as $in): ?><span class="ico-opt" onclick="icoSet(this,'<?=x_h($in)?>')" title="<?=x_h($in)?>"><?=svg($in,16)?></span><?php endforeach; ?></div></div>
    <label class="sw" title="Göster / gizle"><input type="checkbox" name="enabled[<?=x_h($k)?>]" value="1" <?=$c['enabled']?'checked':''?>><span class="sl"></span></label>
    <div class="fg"><label>Menü adı <span class="muted">(<?=x_h(x_type_label($c['type']))?><?=$c['base']?'':' · özel sekme'?>)</span></label><input type="text" name="label[<?=x_h($k)?>]" value="<?=x_h($c['label'])?>" maxlength="30" placeholder="<?=x_h(x_type_label($c['type']))?>"></div>
    <?php if (true): ?><a class="btn btn-or btn-xs" href="?action=tab_delete&key=<?=x_h($k)?>&tab=settings" onclick="return confirm('Bu sekme ve içindeki TÜM kayıtlar (dosya, resim, video) kalıcı olarak silinecek. Emin misiniz?')" title="Sekmeyi ve içeriğini sil"><?=svg('trash',11)?></a><?php endif; ?>
    <?php if (x_super()): ?><div class="tab-vis" style="flex:1 0 100%;display:flex;align-items:center;flex-wrap:wrap;gap:6px 16px;padding:8px 10px;border:1px dashed var(--border);border-radius:var(--r-sm,6px);font-size:12px;color:var(--text2)">
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0"><label class="sw" style="margin:0"><input type="checkbox" name="hide[<?=x_h($k)?>]" value="1" <?=!empty($c['hide'])?'checked':''?> onchange="this.closest('.tab-vis').querySelector('.tv-roles').style.display=this.checked?'flex':'none'"><span class="sl"></span></label> Gizle <span class="muted">(Süper admin her zaman görür)</span></label>
        <span class="tv-roles" style="display:<?=!empty($c['hide'])?'flex':'none'?>;align-items:center;flex-wrap:wrap;gap:6px 14px"><span style="font-weight:600;color:var(--text)">Görebilecekler:</span><?php foreach (x_tab_roles() as $rk=>$rl): ?><label style="display:flex;align-items:center;gap:5px;cursor:pointer;margin:0"><input type="checkbox" class="cbx" name="show[<?=x_h($k)?>][]" value="<?=x_h($rk)?>" <?=(isset($c['show']) && in_array($rk,$c['show'],true))?'checked':''?>> <?=x_h($rl)?></label><?php endforeach; ?></span>
    </div><?php endif; ?>
</div>
<?php endforeach; ?>
<p class="muted" style="margin:6px 0 14px">Kapalı sekmeler (ve içindeki kayıtlar) hem yöneticiden hem ziyaretçiden gizlenir; kategorilerde de görünmez ve dosyalarına erişilemez. Sıralamak için ▲ ▼ düğmelerini kullanıp Kaydet'e basın; ilk sıradaki sekme açılış sayfası olur. En az bir sekme açık kalmalıdır. Adı boş bırakırsanız varsayılan ad kullanılır. Dosya yükleme paneli Bilgiler sekmesinin içindedir.</p>
<button class="btn btn-g" type="submit"><?=svg('check',13)?> Kaydet</button>
</form></div></details>
<details class="panel acc-sec" style="margin-top:14px;max-width:980px"><summary><h3>Yeni sekme ekle</h3></summary><div style="padding:14px">
<p class="muted" style="margin:4px 0 10px">Yeni sekme hangi türde olsun?</p>
<div class="nt-types">
<button type="button" class="nt-t" data-t="dosya" onclick="ntPick(this)"><?=svg('folder',16)?><b>Dosya Arşivi</b><span>Dosya yükleme, önizleme, indirme, kategori</span></button>
<button type="button" class="nt-t" data-t="github" onclick="ntPick(this)"><?=svg('code',16)?><b>GitHub</b><span>Bağlantı / kod arşivi, kategori</span></button>
<button type="button" class="nt-t" data-t="home" onclick="ntPick(this)"><?=svg('home',16)?><b>Ana Sayfa</b><span>Liste yok; hoş geldiniz yazısı gibi editörle düzenlenen tek sayfa</span></button>
<button type="button" class="nt-t" data-t="notes" onclick="ntPick(this)"><?=svg('book',16)?><b>Bilgiler</b><span>Not ve bilgi yazıları, resim, video, ek dosya</span></button>
</div>
<form method="POST" action="?action=tab_add&tab=settings" id="ntForm" style="display:none;margin-top:14px">
<input type="hidden" name="type" id="ntType" value="">
<div class="fg" style="display:flex;flex-direction:column;gap:6px"><label id="ntLbl" style="font-size:11px;color:var(--text)">Sekme adı</label><input type="text" name="label" id="ntName" maxlength="30" placeholder="Örn: Projelerim" required style="padding:10px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:6px;color:var(--text2);font-size:13px;width:100%;max-width:340px;outline:none;font-family:var(--font)"></div>
<button class="btn btn-g" type="submit" style="margin-top:10px"><?=svg('check',13)?> Sekmeyi ekle</button>
</form>
</div></details>
<?php endif; ?>
<?php x_settings_site_ui(); x_sec_ui(); ?>
<style>input[type=checkbox].cbx{-webkit-appearance:none;appearance:none;width:18px;height:18px;flex:0 0 auto;margin:0;border:2px solid #8b93a7;border-radius:4px;background:var(--surface2,#1a1d27);cursor:pointer;position:relative;transition:.12s;vertical-align:middle}input[type=checkbox].cbx:hover{border-color:var(--green)}input[type=checkbox].cbx:checked{background:var(--green);border-color:var(--green)}input[type=checkbox].cbx:checked::after{content:'';position:absolute;left:4px;top:0;width:5px;height:10px;border:solid #fff;border-width:0 2px 2px 0;transform:rotate(45deg)}input[type=checkbox].cbx:focus-visible{outline:2px solid var(--green);outline-offset:2px}.set-row .ord button.btn,.set-row .ico-pick button.ico-cur{background:var(--surface2,#1a1d27);border:1px solid var(--border,#2a2e3f);color:var(--text2,#d1d5e0);box-shadow:none}.set-row .ord button.btn:hover,.set-row .ico-pick button.ico-cur:hover{border-color:var(--green);color:var(--text,#fff)}.ico-pick{position:relative;flex:0 0 auto}.ico-pick .ico-cur{min-width:34px;height:34px;display:inline-flex;align-items:center;justify-content:center;padding:0}.ico-grid{display:none;position:fixed;z-index:200;width:268px;max-height:260px;overflow:auto;padding:8px;background:var(--surface,#12141c);border:1px solid var(--border);border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.45);flex-wrap:wrap;gap:4px}.ico-grid[style*="block"]{display:flex!important}.ico-opt{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;padding:0 6px;border:1px solid var(--border);border-radius:6px;cursor:pointer;color:var(--text2);font-size:11px}.ico-opt:hover{border-color:var(--green);color:var(--text)}.tab-sel{flex:0 0 auto}.nt-types{display:flex;gap:10px;flex-wrap:wrap}.nt-t{display:flex;flex-direction:column;align-items:flex-start;gap:4px;flex:1;min-width:150px;padding:12px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--text2);cursor:pointer;text-align:left;font-family:var(--font)}.nt-t b{color:var(--text);font-size:13px}.nt-t span{font-size:11px}.nt-t.on{border-color:var(--green);color:var(--text)}</style>
<script>function icoToggle(b){var g=b.parentNode.querySelector('.ico-grid'),o=g.style.display==='block';document.querySelectorAll('.ico-grid').forEach(function(x){x.style.display='none'});if(o)return;var r=b.getBoundingClientRect();g.style.display='block';var t=r.bottom+4;if(t+g.offsetHeight>window.innerHeight-8)t=Math.max(8,r.top-g.offsetHeight-4);g.style.top=t+'px';g.style.left=Math.max(8,Math.min(r.left,window.innerWidth-g.offsetWidth-8))+'px'}
function icoSet(el,name){var w=el.closest('.ico-pick');w.querySelector('input').value=name;var c=w.querySelector('.ico-cur');if(name==='none')c.innerHTML='<span style="font-size:10px">Yok</span>';else if(name==='')c.innerHTML='<span style="font-size:10px">Vars.</span>';else c.innerHTML=el.innerHTML;el.closest('.ico-grid').style.display='none'}
document.addEventListener('click',function(e){if(!e.target.closest||!e.target.closest('.ico-pick'))document.querySelectorAll('.ico-grid').forEach(function(x){x.style.display='none'})});
function tabSelSync(){var b=document.querySelectorAll('.tab-sel'),n=0;b.forEach(function(x){if(x.checked)n++});var c=document.getElementById('tabSelCount');if(c)c.textContent=n?n+' sekme seçildi':'';var a=document.getElementById('tabSelAll');if(a)a.checked=b.length>0&&n===b.length}
function tabSelectAll(a){document.querySelectorAll('.tab-sel').forEach(function(x){x.checked=a.checked});tabSelSync()}
function tabBulk(all){var f=document.getElementById('setForm'),n=document.querySelectorAll('.tab-sel:checked').length;if(!all&&!n){alert('Önce silinecek sekmeleri seçin.');return}if(!confirm(all?'Eklediğiniz TÜM sekmeler ve içlerindeki tüm kayıtlar (dosya, resim, video) kalıcı olarak silinecek. Emin misiniz?':n+' sekme ve içlerindeki tüm kayıtlar (dosya, resim, video) kalıcı olarak silinecek. Emin misiniz?'))return;if(all){var i=document.createElement('input');i.type='hidden';i.name='all';i.value='1';f.appendChild(i)}f.action='?action=tab_delete_bulk&tab=settings';f.submit()}
function emoPick(b){var i=b.closest('.emo-wrap').previousElementSibling;if(!i||i.tagName!=='INPUT')return;var e=b.textContent,a=i.selectionStart==null?i.value.length:i.selectionStart,z=i.selectionEnd==null?a:i.selectionEnd,v=i.value.slice(0,a)+e+i.value.slice(z);if(v.length>i.maxLength)return;i.value=v;i.focus();try{i.setSelectionRange(a+e.length,a+e.length)}catch(x){}}
function tabMove(b,d){var r=b.closest('.set-row'),p=r.parentNode,x;if(d<0){x=r.previousElementSibling;if(x&&x.classList.contains('set-row'))p.insertBefore(r,x)}else{x=r.nextElementSibling;if(x&&x.classList.contains('set-row'))p.insertBefore(x,r)}}function ntPick(b){var f=document.getElementById('ntForm');document.getElementById('ntType').value=b.getAttribute('data-t');document.querySelectorAll('.nt-t').forEach(function(x){x.classList.toggle('on',x===b)});document.getElementById('ntLbl').textContent=b.querySelector('b').textContent+' türünde yeni sekme adı';f.style.display='block';document.getElementById('ntName').focus()}</script>
<style>.set-row{display:flex;align-items:center;gap:14px;margin-bottom:12px}
.emo-wrap{display:block;margin-top:5px}.emo-t{display:inline-flex;align-items:center;gap:5px;border:1px solid var(--border);background:var(--surface,transparent);color:var(--text2);border-radius:5px;padding:2px 8px;font:500 11px var(--font,inherit);cursor:pointer}.emo-t:hover,.emo-wrap.open .emo-t{border-color:var(--green);color:var(--green)}.emo-bar{display:none;flex-wrap:wrap;gap:2px;margin-top:5px;max-width:260px}.emo-wrap.open .emo-bar{display:flex}.emo-b{border:1px solid var(--border);background:var(--surface,transparent);border-radius:5px;padding:1px 4px;font-size:14px;line-height:1.4;cursor:pointer}.emo-b:hover{border-color:var(--green)}.emo-txt{font-size:11px;font-weight:600;padding:1px 8px}.set-row .fg{flex:1;margin:0;display:flex;flex-direction:column;gap:6px}.set-row .fg label{font-size:11px;color:var(--text)}.set-row .fg input{padding:10px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:6px;color:var(--text2);font-size:13px;width:100%;max-width:340px;outline:none;font-family:var(--font)}.set-row .fg input:focus{border-color:var(--green)}</style>
<?php elseif ($tab==='home'): ?>
<?php $hk = x_ws_cur('home'); $hc = isset($GLOBALS['x_all_tabs'][$hk]) ? $GLOBALS['x_all_tabs'][$hk] : array('content'=>'','label'=>'Ana Sayfa'); $hHas = trim(strip_tags((string)$hc['content'], '<img><video><iframe>'))!==''; ?>
<div class="panel"><div style="padding:22px">
<div id="homeShow"><?php if ($hHas): ?><style>.rich-content.home-read a{text-decoration:none}</style><div class="rich-content home-read"><?=x_rich($hc['content'])?></div><?php else: ?><div class="empty"><?=svg('home',32)?><h3>Henüz içerik eklenmedi</h3><?php if (x_perm('home_edit')): ?><p>Aşağıdaki "Düzenle" düğmesiyle hoş geldiniz yazınızı ekleyebilirsiniz.</p><?php endif; ?></div><?php endif; ?></div>
<?php if (x_perm('home_edit')): ?>
<div id="homeBtns" style="margin-top:14px"><button class="btn btn-g btn-xs" type="button" onclick="homeEdit(true)"><?=svg('edit',12)?> Düzenle</button></div>
<form method="POST" action="?action=home_save&tab=home" id="homeForm" style="display:none"><input type="hidden" name="key" value="<?=x_h($hk)?>"><?=x_rich_editor('homeContent','content',(string)$hc['content'],'Hoş geldiniz yazısını buraya yazın...')?><div style="margin-top:12px;display:flex;gap:8px"><button class="btn btn-g" type="submit"><?=svg('check',13)?> Kaydet</button><button class="btn btn-xs" type="button" onclick="homeEdit(false)">Vazgeç</button></div></form>
<script>function homeEdit(on){document.getElementById('homeForm').style.display=on?'block':'none';document.getElementById('homeShow').style.display=on?'none':'block';document.getElementById('homeBtns').style.display=on?'none':'block'}</script>
<?php endif; ?>
</div></div>
<?php elseif ($tab==='dosya' || $tab==='all'): ?>
<?php if (x_perm('dosya_add')): ?>
<div class="panel">
    <button class="panel-toggle" onclick="tPanel(this)"><?=svg('upload',13)?> Dosya Yükle<span class="ar"><?=svg('chevron-down',11)?></span></button>
    <div class="panel-body">
        <form method="POST" action="?action=upload&tab=dosya" enctype="multipart/form-data" onsubmit="return prepareRichForm(this,'dosyaUploadDescription')"><?=x_ws_field('dosya')?>
            <div class="form-grid">
                <div class="fg"><label>Dosya Adı</label><input type="text" name="name" placeholder="örn: WSO v2.5" required></div>
                <div class="fg"><label>Kategori</label><select name="category_id"><option value="">Kategorisiz</option><?php foreach ($cats as $c): $pr=$c['parent']?x_cat_name($cats,$c['parent']).' → ':''; ?><option value="<?=$c['id']?>"><?=$pr.x_h($c['name'])?></option><?php endforeach; ?></select></div>
                <div class="fg fw"><label>Açıklama</label><?=x_rich_editor('dosyaUploadDescription','description','','Açıklamayı buraya yazın...')?></div>
                <div class="fg"><label>Dosya <span style="text-transform:none;font-weight:400;color:var(--text3)">(pakete dosya eklediysen boş bırakabilirsin)</span></label><div class="file-zone" id="ufz"><?=svg('upload',14)?> <span class="fzt">Dosya seçmek için tıklayın</span><span class="fzn" style="display:none"></span><input type="file" name="dosya_arsiv" onchange="fu(this,'ufz')"></div></div><?=x_st_select('',false)?><?=x_dl_select('')?>
                <div class="fg"><label>Ekran Görüntüsü</label><div class="file-zone" id="usz"><?=svg('image',14)?> <span class="fzt">Görsel(ler) — birden fazla seçilebilir</span><span class="fzn" style="display:none"></span><input type="file" name="screenshot[]" multiple accept="image/*" onchange="fu(this,'usz')"></div><?=x_url_input('screenshot_url')?></div>
<div class="fw"><div class="toggle-row"><label class="sw"><input type="checkbox" name="show_code" value="1"><span class="sl"></span></label><span class="swl">Kod içeriğini göster</span></div></div><?=x_pack_field('dosya',array(),'',array('enc'=>false,'php'=>''))?>
                <div class="fg fw"><label>Video (opsiyonel)</label><?=x_video_form('uVfz')?></div>
                <div class="fg fw"><label>Dosya (opsiyonel)</label><div class="file-zone" id="uNf"><?=svg('upload',14)?> <span class="fzt">Dosya seçmek için tıklayın (birden fazla seçilebilir)</span><span class="fzn" style="display:none"></span><input type="file" name="nfile[]" multiple onchange="nfu(this,'uNf')"></div><div class="nf-names"></div><?=x_nf_opts()?></div>
                <div class="fw"><button class="btn btn-g" type="submit"><?=svg('upload',13)?> Yükle</button></div>
            </div>
        </form>
    </div>
</div>

<div class="panel">
    <button class="panel-toggle" onclick="tPanel(this)"><?=svg('code',13)?> Kod Editörü — Dosya Oluştur<span class="ar"><?=svg('chevron-down',11)?></span></button>
    <div class="panel-body">
        <form method="POST" action="?action=create&tab=dosya" enctype="multipart/form-data" onsubmit="return prepareRichForm(this,'dosyaCreateDescription')"><?=x_ws_field('dosya')?>
            <div class="form-grid">
                <div class="fg"><label>Dosya Adı</label><input type="text" name="name" placeholder="örn: dosya" required></div>
                <div class="fg"><label>İndirilecek Dosya Adı</label><input type="text" name="filename" placeholder="örn: dosya.php" required></div>
                <div class="fg"><label>Kategori</label><select name="category_id"><option value="">Kategorisiz</option><?php foreach ($cats as $c): $pr=$c['parent']?x_cat_name($cats,$c['parent']).' → ':''; ?><option value="<?=$c['id']?>"><?=$pr.x_h($c['name'])?></option><?php endforeach; ?></select></div>
                <div class="fg"><label>Açıklama</label><?=x_rich_editor('dosyaCreateDescription','description','','Açıklamayı buraya yazın...')?></div>
                <div class="fg fw"><label>Kod İçeriği</label><textarea name="content" rows="12" placeholder="&lt;?php&#10;// Kod buraya&#10;?&gt;" spellcheck="false"></textarea></div>
                <div class="fg"><label>Ekran Görüntüsü</label><div class="file-zone" id="csz"><?=svg('image',14)?> <span class="fzt">Görsel(ler) — birden fazla seçilebilir</span><span class="fzn" style="display:none"></span><input type="file" name="screenshot[]" multiple accept="image/*" onchange="fu(this,'csz')"></div><?=x_url_input('screenshot_url')?></div>
<div class="fg"><div class="toggle-row"><label class="sw"><input type="checkbox" name="has_password" value="1"><span class="sl"></span></label><span class="swl">Şifre korumalı</span></div><div class="toggle-row"><label class="sw"><input type="checkbox" name="show_code" value="1"><span class="sl"></span></label><span class="swl">Kod içeriğini göster</span></div><?=x_php_field('php_version','')?></div>
                <div class="fg fw"><label>Video (opsiyonel)</label><?=x_video_form('cVfz')?></div>
                <div class="fg fw"><label>Dosya (opsiyonel)</label><div class="file-zone" id="cNf"><?=svg('upload',14)?> <span class="fzt">Dosya seçmek için tıklayın (birden fazla seçilebilir)</span><span class="fzn" style="display:none"></span><input type="file" name="nfile[]" multiple onchange="nfu(this,'cNf')"></div><div class="nf-names"></div><?=x_nf_opts()?></div>
                <div class="fw"><button class="btn btn-g" type="submit"><?=svg('plus',13)?> Oluştur</button></div>
            </div>
        </form>
    </div>
</div>

<div class="panel">
    <button class="panel-toggle" onclick="tPanel(this)"><?=svg('tag',13)?> Kategori Yönetimi<span class="ar"><?=svg('chevron-down',11)?></span></button>
    <div class="panel-body">
        <div class="cat-chips">
            <?php foreach ($cats as $c): ?>
            <span class="cat-chip"><form method="POST" action="?action=cat_edit&tab=dosya" class="cat-edit-form"><input type="hidden" name="cat_id" value="<?=x_h($c['id'])?>"><input class="cat-name-input" type="text" name="cat_name" value="<?=x_h($c['name'])?>" aria-label="Kategori adı"><button class="cat-edit" type="submit" title="Kategori adını kaydet" aria-label="Kategori adını kaydet"><?=svg('check',11)?></button></form><?php if ($c['parent']):?><span class="cat-sub">(alt: <?=x_h(x_cat_name($cats,$c['parent']))?>)</span><?php endif;?><a class="del" href="?action=cat_delete&id=<?=$c['id']?>&tab=dosya" onclick="return confirm('Kategori silinsin mi?')">&times;</a></span>
            <?php endforeach; ?>
        </div>
        <form method="POST" action="?action=cat_add&tab=dosya" class="add-cat-form">
            <input type="text" name="cat_name" placeholder="Kategori adı" required>
            <select name="cat_parent"><option value="">Ana kategori</option><?php foreach (x_cat_tree($cats) as $c):?><option value="<?=$c['id']?>">Alt: <?=x_h($c['name'])?></option><?php endforeach;?></select>
            <button class="btn btn-o btn-xs" type="submit"><?=svg('plus',11)?> Ekle</button>
        </form>
    </div>
</div>
<?php endif; ?>

<?php if (($tab==='dosya' && empty($dosya)) || ($tab==='all' && empty($dosya) && empty($github))): ?>
<?php if ($tab==='dosya'): ?><?=x_empty_html('dosya')?><?php else: ?><div class="empty"><?=svg('file',32)?><h3>Bu kategoride içerik yok</h3><?php if (x_admin()):?><p>Yukarıdaki panelden dosya veya GitHub bağlantısı ekleyebilirsiniz.</p><?php endif;?></div><?php endif; ?>
<?php elseif (!empty($dosya)): ?>
<form method="POST" action="?action=bulk_delete&tab=dosya" class="bulk-form" onsubmit="return confirmBulk(this)"><input type="hidden" name="type" value="dosya"><?php if (x_perm('dosya_delete')): ?><div class="bulk-toolbar"><button class="btn btn-or btn-xs bulk-delete" type="submit" disabled style="display:none"><?=svg('trash',11)?> Seçilenleri sil</button><span class="bulk-count" style="display:none"></span></div><?php endif; ?>

<div class="table-wrap">
<table id="dosyaTable" data-type="dosya">
<thead><tr>
    <?php if ($canSort): ?><th class="col-drag"></th><?php endif; ?><?php if (x_perm('dosya_delete')): ?><th class="select-cell"><input type="checkbox" class="select-all" onchange="toggleBulk(this)" aria-label="Tüm dosyaları seç"></th><?php endif; ?><th class="col-pin"></th>
    <th class="col-thumb"></th>
    <th class="col-name">Ad</th>
    <th class="col-desc">Açıklama</th>
    <th class="col-cat">Kategori</th>
    <th class="col-pass">Durum</th>
    <th class="col-php">PHP</th>
    <th class="col-file">Dosya</th>
    <th class="col-date">Tarih</th>
    <th class="col-actions">İşlem</th>
</tr></thead>
<tbody>
<?php foreach ($dosya as $sh):
    $ext=pathinfo((isset($sh['original_name']) ? $sh['original_name'] : ''),PATHINFO_EXTENSION);
    $pinned=(isset($sh['pinned']) ? $sh['pinned'] : false);
    $searchData=x_h(strtolower($sh['name'].' '.((isset($sh['description']) ? $sh['description'] : '')).' '.((isset($sh['original_name']) ? $sh['original_name'] : '')).' '.x_cat_name($cats,(isset($sh['category_id']) ? $sh['category_id'] : null)).' '.implode(' ',array_column(x_item_files($sh),'name'))));
?>
<tr class="<?=$pinned?'pinned':''?>" data-id="<?=x_h($sh['id'])?>" data-search="<?=$searchData?>">
    <?php if ($canSort): ?><td class="col-drag"><span class="drag-h" title="Sürükleyerek sırala">&#8942;&#8942;</span></td><?php endif; ?><?php if (x_perm('dosya_delete')): ?><td class="select-cell"><input type="checkbox" name="ids[]" value="<?=x_h($sh['id'])?>" onchange="syncBulk(this)" aria-label="<?=x_h($sh['name'])?> seç"></td><?php endif; ?><td class="col-pin"><?php if ($pinned):?><?=svg('pin',13)?><?php endif;?></td>
    <td class="col-thumb">
        <?php $mt=x_media_thumb($sh,'dosya'); if ($mt!==''): ?><?=$mt?>
        <?php elseif (x_img_ok(isset($sh['screenshot']) ? $sh['screenshot'] : '')): ?>
        <img class="thumb-img" src="?action=thumb&id=<?=$sh['id']?>&v=<?=x_img_v((isset($sh['screenshot']) ? $sh['screenshot'] : ''))?>" alt="" loading="lazy" onclick="showModal('?action=screenshot&id=<?=$sh['id']?>&v=<?=x_img_v((isset($sh['screenshot']) ? $sh['screenshot'] : ''))?>')">
        <?php if (x_perm('media_delete')):?><a class="img-remove" href="?action=remove_screenshot&id=<?=$sh['id']?>&tab=dosya" onclick="return confirm('Bu resmi silmek istiyor musunuz?')">Resmi sil</a><?php endif;?>
        <?php else: ?>
        <span class="thumb-placeholder"><?=svg('file',14)?></span>
        <?php endif; ?>
    </td>
<td class="col-name"><button class="td-name archive-open-button" type="button" onclick="viewdosya(<?=htmlspecialchars(json_encode(x_ci($sh,'description')+['_v'=>x_img_v((isset($sh['screenshot']) ? $sh['screenshot'] : ''))]+x_gal_meta($sh,'screenshot')+['_t'=>'dosya'],JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)"><?=x_h($sh['name'])?></button><?=x_dl_badge($sh)?></td>
    <td class="col-desc"><button class="td-desc td-desc-button" type="button" title="Açıklamayı görmek için tıklayın" onclick="viewdosya(<?=htmlspecialchars(json_encode(x_ci($sh,'description')+['_v'=>x_img_v((isset($sh['screenshot']) ? $sh['screenshot'] : ''))]+x_gal_meta($sh,'screenshot')+['_t'=>'dosya'],JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)"><?=x_rich((isset($sh['description']) ? $sh['description'] : ''),true)?:'—'?></button></td>
    <td class="col-cat"><?php if ((isset($sh['category_id']) ? $sh['category_id'] : null)):?><span class="badge badge-b"><?=x_h(x_cat_name($cats,$sh['category_id']))?></span><?php else:?><span style="color:var(--text3)">—</span><?php endif;?></td>
    <td class="col-pass"><?php if ($sh['has_password']):?><span class="badge badge-r"><?=svg('lock',9)?> Şifreli</span><?php else:?><span class="badge badge-g"><?=svg('unlock',9)?> Açık</span><?php endif;?></td><td class="col-php"><?=x_php_badges($sh)?></td>
    <td><span class="td-file"><?=x_h((isset($sh['original_name']) ? $sh['original_name'] : '—'))?></span></td>
    <td class="td-date"><?=x_h(date('d.m.y - H:i',strtotime((isset($sh['date_added']) ? $sh['date_added'] : 'now'))))?></td>
    <td class="col-actions"><div class="row-actions">
        <button class="btn btn-o btn-xs" type="button" onclick="viewdosya(<?=htmlspecialchars(json_encode(x_ci($sh,'description')+['_v'=>x_img_v((isset($sh['screenshot']) ? $sh['screenshot'] : ''))]+x_gal_meta($sh,'screenshot')+['_t'=>'dosya'],JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)" data-ab="view" title="Görüntüle"><?=svg(x_ab_icon('view','eye'),11)?></button>
        <?php if (x_pack_list($sh)): ?><button class="btn btn-ob btn-xs" type="button" data-pack="<?=x_pack_modal_data('dosya',$sh)?>" onclick="packOpen(this)" data-ab="pack" title="Paketli — tüm sürümleri indir"><?=svg('download',11)?><?=svg(x_ab_icon('pack','layers'),11)?></button><?php else: ?><a class="btn btn-ob btn-xs" href="?action=download&id=<?=$sh['id']?>" data-ab="download" title="İndir"><?=svg(x_ab_icon('download','download'),11)?></a><?php endif; ?>
        <?php if (x_admin()):?>
        <?php if (x_perm_it('dosya_edit',$sh)): ?><a class="btn btn-o btn-xs" href="?action=edit&id=<?=$sh['id']?>" title="Düzenle" style="color:var(--amber)" data-ab="edit"><?=svg(x_ab_icon('edit','edit'),11)?></a><?php endif; ?>
        <?php if (x_perm('dosya_pin')): ?><a class="btn btn-o btn-xs archive-pin-action <?=$pinned?'is-pinned':''?>" href="?action=pin&id=<?=$sh['id']?>&tab=dosya" title="<?=$pinned?'Kaldır':'Sabitle'?>" data-ab="pin"><?=svg(x_ab_icon('pin','pin'),11)?></a><?php endif; ?>
        <?php if (x_perm_it('dosya_delete',$sh)): ?><a class="btn btn-or btn-xs" href="?action=delete&id=<?=$sh['id']?>&tab=dosya" onclick="return confirm('Silinsin mi?')" title="Sil" data-ab="delete"><?=svg(x_ab_icon('delete','trash'),11)?></a><?php endif; ?>
        <?php endif;?>
        </div></td>
</tr>
<?php endforeach; ?>
</tbody></table></div>
</form>
<?php endif; ?>
<?php if (!empty($github) && ($tab==='github' || $tab==='all')): ?>
<?php if ($tab==='all'): ?><form method="POST" action="?action=bulk_delete&tab=github" class="bulk-form" onsubmit="return confirmBulk(this)"><input type="hidden" name="type" value="github"><div class="bulk-toolbar"><button class="btn btn-or btn-xs bulk-delete" type="submit" disabled style="display:none"><?=svg('trash',11)?> Seçilenleri sil</button><span class="bulk-count" style="display:none"></span></div><?php endif; ?>
<div class="table-wrap" style="margin-top:16px">
<table id="githubCategoryTable"><thead><tr><?php if ($tab==='all' && x_perm('dosya_delete')): ?><th class="select-cell"><input type="checkbox" class="select-all" onchange="toggleBulk(this)" aria-label="Tüm GitHub bağlantılarını seç"></th><?php endif; ?><th class="col-pin"></th><th class="col-thumb"></th><th class="col-name">Ad</th><th class="col-desc">Açıklama</th><th class="col-cat">Kategori</th><th>Durum</th><th class="col-php">PHP</th><?php if (x_gh_col($github)): ?><th>GitHub Linki</th><?php endif; ?><th>Tarih</th><th>İşlem</th></tr></thead><tbody>
<?php foreach ($github as $gh): $gp=(isset($gh['pinned']) ? $gh['pinned'] : false); $gs=x_h(strtolower($gh['name'].' '.((isset($gh['description']) ? $gh['description'] : '')).' '.((x_admin()||x_gh_flag($gh,'gh_link',true)||x_gh_flag($gh,'gh_copy',true))?$gh['url']:'').' '.implode(' ',array_column(x_item_files($gh),'name')))); $shortUrl=mb_strlen($gh['url'])>42?mb_substr($gh['url'],0,39).'…':$gh['url']; ?>
<tr class="<?=$gp?'pinned':''?>" data-search="<?=$gs?>"><?php if ($tab==='all' && x_perm('dosya_delete')): ?><td class="select-cell"><input type="checkbox" name="ids[]" value="<?=x_h($gh['id'])?>" onchange="syncBulk(this)" aria-label="<?=x_h($gh['name'])?> seç"></td><?php endif; ?><td class="col-pin"><?php if ($gp):?><?=svg('pin',13)?><?php endif;?></td><td class="col-thumb"><?php $mt=x_media_thumb($gh,'github'); if ($mt!==''):?><?=$mt?><?php elseif (x_img_ok(isset($gh['image']) ? $gh['image'] : '')):?><img class="thumb-img" src="?action=github_image&id=<?=x_h($gh['id'])?>&v=<?=x_img_v((isset($gh['image']) ? $gh['image'] : ''))?>" alt="<?=x_h($gh['name'])?>" loading="lazy" onclick="showModal('?action=github_image&id=<?=x_h($gh['id'])?>&v=<?=x_img_v((isset($gh['image']) ? $gh['image'] : ''))?>')"><?php else:?><span class="thumb-placeholder"><?=svg('link',14)?></span><?php endif;?></td><td><button class="td-name github-title-button" type="button" onclick="viewGithub(<?=htmlspecialchars(json_encode(x_ci($gh,'description')+['_v'=>x_img_v((isset($gh['image']) ? $gh['image'] : ''))]+x_gal_meta($gh,'image')+['_t'=>'github'],JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)"><?=x_h($gh['name'])?></button><?=x_dl_badge($gh)?></td><td class="col-desc"><button class="td-desc td-desc-button" type="button" onclick="viewGithub(<?=htmlspecialchars(json_encode(x_ci($gh,'description')+['_v'=>x_img_v((isset($gh['image']) ? $gh['image'] : ''))]+x_gal_meta($gh,'image')+['_t'=>'github'],JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)"><?=x_rich((isset($gh['description']) ? $gh['description'] : ''),true)?:'—'?></button></td><td><span class="badge badge-b"><?=x_h(x_cat_name($cats,(isset($gh['category_id']) ? $gh['category_id'] : null)))?></span></td><td class="col-pass"><?php if (!empty($gh['encrypted'])):?><span class="badge badge-r"><?=svg('lock',9)?> Şifreli</span><?php else:?><span class="badge badge-g"><?=svg('unlock',9)?> Açık</span><?php endif;?></td><td class="col-php"><?=x_php_badges($gh)?></td><?php if (x_gh_col($github)): ?><td class="github-url-cell"><?php if (empty($gh['pack_only']) && (x_admin() || x_gh_flag($gh,'gh_link',true))): ?><a href="<?=x_h($gh['url'])?>" target="_blank" rel="noopener noreferrer" class="td-file" title="<?=x_h($gh['url'])?>"><?=x_h($shortUrl)?></a><?php endif; ?></td><?php endif; ?><td class="td-date"><?=x_h(date('d.m.y - H:i',strtotime((isset($gh['date_added']) ? $gh['date_added'] : 'now'))))?></td><td class="col-actions"><div class="row-actions"><?php if (empty($gh['pack_only']) && (x_admin() || x_gh_flag($gh,'gh_copy',true))): ?><button class="btn btn-cp btn-xs" data-ab="copy" type="button" data-github-id="<?=x_h($gh['id'])?>" onclick="copyGithub(this,<?=htmlspecialchars(json_encode($gh['url']), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)" title="GitHub linkini kopyala"><?=svg(x_ab_icon('copy','copy'),11)?> Kopyala</button><?php endif; ?><?php if (empty($gh['pack_only']) && (x_admin() || x_gh_flag($gh,'gh_dl',false))): ?><a class="btn btn-ob btn-xs" href="?action=github_download&id=<?=x_h($gh['id'])?>" data-ab="download" title="İndir"><?=svg(x_ab_icon('download','download'),11)?> İndir</a><?php endif; ?><?php if (x_pack_list($gh)): ?><button class="btn btn-ob btn-xs" type="button" data-pack="<?=x_pack_modal_data('github',$gh)?>" onclick="packOpen(this)" data-ab="pack" title="Paketli — tüm sürümleri indir"><?=svg('download',11)?><?=svg(x_ab_icon('pack','layers'),11)?> İndir</button><?php endif; ?></div></td></tr>
<?php endforeach; ?></tbody></table></div><?php if ($tab==='all'): ?></form><?php endif; ?>
<?php endif; ?>

<?php elseif ($tab==='github'): ?>
<?php if (x_perm('github_add')): ?>
<div class="panel">
    <button class="panel-toggle" onclick="tPanel(this)"><?=svg('plus',13)?> Yeni GitHub Bağlantısı<span class="ar"><?=svg('chevron-down',11)?></span></button>
    <div class="panel-body">
        <form method="POST" action="?action=github_add&tab=github" enctype="multipart/form-data"><?=x_ws_field('github')?>
            <div class="form-grid">
                <div class="fg"><label>İsim</label><input type="text" name="name" placeholder="Proje adı" required></div>
                <div class="fg"><label>Dosya Linki <span style="text-transform:none;font-weight:400;color:var(--text3)">(GitHub raw / github.com veya kendi sitenizdeki dosya adresi)</span></label><input type="text" inputmode="url" name="url" placeholder="https://raw.githubusercontent.com/... veya siteadi.com/dosya.php"></div>
                <div class="fg fw"><label>Açıklama</label><?=x_rich_editor('githubAddDescription','description','','Açıklamayı buraya yazın...')?></div>
                <div class="fg"><label>Kategori</label><select name="category_id"><option value="">Kategorisiz</option><?php foreach ($cats as $cat): ?><option value="<?=x_h($cat['id'])?>"><?=x_h($cat['name'])?></option><?php endforeach; ?></select></div>
                <div class="fg"><div class="toggle-row"><label class="sw"><input type="checkbox" name="show_code" value="1" checked><span class="sl"></span></label><span class="swl">Kod bilgilerini göster</span></div></div><?=x_gh_toggles(array())?><?=x_pack_field('github',array(),'',array('enc'=>false,'php'=>''))?>
                <div class="fg fw"><label>Resim (opsiyonel)</label><div class="file-zone" id="ghfz"><?=svg('upload',14)?> <span class="fzt">Görselleri seçmek için tıklayın (birden fazla)</span><span class="fzn" style="display:none"></span><input type="file" name="image[]" multiple accept="image/*" onchange="fu(this,'ghfz')"></div><?=x_url_input('image_url')?></div>
                <div class="fg fw"><label>Video (opsiyonel)</label><?=x_video_form('ghVfz')?></div>
                <div class="fg fw"><label>Dosya (opsiyonel)</label><div class="file-zone" id="ghNf"><?=svg('upload',14)?> <span class="fzt">Dosya seçmek için tıklayın (birden fazla seçilebilir)</span><span class="fzn" style="display:none"></span><input type="file" name="nfile[]" multiple onchange="nfu(this,'ghNf')"></div><div class="nf-names"></div><?=x_nf_opts()?></div>
                <div class="fw"><button class="btn btn-g" type="submit"><?=svg('plus',13)?> Ekle</button></div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php if (empty($data['github'])): ?>
<?=x_empty_html('github')?>
<?php else: ?>
<form method="POST" action="?action=bulk_delete&tab=github" class="bulk-form" onsubmit="return confirmBulk(this)"><input type="hidden" name="type" value="github"><?php if (x_perm('github_delete')): ?><div class="bulk-toolbar"><button class="btn btn-or btn-xs bulk-delete" type="submit" disabled style="display:none"><?=svg('trash',11)?> Seçilenleri sil</button><span class="bulk-count" style="display:none"></span></div><?php endif; ?>

<div class="table-wrap"><table id="githubTable" data-type="github"><thead><tr><?php if ($canSort): ?><th class="col-drag"></th><?php endif; ?><?php if (x_perm('github_delete')): ?><th class="select-cell"><input type="checkbox" class="select-all" onchange="toggleBulk(this)" aria-label="Tüm GitHub bağlantılarını seç"></th><?php endif; ?><th class="col-pin"></th><th class="col-thumb"></th><th class="col-name">Ad</th><th class="col-desc">Açıklama</th><th class="col-cat">Kategori</th><th>Durum</th><th class="col-php">PHP</th><?php if (x_gh_col($github)): ?><th>GitHub Linki</th><?php endif; ?><th>Tarih</th><th>İşlem</th></tr></thead><tbody>
<?php foreach ($github as $gh): $gp=(isset($gh['pinned']) ? $gh['pinned'] : false); $gs=x_h(strtolower($gh['name'].' '.((isset($gh['description']) ? $gh['description'] : '')).' '.((x_admin()||x_gh_flag($gh,'gh_link',true)||x_gh_flag($gh,'gh_copy',true))?$gh['url']:'').' '.implode(' ',array_column(x_item_files($gh),'name')))); $shortUrl=mb_strlen($gh['url'])>42?mb_substr($gh['url'],0,39).'…':$gh['url']; ?>
<tr class="<?=$gp?'pinned':''?>" data-id="<?=x_h($gh['id'])?>" data-search="<?=$gs?>"><?php if ($canSort): ?><td class="col-drag"><span class="drag-h" title="Sürükleyerek sırala">&#8942;&#8942;</span></td><?php endif; ?><?php if (x_perm('github_delete')): ?><td class="select-cell"><input type="checkbox" name="ids[]" value="<?=x_h($gh['id'])?>" onchange="syncBulk(this)" aria-label="<?=x_h($gh['name'])?> seç"></td><?php endif; ?><td class="col-pin"><?php if ($gp):?><?=svg('pin',13)?><?php endif;?></td><td class="col-thumb"><?php $mt=x_media_thumb($gh,'github'); if ($mt!==''):?><?=$mt?><?php elseif (x_img_ok(isset($gh['image']) ? $gh['image'] : '')):?><img class="thumb-img" src="?action=github_image&id=<?=x_h($gh['id'])?>&v=<?=x_img_v((isset($gh['image']) ? $gh['image'] : ''))?>" alt="<?=x_h($gh['name'])?>" loading="lazy" onclick="showModal('?action=github_image&id=<?=x_h($gh['id'])?>&v=<?=x_img_v((isset($gh['image']) ? $gh['image'] : ''))?>')"><?php if (x_perm('media_delete')):?><a class="img-remove" href="?action=github_remove_image&id=<?=x_h($gh['id'])?>&tab=github" onclick="return confirm('Bu resmi silmek istiyor musunuz?')">Resmi sil</a><?php endif;?><?php else:?><span class="thumb-placeholder"><?=svg('link',14)?></span><?php endif;?></td><td><button class="td-name github-title-button" type="button" onclick="viewGithub(<?=htmlspecialchars(json_encode(x_ci($gh,'description')+['_v'=>x_img_v((isset($gh['image']) ? $gh['image'] : ''))]+x_gal_meta($gh,'image')+['_t'=>'github'],JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)"><?=x_h($gh['name'])?></button><?=x_dl_badge($gh)?></td><td class="col-desc"><button class="td-desc td-desc-button" type="button" title="Açıklamayı görmek için tıklayın" onclick="viewGithub(<?=htmlspecialchars(json_encode(x_ci($gh,'description')+['_v'=>x_img_v((isset($gh['image']) ? $gh['image'] : ''))]+x_gal_meta($gh,'image')+['_t'=>'github'],JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)"><?=x_rich((isset($gh['description']) ? $gh['description'] : ''),true)?:'—'?></button></td><td class="col-cat"><?php if ((isset($gh['category_id']) ? $gh['category_id'] : null)): ?><span class="badge badge-b"><?=x_h(x_cat_name($cats,$gh['category_id']))?></span><?php else: ?><span style="color:var(--text3)">—</span><?php endif; ?></td><td class="col-pass"><?php if (!empty($gh['encrypted'])):?><span class="badge badge-r"><?=svg('lock',9)?> Şifreli</span><?php else:?><span class="badge badge-g"><?=svg('unlock',9)?> Açık</span><?php endif;?></td><td class="col-php"><?=x_php_badges($gh)?></td><?php if (x_gh_col($github)): ?><td class="github-url-cell"><?php if (empty($gh['pack_only']) && (x_admin() || x_gh_flag($gh,'gh_link',true))): ?><a href="<?=x_h($gh['url'])?>" target="_blank" rel="noopener noreferrer" class="td-file" title="<?=x_h($gh['url'])?>"><?=x_h($shortUrl)?></a><?php endif; ?></td><?php endif; ?><td class="td-date"><?=x_h(date('d.m.y - H:i',strtotime((isset($gh['date_added']) ? $gh['date_added'] : 'now'))))?></td><td><div style="display:flex;gap:3px"><?php if (empty($gh['pack_only']) && (x_admin() || x_gh_flag($gh,'gh_copy',true))): ?><button class="btn btn-cp btn-xs" data-ab="copy" type="button" data-github-id="<?=x_h($gh['id'])?>" onclick="copyGithub(this,<?=htmlspecialchars(json_encode($gh['url']), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)"><?=svg(x_ab_icon('copy','copy'),11)?> Kopyala</button><?php endif; ?><?php if (empty($gh['pack_only']) && (x_admin() || x_gh_flag($gh,'gh_dl',false))): ?><a class="btn btn-ob btn-xs" href="?action=github_download&id=<?=x_h($gh['id'])?>" data-ab="download" title="İndir"><?=svg(x_ab_icon('download','download'),11)?> İndir</a><?php endif; ?><?php if (x_pack_list($gh)): ?><button class="btn btn-ob btn-xs" type="button" data-pack="<?=x_pack_modal_data('github',$gh)?>" onclick="packOpen(this)" data-ab="pack" title="Paketli — tüm sürümleri indir"><?=svg('download',11)?><?=svg(x_ab_icon('pack','layers'),11)?> İndir</button><?php endif; ?><?php if (x_admin() && !x_is_editor() && x_perm('dosya_add') && x_type_any_on('dosya')): ?><a class="btn btn-o btn-xs" href="?action=github_archive&id=<?=x_h($gh['id'])?>&tab=github" onclick="return confirm('Bu GitHub kaydı (linkler, paket, görsel ve açıklama dahil) Dosya Arşivi\'ne yedeklensin mi? Dosyalar sunucuya indirilecek.')" title="Dosya Arşivi'ne yedekle" data-ab="arch"><?=svg(x_ab_icon('arch','folder'),11)?></a><?php endif; ?><?php if (x_admin()):?><?php if (x_perm_it('github_edit',$gh)): ?><a class="btn btn-o btn-xs" href="?action=github_edit&id=<?=$gh['id']?>" title="Düzenle" style="color:var(--amber)" data-ab="edit"><?=svg(x_ab_icon('edit','edit'),11)?></a><?php endif; ?><?php if (x_perm('github_pin')): ?><a class="btn btn-o btn-xs" href="?action=github_pin&id=<?=$gh['id']?>&tab=github" title="Sabitle" style="color:<?=$gp?'var(--amber)':'var(--text3)'?>" data-ab="pin"><?=svg(x_ab_icon('pin','pin'),11)?></a><?php endif; ?><?php if (x_perm_it('github_delete',$gh)): ?><a class="btn btn-or btn-xs" href="?action=github_delete&id=<?=$gh['id']?>&tab=github" onclick="return confirm('Silinsin mi?')" title="Sil" data-ab="delete"><?=svg(x_ab_icon('delete','trash'),11)?></a><?php endif; ?><?php endif;?></div></td></tr>
<?php endforeach; ?></tbody></table></div></form>
<?php endif; ?>

<?php else: ?>
<?php if (x_perm('note_add')): ?>
<div class="panel">
<button class="panel-toggle" onclick="tPanel(this)"><?=svg('plus',13)?> Yeni Bilgi Ekle<span class="ar"><?=svg('chevron-down',11)?></span></button>
    <div class="panel-body">
        <form method="POST" action="?action=note_add&tab=notes" enctype="multipart/form-data" onsubmit="return prepareRichForm(this,'noteAddEditor')"><?=x_ws_field('notes')?>
            <div class="form-grid">
                <div class="fg"><label>Başlık</label><input type="text" name="title" placeholder="Bilgi başlığı (boş bırakılırsa yazıdan alınır)..."></div>
<div class="fg fw"><label>İçerik</label><div class="rich-editor"><div class="rich-toolbar" role="toolbar" aria-label="İçerik biçimlendirme"><button type="button" onclick="richCmd('bold','noteAddEditor')" title="Kalın"><strong>B</strong></button><button type="button" onclick="richCmd('italic','noteAddEditor')" title="İtalik"><em>I</em></button><button type="button" onclick="richCmd('underline','noteAddEditor')" title="Altı çizili"><u>U</u></button><button type="button" onclick="richCmd('insertUnorderedList','noteAddEditor')" title="Liste">•</button><button type="button" onclick="richCmd('formatBlock','noteAddEditor','h3')" title="Başlık">H</button><select class="rich-size-select" onchange="richCmd('fontSize','noteAddEditor',this.value)" title="Yazı boyutu"><option value="" selected disabled hidden>Boyut</option><option value="2">Küçük</option><option value="3">Normal</option><option value="5">Büyük</option><option value="7">Çok büyük</option></select><input type="color" onchange="richCmd('foreColor','noteAddEditor',this.value)" title="Yazı rengi"><input type="color" onchange="richCmd('hiliteColor','noteAddEditor',this.value)" title="Yazı arka plan rengi (vurgu)"><button type="button" onclick="richCmd('hiliteColor','noteAddEditor','transparent')" title="Arka planı kaldır" style="color:#e11d2e">&#10005;</button></div><div id="noteAddEditor" class="rich-content" contenteditable="true" data-placeholder="Bilgi içeriğini buraya yazın..."></div><textarea name="content" id="noteAddContent" class="rich-value" aria-hidden="true"></textarea></div></div>
                <div class="fg fw"><label>Resim (opsiyonel)</label><div class="file-zone" id="notefz"><?=svg('upload',14)?> <span class="fzt">Görselleri seçmek için tıklayın (birden fazla)</span><span class="fzn" style="display:none"></span><input type="file" name="image[]" multiple accept="image/*" onchange="fu(this,'notefz')"></div><?=x_url_input('image_url')?></div>
                <div class="fg fw"><label>Video (opsiyonel)</label><?=x_video_form('noteAddVfz')?></div>
                <div class="fg fw"><label>Dosya (opsiyonel)</label><div class="file-zone" id="noteAddNf"><?=svg('upload',14)?> <span class="fzt">Dosya seçmek için tıklayın (birden fazla seçilebilir)</span><span class="fzn" style="display:none"></span><input type="file" name="nfile[]" multiple onchange="nfu(this,'noteAddNf')"></div><div class="nf-names"></div><?=x_nf_opts()?></div>
                <div class="fw"><button class="btn btn-g" type="submit"><?=svg('plus',13)?> Ekle</button></div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<?php if (empty($notes)): ?>
<?=x_empty_html('notes')?>
<?php else: ?>
<form method="POST" action="?action=bulk_delete&tab=notes" class="bulk-form" onsubmit="return confirmBulk(this)"><input type="hidden" name="type" value="notes"><?php if (x_perm('note_delete')): ?><div class="bulk-toolbar"><button class="btn btn-or btn-xs bulk-delete" type="submit" disabled style="display:none"><?=svg('trash',11)?> Seçilenleri sil</button><span class="bulk-count" style="display:none"></span></div><?php endif; ?>

<div class="table-wrap">
<table class="note-table" id="noteTable" data-type="notes">
<thead><tr>
    <?php if ($canSort): ?><th class="col-drag"></th><?php endif; ?><?php if (x_perm('note_delete')): ?><th class="select-cell"><input type="checkbox" class="select-all" onchange="toggleBulk(this)" aria-label="Tüm bilgileri seç"></th><?php endif; ?><th class="col-pin"></th>
    <th class="col-thumb"></th>
    <th class="col-n-title">Başlık</th>
    <th class="col-n-content">İçerik</th>
    <th class="col-n-date">Tarih</th>
    <th class="col-n-actions">İşlem</th>
</tr></thead>
<tbody>
<?php foreach ($notes as $note):
    $np=(isset($note['pinned']) ? $note['pinned'] : false);
    $searchData=x_h(strtolower($note['title'].' '.$note['content'].' '.implode(' ',array_column(x_item_files($note),'name'))));
?>
<tr class="<?=$np?'pinned':''?>" data-id="<?=x_h($note['id'])?>" data-search="<?=$searchData?>">
    <?php if ($canSort): ?><td class="col-drag"><span class="drag-h" title="Sürükleyerek sırala">&#8942;&#8942;</span></td><?php endif; ?><?php if (x_perm('note_delete')): ?><td class="select-cell"><input type="checkbox" name="ids[]" value="<?=x_h($note['id'])?>" onchange="syncBulk(this)" aria-label="<?=x_h($note['title'])?> seç"></td><?php endif; ?><td class="col-pin"><?php if ($np):?><?=svg('pin',13)?><?php endif;?></td>
    <td class="col-thumb"><?=x_note_thumb($note)?></td>
    <td><button class="note-title note-title-button" type="button" onclick="viewNote(<?=htmlspecialchars(json_encode(x_ci($note,'content')+['_v'=>x_img_v((isset($note['image']) ? $note['image'] : ''))]+x_gal_meta($note,'image'),JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)"><?=x_h($note['title'])?></button><?php if (x_item_files($note)): ?><span class="nf-badge" title="Ekli dosya">&#128206; <?=count(x_item_files($note))?></span><?php endif; ?></td>
    <td><button class="note-content td-desc-button" type="button" title="İçeriğin tamamını görmek için tıklayın" onclick="viewNote(<?=htmlspecialchars(json_encode(x_ci($note,'content')+['_v'=>x_img_v((isset($note['image']) ? $note['image'] : ''))]+x_gal_meta($note,'image'),JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)"><?=x_rich($note['content'],true)?:'—'?></button></td>
    <td class="td-date"><?=x_h(date('d.m.y - H:i',strtotime((isset($note['date_added']) ? $note['date_added'] : 'now'))))?></td>
    <td>
        <div style="display:flex;gap:3px">
            <button class="btn btn-o btn-xs" onclick="viewNote(<?=htmlspecialchars(json_encode(x_ci($note,'content')+['_v'=>x_img_v((isset($note['image']) ? $note['image'] : ''))]+x_gal_meta($note,'image'),JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)" data-ab="view" title="Görüntüle"><?=svg(x_ab_icon('view','eye'),11)?></button>
            <?php if (x_admin()):?>
            <?php if (x_perm_it('note_edit',$note)): ?><button class="btn btn-o btn-xs" onclick="editNote(<?=htmlspecialchars(json_encode(x_ci($note,'content')+['_v'=>x_img_v((isset($note['image']) ? $note['image'] : ''))]+x_gal_meta($note,'image'),JSON_UNESCAPED_UNICODE), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')?>)" title="Düzenle" style="color:var(--amber)" data-ab="edit"><?=svg(x_ab_icon('edit','edit'),11)?></button><?php endif; ?>
            <?php if (x_perm('note_pin')): ?><a class="btn btn-o btn-xs" href="?action=note_pin&id=<?=$note['id']?>&tab=notes" title="<?=$np?'Kaldır':'Sabitle'?>" style="color:<?=$np?'var(--amber)':'var(--text3)'?>" data-ab="pin"><?=svg(x_ab_icon('pin','pin'),11)?></a><?php endif; ?>
            <?php if (x_perm_it('note_delete',$note)): ?><a class="btn btn-or btn-xs" href="?action=note_delete&id=<?=$note['id']?>&tab=notes" onclick="return confirm('Not silinsin mi?')" title="Sil" data-ab="delete"><?=svg(x_ab_icon('delete','trash'),11)?></a><?php endif; ?>
            <?php endif;?>
        </div>
    </td>
</tr>
<?php endforeach; ?>
</tbody></table></div></form>
<?php endif; ?>
<?php endif; ?>

    </div>
</main>
</div>

<div class="modal-overlay" id="imgModal" onclick="closeModal()">
    <div class="modal-box" onclick="event.stopPropagation()"><button class="modal-close" onclick="closeModal()"><?=svg('x',16)?></button>
        <img id="modalImg" src="" alt="">
    </div>
</div>

<?php if ($toast): ?><div class="toast <?=($msg==='github_invalid'||$msg==='settings_none'||$msg==='site_upload_err'||$msg==='site_upload_big'||$msg==='site_upload_type'||$msg==='site_post_big'||$msg==='post_big'||$msg==='upload_fail'||!empty($_GET['imgfile'])||$msg==='acc_confirm'||$msg==='acc_short'||$msg==='acc_mismatch'||$msg==='acc_dup'||$msg==='acc_name'||$msg==='acc_self'||$msg==='act_denied'||$msg==='ban_super'||$msg==='acc_verify'||$msg==='save_failed'||$msg==='note_empty'||!empty($_GET['imgerr'])||!empty($_GET['viderr']))?'error':''?>"><?=$toast?></div><?php endif; ?>

<style>
  .toast{background:#14532d!important;border:1px solid #22c55e!important;color:#dcfce7!important}
  .toast.error{background:color-mix(in srgb,var(--green) 30%,#0a0b0f)!important;border-color:var(--green)!important;color:#fff!important}
  *{scrollbar-color:var(--border) var(--surface2);scrollbar-width:thin}*::-webkit-scrollbar{width:8px;height:8px}*::-webkit-scrollbar-thumb{background:var(--border);border-radius:8px}*::-webkit-scrollbar-thumb:hover{background:var(--green)}*::-webkit-scrollbar-track{background:var(--surface2)}.rich-editor{border:1px solid var(--border);border-radius:6px;overflow:hidden;background:var(--surface2)}.rich-toolbar{display:flex;align-items:center;gap:4px;padding:6px;border-bottom:1px solid var(--border);background:var(--surface)}.rich-toolbar button,.rich-toolbar select,.rich-toolbar input{height:28px;background:var(--surface2);border:1px solid var(--border);border-radius:4px;color:var(--text2);font:12px var(--mono);cursor:pointer}.rich-toolbar button{min-width:28px}.rich-toolbar button:hover,.rich-toolbar select:hover,.rich-toolbar select:focus{border-color:var(--green);color:var(--green)}.rich-toolbar .rich-size-select{min-width:76px;width:76px;padding:0 22px 0 7px;overflow:visible;text-overflow:clip;white-space:nowrap}.rich-toolbar input{width:32px;padding:2px}.rich-content{min-height:90px;max-height:320px;padding:10px;color:var(--text);font-size:13px;line-height:1.6;outline:none;overflow:auto;scrollbar-color:var(--border) var(--surface2);scrollbar-width:thin}.rich-content::-webkit-scrollbar{width:8px}.rich-content::-webkit-scrollbar-thumb{background:var(--border);border-radius:8px}.rich-content::-webkit-scrollbar-track{background:var(--surface2)}.rich-content:empty:before{content:attr(data-placeholder);color:var(--text3);pointer-events:none}.rich-editor:focus-within{border-color:var(--green);box-shadow:0 0 0 2px color-mix(in srgb,var(--green) 18%,transparent),inset 0 0 0 1px color-mix(in srgb,var(--green) 28%,transparent)}.rich-content:focus{box-shadow:none}.rich-content h3{margin:8px 0;color:var(--green)}.rich-content ul{padding-left:22px}.rich-value{display:none}.github-modal-box{--mp:22px;width:min(900px,94vw);max-height:90vh;overflow:auto;padding:22px;background:var(--surface);border:1px solid var(--border)}
  .archive-open-button{background:none;border:0;padding:0;cursor:pointer;font:inherit;text-align:left}.archive-open-button:hover,.github-title-button:hover{color:var(--green,#b71c1c)}.github-title-button{background:none;border:0;padding:0;cursor:pointer;font:inherit;text-align:left}.github-url-cell{max-width:170px}.github-url-cell .td-file{display:block;max-width:170px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .archive-detail-image{display:block;width:100%;max-height:300px;object-fit:contain;border-radius:8px;margin:0 auto 14px;background:var(--surface2);cursor:pointer}
  .archive-detail-description,.archive-code-panel pre{scrollbar-color:var(--border) var(--surface2);scrollbar-width:thin}.archive-code-panel pre{max-height:360px;overflow:auto;white-space:pre-wrap;word-break:break-word;line-height:1.5;margin:0;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:6px;padding:12px;color:var(--text2);font:11px var(--mono)}
  .github-modal-box::-webkit-scrollbar,.github-modal-box pre::-webkit-scrollbar,.github-detail-description::-webkit-scrollbar,.archive-detail-description::-webkit-scrollbar{width:8px;height:8px}.github-detail-description,.archive-detail-description,.github-modal-box pre{scrollbar-color:var(--border) var(--surface2);scrollbar-width:thin}.archive-detail-description{max-height:260px;overflow:auto;white-space:pre-wrap;word-break:break-word;padding:14px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:8px;color:var(--text2);line-height:1.7}.note-detail-image{display:block;max-width:100%;max-height:280px;object-fit:contain;border-radius:8px;margin:0 auto 14px;cursor:pointer}.github-modal-box::-webkit-scrollbar,.github-modal-box pre::-webkit-scrollbar.github-modal-box::-webkit-scrollbar-thumb,.github-modal-box pre::-webkit-scrollbar-thumb{background:var(--border);border-radius:8px}.github-modal-box::-webkit-scrollbar-track,.github-modal-box pre::-webkit-scrollbar-track{background:var(--surface2)}.td-desc-button{display:block;width:100%;border:0;background:none;color:inherit;font:inherit;text-align:left;padding:0;cursor:pointer}.img-remove{display:inline-block;white-space:nowrap;color:#ff4d4d;font-size:9px;margin-top:3px}.img-remove:hover{text-decoration:underline}.td-desc-button:hover{color:var(--green)}.td-desc-button>*:first-child{margin-top:0}.td-desc-button,.td-desc-button *{background:none!important}.td-desc-button{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;max-height:3.2em}
#githubModalContent{min-width:0}.github-detail-description{max-height:220px;overflow:auto;white-space:pre-wrap;word-break:break-word;padding:12px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:6px;margin-bottom:12px}.github-code-panel{position:relative}.github-code-panel pre{max-height:330px;overflow:auto;white-space:pre-wrap;word-break:break-word;line-height:1.5;margin:0}.github-code-label{font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:.08em}.github-code-heading{display:flex;align-items:center;justify-content:space-between;margin-bottom:5px}.icon-copy{display:flex;align-items:center;justify-content:center;width:28px;height:26px;border:1px solid var(--border);border-radius:5px;background:var(--surface2);color:var(--text2);cursor:pointer}.icon-copy:hover{border-color:var(--red);color:var(--red)}.icon-copy svg{width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:1.8}
  .table-wrap{width:100%;max-width:100%;max-height:max(260px,calc(100vh - 330px));overflow:auto;scrollbar-color:var(--border) var(--surface2);scrollbar-width:thin;border-radius:var(--r)}.table-wrap::-webkit-scrollbar{width:8px;height:8px}.table-wrap::-webkit-scrollbar-thumb{background:var(--border);border-radius:8px}.table-wrap::-webkit-scrollbar-thumb:hover{background:var(--amber)}.table-wrap::-webkit-scrollbar-track{background:var(--surface2)}.table-wrap table{width:100%;border-collapse:separate;border-spacing:0}.table-wrap thead th{position:sticky;top:0;z-index:2;background:var(--surface);box-shadow:0 1px 0 var(--border)}.table-wrap .col-actions{min-width:132px}.table-wrap .col-pin{width:28px;min-width:28px}.table-wrap td.col-actions>div,.table-wrap td.col-actions .row-actions{white-space:nowrap}#dosyaTable,#githubTable,.note-table{min-width:900px}.bulk-toolbar{display:flex;align-items:center;justify-content:flex-start;gap:10px;width:100%;margin:0 0 10px;padding:0;background:transparent;border:0;border-radius:0}.bulk-toolbar label{display:flex;align-items:center;gap:7px;color:var(--text2);font-size:12px;cursor:pointer}.bulk-toolbar .bulk-delete{margin:0}.select-cell{width:34px;min-width:34px;text-align:center;white-space:nowrap}.select-cell input{appearance:none;-webkit-appearance:none;width:14px;height:14px;margin:0;border:1px solid var(--border2,#4b5060);border-radius:3px;background:var(--d2,#282c36);box-shadow:inset 0 0 0 1px #171a22;cursor:pointer;vertical-align:middle}.select-cell input:hover{border-color:var(--green);background:var(--d2,#333846)}.select-cell input:checked{background:var(--green);border-color:var(--green);box-shadow:inset 0 0 0 3px var(--d2,#282c36)}.select-cell input:focus-visible{outline:2px solid var(--green);outline-offset:2px}.select-cell .bulk-delete{margin-left:6px;vertical-align:middle;text-transform:none}.note-table{min-width:760px}td.col-actions a[href*="action=pin"],td.col-actions a[href*="action=note_pin"],td.col-actions a[href*="action=github_pin"]{color:var(--amber)!important}.table-wrap td.col-actions a[href*="action=pin"]:hover,.table-wrap td.col-actions a[href*="action=note_pin"]:hover,.table-wrap td.col-actions a[href*="action=github_pin"]:hover{border-color:var(--amber);color:var(--amber)!important}@media(max-width:768px){.table-wrap{max-height:max(220px,calc(100vh - 260px))}}@media(max-height:480px){.table-wrap{max-height:max(180px,calc(100vh - 150px))}.main-top{padding:8px 12px}.tabs{padding:0 12px}.tabs a{padding:8px 10px}.main-body{padding:8px 12px}}.toggle-row.php-ver-row input.php-ver-input[type=text]{width:68px;min-width:68px;max-width:68px;padding:5px 7px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:var(--r-sm);color:var(--text2);font-size:11px;font-family:var(--mono);box-sizing:border-box}.toggle-row.php-ver-row input.php-ver-input[type=text]:not(:disabled){border-color:var(--green)}.toggle-row.php-ver-row input.php-ver-input[type=text]:focus{outline:none;border-color:var(--green);box-shadow:0 0 0 3px var(--green-glow,var(--glow))}
.table-wrap th.select-cell,.table-wrap td.select-cell{width:24px;min-width:24px;max-width:24px;padding-left:2px!important;padding-right:2px!important}
.table-wrap th.col-pin,.table-wrap td.col-pin{width:18px;min-width:18px;max-width:18px;padding-left:0!important;padding-right:0!important}
.table-wrap th.col-thumb,.table-wrap td.col-thumb{width:40px;min-width:40px;padding-left:2px!important;padding-right:4px!important}
</style>
<div class="modal-overlay" id="packModal" onclick="if(event.target===this)this.classList.remove('open')"><div class="modal-box" style="max-width:640px;border-radius:2px"><button class="modal-close" type="button" onclick="document.getElementById('packModal').classList.remove('open')" title="Kapat">&times;</button><h3 id="packTitle" style="margin:0 0 10px;font-size:15px"></h3><div id="packList"></div></div></div>
<div class="modal-overlay" id="githubModal" onclick="this.classList.remove('open');vidStopAll()">
    <div class="modal-box github-modal-box" onclick="event.stopPropagation()"><button class="modal-close" onclick="document.getElementById('githubModal').classList.remove('open');vidStopAll()"><?=svg('x',16)?></button>
        <div id="githubModalContent"></div>
    </div>
</div>

<style>.nf-list{margin-top:12px;border:1px solid var(--border);border-radius:8px;overflow-x:hidden;overflow-y:auto;max-height:240px;-webkit-overflow-scrolling:touch}.nf-title{position:sticky;top:0;z-index:1;padding:8px 12px;font-size:11px;font-weight:700;color:var(--text2);background:var(--surface2)}.nf-scroll{max-height:240px;overflow-y:auto;-webkit-overflow-scrolling:touch}.nf-names{max-height:240px;overflow-y:auto}.nf-item{display:flex;align-items:center;gap:10px;padding:9px 12px;border-top:1px solid var(--border);color:var(--text2);text-decoration:none;font-size:12px}.nf-item:hover{background:color-mix(in srgb,var(--green,#b71c1c) 8%,transparent)}.nf-nm{flex:1;min-width:0;word-break:break-all}.nf-sz{color:var(--text3);font-size:11px;white-space:nowrap}.nf-dl{padding:3px 9px;border:1px solid var(--green,#b71c1c);border-radius:5px;color:var(--green,#ff5c65);font-size:11px;white-space:nowrap}.nf-badge{margin-left:6px;font-size:10px;color:var(--text3);white-space:nowrap}.nf-names{display:flex;flex-direction:column;gap:6px;margin-top:8px}.nf-nrow{display:flex;align-items:center;gap:8px;font-size:11px;color:var(--text3)}.nf-rn{flex:1;min-width:0;padding:6px 9px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:5px;color:var(--text2);font-size:12px;outline:none}.nf-rn:focus{border-color:var(--green)}.nf-er{flex-wrap:wrap}.nf-pin{display:inline-flex;align-items:center;gap:3px;font-size:11px;color:var(--text2);cursor:pointer;white-space:nowrap}.nf-nrow{flex-wrap:wrap}.nf-dsc{flex:1 1 100%!important;width:100%}.nf-desc{display:block;margin-top:3px;font-size:11px;color:var(--text3,var(--text));word-break:break-word}</style>
<?=x_vid_assets()?><div class="modal-overlay" id="noteModal" onclick="this.classList.remove('open');vidStopAll()">
    <div class="modal-box" onclick="event.stopPropagation()" style="min-width:400px;max-width:700px"><button class="modal-close" onclick="document.getElementById('noteModal').classList.remove('open');vidStopAll()"><?=svg('x',16)?></button>
        <div id="noteModalContent"></div>
    </div>
</div>

<div class="modal-overlay" id="noteEditModal" onclick="this.classList.remove('open')">
    <div class="modal-box" onclick="event.stopPropagation()" style="min-width:400px;max-width:700px"><button class="modal-close" onclick="document.getElementById('noteEditModal').classList.remove('open')"><?=svg('x',16)?></button>
        <form method="POST" action="?action=note_edit&tab=notes" id="noteEditForm" enctype="multipart/form-data" onsubmit="return prepareRichForm(this,'noteEditEditor')">
            <input type="hidden" name="id" id="noteEditId">
            <div class="form-grid" style="grid-template-columns:1fr">
                <div class="fg"><label>Başlık</label><input type="text" name="title" id="noteEditTitle" required></div>
                <div class="fg"><label>İçerik</label><div class="rich-editor"><div class="rich-toolbar" role="toolbar" aria-label="İçerik biçimlendirme"><button type="button" onclick="richCmd('bold','noteEditEditor')" title="Kalın"><strong>B</strong></button><button type="button" onclick="richCmd('italic','noteEditEditor')" title="İtalik"><em>I</em></button><button type="button" onclick="richCmd('underline','noteEditEditor')" title="Altı çizili"><u>U</u></button><button type="button" onclick="richCmd('insertUnorderedList','noteEditEditor')" title="Liste">•</button><button type="button" onclick="richCmd('formatBlock','noteEditEditor','h3')" title="Başlık">H</button><select class="rich-size-select" onchange="richCmd('fontSize','noteEditEditor',this.value)" title="Yazı boyutu"><option value="" selected disabled hidden>Boyut</option><option value="2">Küçük</option><option value="3">Normal</option><option value="5">Büyük</option><option value="7">Çok büyük</option></select><input type="color" onchange="richCmd('foreColor','noteEditEditor',this.value)" title="Yazı rengi"><input type="color" onchange="richCmd('hiliteColor','noteEditEditor',this.value)" title="Yazı arka plan rengi (vurgu)"><button type="button" onclick="richCmd('hiliteColor','noteEditEditor','transparent')" title="Arka planı kaldır" style="color:#e11d2e">&#10005;</button></div><div id="noteEditEditor" class="rich-content" contenteditable="true" data-placeholder="Bilgi içeriğini buraya yazın..."></div><textarea name="content" id="noteEditContent" class="rich-value" aria-hidden="true"></textarea></div></div>
                <div class="fg fw"><label>Resimler (opsiyonel)</label><?=x_gal_js()?><div id="noteEditGal"></div><div class="file-zone" id="noteEditFz"><?=svg('upload',14)?> <span class="fzt">Görselleri seçmek için tıklayın (birden fazla)</span><span class="fzn" style="display:none"></span><input type="file" name="image[]" multiple accept="image/*" onchange="fu(this,'noteEditFz')"></div><?=x_url_input('image_url')?></div>
                <div class="fg fw"><label>Video (opsiyonel)</label><div id="noteEditVid"></div><?=x_video_form('noteEditVfz')?></div>
                <div class="fg fw"><label>Dosyalar (opsiyonel)</label><div id="noteEditFiles"></div><div class="file-zone" id="noteEditNf"><?=svg('upload',14)?> <span class="fzt">Dosya seçmek için tıklayın (birden fazla seçilebilir)</span><span class="fzn" style="display:none"></span><input type="file" name="nfile[]" multiple onchange="nfu(this,'noteEditNf')"></div><div class="nf-names"></div><?=x_nf_opts()?></div>
                <div class="fw"><button class="btn btn-g" type="submit"><?=svg('check',13)?> Kaydet</button></div>
            </div>
        </form>
    </div>
</div>

<script>

(function(){
var cur=null;
function rowsOf(tb,except){return Array.prototype.filter.call(tb.children,function(r){return r!==except&&r.tagName==='TR'&&r.style.display!=='none'})}
document.addEventListener('pointerdown',function(e){
    var h=e.target.closest&&e.target.closest('.drag-h');if(!h||(e.pointerType==='mouse'&&e.button!==0))return;
    var row=h.closest('tr'),tb=row.parentNode,wrap=row.closest('.table-wrap');
    e.preventDefault();
    cur={row:row,tb:tb,wrap:wrap,h:h,id:e.pointerId,y:e.clientY,moved:false,raf:0};
    try{h.setPointerCapture(e.pointerId)}catch(x){}
    row.classList.add('dragging');document.body.classList.add('drag-on');
    h.addEventListener('pointermove',mv);h.addEventListener('pointerup',up);h.addEventListener('pointercancel',up);
    tick();
});
function place(){
    var c=cur;if(!c)return;
    var list=rowsOf(c.tb,c.row),before=null;
    for(var i=0;i<list.length;i++){var r=list[i].getBoundingClientRect();if(c.y<r.top+r.height/2){before=list[i];break}}
    if(before){if(c.row.nextElementSibling!==before)c.tb.insertBefore(c.row,before)}
    else if(c.row!==c.tb.lastElementChild)c.tb.appendChild(c.row);
}
function mv(e){if(!cur)return;cur.y=e.clientY;cur.moved=true;place()}
function tick(){
    if(!cur)return;
    var w=cur.wrap;
    if(w){var r=w.getBoundingClientRect(),d=0;if(cur.y<r.top+50)d=-12;else if(cur.y>r.bottom-50)d=12;if(d){w.scrollTop+=d;place()}}
    cur.raf=requestAnimationFrame(tick);
}
function up(){
    var c=cur;if(!c)return;cur=null;cancelAnimationFrame(c.raf);
    c.h.removeEventListener('pointermove',mv);c.h.removeEventListener('pointerup',up);c.h.removeEventListener('pointercancel',up);
    c.row.classList.remove('dragging');document.body.classList.remove('drag-on');
    if(!c.moved)return;
    var table=c.tb.closest('table'),fd=new URLSearchParams();
    fd.append('type',table.dataset.type);
    Array.prototype.forEach.call(c.tb.children,function(r){if(r.dataset.id)fd.append('ids[]',r.dataset.id)});
    fetch('?action=reorder',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString()})
    .then(function(r){return r.json()}).then(function(j){sortToast(j&&j.ok?'Sıralama kaydedildi':'Sıralama kaydedilemedi',!(j&&j.ok))})
    .catch(function(){sortToast('Sıralama kaydedilemedi',true)});
}
function sortToast(t,err){var d=document.createElement('div');d.className='toast'+(err?' error':'');d.textContent=t;document.body.appendChild(d);setTimeout(function(){d.remove()},2600)}
})();
function togglePhpVer(cb){var row=cb.closest('.php-ver-row');if(!row)return;var inp=row.querySelector('.php-ver-input');if(!inp)return;if(cb.checked){inp.disabled=false;inp.style.display='';inp.focus()}else{inp.disabled=true;inp.style.display='none';inp.value=''}}
function apprBx(e){return e.closest('.appr-box')}
function apprSync(e){var bx=apprBx(e),s=[].slice.call(bx.querySelectorAll('.appr-sel')),n=s.filter(function(x){return x.checked}).length,c=bx.querySelector('.appr-cnt'),a=bx.querySelector('.appr-all');if(c)c.textContent=n?n+' seçildi':'';bx.querySelectorAll('.appr-bulk').forEach(function(b){b.disabled=!n});if(a)a.checked=s.length>0&&n===s.length}
function apprAll(e){var bx=apprBx(e);bx.querySelectorAll('.appr-sel').forEach(function(x){x.checked=e.checked});apprSync(e)}
function apprIds(bx){return [].slice.call(bx.querySelectorAll('.appr-sel')).filter(function(x){return x.checked}).map(function(x){return x.value})}
function apprNo(b){var ids=apprIds(apprBx(b));if(!ids.length||!confirm(ids.length+' istek reddedilsin mi?'))return;var f=document.createElement('form');f.method='POST';f.action='?action=appr_no&tab=<?=x_appr_tab()?>';ids.forEach(function(i){var h=document.createElement('input');h.type='hidden';h.name='rids[]';h.value=i;f.appendChild(h)});document.body.appendChild(f);f.submit()}
function apprOk(b){var ids=apprIds(apprBx(b));if(!ids.length||!confirm(ids.length+' işlem onaylanıp uygulansın mı?'))return;document.querySelectorAll('.appr-bulk').forEach(function(x){x.disabled=true});var k=0;(function next(){if(k>=ids.length){location.href='?tab=<?=x_appr_tab()?>&msg=appr_ok';return}var fd=new FormData();fd.append('rid',ids[k++]);b.textContent='Onaylanıyor '+k+'/'+ids.length;fetch('?action=appr_ok&tab=<?=x_appr_tab()?>',{method:'POST',body:fd,credentials:'same-origin'}).then(next,next)})()}
function tPanel(btn){btn.classList.toggle('open');btn.nextElementSibling.classList.toggle('open')}
function bulkBoxes(form){return Array.from(form.querySelectorAll('input[name="ids[]"]'))}

function syncBulk(input){var form=input.closest('.bulk-form');if(!form)return;var boxes=bulkBoxes(form),count=boxes.filter(function(b){return b.checked}).length;form.querySelectorAll('.bulk-count').forEach(function(e){e.textContent=count+' kayıt seçildi';e.style.display=count?'':'none'});form.querySelectorAll('.bulk-delete').forEach(function(b){b.disabled=count===0;b.style.display=count?'':'none'});form.querySelectorAll('.select-all').forEach(function(b){b.checked=boxes.length>0&&count===boxes.length})}
function toggleBulk(master){var form=master.closest('.bulk-form');if(!form)return;bulkBoxes(form).forEach(function(b){b.checked=master.checked});syncBulk(bulkBoxes(form)[0]||master)}
function confirmBulk(form){var count=bulkBoxes(form).filter(function(b){return b.checked}).length;return count>0&&confirm(count+' seçili kayıt silinsin mi?')}
function richCmd(command,id,value){var editor=document.getElementById(id);if(!editor)return;editor.focus();if((command==='insertUnorderedList'||command==='insertOrderedList')&&window.richNormLines)window.richNormLines(editor);document.execCommand(command,false,value||null);syncRich(editor)}
function syncRich(editor){var target=document.getElementById(editor.id+'Value')?document.getElementById(editor.id+'Value'):editor.dataset.target?document.querySelector('[name="'+editor.dataset.target+'"]'):document.getElementById(editor.id==='noteEditEditor'?'noteEditContent':'noteAddContent');if(target)target.value=editor.innerHTML}
function prepareRichForm(form,editorId){var editor=document.getElementById(editorId);if(editor)syncRich(editor);return true}
document.addEventListener('input',function(e){if(e.target&&e.target.classList&&e.target.classList.contains('rich-content'))syncRich(e.target)});document.querySelectorAll('.rich-content').forEach(function(e){syncRich(e)});
function fu(i,id){var a=document.getElementById(id),n=a.querySelector('.fzn'),t=a.querySelector('.fzt');
if(i.files.length){a.classList.add('has');n.textContent=i.files.length>1?i.files.length+(/^video/.test(i.name)?' video':' resim')+' seçildi':i.files[0].name;n.style.display='';t.style.display='none'}
else{a.classList.remove('has');n.style.display='none';t.style.display=''}}

function fitTables(){
    var ws=document.querySelectorAll('.table-wrap');
    for(var i=0;i<ws.length;i++){
        var w=ws[i];if(w.offsetParent===null)continue;
        var top=w.getBoundingClientRect().top+(window.pageYOffset||0);
        w.style.maxHeight=Math.max(220,Math.floor(window.innerHeight-top-16))+'px';
    }
}
window.addEventListener('load',fitTables);window.addEventListener('resize',fitTables);window.addEventListener('orientationchange',fitTables);
document.addEventListener('click',function(){setTimeout(fitTables,60)});
fitTables();
document.getElementById('search').addEventListener('input',function(e){
var q=e.target.value.toLowerCase();
['dosyaTable','noteTable','githubTable'].forEach(function(id){var t=document.getElementById(id);
if(t) t.querySelectorAll('tbody tr').forEach(r=>{r.style.display=(r.dataset.search||'').includes(q)?'':'none'})})
})

function showModal(src){document.getElementById('githubModal').classList.remove('open');document.getElementById('noteModal').classList.remove('open');document.getElementById('noteEditModal').classList.remove('open');document.getElementById('modalImg').src=src;document.getElementById('imgModal').classList.add('open')}
function closeModal(){document.getElementById('imgModal').classList.remove('open')}
document.addEventListener('keydown',function(e){if(e.key==='Escape')closeModal()})

function galHtml(type,it,cls,style){
    var n=it._n||0;if(!n)return '';
    var base='?action=gimg&type='+type+'&id='+encodeURIComponent(it.id)+'&v='+(it._gv||0);
    var h='<div class="gal"><img class="gal-main '+(cls||'')+'" style="'+(style||'')+'" src="'+base+'&n=0" alt="" onclick="showModal(this.src)">';
    if(n>1){h+='<div class="gal-strip">';for(var i=0;i<n;i++)h+='<img class="gal-th'+(i?'':' on')+'" src="'+base+'&n='+i+'&t=1" alt="" loading="lazy" onclick="galPick(this)">';h+='</div>'}
    return h+'</div>';
}
function galPick(el){var g=el.closest('.gal'),m=g.querySelector('.gal-main');m.src=el.src.replace('&t=1','');var t=g.querySelectorAll('.gal-th');for(var j=0;j<t.length;j++)t[j].classList.toggle('on',t[j]===el)}
function galEditHtml(type,it){
    var n=it._n||0;if(!n)return '';
    var id=encodeURIComponent(it.id),base='?action=gimg&type='+type+'&id='+id+'&v='+(it._gv||0);
    var h='<div class="gal-wrap"><div class="gal-bar"><label style="display:flex;align-items:center;gap:5px;cursor:pointer"><input type="checkbox" class="gal-all" onchange="galSel(this)"> Tümünü seç</label><button type="button" class="gal-del" disabled onclick="galAct(this,\'?action=img_bulk_remove&type='+type+'&id='+id+'\',\'Seçili resimler silinsin mi?\')">Seçilenleri sil</button><span class="bulk-count" style="display:none"></span></div><div class="gal-e">';
    for(var i=0;i<n;i++){
        h+='<div class="gal-i'+((i||it.main_video!=null)?'':' main')+'"><input type="checkbox" class="gk" name="ns[]" value="'+i+'" onchange="galSel(this)"><img src="'+base+'&n='+i+'&t=1" alt="">';
        h+=(i||it.main_video!=null)?'<button type="button" class="gm" onclick="galAct(this,\'?action=img_main&type='+type+'&id='+id+'&n='+i+'\')">Ana yap</button>':'<span class="gl">Ana resim</span>';
        h+='</div>';
    }
    return h+'</div></div>';
}
function viewDescription(description){
    var modal=document.getElementById('githubModal'), content=document.getElementById('githubModalContent');
    content.innerHTML='<div class="archive-detail-description">'+(description||'Açıklama yok')+'</div>';
    modal.classList.add('open');
  }
function viewdosya(dosya){
    var c=document.getElementById('githubModalContent');
    var name=String(dosya.name||'İsimsiz Dosya').replace(/[<>&]/g,function(x){return {'<':'&lt;','>':'&gt;','&':'&amp;'}[x]});
    var image=galHtml('dosya',dosya,'archive-detail-image');
    c.innerHTML='<h3 style="color:var(--green);margin-bottom:8px">'+name+'</h3>'+(dosya.main_video!=null?vpHtml(dosya)+image:image+vpHtml(dosya))+'<div class="archive-detail-description">'+(dosya.description||'Açıklama yok')+'</div>'+nfHtml(dosya)+(dosya.show_code!==false?'<div class="archive-code-panel" style="margin-top:12px"><div class="github-code-heading"><div class="github-code-label">Kod içeriği</div><button class="icon-copy" type="button" title="Kodu kopyala" aria-label="Kodu kopyala" onclick="copyCode(this)"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"></rect><path d="M5 15V5a2 2 0 0 1 2-2h10"></path></svg></button></div><pre id="archiveCode">Kod yükleniyor...</pre></div>':'');
    vpInit(c);document.getElementById('githubModal').classList.add('open');
    if(dosya.show_code!==false)fetch('?action=archive_content&id='+encodeURIComponent(dosya.id)).then(function(r){return r.text()}).then(function(t){var code=document.getElementById('archiveCode');if(code)code.textContent=t}).catch(function(){var code=document.getElementById('archiveCode');if(code)code.textContent='Kod yüklenemedi.'});
  }
function packOpen(b){var d=JSON.parse(b.getAttribute('data-pack')),L=document.getElementById('packList');document.getElementById('packTitle').textContent=d.title;L.innerHTML='';function bd(c,t,w){var e=document.createElement('span');e.className='badge '+c+' '+w;e.style.whiteSpace='nowrap';e.textContent=t;return e}d.rows.forEach(function(x){var r=document.createElement('div');r.className='pack-item';r.appendChild(bd(x.enc?'badge-r':'badge-g',x.enc?'Şifreli':'Açık kaynak','pk-b'));r.appendChild(bd('badge-a',x.php?x.php:'—','pk-p'));var n=document.createElement('span');n.className='pk-n';n.title=x.name||'';if(x.url){var a=document.createElement('a');a.href=x.url;a.target='_blank';a.rel='noopener noreferrer';a.textContent=x.name||x.url;n.appendChild(a)}else n.textContent=x.name||'';r.appendChild(n);var ac=document.createElement('span');ac.className='pk-a';if(x.copy){var c=document.createElement('button');c.type='button';c.className='btn btn-cp btn-xs';c.textContent='Kopyala';c.onclick=function(){if(navigator.clipboard)navigator.clipboard.writeText(x.copy);c.textContent='Kopyalandı';setTimeout(function(){c.textContent='Kopyala'},1200)};ac.appendChild(c)}if(x.dl){var d2=document.createElement('a');d2.className='btn btn-ob btn-xs';d2.href=x.dl;d2.textContent='İndir';ac.appendChild(d2)}r.appendChild(ac);L.appendChild(r)});if(d.zip){var z=document.createElement('a');z.className='btn btn-g pack-zip';z.href=d.zip;z.textContent='Tümünü ZIP olarak indir';L.appendChild(z)}document.getElementById('packModal').classList.add('open')}
function copyGithub(button,url){
    var githubRow=button.closest('tr'), githubName=githubRow?((githubRow.querySelector('.github-title-button')||{}).textContent||''):' '; 
    fetch('?action=analytics_event',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'type=github&event=copy&id='+encodeURIComponent(button.dataset.githubId||url)+'&label='+encodeURIComponent(githubName.trim()||url)}).catch(function(){});
    function done(){var old=button.innerHTML;button.textContent='Kopyalandı';button.classList.add('copied');setTimeout(function(){button.innerHTML=old;button.classList.remove('copied')},1500)}
    if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(url).then(done)}else{var a=document.createElement('textarea');a.value=url;document.body.appendChild(a);a.select();document.execCommand('copy');a.remove();done()}
}
function viewGithub(g){
  fetch('?action=analytics_event',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'type=github&event=read&id='+encodeURIComponent(g.id||'')+'&label='+encodeURIComponent(g.name||'')}).catch(function(){});
    var c=document.getElementById('githubModalContent'), safeName=String(g.name||'').replace(/[<>&]/g,function(x){return {'<':'&lt;','>':'&gt;','&':'&amp;'}[x]});
    var image=galHtml('github',g,'','max-width:100%;max-height:300px;object-fit:contain;border-radius:6px;cursor:pointer');
    c.innerHTML='<h3 style="color:var(--green);margin-bottom:8px">'+safeName+'</h3>'+(g.main_video!=null?vpHtml(g)+image:image+vpHtml(g))+'<div class="github-detail-description">'+(g.description||'Açıklama yok')+'</div>'+nfHtml(g)+(g.show_code!==false?'<div class="github-code-panel"><div class="github-code-heading"><div class="github-code-label">Kod bilgileri</div><button class="icon-copy" type="button" title="Kodu kopyala" aria-label="Kodu kopyala" onclick="copyCode(this)"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"></rect><path d="M5 15V5a2 2 0 0 1 2-2h10"></path></svg></button></div><pre id="githubCode" style="white-space:pre-wrap;word-break:break-word;max-height:360px;overflow:auto;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:6px;padding:12px;color:var(--text2);font:11px var(--mono)">Kod yükleniyor...</pre></div>':'');
    vpInit(c);document.getElementById('githubModal').classList.add('open');
    if(g.show_code!==false)fetch(g.url).then(function(r){return r.text()}).then(function(t){var code=document.getElementById('githubCode');if(code)code.textContent=t}).catch(function(){var code=document.getElementById('githubCode');if(code)code.textContent='Kod yüklenemedi. Raw bağlantıyı kontrol edin.'});
}
function copyCode(button){var p=button.closest('.archive-code-panel,.github-code-panel'),pre=p?p.querySelector('pre'):(document.getElementById('githubCode')||document.getElementById('archiveCode'));if(pre)copyText(button,pre.textContent)}
function copyText(button,text){var h=button.innerHTML,done=function(){button.textContent='Kopyalandı';setTimeout(function(){button.innerHTML=h},1500)};if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(text).then(done)}else{var a=document.createElement('textarea');a.value=text;document.body.appendChild(a);a.select();document.execCommand('copy');a.remove();done()}}
function nfEsc(t){return String(t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function nfSize(b){b=+b||0;return b>=1073741824?(b/1073741824).toFixed(2)+' GB':(b>=1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB')}
function nfMove(b,d){var r=b.closest('.nf-er'),q=r.parentNode;if(d<0){var s=r.previousElementSibling;if(s)q.insertBefore(r,s)}else{var x=r.nextElementSibling;if(x)q.insertBefore(x,r)}}
function nfu(i,id){
    var a=document.getElementById(id),n=a.querySelector('.fzn'),t=a.querySelector('.fzt'),nm=a.parentNode.querySelector('.nf-names');
    if(nm)nm.innerHTML='';
    if(i.files.length){
        a.classList.add('has');n.textContent=i.files.length>1?i.files.length+' dosya seçildi':i.files[0].name;n.style.display='';t.style.display='none';
        if(nm)for(var k=0;k<i.files.length;k++){var r=document.createElement('div');r.className='nf-nrow';var l=document.createElement('span');l.textContent='Ad:';var inp=document.createElement('input');inp.type='text';inp.className='nf-rn';inp.name='nfname[]';inp.maxLength=120;inp.value=i.files[k].name;inp.title='Listede görünecek ad (değiştirebilirsiniz)';var pl=document.createElement('label');pl.className='nf-pin';pl.title='Üste sabitle';var pc=document.createElement('input');pc.type='checkbox';pc.name='nfpin[]';pc.value=k;pl.appendChild(pc);pl.appendChild(document.createTextNode(' \uD83D\uDCCC'));r.appendChild(l);r.appendChild(inp);r.appendChild(pl);var dd=document.createElement('input');dd.type='text';dd.className='nf-rn nf-dsc';dd.name='nfdesc[]';dd.maxLength=300;dd.placeholder='Dosya hakkında açıklama (isteğe bağlı)';r.appendChild(dd);nm.appendChild(r)}
    }else{a.classList.remove('has');n.style.display='none';t.style.display=''}
}
function nfHtml(note){
    var f=note.files||[];if(!f.length)return '';
    var id=encodeURIComponent(note.id),h='<div class="nf-list"><div class="nf-title">Dosyalar ('+f.length+')</div>';
    for(var i=0;i<f.length;i++)h+='<a class="nf-item" href="?action=nfile&id='+id+'&n='+i+vTy(note)+'" title="İndir"><span class="nf-nm">'+(f[i].pinned?'&#128204; ':'&#128206; ')+nfEsc(f[i].name)+(f[i].desc?'<span class="nf-desc">'+nfEsc(f[i].desc)+'</span>':'')+'</span><span class="nf-sz">'+nfSize(f[i].size)+'</span><span class="nf-dl">İndir</span></a>';
    return h+'</div>';
}
function nfEditHtml(note){
    var f=note.files||[];if(!f.length)return '';
    var id=encodeURIComponent(note.id);
    var h='<div class="gal-wrap" style="margin-bottom:8px"><div class="gal-bar"><label style="display:flex;align-items:center;gap:5px;cursor:pointer"><input type="checkbox" class="gal-all" onchange="galSel(this)"> Tüm dosyaları seç</label><button type="button" class="gal-del" disabled onclick="galAct(this,\'?action=nfile_remove&id='+id+vTy(note)+'\',\'Seçili dosyalar silinsin mi?\')">Seçilenleri sil</button><span class="bulk-count" style="display:none"></span></div><div class="nf-scroll">';
    for(var i=0;i<f.length;i++)h+='<div class="vid-row nf-er"><input type="checkbox" class="gk" name="fns[]" value="'+i+'" onchange="galSel(this)"><input type="text" class="nf-rn" name="nfn['+i+']" value="'+nfEsc(f[i].name)+'" maxlength="120" title="Dosya adı (değiştirebilirsiniz)"><span class="nf-sz">'+nfSize(f[i].size)+'</span><label class="nf-pin" title="Üste sabitle"><input type="checkbox" name="nfp['+i+']" value="1"'+(f[i].pinned?' checked':'')+'> &#128204;</label><button type="button" class="vid-mk" title="Yukarı taşı" onclick="nfMove(this,-1)">&#9650;</button><button type="button" class="vid-mk" title="Aşağı taşı" onclick="nfMove(this,1)">&#9660;</button><a class="vid-mk" href="?action=nfile&id='+id+'&n='+i+vTy(note)+'">İndir</a><input type="hidden" name="nfo[]" value="'+i+'"><input type="text" class="nf-rn nf-dsc" name="nfd['+i+']" value="'+nfEsc(f[i].desc||'')+'" maxlength="300" placeholder="Dosya hakkında açıklama (isteğe bağlı)"></div>';
    return h+'</div></div>';
}
function viewNote(note){
    fetch('?action=analytics_event',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'type=note&event=read&id='+encodeURIComponent(note.id||'')+'&label='+encodeURIComponent(note.title||'')}).catch(function(){});
var noteImage=galHtml('note',note,'note-detail-image');
    document.getElementById('noteModalContent').innerHTML='<h3 style="color:var(--green);margin-bottom:8px">'+note.title.replace(/</g,'&lt;')+'</h3>'+(note.main_video!=null?vpHtml(note)+noteImage:noteImage+vpHtml(note))+'<div class="archive-detail-description">'+(note.content||'Açıklama yok')+'</div>'+nfHtml(note)+'<div style="margin-top:10px;font-size:10px;color:var(--text3)">'+ (note.date_added ? new Date(note.date_added.replace(' ','T')).toLocaleString('tr-TR',{day:'2-digit',month:'2-digit',year:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).replace(/,\s*|\s+(?=\d{2}:\d{2}$)/,' - ') : '')+'</div>';
    vpInit(document.getElementById('noteModalContent'));
    document.getElementById('noteModal').classList.add('open')
}
function editNote(note){
    document.getElementById('noteEditId').value=note.id;
    document.getElementById('noteEditTitle').value=note.title;
    document.getElementById('noteEditEditor').innerHTML=note.content||'';
    document.getElementById('noteEditContent').value=note.content||'';
    document.getElementById('noteEditForm').action='?action=note_edit&id='+note.id+'&tab=notes';
    var _u=document.querySelector('#noteEditForm textarea.img-url');if(_u)_u.value='';var _gf=document.querySelector('#noteEditForm input[type=file]');if(_gf){_gf.value='';fu(_gf,'noteEditFz')}var _gg=document.getElementById('noteEditGal');if(_gg)_gg.innerHTML=galEditHtml('note',note);var _vv=document.getElementById('noteEditVid');if(_vv)_vv.innerHTML=vidEditHtml(note);var _nfl=document.getElementById('noteEditFiles');if(_nfl)_nfl.innerHTML=nfEditHtml(note);var _nff=document.querySelector('#noteEditForm input[name="nfile[]"]');if(_nff){_nff.value='';nfu(_nff,'noteEditNf')}var _vf=document.querySelector('#noteEditForm input[name="video[]"]');if(_vf){_vf.value='';fu(_vf,'noteEditVfz')}var _vu=document.querySelector('#noteEditForm textarea[name=video_url]');if(_vu)_vu.value='';
    document.getElementById('noteEditModal').classList.add('open')
}
</script>
<?=x_editor_assets()?>
<?=x_upload_assets()?>
</body></html>
<?php
function x_login_page($err=false) {
    $shake=$err?'shake':'';
    ?><!DOCTYPE html><html lang="tr"><head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><?=x_h(x_site_get('title'))?></title><?=x_seo_meta()?>
    <style>
        :root{--bg:#0a0b0f;--surface:#111318;--border:#1e2130;--text:#8b8fa3;--text2:#d1d5e0;--green:#b71c1c;--glow:#b71c1c30}
        *{margin:0;padding:0;box-sizing:border-box}
        body{background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;overflow:hidden}
        .bg{position:fixed;inset:0;background:radial-gradient(ellipse at 25% 30%,color-mix(in srgb,var(--green) 2%,transparent) 0%,transparent 55%),radial-gradient(ellipse at 70% 70%,#448aff03 0%,transparent 55%)}
        .bg::after{content:'';position:absolute;inset:0;background-image:linear-gradient(#ffffff03 1px,transparent 1px),linear-gradient(90deg,#ffffff03 1px,transparent 1px);background-size:50px 50px}
        .wrap{position:relative;z-index:1;width:380px;max-width:95vw;padding:16px}
        .card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:36px 28px;box-shadow:0 0 0 1px #ffffff03,0 8px 32px #00000040}
        .icon{width:44px;height:44px;margin:0 auto 16px;display:flex;align-items:center;justify-content:center;background:var(--glow);border-radius:10px;color:var(--green)}
        .card h1{text-align:center;color:var(--text2);font-size:20px;font-weight:800;letter-spacing:-.5px;margin-bottom:2px}
        .card h1 b{color:var(--green)}
        .card .sub{text-align:center;color:var(--text);font-size:12px;margin-bottom:24px}
        .card input[type=password]{width:100%;padding:13px 15px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:8px;color:var(--text2);font-size:14px;outline:none;text-align:center;transition:.2s}
        .card input[type=password]:focus{border-color:var(--green);box-shadow:0 0 0 3px var(--glow)}
        .card input::placeholder{color:#3a3d4a}
        .card button{width:100%;margin-top:14px;padding:13px;background:var(--green);color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;transition:.2s}
        .card button:hover{filter:brightness(1.1);box-shadow:0 3px 16px var(--glow)}
        .hint{text-align:center;margin-top:18px;font-size:11px;color:var(--text)}.hint span{color:var(--text)}
        .shake{animation:sh .4s ease}
        @keyframes sh{0%,100%{transform:translateX(0)}20%{transform:translateX(-5px)}40%{transform:translateX(5px)}60%{transform:translateX(-3px)}80%{transform:translateX(3px)}}table tr.pinned td {
    background: var(--amber-bg);
    height: 58px;
}td.col-actions {
    height: 60px;
}
    </style><?=x_theme_css()?><?=x_login_bg_css()?></head><body>
    <div class="bg"></div>
    <div class="wrap"><div class="card <?=$shake?>">
        <?=x_login_icon()?>
        <h1><?=x_brand_html()?></h1><p class="sub"><?=x_h(x_site_get('login_sub'))?></p>
        <form method="POST"><input type="password" name="password" placeholder="<?=x_h(x_site_get('login_ph'))?>" autofocus autocomplete="off"><button type="submit"><?=x_h(x_site_get('login_btn'))?></button></form><?php if (!empty($GLOBALS['x_login_blocked'])): ?><p class="hint" style="color:#ff4d4d">Bu hesap engellenmiştir. Lütfen yönetici ile iletişime geçin.</p><?php endif; ?><?php if (!empty($GLOBALS['x_login_locked'])): ?><p class="hint" style="color:#ff4d4d">Çok fazla hatalı deneme. Lütfen 15 dakika sonra tekrar deneyin.</p><?php endif; ?><?php if (x_site_get('login_hint')!==''): ?><p class="hint"><?=x_h(x_site_get('login_hint'))?></p><?php endif; ?>
    </div></div></body></html>
    <?php exit;
}

function x_preview_page($dosya,$content,$cats) {
    $ext=pathinfo((isset($dosya['original_name']) ? $dosya['original_name'] : ''),PATHINFO_EXTENSION);
    $lines=count(preg_split('/\R/',$content));
    $bytes=strlen($content);
    ?><!DOCTYPE html><html lang="tr"><head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><?=x_h($dosya['name'])?><?=x_site_get('title')!=='' ? ' — '.x_h(x_site_get('title')) : ''?></title>
    <style>
        :root{--bg:#0a0b0f;--surface:#111318;--border:#1e2130;--text:#8b8fa3;--text2:#d1d5e0;--green:#b71c1c;--red:var(--green);--mono:'JetBrains Mono','Fira Code','Consolas',monospace;--font:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
        *{margin:0;padding:0;box-sizing:border-box}
        body{background:var(--bg);color:var(--text);font-family:var(--mono);min-height:100vh}
        .bar{display:flex;align-items:center;justify-content:space-between;padding:12px 18px;background:var(--surface);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10;gap:12px;flex-wrap:wrap}
        .bar-l{display:flex;align-items:center;gap:10px}.bar h2{color:var(--green);font-size:14px;font-weight:700;font-family:var(--font)}
        .pills{display:flex;gap:6px;flex-wrap:wrap}
        .pill{font-size:10px;padding:3px 8px;border-radius:4px;font-weight:700;font-family:var(--font);letter-spacing:.3px;display:inline-flex;align-items:center;gap:4px}
        .pill-r{background:#5b0b0b;color:#ff4d4d}.pill-g{background:color-mix(in srgb,var(--green) 8%,transparent);color:var(--green)}.pill-b{background:var(--inp,#0c0e14);color:var(--text)}
        .bar-r{display:flex;gap:6px}
        .btn{display:inline-flex;align-items:center;gap:5px;padding:7px 13px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;border:1px solid var(--border);text-decoration:none;font-family:var(--font);transition:.12s;color:var(--text2);background:transparent}
        .btn:hover{border-color:var(--green);color:var(--green)}
        .btn-g{background:var(--green);color:#fff;border-color:var(--green)}.btn-g:hover,.btn-g:focus-visible{filter:brightness(1.1);color:#fff;border-color:var(--green)}
        .desc-m{margin:0 16px;padding:12px 16px;background:var(--surface);border:1px solid var(--border);border-radius:8px;font-family:var(--font)}
        .desc-m .lbl{font-size:10px;color:#555;text-transform:uppercase;letter-spacing:1px;margin-bottom:3px}
        .desc-m .val{font-size:13px;color:var(--text2)}
        .wrap{max-width:1100px;margin:0 auto;padding:20px}
        .ss-wrap{margin:0 16px 16px;display:flex;justify-content:center;align-items:center}
        .ss-wrap img{display:block;width:auto;max-width:100%;max-height:360px;object-fit:contain;border-radius:8px;border:1px solid var(--border)}
        .code-h{display:flex;align-items:center;justify-content:space-between;padding:10px 16px;background:#0d0f16;border:1px solid var(--border);border-radius:8px 8px 0 0;border-bottom:none;font-family:var(--font)}
  .code-actions{display:flex;align-items:center;gap:10px}.copy-btn{display:inline-flex;align-items:center;gap:5px;border:1px solid var(--border);border-radius:5px;padding:5px 9px;background:transparent;color:var(--text2);font:600 11px var(--font);cursor:pointer;transition:.12s}.copy-btn:hover,.copy-btn:focus-visible{border-color:var(--green);color:#fff;outline:none}.copy-btn.copied{color:#fff;background:var(--green);border-color:var(--green)}
        .code-h .lang{font-size:11px;color:#555;text-transform:uppercase;letter-spacing:1px}
        .code-h .stats{font-size:11px;color:#555}
        .code-b{background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:0 0 8px 8px;padding:18px 20px;max-height:min(60vh,560px);overflow:auto;overscroll-behavior:contain}
        .code-b pre{color:var(--text2);font-size:12.5px;line-height:1.7;white-space:pre-wrap;word-break:break-all;margin:0;tab-size:2}
        @media(max-width:640px){.bar{flex-direction:column;align-items:stretch;padding:10px 12px}.bar-l{align-items:flex-start;flex-direction:column;gap:7px}.bar-r{width:100%}.bar-r .btn{flex:1;justify-content:center}.wrap{padding:12px}.ss-wrap{margin:0 12px 12px}.ss-wrap img{width:100%;max-width:100%;max-height:42vh}.code-b{padding:12px 14px;max-height:48vh}.code-b pre{font-size:11px;line-height:1.55}}table tr.pinned td {
    background: var(--amber-bg);
    height: 58px;
}td.col-actions {
    height: 60px;
}
    </style><?=x_editor_css()?><?=x_theme_css()?></head><body>
    <div class="bar">
        <div class="bar-l">
            <h2><?=x_h($dosya['name'])?></h2>
            <div class="pills">
                <span class="pill pill-b"><?=x_h((isset($dosya['original_name']) ? $dosya['original_name'] : '—'))?></span>
                <?php if($dosya['has_password']):?><span class="pill pill-r"><svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg> Şifreli</span>
                <?php else:?><span class="pill pill-g"><svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 019.9-1"/></svg> Açık</span><?php endif;?>
                <?php if((isset($dosya['category_id']) ? $dosya['category_id'] : null)):?><span class="pill pill-b"><svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/></svg> <?=x_h(x_cat_name($cats,$dosya['category_id']))?></span><?php endif;?>
            </div>
        </div>
        <div class="bar-r">
            <a class="btn" href="<?=x_h($_SERVER['SCRIPT_NAME'])?>">Panele Dön</a>
            <a class="btn btn-g" href="?action=download&id=<?=$dosya['id']?>"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> İndir</a>
        </div>
    </div>
    <?php if((isset($dosya['description']) ? $dosya['description'] : '')):?>
    <div style="margin:12px 16px 0"><div class="desc-m"><div class="lbl">Açıklama</div><div class="val"><?=x_rich($dosya['description'])?></div></div></div>
    <?php endif;?>
    <?php if((isset($dosya['screenshot']) ? $dosya['screenshot'] : '')):?>
    <div class="ss-wrap"><img src="?action=screenshot&id=<?=$dosya['id']?>&v=<?=x_img_v((isset($dosya['screenshot']) ? $dosya['screenshot'] : ''))?>" alt="" loading="lazy"></div>
    <?php endif;?>
    <div class="wrap">
        <div class="code-h"><span class="lang"><?=x_h($ext?:'txt')?></span><div class="code-actions"><span class="stats"><?=$lines?> satır &middot; <?=$bytes?> byte</span><button class="copy-btn" type="button" onclick="copyCode(this)"><?=svg('copy',12)?> Tümünü Kopyala</button></div></div>
        <div class="code-b"><pre id="codeContent"><?=x_h($content)?></pre></div>
        <script>function copyCode(button){const code=document.getElementById('codeContent').textContent;navigator.clipboard.writeText(code).then(()=>{const old=button.innerHTML;button.classList.add('copied');button.textContent='Kopyalandı';setTimeout(()=>{button.innerHTML=old;button.classList.remove('copied')},1600)}).catch(()=>{const area=document.createElement('textarea');area.value=code;document.body.appendChild(area);area.select();document.execCommand('copy');area.remove();button.textContent='Kopyalandı';setTimeout(()=>button.innerHTML='<?=svg('copy',12)?> Tümünü Kopyala',1600)})}</script>
    </div></body></html>
    <?php exit;
}

function x_edit_page($dosya,$cats) {
    $content=file_exists(FILES_DIR.'/'.$dosya['stored_name'])?file_get_contents(FILES_DIR.'/'.$dosya['stored_name']):'';
    ?><!DOCTYPE html><html lang="tr"><head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Düzenle: <?=x_h($dosya['name'])?><?=x_site_get('title')!=='' ? ' — '.x_h(x_site_get('title')) : ''?></title>
    <style>
        :root{--bg:#0a0b0f;--surface:#111318;--border:#1e2130;--text:#8b8fa3;--text2:#d1d5e0;--text3:#555a6e;--green:#b71c1c;--glow:#b71c1c30;--mono:'JetBrains Mono','Fira Code','Consolas',monospace;--font:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
        *{margin:0;padding:0;box-sizing:border-box}
        body{background:var(--bg);color:var(--text);font-family:var(--font)}
        .bar{display:flex;align-items:center;justify-content:space-between;padding:12px 18px;background:var(--surface);border-bottom:1px solid var(--border);gap:12px}
        .bar h2{color:var(--text2);font-size:14px;font-weight:700}
        .btn{display:inline-flex;align-items:center;gap:5px;padding:7px 14px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;border:1px solid var(--border);text-decoration:none;font-family:var(--font);transition:.12s;color:var(--text2);background:transparent}
        .btn:hover{border-color:var(--green);color:var(--green)}
        .btn-g{background:var(--green);color:#fff;border-color:var(--green)}.btn-g:hover,.btn-g:focus-visible{filter:brightness(1.1);color:#fff;border-color:var(--green)}
        .wrap{max-width:1000px;margin:0 auto;padding:20px}
        .form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
        .form-grid .fw{grid-column:1/-1}
        .fg{display:flex;flex-direction:column;gap:5px}
        .fg label{font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.5px;font-weight:600}
        .fg input[type=text],.fg input[type=url],.fg textarea,.fg select{padding:10px 13px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:6px;color:var(--text2);font-size:13px;outline:none;font-family:var(--font);transition:.15s;resize:vertical}
        .fg textarea{font-family:var(--mono);font-size:12px;min-height:280px;tab-size:2}
        .fg input:focus,.fg textarea:focus,.fg select:focus{border-color:var(--green);box-shadow:0 0 0 3px var(--glow)}
        *{scrollbar-color:var(--border) var(--bg);scrollbar-width:thin}::-webkit-scrollbar{width:8px;height:8px}::-webkit-scrollbar-track{background:var(--bg)}::-webkit-scrollbar-thumb{background:var(--border);border-radius:8px}::-webkit-scrollbar-thumb:hover{background:var(--green)}
        .fg select{appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23555a6e' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 10px center;padding-right:30px}
        .toggle-row{display:flex;align-items:center;gap:12px;padding:6px 0}
        .sw{position:relative;width:40px;height:22px}
        .toggle-row.php-ver-row input.php-ver-input[type=text]{width:68px;min-width:68px;max-width:68px;padding:5px 7px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:var(--r-sm);color:var(--hi,#fff);font-size:11px;font-family:var(--mono);box-sizing:border-box}.toggle-row.php-ver-row input.php-ver-input[type=text]:not(:disabled){border-color:var(--green)}.toggle-row.php-ver-row input.php-ver-input[type=text]:focus{outline:none;border-color:var(--green);box-shadow:0 0 0 3px var(--green-glow,var(--glow))}
        .sw input{opacity:0;width:0;height:0}
        .sw .sl{position:absolute;inset:0;background:var(--d2,#1a1d28);border-radius:22px;cursor:pointer;transition:.15s}
        .sw .sl::before{content:'';position:absolute;width:16px;height:16px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.15s}
        .sw input:checked+.sl{background:var(--green)}
        .sw input:checked+.sl::before{background:#fff;transform:translateX(18px)}
        .file-zone{position:relative;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:6px;padding:14px;border:2px dashed var(--border);border-radius:6px;cursor:pointer;background:var(--inp,#0c0e14);text-align:center;transition:.15s}
        .file-zone:hover{border-color:var(--green);background:color-mix(in srgb,var(--green) 3%,transparent)}
        .file-zone input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer}
        .file-zone .fzt{font-size:11px;color:var(--text3)}
        .rich-editor{border:1px solid var(--border);border-radius:6px;overflow:hidden;background:var(--inp,#0c0e14)}.rich-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:4px;padding:6px;border-bottom:1px solid var(--border);background:var(--surface)}.rich-toolbar button,.rich-toolbar select,.rich-toolbar input{height:28px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:4px;color:var(--text2);font:12px var(--font);cursor:pointer;box-sizing:border-box}.rich-toolbar button{min-width:28px}.rich-toolbar button:hover,.rich-toolbar select:hover,.rich-toolbar select:focus{border-color:var(--green);color:var(--green)}.rich-toolbar .rich-size-select{flex:0 0 100px;min-width:100px;width:100px;height:30px;padding:0 24px 0 8px;overflow:visible;text-overflow:clip;white-space:nowrap;line-height:28px}.rich-toolbar input{width:32px;padding:2px}.rich-content{min-height:90px;max-height:320px;padding:10px;color:var(--text2);font-size:13px;line-height:1.6;outline:none;overflow:auto;scrollbar-color:var(--border) var(--bg);scrollbar-width:thin}.rich-content::-webkit-scrollbar{width:8px}.rich-content::-webkit-scrollbar-thumb{background:var(--border);border-radius:8px}.rich-content::-webkit-scrollbar-track{background:var(--bg)}.rich-content:empty:before{content:attr(data-placeholder);color:var(--text3);pointer-events:none}.rich-content:focus{box-shadow:inset 0 0 0 1px var(--green)}.rich-content h3{margin:8px 0;color:var(--green)}.rich-content ul{padding-left:22px}.rich-value{display:none}@media(max-width:640px){.form-grid{grid-template-columns:1fr}.bar{flex-direction:column;align-items:flex-start}.wrap{padding:12px}}table tr.pinned td {
    background: var(--amber-bg);
    height: 58px;
}td.col-actions {
    height: 60px;
}
    </style><?=x_theme_css()?></head><body>
    <div class="bar"><h2>Düzenle: <?=x_h($dosya['name'])?></h2><a class="btn" href="<?=x_h($_SERVER['SCRIPT_NAME'])?>">Vazgeç</a></div>
    <div class="wrap">
        <form method="POST" action="?action=edit&id=<?=$dosya['id']?>" enctype="multipart/form-data" onsubmit="return prepareRichForm(this,'dosyaEditDescription')">
            <div class="form-grid">
                <div class="fg"><label>Dosya Adı</label><input type="text" name="name" value="<?=x_h($dosya['name'])?>" required></div>
                <div class="fg"><label>Kategori</label><select name="category_id"><option value="">Kategorisiz</option><?php foreach ($cats as $c):$pr=$c['parent']?x_cat_name($cats,$c['parent']).' → ':'';?><option value="<?=$c['id']?>" <?=((isset($dosya['category_id']) ? $dosya['category_id'] : null))===$c['id']?'selected':''?>><?=$pr.x_h($c['name'])?></option><?php endforeach;?></select></div>
                <div class="fg fw"><label>Açıklama</label><?=x_rich_editor('dosyaEditDescription','description',(isset($dosya['description']) ? $dosya['description'] : ''),'Açıklamayı buraya yazın...')?></div>
                <div class="fg fw"><label>Kod İçeriği</label><textarea name="content" rows="18" spellcheck="false"><?=x_h($content)?></textarea></div>
                <div class="fg fw"><label>Yeni Dosya Yükle</label><div class="file-zone" id="efz"><?=svg('upload',14)?> <span class="fzt">Mevcut dosyayı değiştirmek için tıklayın</span><span class="fzn" style="display:none"></span><input type="file" name="dosya_arsiv" onchange="fu(this,'efz')"></div></div><?=x_st_select(isset($dosya['stored_name'])?$dosya['stored_name']:'',true)?><?=x_dl_select(!empty($dosya['download_name'])?$dosya['download_name']:'')?>
                <div class="fg"><label>Ekran Görüntüleri</label><?=x_edit_gallery('dosya',$dosya,'screenshot')?><div class="file-zone" id="ssfz"><span class="fzt">Görsel(ler) ekle — birden fazla seçilebilir</span><span class="fzn" style="display:none"></span><input type="file" name="screenshot[]" multiple accept="image/*" onchange="fu(this,'ssfz')"></div><?=x_url_input('screenshot_url')?></div>
                <div class="fg"><div class="toggle-row"><label class="sw"><input type="checkbox" name="show_code" value="1" <?=((isset($dosya['show_code']) ? $dosya['show_code'] : true))?'checked':''?>><span class="sl"></span></label><span style="font-size:12px;color:var(--hi,#fff)">Kod içeriğini göster</span></div></div><?=x_pack_field('dosya',x_pack_list($dosya),'',array('zip'=>(!isset($dosya['zip_on']) || $dosya['zip_on']),'enc'=>!empty($dosya['has_password']),'php'=>(isset($dosya['php_version']) ? $dosya['php_version'] : ''),'name'=>(isset($dosya['original_name']) ? $dosya['original_name'] : '')))?>
                <div class="fg fw"><label>Video (opsiyonel)</label><?=x_media_videos_html('dosya',$dosya)?><?=x_video_form('eVfz')?></div><div class="fg fw"><label>Dosyalar (opsiyonel)</label><?=x_media_files_html('dosya',$dosya)?><div class="file-zone" id="eNf"><?=svg('upload',14)?> <span class="fzt">Dosya seçmek için tıklayın (birden fazla seçilebilir)</span><span class="fzn" style="display:none"></span><input type="file" name="nfile[]" multiple onchange="nfu(this,'eNf')"></div><div class="nf-names"></div><?=x_nf_opts()?></div>
                <div class="fw"><button class="btn btn-g" type="submit"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Kaydet</button></div>
                </div>
        </form>
    </div><script>function togglePhpVer(cb){var row=cb.closest('.php-ver-row');if(!row)return;var inp=row.querySelector('.php-ver-input');if(!inp)return;if(cb.checked){inp.disabled=false;inp.style.display='';inp.focus()}else{inp.disabled=true;inp.style.display='none';inp.value=''}}function richCmd(command,id,value){var editor=document.getElementById(id);if(!editor)return;editor.focus();if((command==='insertUnorderedList'||command==='insertOrderedList')&&window.richNormLines)window.richNormLines(editor);document.execCommand(command,false,value||null);syncRich(editor)}function syncRich(editor){var target=document.getElementById(editor.id+'Value')?document.getElementById(editor.id+'Value'):editor.dataset.target?document.querySelector('[name="'+editor.dataset.target+'"]'):document.getElementById(editor.id+'Value');if(target)target.value=editor.innerHTML}function prepareRichForm(form,editorId){var editor=document.getElementById(editorId);if(editor)syncRich(editor);return true}document.addEventListener('input',function(e){if(e.target&&e.target.classList&&e.target.classList.contains('rich-content'))syncRich(e.target)});document.querySelectorAll('.rich-content').forEach(function(e){syncRich(e)});function fu(i,id){var a=document.getElementById(id),n=a.querySelector('.fzn'),t=a.querySelector('.fzt');if(i.files.length){a.classList.add('has');n.textContent=i.files.length>1?i.files.length+' resim seçildi':i.files[0].name;n.style.display='';t.style.display='none'}}</script><?=x_nf_edit_assets()?><?=x_editor_assets()?><?=x_upload_assets()?></body></html>
    <?php exit;
  }

function x_github_edit_page($g,$cats=array()) {
    ?><!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>GitHub Düzenle<?=x_site_get('title')!=='' ? ' — '.x_h(x_site_get('title')) : ''?></title><style>
    :root{--bg:#0a0b0f;--surface:#111318;--border:#1e2130;--text:#8b8fa3;--text2:#d1d5e0;--green:#b71c1c;--glow:#b71c1c30;--red:var(--green);--red-bg:color-mix(in srgb,var(--green) 14%,transparent);--font:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:var(--font)}.bar{padding:14px 18px;background:var(--surface);border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center}.bar h2{margin:0;color:var(--text2);font-size:15px}.btn{padding:8px 14px;border:1px solid var(--border);border-radius:6px;color:var(--text2);text-decoration:none;background:transparent;cursor:pointer;font-size:13px}.btn-g{background:var(--green);border-color:var(--green);color:#fff}.btn-cancel{border-color:var(--border);color:var(--red);background:transparent;transition:.12s}.btn-cancel:hover{border-color:var(--red);background:var(--red-bg);color:var(--red)}.wrap{max-width:700px;margin:auto;padding:24px}.fg{display:flex;flex-direction:column;gap:6px;margin-bottom:14px}.fg label{font-size:11px;color:var(--text)}input,select{padding:11px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:6px;color:var(--text2);font-size:13px;width:100%;outline:none}input:focus,select:focus{border-color:var(--green);box-shadow:0 0 0 3px var(--glow)}select option{background:var(--inp,#0c0e14);color:var(--text2)}.file-zone{position:relative;min-height:44px;padding:12px 14px;background:var(--inp,#0c0e14);border:1px dashed var(--border);border-radius:6px;color:var(--text);font-size:12px;display:flex;align-items:center;gap:8px;cursor:pointer;transition:border-color .15s,box-shadow .15s}.file-zone:hover,.file-zone:focus-within{border-color:var(--green);box-shadow:0 0 0 3px var(--glow)}.file-zone input[type=file]{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer;padding:0}.file-zone .fzn{color:var(--text2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.form-actions{display:flex;justify-content:flex-start;align-items:center;gap:8px;margin-top:18px}.toggle-row{display:flex;align-items:center;gap:10px;padding:4px 0}.sw{position:relative;width:36px;height:20px;flex-shrink:0}.sw input{opacity:0;width:0;height:0}.sw .sl{position:absolute;inset:0;background:var(--d2,#1a1d28);border-radius:20px;cursor:pointer;transition:.15s}.sw .sl:before{content:'';position:absolute;width:14px;height:14px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.15s}.sw input:checked+.sl{background:var(--green)}.sw input:checked+.sl:before{transform:translateX(16px)}.swl{font-size:12px;color:var(--text2)}input:focus,select:focus{outline:none;border-color:var(--green);box-shadow:0 0 0 3px var(--glow)}
    .rich-editor{border:1px solid var(--border);border-radius:6px;overflow:hidden;background:var(--inp,#0c0e14)}.rich-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:4px;padding:6px;border-bottom:1px solid var(--border);background:var(--surface)}.rich-toolbar button,.rich-toolbar select,.rich-toolbar input{height:28px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:4px;color:var(--text2);font:12px var(--font);cursor:pointer;box-sizing:border-box}.rich-toolbar button{min-width:28px}.rich-toolbar button:hover,.rich-toolbar select:hover,.rich-toolbar select:focus{border-color:var(--green);color:var(--green)}.rich-toolbar .rich-size-select{flex:0 0 100px;min-width:100px;width:100px;height:30px;padding:0 24px 0 8px;overflow:visible;text-overflow:clip;white-space:nowrap;line-height:28px}.rich-toolbar input{width:32px;padding:2px}.rich-content{min-height:90px;max-height:320px;padding:10px;color:var(--text2);font-size:13px;line-height:1.6;outline:none;overflow:auto;scrollbar-color:var(--border) var(--bg);scrollbar-width:thin}.rich-content::-webkit-scrollbar{width:8px}.rich-content::-webkit-scrollbar-thumb{background:var(--border);border-radius:8px}.rich-content::-webkit-scrollbar-track{background:var(--bg)}.rich-content:empty:before{content:attr(data-placeholder);color:var(--text3);pointer-events:none}.rich-content:focus{box-shadow:inset 0 0 0 1px var(--green)}.rich-content h3{margin:8px 0;color:var(--green)}.rich-content ul{padding-left:22px}.rich-value{display:none}.toggle-row{display:flex;align-items:center;gap:12px}.toggle-row>span{font-size:12px;color:var(--hi,#fff)}.sw{position:relative;width:40px;height:22px}.sw input{opacity:0;width:0;height:0}.sw .sl{position:absolute;inset:0;background:var(--d2,#1a1d28);border-radius:22px;cursor:pointer}.sw .sl:before{content:'';position:absolute;width:16px;height:16px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.15s}.sw input:checked+.sl{background:var(--green)}.sw input:checked+.sl:before{transform:translateX(18px)}.toggle-row.php-ver-row input.php-ver-input[type=text]{width:68px;min-width:68px;max-width:68px;padding:5px 7px;background:var(--inp,#0c0e14);border:1px solid var(--border);border-radius:var(--r-sm);color:var(--hi,#fff);font-size:11px;font-family:var(--mono);box-sizing:border-box}.toggle-row.php-ver-row input.php-ver-input[type=text]:not(:disabled){border-color:var(--green)}.toggle-row.php-ver-row input.php-ver-input[type=text]:focus{outline:none;border-color:var(--green);box-shadow:0 0 0 3px var(--green-glow,var(--glow))}</style><?=x_theme_css()?></head><body><div class="bar"><h2>GitHub Bağlantısını Düzenle</h2><a class="btn btn-cancel" href="<?=x_h($_SERVER['SCRIPT_NAME'])?>?tab=github">Vazgeç</a></div><div class="wrap"><form method="POST" enctype="multipart/form-data" action="?action=github_edit&id=<?=x_h($g['id'])?>&tab=github" onsubmit="return prepareRichForm(this,'githubEditDescription')"><div class="fg"><label>İsim</label><input name="name" value="<?=x_h($g['name'])?>" required></div><div class="fg"><label>Dosya Linki <span style="text-transform:none;font-weight:400;color:var(--text3)">(GitHub raw / github.com veya kendi sitenizdeki dosya adresi)</span></label><input type="text" inputmode="url" name="url" value="<?=x_h($g['url'])?>" required></div><div class="fg"><label>Açıklama</label><?=x_rich_editor('githubEditDescription','description',(isset($g['description']) ? $g['description'] : ''),'Açıklamayı buraya yazın...')?></div><div class="fg"><label>Kategori</label><select name="category_id"><option value="">Kategorisiz</option><?php foreach ($cats as $cat): ?><option value="<?=x_h($cat['id'])?>" <?=((isset($g['category_id']) ? $g['category_id'] : ''))===$cat['id']?'selected':''?>><?=x_h($cat['name'])?></option><?php endforeach; ?></select></div><div class="fg"><div class="toggle-row"><label class="sw"><input type="checkbox" name="show_code" value="1" <?=((isset($g['show_code']) ? $g['show_code'] : true))?'checked':''?>><span class="sl"></span></label><span>Kod bilgilerini göster</span></div></div><?=x_gh_toggles($g)?><?=x_pack_field('github',x_pack_list($g),'',array('zip'=>(!isset($g['zip_on']) || $g['zip_on']),'enc'=>!empty($g['encrypted']),'php'=>(isset($g['php_version']) ? $g['php_version'] : '')))?><div class="fg"><label>Resimler (opsiyonel)</label><?=x_edit_gallery('github',$g,'image')?><div class="file-zone" id="ghefz"><?=svg('upload',14)?> <span class="fzt">Görselleri seçmek için tıklayın (birden fazla)</span><span class="fzn" style="display:none"></span><input type="file" name="image[]" multiple accept="image/*" onchange="var n=this.files&&this.files.length>1?this.files.length+' resim seçildi':(this.files&&this.files[0]?this.files[0].name:'');this.parentNode.querySelector('.fzt').style.display=n?'none':'';var z=this.parentNode.querySelector('.fzn');z.textContent=n;z.style.display=n?'inline':'none'"></div><?=x_url_input('image_url')?></div><div class="fg fw"><label>Video (opsiyonel)</label><?=x_media_videos_html('github',$g)?><?=x_video_form('gheVfz')?></div><div class="fg fw"><label>Dosyalar (opsiyonel)</label><?=x_media_files_html('github',$g)?><div class="file-zone" id="gheNf"><?=svg('upload',14)?> <span class="fzt">Dosya seçmek için tıklayın (birden fazla seçilebilir)</span><span class="fzn" style="display:none"></span><input type="file" name="nfile[]" multiple onchange="nfu(this,'gheNf')"></div><div class="nf-names"></div><?=x_nf_opts()?></div><div class="form-actions"><button class="btn btn-g" type="submit"><?=svg('check',13)?> Kaydet</button></div></form></div><script>function togglePhpVer(cb){var row=cb.closest('.php-ver-row');if(!row)return;var inp=row.querySelector('.php-ver-input');if(!inp)return;if(cb.checked){inp.disabled=false;inp.style.display='';inp.focus()}else{inp.disabled=true;inp.style.display='none';inp.value=''}}function richCmd(command,id,value){var editor=document.getElementById(id);if(!editor)return;editor.focus();if((command==='insertUnorderedList'||command==='insertOrderedList')&&window.richNormLines)window.richNormLines(editor);document.execCommand(command,false,value||null);syncRich(editor)}function syncRich(editor){var target=document.getElementById(editor.id+'Value')?document.getElementById(editor.id+'Value'):editor.dataset.target?document.querySelector('[name="'+editor.dataset.target+'"]'):document.getElementById(editor.id+'Value');if(target)target.value=editor.innerHTML}function prepareRichForm(form,editorId){var editor=document.getElementById(editorId);if(editor)syncRich(editor);return true}document.addEventListener('input',function(e){if(e.target&&e.target.classList&&e.target.classList.contains('rich-content'))syncRich(e.target)});document.querySelectorAll('.rich-content').forEach(function(e){syncRich(e)});</script><?=x_nf_edit_assets()?><?=x_editor_assets()?><?=x_upload_assets()?></body></html><?php exit;
}
